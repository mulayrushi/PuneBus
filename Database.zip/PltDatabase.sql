DROP TABLE IF EXISTS "bStopTable";
CREATE TABLE `bStopTable` (
	`stop_id`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	`stop_name_en`	TEXT NOT NULL,
	`stop_name_mr`	TEXT NOT NULL,
	`stop_area_code`	TEXT,
	`stop_description`	TEXT,
	`stop_status`	TEXT NOT NULL DEFAULT 'Active'
);
INSERT INTO "bStopTable" VALUES(1,'15 August Lodge Somwar Peth','१५ ऑगस्ट लॉज सोमवार पेठ','411011',NULL,'Active');
INSERT INTO "bStopTable" VALUES(2,'15 number Manjari Gaon Phata','१५ नं. मांजरी गाव फाटा','411028',NULL,'Active');
INSERT INTO "bStopTable" VALUES(3,'16 Number','१६ नंबर','411033',NULL,'');
INSERT INTO "bStopTable" VALUES(4,'40 aundh road','४० औंध रोड','411007',NULL,'Active');
INSERT INTO "bStopTable" VALUES(5,'512 Factory Gate','५१२ फॅक्टरी गेट','411003',NULL,'Active');
INSERT INTO "bStopTable" VALUES(6,'Aaimata Mandir','आईमाता मंदिर','411037',NULL,'Active');
INSERT INTO "bStopTable" VALUES(7,'Aanand park sindhi colony','आनंद पार्क सिंधी कॉलनी','411007',NULL,'Active');
INSERT INTO "bStopTable" VALUES(8,'A B Chowk','अ ब चौक','411002',NULL,'Active');
INSERT INTO "bStopTable" VALUES(9,'Abhi Chemicals','अभि केमिकल्स','411018',NULL,'Active');
INSERT INTO "bStopTable" VALUES(10,'Abhinav college','अभिनव कॉलेज','411030',NULL,'Active');
INSERT INTO "bStopTable" VALUES(11,'Abhinav Kala Vidyalaya','अभिनव कला विद्यालय','411030',NULL,'Active');
INSERT INTO "bStopTable" VALUES(12,'Adarshnagar Corner','आदर्श नगर कॉर्नर','411041',NULL,'Active');
INSERT INTO "bStopTable" VALUES(13,'A D Camp Chowk','ए डी कँप चौक','411042',NULL,'Active');
INSERT INTO "bStopTable" VALUES(14,'Aditya garden city','आदित्य गार्डन सिटी','411052',NULL,'Active');
INSERT INTO "bStopTable" VALUES(15,'Adlar Engineering','अदलार इंजिनीअरिंग','412205',NULL,'Active');
INSERT INTO "bStopTable" VALUES(16,'ADP hadapasar','एडीपी हडपसर','411028',NULL,'Active');
INSERT INTO "bStopTable" VALUES(17,'Agakhan palace','आगाखान पॅलेस','411006',NULL,'Active');
INSERT INTO "bStopTable" VALUES(18,'Agalambe Gaon','आगळंबे गाव','411023',NULL,'Active');
INSERT INTO "bStopTable" VALUES(19,'Agalambe Phata','आगळंबे फाटा','411023',NULL,'Active');
INSERT INTO "bStopTable" VALUES(20,'Agarwal Container','अग्रवाल कंटेनर','411041',NULL,'Active');
INSERT INTO "bStopTable" VALUES(21,'Agrawal Colony','अग्रवाल कॉलनी','411028',NULL,'Active');
INSERT INTO "bStopTable" VALUES(22,'Aher Garden','आहेर गार्डन','411033',NULL,'Active');
INSERT INTO "bStopTable" VALUES(23,'Ahilyadevi Shala','अहिल्यादेवी शाळा','411030',NULL,'Active');
INSERT INTO "bStopTable" VALUES(24,'Ahilya Society','अहिल्या सोसायटी','411006',NULL,'Active');
INSERT INTO "bStopTable" VALUES(25,'Ahire gate Phata','अहिरे गेट फाटा','411023',NULL,'Active');
INSERT INTO "bStopTable" VALUES(26,'Ahire wadi','अहिरे वाडी','411041',NULL,'Active');
INSERT INTO "bStopTable" VALUES(27,'Airport','एअरपोर्ट','411032',NULL,'Active');
INSERT INTO "bStopTable" VALUES(28,'AIT college','एआयटी कॉलेज','411015',NULL,'Active');
INSERT INTO "bStopTable" VALUES(29,'Ajanta Nagar Corner','अजंठा नगर कॉर्नर','411019',NULL,'Active');
INSERT INTO "bStopTable" VALUES(30,'Ajinkyatara','अजिंक्यतारा','411041',NULL,'Active');
INSERT INTO "bStopTable" VALUES(31,'Ajmer school','अजमेर शाळा','411018',NULL,'Active');
INSERT INTO "bStopTable" VALUES(32,'Akashwani hadapasar','आकाशवानी हडपसर','411028',NULL,'Active');
INSERT INTO "bStopTable" VALUES(33,'akate wasti','नकाते वस्ती','411017',NULL,'Active');
INSERT INTO "bStopTable" VALUES(34,'Akshay Sunshri','अक्षय सनश्री','411015',NULL,'Active');
INSERT INTO "bStopTable" VALUES(35,'Akurdi Khandoba Chowk','आकुर्डी खंडोबा चौक','411035',NULL,'Active');
INSERT INTO "bStopTable" VALUES(36,'Akurdi Police Chowky','आकुर्डी पोलिस चौकी','411035',NULL,'Active');
INSERT INTO "bStopTable" VALUES(37,'Akurdi rly stn','आकुर्डी रेल्वे स्टेशन','411044',NULL,'Active');
INSERT INTO "bStopTable" VALUES(38,'Alandi bus stand','आळंदी बस स्टॅंड','411015',NULL,'Active');
INSERT INTO "bStopTable" VALUES(39,'Alandi jakat naka','आळंदी जकात नाका','411014',NULL,'Active');
INSERT INTO "bStopTable" VALUES(40,'Alandi Phata','आळंदी फाटा','411026',NULL,'Active');
INSERT INTO "bStopTable" VALUES(41,'Alankar Police Chowki','अलंकार पोलिस चौकी','411052',NULL,'Active');
INSERT INTO "bStopTable" VALUES(42,'Alankar Talkies','अलंकार टॉकीज','411001',NULL,'Active');
INSERT INTO "bStopTable" VALUES(43,'Alear Weare Housing','अलियर वेअर हाउसींग',NULL,NULL,'');
DROP TABLE IF EXISTS "busTable";
CREATE TABLE `busTable` (
	`bus_id`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	`bus_no`	TEXT NOT NULL,
	`bus_source`	TEXT NOT NULL,
	`bus_destination`	TEXT NOT NULL,
	`days_of_week`	TEXT NOT NULL,
	`total_distance`	TEXT NOT NULL,
	`estimated_time`	TEXT NOT NULL,
	`source_stop_names`	TEXT NOT NULL,
	`destination_stop_names`	TEXT NOT NULL,
	`total_stops`	TEXT NOT NULL,
	`source_trip_time`	TEXT NOT NULL,
	`destination_trip_time`	TEXT NOT NULL,
	`bus_status`	TEXT DEFAULT 'Active'
);
INSERT INTO "busTable" VALUES(1,'1','Swargate ','Narveer Tanaji Wadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','8 KMs','25 Minutes','1	Swargate
2	Sarasbag
3	Bhikardas maruti madnir
4	Shanipar
5	A B Chowk
6	Dakshinabhimukh Maruti mandir
7	Shaniwar wada
8	PMC mangala
9	Shivaji putala pmc
10	shimala office shivajinagar
11	Shivaji nagar ST Stand
12	N T wadi','1	N T wadi
2	Shivaji nagar S T stand
3	Sancheti Hospital
4	Shivaji putala
5	PMC Mangala
6	Kasaba Police Chowky
7	Vasant talkies
8	Mandai
9	Shahu chauk
10	Gokul bhavan
11	Swargate','12','08:40
09:30
10:20
11:10
12:30
13:20
14:20
15:10
16:00
18:30
19:50
20:40
07:10
08:50
09:40
10:30
11:50
12:40
13:30
14:30
15:20
16:10
17:00
18:40
20:00
09:00
10:40
12:00
13:40
14:40
15:30
16:20
17:10
18:00
07:30
08:20
09:10
10:00
12:10
13:00
14:50
15:40
16:30
17:20
18:10
19:00
20:20
21:10
07:40
08:30
09:20
10:10
11:00
12:20
13:10
14:00
15:00
16:40
17:30
18:20
19:10
20:30
21:20','09:05
10:45
11:15
12:55
13:45
14:45
15:35
16:25
18:55
20:15
21:05
07:35
09:15
10:05
12:15
13:05
14:55
15:45
16:35
17:25
18:15
19:05
20:25
21:20
09:25
10:25
11:05
12:25
13:15
14:05
15:05
16:45
17:35
18:25
19:15
07:55
08:45
09:35
10:25
11:15
12:35
13:25
14:15
15:15
16:05
17:45
18:35
19:25
20:45
21:35
08:05
09:45
10:35
11:25
12:45
13:35
14:25
15:25
16:15
17:05
18:45
19:35
20:55
21:45','Active');
INSERT INTO "busTable" VALUES(2,'100','Manpa bhavan','Hinjewadi phase 3',' Mon, Tue, Wed, Thu, Fri, Sat, Sun','24.4 KMs','70 Minutes','1	PMC
2	PMC mangala
3	Shivaji putala pmc
4	shimala office shivajinagar
5	Masoba gate
6	Pumping station
7	Pune central
8	E square
9	Rangehills Corner
10	Rajbhavan
11	Boys batalian
12	Kasturba vasahat
13	Sindh colony gate 2
14	Bremen chauk
15	Body gate
16	Aundh gaon
17	Sangvi phata
18	Aundh chest hospital
19	Aundh post office
20	ESI Hospital
21	Rakshak chauk
22	Military Stores
23	Wakad phata
24	Vikasnagar Corner
25	Maruti Mandir Wakad
26	Kaspate Vasti
27	Wakad Chowk
28	Wakad Highway
29	Hinjewadi Gaon
30	Hinjewadi Police Station
31	Infosys company
32	Wipro company Circle
33	Infosys Phase 2
34	Power House IT Park
35	Tata Motors IT Park
36	Circle IT Park
37	Infosys Phase 3 Gawarwadi','1	Infosys Phase 3 Gawarwadi
2	Circle IT Park
3	Tata Motors IT Park
4	Power House IT Park
5	Infosys Phase 2
6	Wipro company Circle
7	Infosys company
8	Hinjewadi Police Station
9	Hinjewadi Gaon
10	Wakad Highway
11	Wakad Chowk
12	Kaspate Vasti
13	Maruti Mandir Wakad
14	Vikasnagar Corner
15	Wakad phata
16	Military Stores
17	Rakshak chauk
18	ESI Hospital
19	Aundh post office
20	Aundh chest hospital
21	Sangvi Phata
22	Aundh gaon
23	Body gate
24	Bremen chauk
25	Sindh Colony Gate2
26	Kasturba vasahat
27	Boys Batalian
28	Pune University Gate
29	Rangehills Corner
30	E Square
31	Pune central
32	Pumping station
33	Masoba gate
34	shimala office shivajinagar
35	Engineering college hostel
36	Shivaji putala
37	PMC','37','05:30
08:20
10:45
13:40
16:30
18:50
06:20
08:40
11:30
14:05
16:55
19:15
06:40
09:00
11:50
14:30
17:20
19:40
07:00
09:25
12:15
14:50
17:40
20:00
07:25
09:50
12:40
15:15
18:05
20:25
07:55
10:20
13:05
15:40
18:30
20:50','06:40
09:30
11:50
14:50
17:40
20:00
07:30
09:50
12:40
15:15
18:05
20:25
07:50
10:10
13:00
15:40
18:30
20:50
08:15
10:35
13:25
16:00
18:50
21:10
08:35
11:00
13:45
16:25
19:15
21:35
09:10
11:25
14:15
16:50
19:40
22:00','Active');
INSERT INTO "busTable" VALUES(3,'101','Kothrud depot','Kondhava','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18.2 KMs','79 Minutes','1	Somaji Khat Karkhana
2	Talab Farm
3	Mangalben company Sai service
4	Chaitanya Vidyalaya
5	Kondhva Khurd
6	Kondhava Shala
7	NIBM Road
8	Mahatma Phule wasahat
9	Lullanagar
10	Netajinagar
11	Wanvadi Bazar
12	Wanvadi Corner
13	Military Hospital Wanvadi
14	Mahatma gandhi stand
15	Golibar maidan
16	Meera society
17	S T Divisional office
18	Ghorpadi Peth Colony
19	Swargate police line
20	Swargate
21	Sarasbag
22	Madiwale colony
23	S P college
24	Maharashtra mandal
25	Sahitya parishad peru gate
26	Deccan corner sambhaji pool
27	Garware college
28	Petrol Pump Karve Road
29	Nal Stop
30	SNDT college
31	Paud phata police chauky
32	More vidyalaya
33	LIC colony
34	Anand nagar paud road
35	Jai bhavani
36	Pratik nagar
37	Vanaz Corner
38	Paramhans corner
39	Kachara depot
40	Bharti nagar
41	kothrud depot','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Sahitya Parishad Peru Gate
17	Maharashtra mandal
18	S P college
19	Madiwale colony
20	Hirabag
21	Swargate corner
22	Ghorpade peth colony
23	S T Divisional office
24	Meera society
25	Golibar maidan
26	juna pul gate
27	Mahatma gandhi stand
28	Mammadevi Chowk
29	Military Hospital Wanvadi
30	Wanvadi Corner
31	Wanvadi Bazar
32	Netajinagar
33	Lullanagar
34	Mahatma Phule Vasahat
35	N I B M Road
36	Kondhva Shala
37	Kondhava Khurd
38	Chaitanya Vidyalaya
39	Mangalben company Sai service
40	Talab Farm
41	Somaji Khat Karkhana','41','06:55
09:20
12:20
15:25
17:50
20:50
07:15
09:45
12:45
15:45
18:15
21:10
07:35
10:05
13:05
16:05
18:35
21:30
07:55
13:25
16:35
21:55
08:15
10:45
13:45
17:00
19:25
22:20
08:35
11:05
14:10
17:20
20:20
22:40
12:00','05:45
08:05
11:10
14:15
16:40
19:40
06:05
08:30
11:35
14:35
17:00
20:00
06:25
08:50
11:55
14:55
17:20
20:20
06:45
12:15
15:25
20:45
07:05
09:30
12:35
15:50
18:10
21:10
07:25
09:50
13:00
16:10
19:05
21:35
10:55','Active');
INSERT INTO "busTable" VALUES(4,'102','Kothrud Depot','Lohgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','23.6 KMs','87 Minutes','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhans nagar
5	Paramhansa Corner
6	Vanaz corner
7	Jai bhavani
8	Anand nagar paud road
9	LIC Colony Paud Road
10	More vidyalaya
11	Paudphata police chowky
12	SNDT college
13	Nal stop
14	Petrol pump karve road
15	Garware college
16	Deccan corner sambhaji pul
17	Goodluck Chowk
18	F C College
19	Dnyaneshwar paduka chauk
20	shimala office shivajinagar
21	Lokmangal
22	College of engineering pune
23	RTO wellesley road
24	Juna Bajar
25	Ambedkar bhavan
26	Sasoon hospital
27	Pune station
28	Ruby hall
29	Wadia college
30	Guruprasad bangala
31	Band garden
32	Yerwada
33	Gunjan Theature
34	White House
35	Netaji school
36	Vikrikar Karyalaya
37	Yerwada post office
38	Nagpur chawl
39	Sanjay park
40	Five nine area
41	Burmashell
42	Kalwad
43	Officers mess
44	Central school khese
45	Water tank
46	Lohoan','1	Lohoan
2	Water tank
3	Central School Khese
4	Officers Mess
5	Kalwad
6	Burmashell
7	Five nine area
8	Sanjay park
9	Nagpur Chawl
10	Yerwada post office
11	Vikrikar karyalaya
12	Netaji school
13	White House
14	Yerwada
15	Band garden
16	Guruprasad bangala
17	Jahangir Hospital
18	Alankar Talkies
19	Sadhu wasvani chauk
20	GPO
21	Collector kacheri
22	Ambedkar bhavan
23	Juna Bajar
24	RTO wellesley road
25	College of engineering pune
26	Engineering college hostel
27	Modern Highschool
28	Balgandharv sambhaji par
29	Deccan Gymkhana
30	Deccan corner sambhaji pool
31	Garware college
32	Petrol Pump Karve Road
33	Nal Stop
34	SNDT college
35	Paud phata police chauky
36	More vidyalaya
37	LIC colony
38	Anand nagar paud road
39	Jai bhavani
40	Pratik nagar
41	Vanaz Corner
42	Paramhans corner
43	Paramhans nagar
44	Kachara depot
45	Bharti nagar
46	kothrud depot','46','05:20
08:00
11:45
14:30
17:20
21:10
06:00
08:45
12:30
15:10
18:10
06:45
09:30
13:20
15:55
19:00
07:25
10:15
14:00
16:35
20:00','06:35
09:30
13:15
15:50
19:00
22:35
07:20
10:15
14:00
16:25
19:55
08:05
11:00
14:45
17:20
20:45
08:45
11:40
15:25
18:00
21:30','Active');
INSERT INTO "busTable" VALUES(5,'103','Katraj bus stand','Kothrud depot','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','61 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Madiwale colony
17	S P college
18	Maharashtra mandal
19	Sahitya parishad peru gate
20	Deccan corner sambhaji pool
21	Garware college
22	Petrol Pump Karve Road
23	Nal Stop
24	SNDT college
25	Paud phata police chauky
26	More vidyalaya
27	LIC colony
28	Anand nagar paud road
29	Jai bhavani
30	Vanaz Corner
31	Vanaz company
32	Paramhans corner
33	Kachara depot
34	Bharti nagar
35	kothrud depot','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Sahitya Parishad Peru Gate
17	Maharashtra mandal
18	S P college
19	Madiwale colony
20	Hirabag
21	Swargate corner
22	Swargate
23	Lakshi narayan theature
24	Panchami hotel
25	Bhapkar Petrol Pump City pride
26	Aranyeshwar Corner
27	Natu Bag
28	Padmavati corner
29	Vishweshwar Bank KK market
30	Balaji nagar
31	Chaitanya nagar
32	Bharti vidyapeeth gate
33	Katraj dairy Sarpodyan
34	More bag
35	Katraj bus stand','35','05:20
07:20
09:20
11:45
14:00
16:00
18:00
20:25
05:40
07:40
09:40
12:10
14:20
16:20
18:20
20:45
06:00
08:05
10:05
12:35
14:40
16:25
19:10
21:15
06:20
08:20
10:20
12:50
15:00
17:00
19:00
21:30
06:40
08:40
10:40
13:10
15:30
17:20
19:25
21:50
07:00
09:00
11:05
13:30
15:40
17:40
19:45
22:10
08:10
10:10
13:45
15:50
17:50
08:30
10:30
14:10
16:10
18:10
08:50
10:50
14:30
16:30
18:30','06:20
08:20
10:20
12:45
15:00
17:00
19:00
21:25
06:40
08:40
10:40
13:10
15:20
17:20
19:20
21:45
07:00
09:10
11:05
13:35
15:40
17:45
20:15
22:15
07:20
09:20
11:20
13:50
16:00
18:00
20:00
22:30
07:40
09:40
11:40
14:10
16:20
18:20
20:20
22:50
08:00
10:00
12:05
14:30
16:40
18:50
20:40
23:10
09:10
11:10
14:45
16:50
18:50
09:30
11:40
15:20
17:10
19:10
09:50
11:50
15:30
17:30
19:30','Active');
INSERT INTO "busTable" VALUES(6,'105','Deccan Gymkhana','Medi point','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','46 Minutes','1	Deccan Gymkhana
2	Goodluck Chowk
3	F C College
4	Dnyaneshwar Paduka chowk
5	Police Line Modern College
6	Modern Highschool
7	PMC
8	Shivaji putala pmc
9	shimala office shivajinagar
10	Masoba gate
11	Pumping station
12	Pune central
13	E square
14	Rangehills Corner
15	Pune University Gate
16	chavan nagar university road
17	Sakal nagar
18	Sindh colony
19	Baner phata
20	Sanewadi
21	Anand park sindhi colony
22	ITI parihar Chauk
23	Pinnac Society
24	Vasundara Lawns
25	Medi point','1	Medi point
2	Vasundara Lawns
3	Pinnac Society
4	ITI parihar chauk
5	Aanand park sindhi colony
6	Sanewadi
7	Baner phata
8	Sindh colony
9	Sakal nagar
10	Chavan Nagar University Road
11	Pune University Gate
12	Pune University Gate
13	Rangehills Corner
14	E Square
15	Pune central
16	Pumping station
17	Masoba gate
18	shimala office shivajinagar
19	Engineering college hostel
20	Modern Highschool
21	Balgandharv sambhaji par
22	Deccan Gymkhana','25','05:45
07:15
08:50
10:30
12:25
14:45
16:15
17:40
20:10
06:30
08:00
09:35
11:45
13:10
15:30
17:05
18:45
21:00','06:30
08:00
09:35
11:10
13:05
15:30
17:00
18:35
21:00
07:15
08:50
10:30
12:25
13:50
16:20
17:50
19:30
21:45','Active');
INSERT INTO "busTable" VALUES(7,'107','Deccan Gymkhana','Pimple gurav','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14.4 KMs','59 Minutes','1	Deccan Gymkhana
2	Goodluck Chowk
3	F C College
4	Dnyaneshwar Paduka chowk
5	Police Line Modern College
6	Modern Highschool
7	PMC
8	PMC
9	Shivaji putala pmc
10	shimala office shivajinagar
11	Masoba gate
12	Pumping station
13	Pune central
14	E square
15	Rangehills Corner
16	Yashwant Nagar
17	Ashoknagar
18	Rangehill Circle 1
19	Rangehill Circle 2
20	Rangehills H Type Quarters
21	Military Hospital
22	Khadaki station corner
23	LIC Colony Khadki
24	40 aundh road
25	Bhaurao Patil Chowk
26	Bopodi Gaon
27	Buddha Vihar
28	Shivaji putala dapodi
29	Mantri Niketan Dapodi
30	Dapodi Gaon
31	Shitaladevi Mandir
32	Raviraj Hotel
33	Ramkrushna Mangal Karyalaya
34	Pooja hospital
35	Suvarna park
36	Pimple gurav','1	Pimple gurav
2	Panyachi Taki Pimple Gurav
3	Suvarna Park
4	Pooja Hospital
5	Ramkrishna mangal karyalay
6	Raviraaj hotel
7	Shitaladevi Mandir
8	Dapodi Gaon
9	Mantri niketan Dapodi
10	Shivaji Putala Dapodi
11	Buddha Vihar
12	Bopodi Gaon
13	Bhaurao Patil Chowk
14	40 Aundh Road
15	LIC Colony Khadaki
16	Khadaki Station corner
17	Military Hospital
18	Rangehills H Type Quarters
19	Rangehill Circle 2
20	Rangehill Circle 1
21	Ashoknagar
22	Yashwant Nagar
23	Rangehills Corner
24	E Square
25	Pune central
26	Pumping station
27	Masoba gate
28	shimala office shivajinagar
29	Engineering college hostel
30	Shivaji putala
31	PMC
32	Balgandharv sambhaji par
33	Deccan Gymkhana','36','05:30
07:15
09:15
11:45
13:45
15:45
17:45
20:15
06:00
08:05
10:05
12:35
14:45
16:45
18:45
21:15','06:20
08:15
10:15
12:45
14:45
16:45
18:45
21:05
07:10
09:05
11:05
13:35
15:45
17:45
19:45
22:05','Active');
INSERT INTO "busTable" VALUES(8,'108','Sutardara','Pune station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.3 KMs','57 Minutes','1	Sutardara
2	Shivteerthnagar
3	Jai bhavani
4	Anand nagar paud road
5	LIC Colony Paud Road
6	More vidyalaya
7	Paudphata police chowky
8	SNDT college
9	Nal stop
10	Petrol pump karve road
11	Garware college
12	Deccan corner sambhaji pul
13	Narayan peth police chowky
14	Raman bag
15	Kesari Wada
16	Ramanbag
17	A B Chowk
18	Dakshinabhimukh Maruti mandir
19	Shaniwar wada
20	Kasaba Police Chowky
21	Lalmahal
22	Phadake Haud
23	RCM
24	Rastewada
25	15 August Lodge Somwar Peth
26	Ambedkar bhavan
27	Sasoon hospital
28	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Zila Parishad
6	15 August Lodge Somwar Peth
7	Rastewada
8	RCM
9	Phadake Houd
10	Lal mahala
11	Vasant talkies
12	Ramanbag
13	Kesari Wada
14	Raman bag
15	Narayan peth police chowky
16	Deccan Corner Sambhaji Pul Corner
17	Garware college
18	Petrol Pump Karve Road
19	Nal Stop
20	SNDT college
21	Paud phata police chauky
22	More vidyalaya
23	LIC colony
24	Anand nagar paud road
25	Jai bhavani
26	Shivteerthnagar
27	Sutardara','28','06:00
07:45
09:40
12:15
15:00
17:00
19:00','06:50
08:40
10:40
13:15
16:00
18:00
19:55','Active');
INSERT INTO "busTable" VALUES(9,'109','Manapa','Manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21.4 KMs','75 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Masoba gate
5	Pumping station
6	Pune central
7	E square
8	Rangehills Corner
9	Pune Vidyapeeth
10	Police head office
11	Loyala Highschool
12	NCL market
13	NCL
14	Panchwati
15	IITM
16	ARDE bus stop
17	Pashan
18	ARDE Colony
19	Ramnagar Bharat Electronics
20	Bavdhan gaon
21	Shinde Nagar
22	Bavdhan khind
23	Chandani chauk
24	Shinde Farm
25	Kothrud depot
26	Bharti nagar
27	kachra depot
28	Paramhansa Corner
29	Vanaz corner
30	Jai bhavani
31	Anand nagar paud road
32	LIC Colony Paud Road
33	More vidyalaya
34	Paudphata police chowky
35	SNDT college
36	Nal stop
37	Petrol pump karve road
38	Garware college
39	Deccan corner sambhaji pul
40	Goodluck Chowk
41	F C College
42	Dnyaneshwar Paduka chowk
43	Police Line Modern College
44	Modern Highschool
45	PMC','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Masoba gate
5	Pumping station
6	Pune central
7	E square
8	Rangehills Corner
9	Pune Vidyapeeth
10	Police head office
11	Loyala Highschool
12	NCL market
13	NCL
14	Panchwati
15	IITM
16	ARDE bus stop
17	Pashan
18	ARDE Colony
19	Ramnagar Bharat Electronics
20	Bavdhan gaon
21	Shinde Nagar
22	Bavdhan khind
23	Chandani chauk
24	Shinde Farm
25	Kothrud depot
26	Bharti nagar
27	kachra depot
28	Paramhansa Corner
29	Vanaz corner
30	Jai bhavani
31	Anand nagar paud road
32	LIC Colony Paud Road
33	More vidyalaya
34	Paudphata police chowky
35	SNDT college
36	Nal stop
37	Petrol pump karve road
38	Garware college
39	Deccan corner sambhaji pul
40	Goodluck Chowk
41	F C College
42	Dnyaneshwar Paduka chowk
43	Police Line Modern College
44	Modern Highschool
45	PMC','45','06:00
07:15
08:30
09:50
11:40
13:00
14:20
15:35
16:55
18:15
20:05
21:30
06:15
07:35
08:50
10:10
12:00
13:15
14:40
15:55
17:15
18:35
20:25
21:45
06:35
07:55
09:10
10:30
12:20
13:40
15:00
16:15
17:35
18:55
20:45
22:05
07:00
08:15
09:30
10:50
12:45
14:00
15:15
16:35
17:55
19:15
21:05
22:20','06:00
07:15
08:30
09:50
11:40
13:00
14:20
15:35
16:55
18:15
20:05
21:30
06:15
07:35
08:50
10:10
12:00
13:15
14:40
15:55
17:15
18:35
20:25
21:45
06:35
07:55
09:10
10:30
12:20
13:40
15:00
16:15
17:35
18:55
20:45
22:05
07:00
08:15
09:30
10:50
12:45
14:00
15:15
16:35
17:55
19:15
21:05
22:20','Active');
INSERT INTO "busTable" VALUES(10,'10S','Kumbare Park','Shivajinagar Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','56 Minutes','1	Kumbare Park
2	Guruganesh Nagar
3	Ashish Garden
4	Mahesh Vidyalaya
5	Sahajanand Soc
6	Gandhibhavan Andhshala
7	Dahanukar colony
8	Kothrud Stand
9	Karve putala
10	Maruti Mandir Karve Road
11	Paud phata dashbhuja mandir
12	SNDT college
13	Nal stop
14	Petrol pump karve road
15	Garware college
16	Deccan corner sambhaji pul
17	Goodluck Chowk
18	F C College
19	Dnyaneshwar Paduka chowk
20	Police Line Modern College
21	Modern Highschool
22	PMC
23	Shivaji putala pmc
24	shimala office shivajinagar
25	Shivajinagar Station','1	Shivajinagar Station
2	Engineering college hostel
3	Shivaji putala
4	PMC
5	Balgandharv sambhaji par
6	Deccan Gymkhana
7	Deccan Corner Sambhaji Pul Corner
8	Garware college
9	Petrol Pump Karve Road
10	Nal Stop
11	SNDT college
12	Paud Phata Dashabhuja Ganpati
13	Maruti mandir karve road
14	Karve putala
15	Kothrud Stand
16	Dahanukar colony
17	Andhshala
18	Sahajanand Soc
19	Mahesh vidyalaya
20	Ashish Garden
21	Guruganesh nagar
22	Kumbare Park','25','07:40
09:25
11:10
13:25
15:10
16:55','08:35
10:20
12:05
14:20
16:05
17:55','Active');
INSERT INTO "busTable" VALUES(11,'11','Marketyard','Pimple gurav','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','65 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	Godown Marketyard
4	Shivaji Putala Kalubai Mandir
5	Mafco Company
6	Bhapkar petrol pump City Pride
7	Panchami hotel
8	Laxmi Narayan Theature
9	Swargate
10	Sarasbag
11	Bhikardas maruti madnir
12	Shanipar
13	A B Chowk
14	Dakshinabhimukh Maruti mandir
15	Shaniwar wada
16	PMC mangala
17	Shivaji putala pmc
18	shimala office shivajinagar
19	Lokmangal
20	Patil Estate
21	Labour office
22	Bajaj showroom wakadewadi
23	Mariaai Gate Old Mumbai Pune Road
24	Poultry Farm Old Mumbai Pune Road
25	Mula road bhaiyawadi
26	Pachawadw
27	Surgeon quarters
28	Mathyadist Church
29	Amunition factory road
30	Suply depot
31	Khadaki bajar
32	Alegaonkar High school
33	Kirloskar Oil Engine Manaji Bag
34	Gangaram park
35	Bopodi
36	Buddha Vihar
37	Shivaji putala dapodi
38	Mantri Niketan Dapodi
39	Raviraj Hotel
40	Ramkrushna Mangal Karyalaya
41	Pooja hospital
42	Suvarna park
43	Panyachi Taki Pimple Gurav
44	Pimple gurav','1	Pimple gurav
2	Panyachi Taki Pimple Gurav
3	Suvarna Park
4	Pooja Hospital
5	Ramkrishna mangal karyalay
6	Raviraaj hotel
7	Mantri niketan Dapodi
8	Shivaji Putala Dapodi
9	Buddha Vihar
10	Bopodi
11	Gangaram park
12	Kirloskar oil engine manaji bag
13	Alegaonkar High school
14	Khadki Bazar
15	Supply Depot
16	Amunition Factory Road
17	Mathyadist Church
18	Surgeon Quarters
19	Pachwade
20	Mula bhaiyawadi
21	Poultry Farm Old Mumbai Pune Road
22	Mariaai Gate Old Mumbai Pune Road
23	Bajaj showroom
24	Labor office
25	Patil Estate
26	Engineering college hostel
27	Shivaji putala
28	PMC Mangala
29	Kasaba Police Chowky
30	Vasant talkies
31	Mandai
32	Shahu chauk
33	Gokul bhavan
34	Swargate
35	Lakshi narayan theature
36	Panchami hotel
37	Bhapkar Petrol Pump City pride
38	Mafco Company
39	Shivaji putala Kalubai mandir
40	Godown Marketyard
41	Wakhar Mahamandal Marketyard
42	Marketyard','44','05:20
07:45
10:00
12:10
14:40
17:25
20:00
05:35
07:30
10:15
12:25
14:55
17:40
20:10
05:45
08:10
10:25
12:35
15:10
17:55
20:25
06:00
07:55
10:40
12:50
15:25
18:10
20:40
06:10
08:35
10:50
13:00
15:40
18:25
20:55
06:25
08:20
11:00
13:10
15:55
18:40
21:10
06:35
09:00
11:15
13:25
16:10
18:55
21:25
06:50
08:45
11:25
13:35
16:25
19:10
21:40
07:00
09:30
11:40
13:50
16:40
19:15
21:55
07:10
09:15
11:50
14:00
16:55
19:40
22:10
07:20
09:45
12:00
14:10
17:10
19:50
22:30
06:00
08:00
10:30
06:40
08:40
11:10
07:20
09:20
11:50','06:15
08:50
11:05
13:15
15:50
18:35
21:05
06:30
08:35
11:20
13:30
16:05
18:50
21:15
06:40
09:15
11:30
13:40
16:20
19:05
21:30
06:55
09:00
11:45
13:55
16:35
19:20
21:45
07:05
09:40
11:55
14:05
16:50
19:35
22:00
07:20
09:25
12:05
14:15
17:05
19:50
22:15
07:30
10:10
12:20
14:30
17:20
20:05
22:30
07:45
09:50
12:30
14:40
17:35
20:20
22:45
07:55
10:35
12:45
14:55
17:50
20:35
23:00
08:05
10:20
12:55
15:05
18:05
20:45
23:15
08:15
10:55
13:05
15:15
18:20
20:55
23:35
07:00
09:00
11:30
07:40
09:40
12:10
08:20
10:20
12:50','Active');
INSERT INTO "busTable" VALUES(12,'110','Manapa','Manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','20 KMs','75 Minutes','1	PMC
2	Balgandharv sambhaji par
3	Deccan Gymkhana
4	Deccan corner sambhaji pool
5	Garware college
6	Petrol Pump Karve Road
7	Nal Stop
8	SNDT college
9	Paud phata police chauky
10	More vidyalaya
11	LIC colony
12	Anand nagar paud road
13	Jai bhavani
14	Vanaz Corner
15	Paramhans corner
16	Kachara depot
17	Bharti nagar
18	kothrud depot
19	Shinde farm
20	Chandani chauk
21	Bavdhan Khind
22	Shinde Nagar
23	Bavdhan goan
24	Ramnagar Bharat Electronics
25	ARDE Colony
26	Pashan
27	ARDE bus stop
28	IITM
29	Panchwati
30	NCL
31	NCL Market
32	Loyala Highschool
33	Police head office
34	Pune Vidyapeeth
35	Pune University Gate
36	Rangehills Corner
37	E Square
38	Pune central
39	Pumping station
40	Masoba gate
41	shimala office shivajinagar
42	Engineering college hostel
43	Shivaji putala
44	PMC','1	PMC
2	Balgandharv sambhaji par
3	Deccan Gymkhana
4	Deccan corner sambhaji pool
5	Garware college
6	Petrol Pump Karve Road
7	Nal Stop
8	SNDT college
9	Paud phata police chauky
10	More vidyalaya
11	LIC colony
12	Anand nagar paud road
13	Jai bhavani
14	Vanaz Corner
15	Paramhans corner
16	Kachara depot
17	Bharti nagar
18	kothrud depot
19	Shinde farm
20	Chandani chauk
21	Bavdhan Khind
22	Shinde Nagar
23	Bavdhan goan
24	Ramnagar Bharat Electronics
25	ARDE Colony
26	Pashan
27	ARDE bus stop
28	IITM
29	Panchwati
30	NCL
31	NCL Market
32	Loyala Highschool
33	Police head office
34	Pune Vidyapeeth
35	Pune University Gate
36	Rangehills Corner
37	E Square
38	Pune central
39	Pumping station
40	Masoba gate
41	shimala office shivajinagar
42	Engineering college hostel
43	Shivaji putala
44	PMC','44','06:10
07:25
08:40
10:00
10:50
12:00
14:30
15:45
17:05
18:25
20:15
21:40
06:30
07:45
09:00
10:20
12:10
13:25
14:50
16:05
17:25
18:45
20:35
21:50
06:45
08:05
09:20
10:40
12:30
13:50
15:10
16:25
17:45
19:05
20:55
22:15
07:10
08:25
09:40
11:00
12:55
14:15
15:25
16:45
18:05
19:25
21:15
22:30','06:10
07:25
08:40
10:00
10:50
12:00
14:30
15:45
17:05
18:25
20:15
21:40
06:30
07:45
09:00
10:20
12:10
13:25
14:50
16:05
17:25
18:45
20:35
21:50
06:45
08:05
09:20
10:40
12:30
13:50
15:10
16:25
17:45
19:05
20:55
22:15
07:10
08:25
09:40
11:00
12:55
14:15
15:25
16:45
18:05
19:25
21:15
22:30','Active');
INSERT INTO "busTable" VALUES(13,'111','Hadapsar gadital','Manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','64 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Golibar maidan
13	Meera society
14	S T Divisional office
15	Ghorpadi Peth Colony
16	Swargate police line
17	Sarasbag
18	Mahila Mandal
19	Dandekar pul
20	Petrol Pump Rajendranagar
21	Lokmanya nagar
22	Ganjwewadi
23	Alka talkies
24	Goodluck Chowk
25	F C College
26	Dnyaneshwar Paduka chowk
27	Police Line Modern College
28	Modern Highschool
29	PMC','1	PMC
2	Balgandharv sambhaji par
3	Deccan Gymkhana
4	Alka talkies
5	Ganjwewadi
6	Lokmanya nagar
7	Petrol pump rajendranagar
8	Dandekar pul
9	Mahila mandal
10	Hirabag
11	Swargate corner
12	Ghorpade peth colony
13	S T Divisional office
14	Meera society
15	Golibar maidan
16	juna pul gate
17	Mahatma gandhi stand
18	Race course
19	Bhauraba nala
20	Fatimanagar Municipal shala
21	Kalubai mandir
22	Ram tekadi
23	Vaidwadi
24	Gurushankar math
25	Magarpatta
26	Hadapsar gaon
27	Hadapsar gadital','29','05:20
07:20
09:30
12:10
14:30
16:30
18:40
21:20
05:35
07:35
09:45
12:25
14:45
16:45
18:55
21:35
05:50
07:50
10:00
12:40
15:00
17:00
19:10
21:50
06:05
08:05
10:15
12:55
15:15
17:15
19:25
22:05
06:20
08:20
10:30
13:10
15:30
17:30
19:40
22:20
06:35
08:35
10:45
15:45
17:45
20:00
06:50
08:50
11:30
13:40
16:00
18:00
20:20
09:00
11:10
13:20
16:15
18:15
07:05
09:15
11:55
14:05
18:25
20:40
22:40','06:20
08:25
10:35
13:15
15:30
17:35
19:45
22:25
06:35
08:40
10:50
13:30
15:45
17:50
20:00
22:40
06:50
08:55
11:05
13:45
16:00
18:05
20:15
22:55
07:05
09:10
11:20
14:00
16:15
18:20
20:30
23:10
07:20
09:25
11:35
14:15
16:30
18:35
20:45
23:25
07:35
09:40
11:50
16:45
18:50
21:05
07:50
09:55
12:35
14:45
17:00
19:05
21:25
10:05
12:15
14:25
17:15
19:20
08:10
10:20
13:00
15:05
19:30
21:45
23:35','Active');
INSERT INTO "busTable" VALUES(14,'112','Eklavya polytechnic College','Swargate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','53 Minutes','1	Eklavya polytechnic College
2	Kumbare Park
3	Guruganesh Nagar
4	Ashish Garden
5	Mahesh vidyalaya
6	Sahajanand Soc
7	Gandhibhavan Andhshala
8	Ankur Bungalow
9	Vivekanand Society
10	Sutar Dawakhana
11	Vanaz corner
12	Jai bhavani
13	Anand nagar paud road
14	LIC Colony Paud Road
15	More vidyalaya
16	Paudphata police chowky
17	SNDT college
18	Nal stop
19	Petrol pump karve road
20	Garware college
21	Deccan corner sambhaji pul
22	Sahitya Parishad Peru Gate
23	Maharashtra mandal
24	S P college
25	Madiwale colony
26	Hirabag
27	Swargate corner
28	Swargate','1	Swargate
2	Sarasbag
3	Madiwale colony
4	S P college
5	Maharashtra mandal
6	Sahitya parishad peru gate
7	Deccan Corner Sambhaji Pul Corner
8	Garware college
9	Petrol Pump Karve Road
10	Nal Stop
11	SNDT college
12	Paud phata police chauky
13	More vidyalaya
14	LIC colony
15	Anand nagar paud road
16	Jai bhavani
17	Pratik nagar
18	Vanaz Corner
19	Sutar Dawakhana
20	Vivekanand Society
21	Ankur Bungalow
22	Andhshala
23	Sahajanand Soc
24	Mahesh Vidyalaya
25	Ashish Garden
26	Guruganesh nagar
27	Kumbare Park
28	Eklavya polytechnic College','28','08:10
09:50
11:30
13:55
15:40
17:35','09:00
10:40
12:25
14:45
16:35
18:35','Active');
INSERT INTO "busTable" VALUES(15,'113','A B Chowk','Sangvi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','38 Minutes','1	A B Chauk Stand
2	Dakshinabhimukh Maruti mandir
3	Shaniwar wada
4	PMC mangala
5	PMC
6	Shivaji putala pmc
7	shimala office shivajinagar
8	Masoba gate
9	Pumping station
10	Pune central
11	E square
12	Rangehills Corner
13	Rajbhavan
14	Boys batalian
15	Kasturba vasahat
16	Sindh colony gate 2
17	Bremen chauk
18	Body gate
19	Aundh gaon
20	Sangvi phata
21	Sangvi Phata
22	Nurses Quarters
23	Ba ra gholap
24	Navi Sangvi
25	Panyachi taki sangvi
26	shitole nagar corner
27	Anand nagar
28	Sangvi goan
29	Vasantdada Putala','1	Vasantdada Putala
2	Sangvi goan
3	Anand nagar
4	shitole nagar corner
5	panyachi takai sangvi
6	Navi Sangvi
7	Bara gholap
8	Nurses Quarters
9	Sangvi Phata
10	Aundh gaon
11	Body gate
12	Bremen chauk
13	Sindh Colony Gate2
14	Kasturba vasahat
15	Boys Batalian
16	Pune University Gate
17	Rangehills Corner
18	E Square
19	Pune central
20	Pumping station
21	Masoba gate
22	shimala office shivajinagar
23	Engineering college hostel
24	Shivaji putala
25	PMC Mangala
26	Kasaba Police Chowky
27	Vasant talkies
28	A B Chauk Stand','29','05:30
14:25
08:10
05:45
14:45
05:55
14:55
07:20
06:10
15:10
06:20
15:15
06:25
15:25
06:35
15:30
22:15
06:40
15:40
22:30','06:05
07:25
08:45
10:05
12:00
13:20
15:05
16:30
18:05
20:10
21:45
08:50
10:15
11:40
13:30
14:50
16:20
17:40
19:05
06:20
07:40
09:00
10:25
12:20
13:40
15:25
16:50
18:25
20:30
22:05
06:30
07:50
09:10
10:35
12:30
13:50
15:35
17:00
18:35
20:40
22:15
08:00
09:20
10:45
12:40
14:00
15:20
16:45
18:15
06:45
08:05
09:25
10:50
12:45
14:05
15:50
17:15
18:50
20:55
22:30
06:55
08:15
09:35
11:00
12:55
14:15
15:55
17:25
19:00
21:05
22:40
07:00
08:20
09:40
11:05
13:00
14:20
16:05
17:35
19:10
21:15
22:50
07:10
08:30
09:45
11:15
13:05
14:25
16:10
17:45
19:50
21:25
22:55
07:15
08:35
09:55
11:25
13:15
14:35
16:25
17:55
19:30
21:35
23:05','Active');
INSERT INTO "busTable" VALUES(16,'113A','A B Chowk','Pimple gurav','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','50 Minutes','1	A B Chauk Stand
2	Dakshinabhimukh Maruti mandir
3	Shaniwar wada
4	PMC mangala
5	Shivaji putala pmc
6	shimala office shivajinagar
7	Masoba gate
8	Pumping station
9	Pune central
10	E square
11	Rangehills Corner
12	Pune University Gate
13	chavan nagar university road
14	Sakal nagar
15	Sindh colony
16	Baner phata
17	Sanewadi
18	Anand park sindhi colony
19	ITI parihar Chauk
20	Police workshop
21	Body gate
22	Aundh gaon
23	Sangvi phata
24	Sangvi Phata
25	Nurses Quarters
26	Ba ra gholap
27	Navi Sangvi
28	Panyachi taki sangvi
29	Panyachi taki
30	Sai chauk
31	Krishna bajar
32	Katepuram
33	New pmc school
34	Pimple gurav','1	Pimple gurav
2	New pmc school
3	Katepuram
4	Krishna bajar
5	Sai chauk
6	Panyachi taki
7	panyachi takai sangvi
8	Navi Sangvi
9	Bara gholap
10	Nurses Quarters
11	Sangvi Phata
12	Aundh gaon
13	Body gate
14	ITI parihar chauk
15	Aanand park sindhi colony
16	Sanewadi
17	Baner phata
18	Sindh colony
19	Sakal nagar
20	Chavan Nagar University Road
21	Pune University Gate
22	Pune University Gate
23	Rangehills Corner
24	E Square
25	Pune central
26	Pumping station
27	Masoba gate
28	shimala office shivajinagar
29	Engineering college hostel
30	Shivaji putala
31	PMC Mangala
32	Kasaba Police Chowky
33	Vasant talkies
34	A B Chauk Stand','34','07:30
09:15
10:55
13:15
14:40
16:25
18:20
20:30
06:30
08:00
09:40
11:25
13:45
15:20
17:05
19:00
21:05
07:05
08:35
10:15
12:00
14:15
15:50
17:35
19:35
21:40','08:20
10:05
12:20
14:00
15:30
17:20
19:40
21:20
07:15
08:50
10:35
12:50
14:30
16:10
18:00
20:20
21:55
07:45
09:20
11:05
13:20
15:00
16:40
18:30
20:50
22:30','Active');
INSERT INTO "busTable" VALUES(17,'113B','Manapa','Pimple Gurav','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','49 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Masoba gate
5	Pumping station
6	Pune central
7	E square
8	Rangehills Corner
9	Pune University Gate
10	chavan nagar university road
11	Sakal nagar
12	Sindh colony
13	Baner phata
14	Sanewadi
15	Anand park sindhi colony
16	ITI parihar Chauk
17	Police workshop
18	Body gate
19	Aundh gaon
20	Sangvi phata
21	Sangvi Phata
22	Nurses Quarters
23	Ba ra gholap
24	Navi Sangvi
25	Panyachi taki sangvi
26	Panyachi taki
27	Sai chauk
28	Krishna bajar
29	Katepuram
30	New pmc school
31	Pimple gurav','1	Pimple gurav
2	New pmc school
3	Katepuram
4	Krishna bajar
5	Sai chauk
6	Panyachi taki
7	Navi Sangvi
8	Bara gholap
9	Nurses Quarters
10	Sangvi Phata
11	Aundh gaon
12	Body gate
13	ITI parihar chauk
14	Aanand park sindhi colony
15	Sanewadi
16	Baner phata
17	Sindh colony
18	Sakal nagar
19	Chavan Nagar University Road
20	Pune University Gate
21	Pune University Gate
22	Rangehills Corner
23	E Square
24	Pune central
25	Pumping station
26	Masoba gate
27	shimala office shivajinagar
28	Engineering college hostel
29	Shivaji putala
30	PMC','31','06:00
07:30
09:10
11:20
13:00
14:30
16:10
18:10
20:30
06:50
08:20
10:00
12:05
13:50
15:30
17:20
19:20
21:40','06:40
08:15
10:30
12:10
13:45
15:20
17:10
19:35
21:15
07:30
09:10
11:20
13:00
14:40
16:20
18:20
20:45
22:20','Active');
INSERT INTO "busTable" VALUES(18,'114','Manapa','Mhalunge gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.7 KMs','45 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Masoba gate
5	Pumping station
6	Pune central
7	E square
8	Rangehills Corner
9	Pune University Gate
10	chavan nagar university road
11	Sakal nagar
12	Sindh colony
13	Baner phata
14	Green Park hotel
15	Trimurti bunglow
16	Ambedkar nagar
17	Murkute wasti
18	Baner gaon
19	Baner odha
20	Balewadi Phata
21	Kalamkar wasti
22	Samadhi mandir
23	Insureance company
24	Mhalunge corner
25	Mhalunge Gaon','1	Mhalunge Gaon
2	Mhalunge corner
3	Insurance company
4	Samadhimandir
5	Kalamkar Vasti
6	Balewadi Phata
7	Baner odha
8	Baner Gaon
9	Murkutewasti Pavitra hotel
10	Ambedkar Nagar
11	Trimurti Bungalow
12	Green park hotel
13	Baner phata
14	Sindh colony
15	Sakal nagar
16	Chavan Nagar University Road
17	Pune University Gate
18	Pune University Gate
19	Rangehills Corner
20	E Square
21	Pune central
22	Pumping station
23	Masoba gate
24	shimala office shivajinagar
25	Engineering college hostel
26	Shivaji putala
27	PMC','25','05:45
07:15
08:45
10:45
12:15
14:45
16:15
17:45
19:15
21:15
06:30
08:00
09:30
11:30
13:00
15:30
17:00
18:30
20:30
22:00','06:20
08:00
09:30
11:30
13:00
15:30
17:00
18:30
20:00
22:00
07:15
08:45
10:15
12:15
13:45
16:15
17:45
19:15
21:15
22:45','Active');
INSERT INTO "busTable" VALUES(19,'114A','Hadapsar gadital','Mhalunge Gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','24 KMs','86 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri
17	Ambedkar bhavan
18	Kumbhar wada
19	PMC
20	Shivaji putala pmc
21	shimala office shivajinagar
22	Masoba gate
23	Pumping station
24	Pune central
25	E square
26	Pune University Gate
27	chavan nagar university road
28	Sakal nagar
29	Sindh colony
30	Baner phata
31	Green Park hotel
32	Trimurti bunglow
33	Ambedkar nagar
34	Murkute wasti
35	Baner gaon
36	Baner odha
37	Balewadi Phata
38	Kalamkar wasti
39	Samadhi mandir
40	Insureance company
41	Mhalunge corner
42	Mhalunge Gaon','1	Mhalunge Gaon
2	Mhalunge corner
3	Insurance company
4	Samadhimandir
5	Kalamkar Vasti
6	Balewadi Phata
7	Baner odha
8	Baner Gaon
9	Murkutewasti Pavitra hotel
10	Ambedkar Nagar
11	Trimurti Bungalow
12	Green park hotel
13	Baner phata
14	Sindh colony
15	Sakal nagar
16	Chavan Nagar University Road
17	Pune University Gate
18	Rangehills Corner
19	E Square
20	Pune central
21	Pumping station
22	Masoba gate
23	shimala office shivajinagar
24	Sancheti Hospital
25	Shivaji putala pmc
26	PMC Mangala
27	Kumbhar Wada
28	Ambedkar bhavan
29	Sasoon hospital
30	Sadhu wasvani chauk
31	General post office
32	West end talkies
33	Bombay garaje
34	juna pul gate
35	Mahatma gandhi stand
36	Race course
37	Bhauraba nala
38	Fatimanagar Municipal shala
39	Kalubai mandir
40	Ram tekadi
41	Vaidwadi
42	Gurushankar math
43	Magarpatta
44	Hadapsar gaon
45	Hadapsar gadital','42','05:30
08:10
11:35
14:15
17:15
20:40
06:10
08:50
12:15
15:00
18:00
21:20
06:50
09:30
12:55
15:45
18:45
22:00
07:30
10:10
13:35
16:30
19:30','06:50
09:40
12:55
15:45
18:45
22:00
07:30
10:20
13:35
16:30
19:30
22:40
08:10
11:00
14:15
17:15
20:15
23:20
08:50
11:40
14:55
18:20
21:00','Active');
INSERT INTO "busTable" VALUES(20,'117','Swargate','DSK Vishwa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18.6 KMs','40 Minutes','1	Swargate
2	Parvati payatha
3	Dandekar pul
4	Pan mala Sinhgad Road
5	Jal Shuddhikarn Kendra Sinhgad Road
6	Ganesh mala
7	Vitbhatti Sinhgad Road
8	Vitthalwadi jakat naka
9	Jaydeo nagar
10	Rajaram pul
11	Vitthalwadi Mandir Hingne
12	Hingne rasta
13	Anand nagar singhgad rd
14	Manik Bag
15	Indian hum company
16	Wadgaon phata
17	Patil colony
18	Dhayari phata
19	Sanas Vidyalaya
20	Dangat wasti
21	Gar mala
22	Dhayarai gaon
23	Raykar wasti
24	Poultry farm singhgad road
25	Dhayarigaon shala
26	Chavan mala
27	DSK Vishwa','1	DSK Vishwa
2	chavan mala
3	Dhayarigaon Shala
4	Poultry Farm Sinhgadh Road
5	Raykar wasti
6	Dhayari Gaon
7	Gar mala
8	Dangat wasti
9	Sanas Vidyalaya
10	Dhayari phata
11	Patil colony
12	Wadgaon phata
13	Indican hyum company
14	Manik bag
15	Anand nagar
16	Hingne rasta
17	Vitthalwadi mandir hingne
18	RajaramPool
19	Jaydeo nagar
20	Vitthalwadi Jakat Naka
21	Vitbhatti singhgad rd
22	Ganesh mala
23	Jal shudhikaran kendra singhroad rd
24	Pan mala siinghgad road
25	Dandekar pul
26	Parvati payatha
27	Sarasbag
28	Hirabag
29	Swargate corner
30	Swargate','27','05:35
14:45
06:55
16:15
05:55
15:05
07:15
16:35
06:15
07:35
15:35
06:30
15:45
07:45
17:15
06:40
16:00
07:10
08:35
10:15
12:25
13:50
16:30
18:05
20:10
22:05
23:20
06:20
07:30
09:05
10:35
12:00
13:40
16:20
17:40
19:10
20:45
22:25
23:40
07:10
08:20
09:45
11:05
12:20
14:15
16:50
18:30
20:10
21:55
23:05
08:05
16:10
08:35
16:40','06:10
07:20
08:40
10:00
11:50
13:00
15:25
16:45
18:05
19:55
21:15
22:25
07:30
08:50
10:10
12:00
13:10
14:20
16:55
18:15
20:05
21:25
22:35
23:45
06:30
07:40
09:00
10:20
12:10
13:20
15:45
17:05
18:25
20:15
21:35
22:45
07:50
09:10
10:30
12:20
13:30
14:40
17:15
18:35
20:25
21:45
22:55
00:05
06:50
08:00
09:20
10:40
12:30
13:40
16:00
17:25
18:45
20:35
21:55
23:05
08:10
09:30
10:50
12:40
13:50
15:00
16:15
17:35
18:55
20:45
22:00
23:15
07:05
08:15
09:35
10:55
12:45
13:55
16:25
17:45
19:05
20:55
22:10
23:25
08:20
09:40
11:30
12:50
14:00
15:10
17:55
19:40
21:05
22:15
00:40
07:15
08:30
09:50
11:10
12:55
14:05
16:40
18:00
19:20
21:10
22:20
23:35
07:50
09:25
11:35
13:10
14:35
17:15
19:25
21:05
22:40
23:55
06:55
08:15
09:50
11:20
13:05
14:15
17:00
18:25
20:00
21:50
23:00
00:15
07:45
09:00
10:25
11:40
13:35
14:50
17:40
19:20
21:20
22:30
23:40
08:45
10:05
11:20
16:50
18:10
19:30
09:15
10:35
11:55
17:20
18:40
19:50','Active');
INSERT INTO "busTable" VALUES(21,'118','Swargate','Wadgaon budruk','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9.4 KMs','37 Minutes','1	Swargate
2	Parvati payatha
3	Dandekar pul
4	Pan mala Sinhgad Road
5	Jal Shuddhikarn Kendra Sinhgad Road
6	Ganesh mala
7	Vitbhatti Sinhgad Road
8	Vitthalwadi jakat naka
9	Jaydeo nagar
10	Rajaram pul
11	Vitthalwadi Mandir Hingne
12	Hingne rasta
13	Anand nagar singhgad rd
14	Manik Bag
15	Indian hum company
16	Wadgaon phata
17	Wadgaon budruk','1	Wadgaon budruk
2	Wadgaon phata
3	Indican hyum company
4	Manik bag
5	Anand nagar
6	Hingne rasta
7	Vitthalwadi mandir hingne
8	RajaramPool
9	Jaydeo nagar
10	Vitthalwadi Jakat Naka
11	Vitbhatti singhgad rd
12	Ganesh mala
13	Jal shudhikaran kendra singhroad rd
14	Pan mala siinghgad road
15	Dandekar pul
16	Parvati payatha
17	Sarasbag
18	Hirabag
19	Swargate corner
20	Swargate','17','05:45
06:55
08:05
09:20
10:40
12:20
13:45
15:00
16:20
17:30
18:35
20:30
06:00
07:15
08:25
09:35
10:55
12:35
14:00
15:15
16:30
17:45
19:00
20:45
06:15
07:25
08:35
09:50
11:10
12:50
15:30
16:45
18:00
19:15
21:00
22:20
06:25
07:45
08:50
10:00
11:20
13:00
14:30
15:45
17:10
18:20
19:40
21:15
06:45
08:00
09:10
10:25
11:40
13:20
16:35
17:50
19:10
20:20
22:00
23:05
06:10
07:30
08:40
10:10
12:00
13:10
14:45
16:05
17:20
18:50
20:00
21:30
08:15
09:25
10:35
15:50
17:00
18:10
08:30
09:40
10:50
16:00
17:20
18:30','06:20
07:30
08:40
10:00
11:45
12:55
14:25
15:40
16:55
18:05
19:50
21:00
06:35
07:50
09:00
10:10
12:00
13:10
14:40
15:55
17:10
18:25
20:05
21:20
06:50
08:00
09:15
10:30
12:15
13:25
16:10
17:25
18:40
20:20
21:35
22:55
07:05
08:20
09:25
10:40
12:25
13:35
15:05
16:25
17:45
18:55
20:40
21:50
07:20
08:35
09:45
11:00
12:45
13:55
17:15
18:30
19:45
21:25
22:35
23:35
06:50
08:05
09:25
11:20
12:35
13:45
15:25
16:45
18:05
19:25
21:00
22:10
08:50
10:00
11:10
16:25
17:35
18:50
09:05
10:15
11:30
16:40
17:55
19:00','Active');
INSERT INTO "busTable" VALUES(22,'118A','Swargate','Suncity','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7 KMs','30 Minutes','1	Swargate
2	Parvati payatha
3	Dandekar pul
4	Pan mala Sinhgad Road
5	Jal Shuddhikarn Kendra Sinhgad Road
6	Ganesh mala
7	Vitbhatti Sinhgad Road
8	Vitthalwadi jakat naka
9	Jaydeo nagar
10	Rajaram pul
11	Vitthalwadi Mandir Hingne
12	Hingne rasta
13	Anand nagar singhgad rd
14	Shivpushpak park
15	Star gardan
16	Krushna mandir
17	Suncity','1	Suncity
2	Krushna mandir
3	Star garden
4	Shivpushpak park
5	Anand nagar
6	Hingne rasta
7	Vitthalwadi mandir hingne
8	RajaramPool
9	Jaydeo nagar
10	Vitthalwadi Jakat Naka
11	Vitbhatti singhgad rd
12	Ganesh mala
13	Jal shudhikaran kendra singhroad rd
14	Pan mala siinghgad road
15	Dandekar pul
16	Parvati payatha
17	Sarasbag
18	Hirabag
19	Swargate corner
20	Swargate','17','05:50
06:50
07:50
08:50
10:20
11:20
12:20
14:20
15:20
16:20
17:50
18:50
19:50
20:50','06:20
07:20
08:15
09:20
10:50
11:50
12:50
14:50
15:50
16:50
18:20
19:20
20:20
21:20','Active');
INSERT INTO "busTable" VALUES(23,'119','Manapa bhavan','Alandi bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','23.5 KMs','63 Minutes','1	PMC
2	Modern Highschool
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Mula road bhaiyawadi
11	Pachawadw
12	Holkar Water Supply
13	Sapras post
14	Deccan college
15	Ambedkar Society
16	RTO New
17	Phulenagar
18	MES Water Works
19	Mental Hospital Corner
20	Shantinagar
21	Sathe Biscuit company
22	Vishrantwadi
23	R D colony
24	kalasgaon
25	Mhaske wasti
26	Parade ground
27	Wireless colony
28	AIT college
29	Dighigaon
30	Mitra sahakar nagar
31	Dattanagar
32	Telco godown
33	Bhosari phata
34	Moje vidyalaya
35	Sai madnir
36	Nirma company
37	Gokhale Mala Sankalpa Garden
38	Wadmukhwadi
39	Chincheche jhad
40	Charholi phata
41	Sai Lila nagar Kate Wasti
42	Moshi Phata Dehu Phata
43	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Dnyaneshwar June Nivas/Sai Mandir
10	Sai mandir
11	Moje vidyalaya
12	Bhosari phata
13	Telco godown
14	Dattanagar
15	Mitra sahkar nagar
16	Dighigaon
17	AIT college
18	Wireless colony
19	Parade ground
20	Mhaske wasti
21	Kalasgaon
22	R D colony
23	Vishrantwadi
24	Sathe Biscuit company
25	Shantinagar
26	Mental Hospital Corner
27	MES Water Works
28	Phulenagar
29	RTO New
30	Ambedkar Society
31	Deccan college
32	Sapras post
33	Holkar Water Supply
34	Pachwade
35	Mula bhaiyawadi
36	Poultry Farm Old Mumbai Pune Road
37	Mariaai Gate Old Mumbai Pune Road
38	Bajaj showroom
39	Labor office
40	Patil Estate
41	Engineering college hostel
42	Shivaji putala
43	PMC','43','07:25
10:00
12:20
14:45
17:30
19:55
05:40
07:40
10:25
12:40
15:05
17:50
20:15
05:55
07:55
10:40
12:55
15:20
18:10
20:30
06:10
08:10
10:55
13:10
15:40
18:30
20:50
23:05
06:30
08:30
11:15
13:30
15:55
18:45
21:05
06:45
08:50
11:30
13:45
16:15
19:05
21:25
07:00
09:35
11:45
14:00
16:35
19:20
21:40
07:15
09:10
12:00
14:20
16:55
19:40
22:00','06:00
08:25
11:05
13:20
15:50
18:40
21:05
06:35
08:45
11:30
13:40
16:10
19:05
21:25
06:50
09:00
11:45
13:55
16:30
19:20
21:40
07:05
09:15
12:00
14:10
16:50
19:40
22:00
07:25
09:35
12:20
14:30
17:05
19:55
22:15
07:40
09:50
12:35
14:45
17:25
20:15
22:35
07:55
10:35
12:50
15:00
17:40
20:30
22:50
08:10
10:15
13:05
15:20
18:00
20:50
23:10','Active');
INSERT INTO "busTable" VALUES(24,'11K','Katraj bus stand','Pimple gurav','Mon, Tue, Wed, Thu, Fri, Sat, Sun','20 KMs','74 Minutes','1	Katraj bus stand
2	Katraj dairy Sarpodyan
3	Bharti vidyapeeth gate
4	Chaitanya nagar
5	Balaji nagar
6	Vishweshwar Bank KK market
7	Padmavati corner
8	Natu bag
9	Aranyeshwar Corner
10	Bhapkar petrol pump City Pride
11	Panchami hotel
12	Laxmi Narayan Theature
13	Swargate
14	Sarasbag
15	Bhikardas maruti madnir
16	Shanipar
17	A B Chowk
18	Dakshinabhimukh Maruti mandir
19	Shaniwar wada
20	PMC mangala
21	Shivaji putala pmc
22	shimala office shivajinagar
23	College of engineering pune
24	Patil Estate
25	Labour office
26	Bajaj showroom wakadewadi
27	Mariaai Gate Old Mumbai Pune Road
28	Poultry Farm Old Mumbai Pune Road
29	Mula road bhaiyawadi
30	Pachawadw
31	Surgeon quarters
32	Mathyadist Church
33	Amunition factory road
34	Khadaki bajar
35	Alegaonkar High school
36	Kirloskar Oil Engine Manaji Bag
37	Gangaram park
38	Bopodi
39	Buddha Vihar
40	Shivaji putala dapodi
41	Mantri Niketan Dapodi
42	Ramkrushna Mangal Karyalaya
43	Suvarna park
44	Panyachi Taki Pimple Gurav
45	Pimple gurav','1	Pimple gurav
2	Panyachi Taki Pimple Gurav
3	Suvarna Park
4	Ramkrishna mangal karyalay
5	Mantri niketan Dapodi
6	Shivaji Putala Dapodi
7	Buddha Vihar
8	Bopodi
9	Kirloskar oil engine manaji bag
10	Alegaonkar High school
11	Khadki Bazar
12	Amunition Factory Road
13	Mathyadist Church
14	Surgeon Quarters
15	Pachwade
16	Mula bhaiyawadi
17	Poultry Farm Old Mumbai Pune Road
18	Mariaai Gate Old Mumbai Pune Road
19	Bajaj showroom
20	Labor office
21	Patil Estate
22	College of engineering pune
23	Engineering college hostel
24	Shivaji putala
25	PMC Mangala
26	Kasaba Police Chowky
27	Vasant talkies
28	Mandai
29	Shahu chauk
30	Gokul bhavan
31	Swargate
32	Lakshi narayan theature
33	Panchami hotel
34	Bhapkar Petrol Pump City pride
35	Aranyeshwar Corner
36	Natu Bag
37	Padmavati corner
38	Vishweshwar Bank KK market
39	Balaji nagar
40	Chaitanya nagar
41	Bharti vidyapeeth gate
42	Katraj dairy Sarpodyan
43	Katraj bus stand','45','07:30
09:55
13:55
16:25
08:00
10:25
14:25
16:55
08:30
10:55
14:55
17:25
09:00
11:25
15:25
17:55
09:30
11:55
15:55
18:25','08:40
11:10
15:10
17:40
09:10
11:40
15:40
18:10
09:40
12:10
16:10
19:40
10:10
12:40
16:40
19:10
10:40
13:10
17:10
19:40','Active');
INSERT INTO "busTable" VALUES(25,'11S','Deccan Gymkhana','Ghotawale phata','Mon, Tue, Wed, Thu, Fri, Sat, Sun','20 KMs','60 Minutes','1	Deccan Gymkhana
2	Deccan corner sambhaji pool
3	Garware college
4	Petrol Pump Karve Road
5	Nal Stop
6	SNDT college
7	Paud phata police chauky
8	More vidyalaya
9	LIC colony
10	Anand nagar paud road
11	Jai bhavani
12	Pratik nagar
13	Vanaz Corner
14	Paramhans corner
15	Kachara depot
16	Bharti nagar
17	kothrud depot
18	Shinde farm
19	Chandani chauk
20	Mail Dagad Kramank 8
21	Rajwade banglaow
22	Dagade wasti
23	Bhagwat wasti
24	Deshmukh wasti
25	Mariaai Mandir Bhugaon
26	Daulat Garden
27	Bhugoan
28	Chukate wasti
29	Mathalwadi
30	Tangde Bandhu Mala
31	Mail Dagad Kramank 18
32	Nerolac Paint Company
33	Bhukoom Ashram
34	Bandal farm
35	Ashram
36	Mail dagad kramank 21
37	Mail Dagad Kramank 22
38	Lavale Phata
39	ST stand pirangut
40	Vishkar India company
41	Ghotawale phata','1	Ghotawade Phata
2	Viskar India Company
3	ST stand Pirangut
4	Lavale phata
5	Mail Dagad Kramank 22
6	Mail Dagad Kramank 21
7	Ashram
8	Bandal Farm
9	Bhukoom ashram
10	Nerolac paint company
11	Mail dagad no.18
12	Tangade bandhu mala
13	Mathalwadi
14	Chutke wasti
15	Bhugaon
16	Daulat garden
17	Mariaai mandir bhugaon
18	Deshmukh wasti
19	Bhagwat wasti
20	Dagade wasti
21	Rajwade Bungalow
22	Chandani chauk
23	Shinde Farm
24	Kothrud depot
25	Bharti nagar
26	kachra depot
27	Paramhansa Corner
28	Vanaz corner
29	Jai bhavani
30	Anand nagar paud road
31	LIC Colony Paud Road
32	More vidyalaya
33	Paudphata police chowky
34	SNDT college
35	Nal stop
36	Petrol pump karve road
37	Garware college
38	Deccan corner sambhaji pul
39	Goodluck Chowk
40	Deccan Gymkhana','41','07:00
09:00
11:30
14:45
17:15
19:15','06:00
08:00
10:00
12:30
15:45
18:15
20:15','Active');
INSERT INTO "busTable" VALUES(26,'120','Manapa bhavan','Chakan ','Mon, Tue, Wed, Thu, Fri, Sat, Sun','41 KMs','91 Minutes','1	Bajaj Mhalunge
2	Suvarna Fabricators
3	MIDC Phata
4	Mhalunge Phata
5	LueMax
6	Chorex Company
7	I B P Pump
8	Pancharatna Complex
9	Kharabwadi
10	Ranubai Mala
11	Pegra gran company
12	Talegaon Phata ST Stand
13	Petrol Pump
14	Alandi Phata
15	Kuruli Gaon
16	Gaikwad wasti
17	Moshi phata chimboli phata
18	Hood company
19	Moshi goan
20	Chaudhari dhaba
21	Bankar Vasti Moshi
22	Borate wasti
23	Juna Jakat naka
24	Tan Protex
25	Wakhar Mahamandal Bhosari
26	Panjarpol
27	Sadgurunagar PCMT depot
28	Bhosari gaon
29	Century Enka Colony
30	Landewadi
31	Philips
32	MIDC Bhosari
33	Bhosari police station
34	Nashik phata
35	Kasarwadi
36	Forbes marshal stop
37	Alfa Laval Atlas Company
38	Sandwik
39	Fugewadi
40	Dapodi
41	Bopodi Jakat Naka
42	Bopodi
43	Khadaki
44	Khadaki railway station
45	Petrol Pump Khadki
46	Khadaki church stop
47	Khadaki post office
48	Raja bangalow
49	Krutrim Reshim Paidas Kendra
50	Poultry Farm Old Mumbai Pune Road
51	Mariaai Gate Old Mumbai Pune Road
52	Bajaj showroom
53	Labor office
54	Patil Estate
55	Engineering college hostel
56	Modern Highschool
57	PMC','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Bhosari police station
25	MIDC bhosari
26	Philips
27	Landewadi
28	Century Enka Colony
29	Bhosari gaon
30	Sadgurunagar PCMT depot
31	Panjarpol
32	Wakhar mahamandal bhosari
33	Tan protex
34	Juna jakat naka
35	Borate Vasti
36	Bankar wasti moshi
37	Chaudhari dhaba
38	Moshi goan
39	Hood company
40	Moshi Phata Chimbli Phata
41	Gaikwad wasti
42	Kuruli Gaon
43	Alandi Phata
44	Petrol Pump
45	Talegaon Phata ST Stand
46	Pegra gran company
47	Ranubai Mala
48	Kharabwadi
49	Pancharatna Complex
50	I B P Pump
51	Chorex Company
52	LueMax
53	Mhalunge Phata
54	MIDC Phata
55	Suvarna Fabricators
56	Bajaj Mhalunge','57','06:00
08:35
12:35
16:05
20:05
06:25
09:00
13:00
16:35
20:35
06:50
09:25
13:25
17:25
20:55
06:25
09:50
13:50
17:50
07:40
10:15
14:15
18:15
21:45
07:15
10:45
14:45
18:45
08:35
11:15
15:15
19:15
22:40
08:15
11:45
15:40
19:45','06:50
10:50
14:20
17:50
21:00
07:15
11:15
14:45
18:15
22:15
07:40
11:40
15:10
19:10
21:50
08:05
12:05
15:35
19:35
08:30
12:30
16:00
20:00
22:40
09:00
13:00
16:30
20:30
09:25
13:25
16:55
21:00
23:35
09:55
13:55
17:25
21:25','Active');
INSERT INTO "busTable" VALUES(27,'121','Bhosari','Manapa bhavan','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17.1 KMs','50 Minutes','1	Bhosari gaon
2	Century Enka Colony
3	Philips
4	MIDC Bhosari
5	Bhosari police station
6	Bhosari Police Station
7	Nashik phata
8	Kasarwadi
9	Forbes marshal stop
10	Alfa Laval Atlas Company
11	Sandwik
12	Fugewadi
13	Dapodi
14	Bopodi Jakat Naka
15	Bopodi
16	Khadaki
17	Khadaki railway station
18	Petrol Pump Khadki
19	Khadaki church stop
20	Khadaki post office
21	Raja bangalow
22	Krutrim Reshim Paidas Kendra
23	Poultry Farm Old Mumbai Pune Road
24	Mariaai Gate Old Mumbai Pune Road
25	Bajaj showroom
26	Labor office
27	Patil Estate
28	Engineering college hostel
29	Modern Highschool
30	PMC','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Bhosari Police Station
25	Bhosari police station
26	MIDC bhosari
27	Philips
28	Century Enka Colony
29	Bhosari gaon','30','05:30
07:10
08:50
11:00
12:40
14:20
16:00
17:40
19:20
21:30
05:40
07:20
09:00
11:10
12:50
14:30
16:10
17:50
19:30
21:40
05:50
07:30
09:10
11:20
13:00
14:40
16:20
18:00
19:40
21:50
06:00
07:40
09:20
11:30
13:10
14:50
16:30
18:10
19:50
22:00','06:20
08:00
09:40
11:50
13:30
15:10
16:50
18:30
20:10
22:25
06:30
08:10
09:50
12:00
13:40
15:20
17:00
18:40
20:20
22:35
06:40
08:20
10:00
12:10
13:50
15:30
17:10
18:50
20:30
22:45
06:50
08:30
10:10
12:20
14:00
15:40
17:20
19:00
20:40
22:50','Active');
INSERT INTO "busTable" VALUES(28,'121A','Bhosari','Manapa bhavan','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','51 Minutes','1	Bhosari gaon
2	Century Enka Colony
3	Landewadi
4	Philips
5	MIDC Bhosari
6	Bhosari police station
7	Nashik phata
8	Kasarwadi
9	Forbes marshal stop
10	Alfa Laval Atlas Company
11	Sandwik
12	Fugewadi
13	Dapodi
14	Bopodi Jakat Naka
15	Bopodi
16	Khadaki
17	Khadaki railway station
18	Petrol Pump Khadki
19	Khadaki church stop
20	Khadaki post office
21	Raja bangalow
22	Krutrim Reshim Paidas Kendra
23	Poultry Farm Old Mumbai Pune Road
24	Mariaai Gate Old Mumbai Pune Road
25	Bajaj showroom
26	Labor office
27	Patil Estate
28	Engineering college hostel
29	Modern Highschool
30	PMC','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Bhosari police station
25	MIDC bhosari
26	Philips
27	Landewadi
28	Century Enka Colony
29	Bhosari gaon','30','06:10
07:50
09:30
11:40
13:20
15:00
16:40
18:20
20:00
06:20
08:00
09:40
11:50
13:30
15:10
16:50
18:30
20:10
06:30
08:10
09:50
12:00
13:40
15:20
17:00
18:40
20:20
06:40
08:20
10:00
12:10
13:50
15:30
17:10
18:50
20:30
06:50
08:30
10:10
12:20
14:00
15:40
17:20
19:00
20:40
07:00
08:40
10:20
12:30
14:10
15:50
17:30
19:10
20:50
06:40
08:40
11:00
13:30
15:30
17:15
19:40
07:15
08:55
10:35
12:15
14:55
16:35
07:55
09:35
11:15
12:55
15:35
17:15','07:00
08:40
10:50
12:30
14:10
15:50
17:30
19:10
21:20
07:10
08:50
10:30
12:40
14:20
16:00
17:40
19:20
21:30
07:20
09:00
11:10
12:50
14:30
16:10
17:50
19:30
21:40
07:30
09:10
11:20
13:00
14:40
16:20
18:00
19:40
21:50
07:40
09:20
11:30
13:10
14:50
16:30
18:10
19:50
22:00
07:50
09:30
11:40
13:20
15:00
16:40
18:20
20:00
22:10
07:45
10:15
12:05
14:35
16:25
18:40
20:45
08:05
09:45
11:25
14:05
15:45
17:25
08:45
10:25
12:05
14:45
16:25
18:05','Active');
INSERT INTO "busTable" VALUES(29,'122','Manapa bhavan','Chinchwad','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18.7 KMs','59 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Deichi company
25	Vallabhnagar
26	HA Factory D Y Patil college
27	Kharalwadi
28	Pimpri chauk Bus stop
29	Finolex
30	Premier company
31	Chinchwad station
32	Lokmanya Hospital
33	Prekshagruha
34	Elpro Company
35	Chinchwad gaon','1	Chinchwad gaon
2	Elpro Company
3	Prekshagruha
4	Lokmanya Hospital
5	chinchwad station
6	Chinchwad chauk
7	Premier company
8	Finolex
9	Pimpri chauk Bus stand
10	Kharalwadi
11	H A Factory
12	Vallabhnagar
13	Deichi Company
14	Nashik phata
15	Kasarwadi
16	Forbes marshal stop
17	Alfa Laval Atlas Company
18	Sandwik
19	Fugewadi
20	Dapodi
21	Bopodi Jakat Naka
22	Bopodi
23	Khadaki
24	Khadaki railway station
25	Petrol Pump Khadki
26	Khadaki church stop
27	Khadaki post office
28	Raja bangalow
29	Krutrim Reshim Paidas Kendra
30	Poultry Farm Old Mumbai Pune Road
31	Mariaai Gate Old Mumbai Pune Road
32	Bajaj showroom
33	Labor office
34	Patil Estate
35	Engineering college hostel
36	Shivaji putala
37	PMC','35','05:30
07:25
09:55
12:00
14:10
16:10
18:40
20:45
05:40
07:40
10:15
12:15
14:25
16:25
18:55
21:00
05:55
07:50
10:25
12:25
14:35
16:36
19:05
21:10
06:10
08:05
10:40
12:40
14:50
16:50
19:20
21:25
06:25
08:20
10:55
12:55
15:05
17:05
19:35
21:40
06:40
08:35
11:10
13:10
15:20
17:20
19:50
21:55
06:55
08:50
11:25
13:25
15:35
17:35
20:05
22:10
07:05
09:30
11:35
13:35
15:45
18:15
20:15
22:20
07:15
09:10
11:45
13:45
15:55
17:55
20:25
22:35','06:25
08:25
10:55
13:00
15:10
17:10
19:40
21:45
06:40
08:40
11:15
13:15
15:25
17:25
19:55
22:00
06:50
08:50
11:25
13:25
15:35
17:35
20:05
22:10
07:05
09:05
11:40
13:40
15:50
17:50
20:20
22:25
07:10
09:20
11:55
13:55
16:05
18:05
20:35
22:40
07:35
09:35
12:10
14:10
16:20
18:20
20:50
22:55
07:50
09:50
12:25
14:25
16:35
18:35
21:05
23:10
08:00
10:30
12:35
14:35
16:45
19:15
21:15
23:20
08:10
10:10
12:45
14:45
16:55
18:55
21:25
23:30','Active');
INSERT INTO "busTable" VALUES(30,'123','Nigadi Bhakti shakti','Manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','62 Minutes','1	Bhakti shakti depot
2	Nigadi jakat naka
3	Pradhikaran Chowk
4	Bajaj auto
5	Akurdi Khandoba Chowk
6	Ruston Company
7	Kalbhor nahar bus stop
8	Mehta hospital
9	chinchwad station
10	Chinchwad chauk
11	Premier company
12	Finolex
13	Pimpri chauk Bus stand
14	Kharalwadi
15	H A Factory
16	Vallabhnagar
17	Deichi Company
18	Nashik phata
19	Kasarwadi
20	Forbes marshal stop
21	Alfa Laval Atlas Company
22	Sandwik
23	Fugewadi
24	Dapodi
25	Bopodi Jakat Naka
26	Khadaki
27	Khadaki railway station
28	Khadaki church stop
29	Khadaki post office
30	Raja bangalow
31	Krutrim Reshim Paidas Kendra
32	Poultry Farm Old Mumbai Pune Road
33	Mariaai Gate Old Mumbai Pune Road
34	Bajaj showroom
35	Labor office
36	Patil Estate
37	Engineering college hostel
38	Shivaji putala
39	PMC','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Deichi company
25	Vallabhnagar
26	HA Factory D Y Patil college
27	Kharalwadi
28	Pimpri chauk Bus stop
29	Finolex
30	Premier company
31	Chinchwad station
32	Mehta hospital
33	Kalbhor nagar bus stop
34	Rustan company
35	Akurdi khandoba chauk
36	Bajaj auto
37	Nigadi jakat naka
38	Bhakti shakti depot','39','05:35
07:35
09:40
12:15
15:55
18:00
20:40
22:45
06:00
08:00
10:35
12:40
16:20
18:25
21:05
23:10
05:20
07:20
09:55
12:05
14:30
16:35
19:10
21:15
05:30
07:30
10:05
12:15
14:40
16:45
19:20
21:25
05:45
07:45
10:20
12:30
16:10
18:45
20:50
05:55
07:55
10:30
12:40
15:05
17:10
19:45
21:50
06:10
08:10
10:45
12:55
16:20
18:25
21:00
06:20
08:20
10:55
13:05
15:30
17:35
20:10
22:15
06:45
08:45
11:20
13:30
15:45
17:50
20:25
22:30
07:10
09:10
11:45
13:55
15:55
18:00
20:35
22:40','06:35
08:35
11:10
13:20
17:00
19:35
21:40
23:45
07:00
09:30
11:35
13:45
17:25
20:00
22:05
00:15
06:20
08:25
11:00
13:05
15:30
17:35
20:15
22:20
06:30
08:35
11:10
13:15
15:40
17:45
20:25
22:30
06:45
08:50
11:25
13:30
17:10
19:45
21:55
06:55
09:00
11:35
13:40
16:05
18:10
20:50
22:55
07:10
09:15
11:50
13:55
17:20
19:25
22:05
07:20
09:25
12:00
14:05
16:30
18:35
21:15
23:20
07:45
09:50
12:25
14:30
16:45
18:50
21:30
23:35
08:10
10:15
12:50
14:55
16:55
19:00
21:40
23:45','Active');
INSERT INTO "busTable" VALUES(31,'123A','Akurdi Station','Manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','61 Minutes','1	PMC
2	PMC
3	Shivaji putala pmc
4	shimala office shivajinagar
5	Lokmangal
6	Patil Estate
7	Labour office
8	Bajaj showroom wakadewadi
9	Mariaai Gate Old Mumbai Pune Road
10	Poultry Farm Old Mumbai Pune Road
11	Krutrim reshim paidas kendra
12	Raja Bungalow
13	Khadaki post office
14	Khadki church stop
15	Khadaki railway station
16	Khadaki
17	Bopodi
18	Dapodi
19	Fugewadi
20	Sandwik
21	Alfa laval atlas company
22	Forbes marshal stop
23	Kasrawadi
24	Nashik phata
25	Deichi company
26	Vallabhnagar
27	HA Factory D Y Patil college
28	Kharalwadi
29	Pimpri chauk Bus stop
30	Finolex
31	Premier company
32	Chinchwad station
33	Mehta hospital
34	Kalbhor nagar bus stop
35	Rustan company
36	Akurdi khandoba chauk
37	Mhalasakant chauk
38	Sambhaji chauk
39	Akurdi police chauky
40	Akurdi rly stn','1	Akurdi rly stn
2	Akurdi Police Chowky
3	Sambhaji chowk
4	Mhalsakant Chowk
5	Akurdi Khandoba Chowk
6	Ruston Company
7	Kalbhor nahar bus stop
8	Mehta hospital
9	chinchwad station
10	Chinchwad chauk
11	Premier company
12	Finolex
13	Pimpri chauk Bus stand
14	Kharalwadi
15	H A Factory
16	Vallabhnagar
17	Deichi Company
18	Nashik phata
19	Kasarwadi
20	Forbes marshal stop
21	Alfa Laval Atlas Company
22	Sandwik
23	Fugewadi
24	Dapodi
25	Bopodi
26	Khadaki
27	Khadaki railway station
28	Khadaki church stop
29	Khadaki post office
30	Raja bangalow
31	Krutrim Reshim Paidas Kendra
32	Poultry Farm Old Mumbai Pune Road
33	Mariaai Gate Old Mumbai Pune Road
34	Bajaj showroom
35	Labor office
36	Patil Estate
37	Engineering college hostel
38	Modern Highschool
39	PMC','40','06:00
10:15
12:50
18:05
20:45','07:00
11:45
13:50
19:10
21:45','Active');
INSERT INTO "busTable" VALUES(32,'125','Sangvi','Vishrantwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14.1 KMs','73 Minutes','1	Vasantdada Putala
2	Sangvi goan
3	Anand nagar
4	shitole nagar corner
5	panyachi takai sangvi
6	Navi Sangvi
7	Bara gholap
8	Nurses Quarters
9	Sangvi Phata
10	Aundh gaon
11	Body gate
12	Spicer college
13	Spicer college press
14	Botanical Garden
15	40 Aundh Road
16	LIC Colony Khadaki
17	Khadaki Station corner
18	Khadaki police station
19	Factory Hospital
20	Amunition Factory Road
21	MSEB Khadki
22	512 Factory Gate
23	Shantinagar
24	Sathe Biscuit company
25	Vishrantwadi','1	Vishrantwadi
2	Sathe Biscuit company
3	Shantinagar
4	512 Factory Gate
5	MSEB Khadki
6	Amunition factory road
7	Factory Hospital
8	Khadki Police Station
9	Khadaki station corner
10	LIC Colony Khadki
11	40 aundh road
12	Botanical garden
13	Spicer College Press
14	Spicer college
15	Body gate
16	Aundh gaon
17	Sangvi phata
18	Sangvi Phata
19	Nurses Quarters
20	Ba ra gholap
21	Navi Sangvi
22	Panyachi taki sangvi
23	shitole nagar corner
24	Anand nagar
25	Sangvi goan
26	Vasantdada Putala','25','06:50
09:05
11:15
13:45
15:00
17:10
19:45
22:00','08:00
10:10
12:50
15:00
16:30
18:15
20:55
22:50','Active');
INSERT INTO "busTable" VALUES(33,'126','Mhaske wasti','Pimple nilakh','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','58 Minutes','1	Mhaske wasti
2	Kalasgaon
3	R D colony
4	Vishrantwadi
5	Sathe Biscuit company
6	Shantinagar
7	512 Factory Gate
8	MSEB Khadki
9	Khadki Bazar
10	Supply Depot
11	Amunition Factory Road
12	Factory Hospital
13	Khadki Police Station
14	Khadaki station corner
15	LIC Colony Khadki
16	40 aundh road
17	Botanical garden
18	Spicer College Press
19	Spicer college
20	Body gate
21	Aundh gaon
22	Sangvi phata
23	Aundh chest hospital
24	Aundh post office
25	ESI Hospital
26	Rakshak chauk
27	Rakshak Soc.
28	Pimple Nilakh Shala
29	Pimple Nilakh','1	Pimple Nilakh
2	Pimple Nilakh Shala
3	Rakshak Soc. Ganpati mandir
4	Rakshak chauk
5	ESI Hospital
6	Aundh post office
7	Aundh chest hospital
8	Sangvi Phata
9	Aundh gaon
10	Body gate
11	Spicer college
12	Spicer college press
13	Botanical Garden
14	40 Aundh Road
15	LIC Colony Khadaki
16	Khadaki Station corner
17	Khadaki police station
18	Factory Hospital
19	Suply depot
20	Khadaki bajar
21	MSEB Khadki
22	512 Factory Gate
23	Shantinagar
24	Sathe Biscuit company
25	Vishrantwadi
26	R D colony
27	kalasgaon
28	Mhaske wasti','29','07:25
09:15
11:15
13:35
15:25
17:15
19:15
21:40
05:40
07:30
09:25
11:55
13:45
15:35
17:30
19:25
21:50
05:55
07:45
09:35
11:35
13:55
15:45
17:40
20:05
06:05
07:55
09:45
12:10
14:05
15:55
17:50
19:45
06:15
08:05
10:00
12:20
14:15
16:05
18:00
20:25
06:30
08:20
10:15
12:40
14:30
16:20
18:15
20:40
06:40
08:30
10:30
12:55
14:40
16:30
18:30
20:55
06:50
08:40
10:40
13:05
14:50
16:40
18:40
21:05
07:00
08:50
10:50
13:15
15:00
16:50
18:50
07:10
09:00
11:00
13:25
15:10
17:00
19:00
21:25','08:20
10:15
12:40
14:30
16:20
18:15
20:40
22:35
06:40
08:30
10:55
12:45
14:40
16:30
18:30
20:55
22:45
06:50
08:40
10:35
13:00
14:50
16:40
18:40
21:05
07:00
08:50
11:15
13:10
15:05
16:50
18:50
22:15
07:10
09:00
11:30
13:20
15:10
17:00
19:00
21:25
07:25
09:15
11:45
13:35
15:25
17:15
19:15
21:40
07:35
09:30
12:00
13:45
15:35
17:30
19:30
21:50
07:45
09:40
12:10
13:55
15:45
17:40
19:45
22:00
07:55
09:50
12:20
14:05
15:55
17:50
20:20
08:05
10:00
12:30
14:15
16:05
18:00
20:00
22:25','Active');
INSERT INTO "busTable" VALUES(34,'127','Manapa bhavan','Telegaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','37.5 KMs','104 Minutes','1	PMC
2	Modern Highschool
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Deichi company
25	Vallabhnagar
26	HA Factory D Y Patil college
27	Kharalwadi
28	Pimpri chauk Bus stop
29	Finolex
30	Premier company
31	Chinchwad station
32	Mehta hospital
33	Kalbhor nagar bus stop
34	Rustan company
35	Akurdi khandoba chauk
36	Bajaj auto
37	Pradhikaran Chowk
38	Nigadi jakat naka
39	Cantonment jakat naka
40	Kohima line
41	B sub depot
42	Kendriya vidyalaya
43	Garden city
44	CISV
45	Dehu phata highway
46	Dehuroad railway staion
47	Dehuroad bajar
48	Gurudwara dehu road
49	Dehu road police station
50	Central Restaurant
51	Krushna Mandir Dehu Road
52	Mata Amardevi temple
53	Amarjai Begdewadi phata
54	Shankarwadi
55	Shelarwadi
56	Pune poultry farm
57	Somatne Phata
58	Talegaon Khind
59	Talegoan phata
60	Bhandari hospital
61	Jijamata chowk Talegaon
62	Talegaon nagar parishad
63	Paranjpe Hospital
64	Talegaon station
65	Egale Plax Petrol Pump
66	Bharat Petrol Pump
67	Samartha Vidyalaya Wadgaon Maval
68	Paisa Phand Kach Karkhana
69	Wadgaon Maval Phata','1	Wadgaon Maval Phata
2	Paisa phand kach karkhana
3	Samarth vidyalaya Wadgaon maval
4	Bharat petrol pump
5	Egale Plax Petrol Pump
6	Talegaon Station
7	Paranjape Hospital
8	Talegaon Nagarparishad
9	Jijamata chauk talegoan
10	Bhandari Hospital
11	Talegoan phata
12	Talegoan khind
13	Somatne Phata
14	Pune poultry farm
15	Shelarwadi
16	Shankarwadi
17	Amarjai begdewadi phata
18	Mata amardevi temple
19	Krishan mandir dehu road
20	Central restaurant
21	Dehu road police station
22	Gurudwara Dehu Road
23	Dehuroad Bazar
24	Dehu road railway station
25	Dehu phata highway
26	CISV
27	Garden City
28	Kendriya Vidyalaya
29	B Sub Depot
30	Kohima Line
31	Cantonment Jakat Naka
32	Nigadi jakat naka
33	Nigadi
34	Pradhikaran Chowk
35	Bajaj auto
36	Akurdi Khandoba Chowk
37	Ruston Company
38	Kalbhor nahar bus stop
39	Mehta hospital
40	chinchwad station
41	Chinchwad chauk
42	Premier company
43	Finolex
44	Pimpri chauk Bus stand
45	Kharalwadi
46	H A Factory
47	Vallabhnagar
48	Deichi Company
49	Nashik phata
50	Kasarwadi
51	Forbes marshal stop
52	Alfa Laval Atlas Company
53	Sandwik
54	Fugewadi
55	Dapodi
56	Bopodi Jakat Naka
57	Bopodi
58	Khadaki
59	Khadaki railway station
60	Khadaki church stop
61	Khadaki post office
62	Raja bangalow
63	Krutrim Reshim Paidas Kendra
64	Poultry Farm Old Mumbai Pune Road
65	Mariaai Gate Old Mumbai Pune Road
66	Bajaj showroom
67	Labor office
68	Patil Estate
69	Engineering college hostel
70	Shivaji putala
71	PMC','69','05:30
09:30
14:00
18:00
07:35
11:35
16:30
20:45','07:15
11:15
15:45
19:45
09:20
13:20
18:15
22:25','Active');
INSERT INTO "busTable" VALUES(35,'129','Pune Station','Medi Point','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','53 Minutes','1	Pune Station Depot
2	Sadhu wasvani chauk
3	Collector kacheri
4	Ambedkar bhavan
5	Juna Bajar
6	Kumbhar wada
7	PMC
8	Shivaji putala pmc
9	shimala office shivajinagar
10	Masoba gate
11	Pumping station
12	Pune central
13	E square
14	Rangehills Corner
15	Pune University Gate
16	chavan nagar university road
17	Sakal nagar
18	Sindh colony
19	Baner phata
20	Sanewadi
21	Anand park sindhi colony
22	ITI parihar Chauk
23	Pinnac Society
24	Vasundara Lawns
25	Medi point','1	Medi point
2	Vasundara Lawns
3	Pinnac Society
4	ITI parihar chauk
5	Aanand park sindhi colony
6	Sanewadi
7	Baner phata
8	Sindh colony
9	Sakal nagar
10	Chavan Nagar University Road
11	Pune University Gate
12	Pune University Gate
13	Rangehills Corner
14	E Square
15	Pune central
16	Pumping station
17	Masoba gate
18	shimala office shivajinagar
19	Engineering college hostel
20	Modern Highschool
21	PMC
22	Kumbhar Wada
23	Juna Bajar
24	Ambedkar bhavan
25	Sasoon hospital
26	Pune Station Depot','25','08:10
09:55
11:40
14:15
16:10
18:00','09:05
10:45
13:05
15:10
17:05
18:50','Active');
INSERT INTO "busTable" VALUES(36,'12S','Manapa','Ishan nagari','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','39 Minutes','1	PMC
2	Balgandharv sambhaji par
3	Deccan Gymkhana
4	Deccan Corner Sambhaji Pul Corner
5	Garware college
6	Petrol Pump Karve Road
7	Nal Stop
8	SNDT college
9	Paud Phata Dashabhuja Ganpati
10	Maruti mandir karve road
11	Karve putala
12	Kothrud Stand
13	Dahanukar colony
14	Wadache Jhad Bhairavnath Mandir
15	Karvenagar
16	Warje Jakatnaka
17	Ishanya Nagari','1	Ishanya Nagari
2	Warje jakatnaka
3	Karvenagar
4	Wadache jhad
5	Dahanukar colony
6	Kothrud Stand
7	Karve putala
8	Maruti Mandir Karve Road
9	Paud phata dashbhuja mandir
10	SNDT college
11	Nal stop
12	Petrol pump karve road
13	Garware college
14	Deccan corner sambhaji pul
15	Goodluck Chowk
16	F C College
17	Dnyaneshwar Paduka chowk
18	Police Line Modern College
19	Modern Highschool
20	PMC','17','08:05
09:35
11:05
13:20
14:50
16:20
17:50','07:20
08:50
10:20
11:50
14:05
15:35
17:05','Active');
INSERT INTO "busTable" VALUES(37,'130','Yewlewadi','Shivajinagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','16 KMs','59 Minutes','1	Zila Parishad School Yewlewadi
2	Kondhava Hospital
3	Lonkar Wasti
4	Surya Kiran Khat Karkhana
5	Smashanbhumi Kondhava
6	Hill Villa
7	Shri Shatrunjay jain temple
8	Gokulnagar Katraj
9	Sundarban
10	Sudarshan nagar Katraj
11	Rajas Soc. Corner
12	Katraj bus stand
13	More bag
14	Katraj dairy Sarpodyan
15	Bharti vidyapeeth gate
16	Chaitanya nagar
17	Balaji nagar
18	Vishweshwar Bank KK market
19	Padmavati corner
20	Natu bag
21	Aranyeshwar Corner
22	Bhapkar petrol pump City Pride
23	Panchami hotel
24	Laxmi Narayan Theature
25	Swargate
26	Sarasbag
27	Bhikardas maruti madnir
28	Shanipar
29	A B Chowk
30	Dakshinabhimukh Maruti mandir
31	Shaniwar wada
32	PMC mangala
33	Shivaji putala pmc
34	shimala office shivajinagar
35	Shivajinagar Station','1	Shivajinagar Station
2	Sancheti Hospital
3	Shivaji putala
4	PMC Mangala
5	Kasaba Police Chowky
6	Vasant talkies
7	Mandai
8	Shahu chauk
9	Gokul bhavan
10	Swargate
11	Lakshi narayan theature
12	Panchami hotel
13	Bhapkar Petrol Pump City pride
14	Aranyeshwar Corner
15	Natu Bag
16	Padmavati corner
17	Vishweshwar Bank KK market
18	Balaji nagar
19	Chaitanya nagar
20	Bharti vidyapeeth gate
21	Katraj dairy Sarpodyan
22	More bag
23	Katraj bus stand
24	Rajas Soc. Corner
25	Sudarshan nagar Katraj
26	Sundarban
27	Gokul Nagar Katraj
28	Shri Shatrunjay Jain Temple
29	Hill Villa
30	Smashanbhumi Kondhava
31	Khadi Machine
32	Surya Kiran Khat Karkhana
33	Lonkar Wasti
34	Kondhava Hospital
35	Zila Parishad School Yewlewadi','35','07:40
10:00
12:50
15:30
17:50
20:40
06:40
09:00
11:20
14:10
16:30
18:50
21:40','08:50
11:40
16:40
19:30
21:50
07:50
10:10
13:00
17:40
20:30
22:50','Active');
INSERT INTO "busTable" VALUES(38,'131','Pune Station','Wadgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','58 Minutes','1	Jayprakash Stand Pune station
2	Pune station
3	Pune station
4	Alankar Talkies
5	Jahangir Hospital
6	Ruby hall
7	Wadia college
8	Guruprasad bangala
9	Band garden
10	Yerwada
11	Neeta park
12	Gunjan Theature
13	White House
14	Netaji school
15	Vikrikar Karyalaya
16	Yerwada post office
17	Nagpur chawl
18	Guardroom gate
19	Sanjay park
20	Five nine area
21	Burmashell
22	Kalwad
23	Officers mess
24	Central school khese
25	Water tank
26	Lohoan
27	Jakat Naka Khese Ali
28	Balaji super market
29	Kirti Grapes
30	Khandave Bungalow
31	Atma Anand Dhyan Kendra
32	Shinde wasti lohgoan
33	Kakde Vasti Lohgaon
34	Lakshmi Provision Stores
35	Patil Wasti Wadgaon Shinde
36	Zila Parishad School
37	Wadgaon Shinde','1	Wadgaon Shinde
2	Zila Parishad School
3	Patil wasti Wadgoan shinde
4	Lakshmi Provision Stores
5	Kakade wasti Lohgoan
6	Shinde Wasti Lohgaon
7	Atma anand dhyan kendra
8	Khandave bangalow
9	Kirti Grapes
10	Balaji super market
11	Jakat naka khese Ali
12	Lohoan
13	Water tank
14	Central School Khese
15	Officers Mess
16	Kalwad
17	Burmashell
18	Five nine area
19	Sanjay park
20	Guardroom gate
21	Nagpur Chawl
22	Yerwada post office
23	Maharashtra Housing Corner
24	Vikrikar karyalaya
25	Netaji school
26	White House
27	Gunjan Theature
28	Neeta park
29	Yerwada
30	Band garden
31	Guruprasad bangala
32	Wadia college
33	Ruby Hall
34	Jahangir Hospital
35	Alankar Talkies
36	Sadhu wasvani chauk
37	GPO
38	Collector kacheri
39	Sasoon hospital
40	Pune station','37','05:50
07:50
14:50
19:10','06:40
08:50
15:50
20:10','Active');
INSERT INTO "busTable" VALUES(39,'132','Manapa bhavan','Shubham','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','45 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Pune station
8	Ruby hall
9	Wadia college
10	Guruprasad bangala
11	Band garden
12	Yerwada
13	wadia bangala
14	Shastri nagar
15	Agakhan palace
16	Ramwadi Jakatnaka
17	Ramwadi
18	Weikfield
19	ISL Company
20	WNC Company
21	Someshwar Mandir
22	Vitthai mangal karyalaya
23	karan Park
24	Shubham Society','1	Shubham Society
2	karan Park
3	Vitthai mangal karyalaya
4	Someshwar Mandir
5	WNC Company
6	ISL Company
7	Weikfield
8	Ramwadi
9	Ramwadi jakatnaka
10	Agakhan palace
11	Shastri nagar
12	Wadia bunglow
13	Yerwada
14	Band garden
15	Guruprasad bangala
16	Jahangir Hospital
17	Alankar Talkies
18	Sadhu wasvani chauk
19	GPO
20	Collector kacheri
21	Ambedkar bhavan
22	Juna Bajar
23	Kumbhar wada
24	PMC','24','05:45
07:15
08:45
10:45
12:15
14:30
16:00
17:30
19:30
21:00
06:10
07:40
09:10
11:10
12:40
14:55
16:25
17:55
19:55
21:20
06:30
08:00
09:30
11:30
13:00
15:00
16:45
18:15
20:15
21:40
06:55
08:25
09:55
11:55
13:25
15:40
17:10
18:40
20:40
22:00
08:35
10:15
11:45
14:00
15:30
17:00
18:30','06:30
08:00
09:30
11:30
13:00
15:15
16:45
18:15
20:15
21:40
06:55
08:25
09:55
11:55
13:25
15:40
17:10
18:40
20:40
22:05
07:15
08:45
10:15
12:15
13:45
15:55
17:30
19:00
21:00
22:25
07:40
09:10
10:40
12:40
14:10
16:25
17:55
19:25
21:25
22:50
09:20
11:00
12:30
14:45
16:15
17:45
19:15','Active');
INSERT INTO "busTable" VALUES(40,'133','Manapa','Sainathnagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','50 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Wadia college
8	Guruprasad bangala
9	Band garden
10	Yerwada
11	wadia bangala
12	Shastri nagar
13	Agakhan palace
14	Ramwadi Jakatnaka
15	Ramwadi
16	Weikfield
17	ISL Company
18	WNC Company
19	Dharmanagar 5 va Mail
20	Tata gaurdroom Kharadi phata
21	Panyachi Taki Chandannagar
22	Salunke hospital
23	Sundarbai shala
24	Sambhaji chauk Ganesh nagar
25	Karehar company
26	Raghuveer Nagar
27	Paranj company Relax hotel
28	Alear weare housing
29	Jog Engineering
30	Vishnu Udyog
31	Sainathnagar Mundhava','1	Sainathnagar Mundhva
2	Vishnu Udyog
3	Jog Engineering
4	Alear Weare Housing
5	Paranj Company Relax Hotel
6	Raghuveer nagar
7	Karehar Company
8	Sambhaji Chowk Ganesh Nagar
9	Sundarabai shala
10	Salunke Hospital
11	Tata Guardroom Kharadi Phata
12	Dharmanagar 5 va mail
13	WNC Company
14	ISL Company
15	Weikfield
16	Ramwadi
17	Ramwadi jakatnaka
18	Agakhan palace
19	Shastri nagar
20	Wadia bunglow
21	Yerwada
22	Band garden
23	Guruprasad bangala
24	Jahangir Hospital
25	Alankar Talkies
26	Sadhu wasvani chauk
27	GPO
28	Collector kacheri
29	Ambedkar bhavan
30	Juna Bajar
31	Kumbhar wada
32	PMC','31','05:30
07:00
08:35
10:40
12:25
14:15
15:45
17:45
20:00
05:45
07:15
08:50
11:00
12:40
14:30
16:10
18:00
20:20
06:00
07:30
09:05
11:15
12:55
16:20
18:10
20:30
22:05
06:10
07:40
09:15
11:25
13:05
14:55
16:35
18:25
20:45
06:20
07:50
09:25
11:35
13:15
16:45
18:35
20:55
22:35
06:30
08:00
09:35
11:45
13:25
15:20
17:00
18:50
21:10
06:40
08:00
10:15
11:55
13:35
15:30
17:10
19:35
21:20
08:10
09:50
12:00
13:40
15:20
17:00
07:55
09:30
10:55
13:05
14:35
16:05','06:15
07:45
09:25
11:30
13:15
15:05
16:50
18:40
20:50
06:30
08:00
09:40
11:50
13:30
15:20
17:05
18:55
21:10
06:45
08:15
09:55
12:05
13:45
17:15
19:05
21:20
22:55
06:55
08:25
10:05
12:15
13:55
15:45
17:30
19:20
21:35
07:05
08:35
10:15
12:25
14:05
17:40
19:30
21:45
23:25
07:15
08:45
10:25
12:35
14:15
16:10
17:55
19:45
22:00
07:25
08:55
11:05
12:45
14:25
16:20
18:05
20:30
22:10
09:00
10:40
12:50
14:30
16:10
17:50
08:40
10:15
11:40
13:50
15:20
16:50','Active');
INSERT INTO "busTable" VALUES(41,'134','Pune Station','Vidyanagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','33 Minutes','1	Collector kacheri
2	Pune station
3	Ruby hall
4	Wadia college
5	Guruprasad bangala
6	Band garden
7	Yerwada
8	Gunjan Theature
9	Netaji school
10	Vikrikar Karyalaya
11	Yerwada post office
12	Nagpur chawl
13	Sanjay park
14	Five nine area
15	Kekan gas agency
16	Medical Stores
17	Grampanchayat Tingrenagar
18	Vidyanagar Swapnaganga bangalow','1	Vidyanagar Swapnaganga bangalow
2	Grampanchayat Tingrenagar
3	Medical stores
4	Kekan ges agency
5	Five nine area
6	Sanjay park
7	Nagpur Chawl
8	Yerwada post office
9	Vikrikar karyalaya
10	Netaji school
11	White House
12	Yerwada
13	Band garden
14	Guruprasad bangala
15	Jahangir Hospital
16	Alankar Talkies
17	Sadhu wasvani chauk
18	Collector kacheri
19	Pune station','18','05:30
06:35
07:40
08:50
10:35
11:45
13:45
14:50
15:55
17:35
18:50
20:05
05:55
07:00
08:05
09:15
11:00
12:10
14:10
15:15
16:20
17:55
19:15
20:30
06:15
07:20
08:25
09:35
11:20
12:30
14:30
15:35
16:40
18:20
19:35
21:00','06:00
07:05
08:15
09:30
11:10
12:20
14:15
15:20
16:30
18:10
19:25
20:35
06:25
07:30
08:40
09:55
11:35
12:45
14:40
15:45
16:50
18:30
19:50
21:05
06:45
07:50
09:00
10:15
11:55
13:05
15:00
16:05
17:15
18:55
20:10
21:25','Active');
INSERT INTO "busTable" VALUES(42,'135','Manapa','Wade Bolhai','Mon, Tue, Wed, Thu, Fri, Sat, Sun','27 KMs','85 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Ruby hall
8	Wadia college
9	Guruprasad bangala
10	Band garden
11	Yerwada
12	wadia bangala
13	Shastri nagar
14	Agakhan palace
15	Ramwadi Jakatnaka
16	Ramwadi
17	Weikfield
18	Dharmanagar 5 va Mail
19	Tata Guardroom Kharadi Phata
20	Chandan Nagar
21	Nagarroad Phata Shriramnagar
22	NEI Company
23	Naik bungalow
24	Janakbaba Darga
25	Ramnarayan Bungalow
26	Lieson company
27	Satav High School
28	Wagholi
29	Kesanand phata
30	Pacharne wasti
31	Tikone Godown
32	S T Stand Kesnand
33	Dnyaneshwar Paduka Wade Bolhai
34	Highpeek Company
35	Kesnand
36	Dhore Vasti
37	Bagal Vasti
38	Shivneri Poultry Farm
39	Dadegaon Phata
40	Wade Bolhai','1	Wade Bolhai
2	Dadegaon Phata
3	Shivneri Poultry Farm
4	Bagal Vasti
5	Dhore Vasti
6	Kesnand
7	Highpeek Company
8	Dnyaneshwar Paduka Wade Bolhai
9	S T Stand Kesnand
10	Tikone Godown
11	Pacharne wasti
12	Kesanand phata
13	Wagholi
14	Satva high school
15	Lieson Company
16	Ramnarayan Bungalow
17	Janakbaba Darga
18	Naik Bungalow
19	NEI company
20	Nagarroad Phata Shriramnagar
21	Chandan nagar
22	Tata gaurdroom Kharadi phata
23	Dharmanagar 5 va mail
24	Weikfield
25	Ramwadi
26	Ramwadi jakatnaka
27	Agakhan palace
28	Shastri nagar
29	Wadia bunglow
30	Yerwada
31	Band garden
32	Guruprasad bangala
33	Jahangir Hospital
34	Alankar Talkies
35	Sadhu wasvani chauk
36	Collector kacheri
37	Ambedkar bhavan
38	Juna Bajar
39	Kumbhar wada
40	PMC','40','07:50
11:30
14:40
17:40
09:20
12:50
16:00
19:05','09:10
12:50
16:05
19:10
10:50
14:10
17:30
20:30','Active');
INSERT INTO "busTable" VALUES(43,'139','Hadapsar gadital','Nigadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','30 KMs','93 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri
17	Ambedkar bhavan
18	Juna Bajar
19	RTO wellesley road
20	College of engineering pune
21	Patil Estate
22	Labour office
23	Bajaj showroom wakadewadi
24	Mariaai Gate Old Mumbai Pune Road
25	Poultry Farm Old Mumbai Pune Road
26	Krutrim reshim paidas kendra
27	Raja Bungalow
28	Khadaki post office
29	Khadki church stop
30	Khadaki railway station
31	Khadaki
32	Bopodi
33	Dapodi
34	Fugewadi
35	Sandwik
36	Alfa laval atlas company
37	Forbes marshal stop
38	Kasrawadi
39	Deichi company
40	Vallabhnagar
41	HA Factory D Y Patil college
42	Kharalwadi
43	Pimpri chauk Bus stop
44	Finolex
45	Premier company
46	Chinchwad station
47	Mehta hospital
48	Kalbhor nagar bus stop
49	Rustan company
50	Akurdi khandoba chauk
51	Bajaj auto
52	Nigadi jakat naka','1	Nigadi jakat naka
2	Pradhikaran Chowk
3	Bajaj auto
4	Akurdi Khandoba Chowk
5	Ruston Company
6	Kalbhor nahar bus stop
7	Mehta hospital
8	chinchwad station
9	Chinchwad chauk
10	Premier company
11	Finolex
12	Pimpri chauk Bus stand
13	Kharalwadi
14	H A Factory
15	Vallabhnagar
16	Deichi Company
17	Nashik phata
18	Kasarwadi
19	Forbes marshal stop
20	Alfa Laval Atlas Company
21	Sandwik
22	Fugewadi
23	Dapodi
24	Bopodi
25	Khadaki
26	Khadaki railway station
27	Khadaki church stop
28	Khadaki post office
29	Raja bangalow
30	Krutrim Reshim Paidas Kendra
31	Poultry Farm Old Mumbai Pune Road
32	Mariaai Gate Old Mumbai Pune Road
33	Bajaj showroom
34	Labor office
35	Patil Estate
36	College of engineering pune
37	RTO wellesley road
38	Juna Bajar
39	Ambedkar bhavan
40	Sadhu wasvani chauk
41	General post office
42	West end talkies
43	Bombay garaje
44	juna pul gate
45	Mahatma gandhi stand
46	Race course
47	Bhauraba nala
48	Fatimanagar Municipal shala
49	Kalubai mandir
50	Ram tekadi
51	Vaidwadi
52	Gurushankar math
53	Magarpatta
54	Hadapsar gaon
55	Hadapsar gadital','52','05:30
08:20
11:40
14:30
18:30
05:40
08:30
11:50
14:45
18:45
05:50
08:40
12:00
15:00
19:00
06:00
08:50
12:10
15:15
19:15
06:10
09:00
12:20
15:30
19:30
06:20
09:10
12:30
15:45
19:45
06:30
09:20
12:40
16:00
20:00
06:40
09:30
12:50
16:15
20:15','06:50
09:45
13:05
16:15
20:15
07:00
09:55
13:15
16:30
20:30
07:10
10:05
13:25
16:45
20:45
07:20
10:15
13:35
17:00
21:00
07:30
10:25
13:45
17:15
21:20
07:40
10:35
13:55
17:30
21:40
07:50
11:15
14:05
17:45
22:05
08:00
10:55
14:15
18:00
22:30','Active');
INSERT INTO "busTable" VALUES(44,'139A','Nigadi','Hadapsar gadital','Mon, Tue, Wed, Thu, Fri, Sat, Sun','30 KMs','97 Minutes','1	Bhakti shakti depot
2	Nigadi jakat naka
3	Pradhikaran Chowk
4	Bajaj auto
5	Akurdi Khandoba Chowk
6	Ruston Company
7	Kalbhor nahar bus stop
8	Mehta hospital
9	chinchwad station
10	Chinchwad chauk
11	Premier company
12	Finolex
13	Pimpri chauk Bus stand
14	Kharalwadi
15	H A Factory
16	Vallabhnagar
17	Deichi Company
18	Nashik phata
19	Kasarwadi
20	Forbes marshal stop
21	Alfa Laval Atlas Company
22	Sandwik
23	Fugewadi
24	Dapodi
25	Bopodi Jakat Naka
26	Bopodi
27	Khadaki
28	Khadaki railway station
29	Khadaki church stop
30	Khadaki post office
31	Raja bangalow
32	Krutrim Reshim Paidas Kendra
33	Poultry Farm Old Mumbai Pune Road
34	Mariaai Gate Old Mumbai Pune Road
35	Bajaj showroom
36	Labor office
37	Patil Estate
38	College of engineering pune
39	RTO wellesley road
40	Juna Bajar
41	Ambedkar bhavan
42	Central building
43	Sadhu wasvani chauk
44	General post office
45	West end talkies
46	Bombay garaje
47	juna pul gate
48	Mahatma gandhi stand
49	Race course
50	Bhauraba nala
51	Fatimanagar Municipal shala
52	Kalubai mandir
53	Ram tekadi
54	Vaidwadi
55	Gurushankar math
56	Magarpatta
57	Hadapsar gaon
58	Hadapsar gadital','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri
17	Ambedkar bhavan
18	Juna Bajar
19	RTO wellesley road
20	College of engineering pune
21	Patil Estate
22	Labour office
23	Bajaj showroom wakadewadi
24	Mariaai Gate Old Mumbai Pune Road
25	Poultry Farm Old Mumbai Pune Road
26	Krutrim reshim paidas kendra
27	Raja Bungalow
28	Khadaki post office
29	Khadki church stop
30	Khadaki railway station
31	Khadaki
32	Bopodi
33	Dapodi
34	Fugewadi
35	Sandwik
36	Alfa laval atlas company
37	Forbes marshal stop
38	Kasrawadi
39	Nashik phata
40	Deichi company
41	Vallabhnagar
42	HA Factory D Y Patil college
43	Kharalwadi
44	Pimpri chauk Bus stop
45	Finolex
46	Premier company
47	Chinchwad station
48	Mehta hospital
49	Kalbhor nagar bus stop
50	Rustan company
51	Akurdi khandoba chauk
52	Bajaj auto
53	Nigadi jakat naka
54	Bhakti shakti depot','58','05:25
08:10
11:35
14:40
18:15
08:20
11:45
15:00
18:30
05:50
08:35
12:00
15:10
18:45
06:05
08:50
12:15
15:20
19:00
06:15
09:05
12:30
15:30
19:15
06:25
09:20
12:45
15:45
19:30
06:15
09:30
12:55
15:55
19:45','06:50
09:40
13:00
16:30
20:30
09:50
13:10
16:45
20:45
07:15
10:05
13:25
17:00
21:00
07:30
10:20
13:40
17:15
21:20
07:45
10:35
13:55
17:30
21:40
08:00
11:20
14:10
17:45
22:05
08:10
11:00
14:20
18:00
22:30','Active');
INSERT INTO "busTable" VALUES(45,'13L','Upper Depot','Shivajinagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','42 Minutes','1	Rajiv Gandhi Nagar Upper Depot
2	Upper Indiranagar
3	Chintamani Nagar
4	Lower Indiranagar
5	Bibwewadi
6	Kothari Corner
7	Vasant Bag
8	Pushp Mangal karyalaya
9	Bhapkar petrol pump City Pride
10	Panchami hotel
11	Laxmi Narayan Theature
12	Swargate
13	Sarasbag
14	Bhikardas maruti madnir
15	Shanipar
16	A B Chowk
17	Dakshinabhimukh Maruti mandir
18	Shaniwar wada
19	PMC mangala
20	Shivaji putala pmc
21	shimala office shivajinagar
22	Shivajinagar Station','1	Shivajinagar Station
2	Engineering college hostel
3	Shivaji putala
4	PMC Mangala
5	Kasaba Police Chowky
6	Vasant talkies
7	Mandai
8	Shahu chauk
9	Gokul bhavan
10	Swargate
11	Lakshi narayan theature
12	Panchami hotel
13	Bhapkar Petrol Pump City pride
14	Pushp Mangal karyalaya
15	Vasant Bag
16	Kothari Corner
17	Bibwewadi
18	Lower Indiranagar
19	Chintamani Nagar
20	Upper Indiranagar
21	Rajiv Gandhi Nagar Upper Depot','22','05:55
07:15
08:35
09:55
11:45
13:00
14:25
15:55
17:25
19:25
06:10
07:30
08:50
10:10
12:00
13:15
14:40
16:10
17:40
19:40
06:25
07:55
09:25
11:25
12:55
14:25
15:55
17:25
19:25
20:55
06:40
08:00
09:20
10:40
12:30
13:45
15:10
16:40
18:10
20:10
07:00
08:15
09:40
11:00
12:50
14:00
15:25
16:55
18:25
20:25','06:35
07:55
09:15
10:35
12:25
13:40
15:05
16:35
18:05
20:10
06:50
08:10
09:30
10:50
12:40
13:55
15:25
16:55
18:25
20:25
07:10
08:40
10:10
12:10
13:40
15:10
16:40
18:10
20:10
21:40
07:20
08:35
10:00
11:20
13:10
14:25
15:55
17:25
18:55
20:55
07:40
08:55
10:20
11:40
13:25
14:40
16:10
17:40
19:10
21:10','Active');
INSERT INTO "busTable" VALUES(46,'13S','Nigadi','Akurdi rly stn','Mon, Tue, Wed, Thu, Fri, Sat, Sun','6.2 KMs','25 Minutes','1	Nigadi
2	Nigadi jakat naka
3	Bhakti shakti depot
4	Transport nagar
5	Appu Ghar
6	Mukbadhir Shala
7	Big India
8	Sindhunagar Corner
9	Geetabhavan
10	Ashoka
11	Mhalsakant Chowk
12	Ganganagar
13	Giriraj Corner
14	Prachi
15	Akurdi rly stn','1	Akurdi rly stn
2	Akurdi Police Chowky
3	Sambhaji chowk
4	Prachi
5	Giriraj corner
6	Ganganagar
7	Mhalasakant chauk
8	Ashoka
9	Geetabhavan
10	Sindhunagar corner
11	Big India
12	Mukbadhir shala
13	Appu Ghar
14	Transport Nagari
15	Nigadi jakat naka
16	Pradhikaran Chowk
17	Nigadi','15','05:45
06:35
07:25
08:15
09:05
09:55
11:15
12:05
12:55
14:00
14:50
15:40
16:30
17:20
18:10
19:05
19:55
21:15
06:00
06:50
07:40
08:30
09:20
10:10
11:30
12:20
13:10
14:15
15:05
15:55
16:45
17:35
18:25
19:15
20:05
21:25
06:20
07:10
08:00
08:50
09:40
10:20
11:50
12:40
13:30
14:35
15:25
16:15
17:05
17:55
18:45
19:35
20:25
21:45','06:10
07:00
07:50
08:40
09:30
10:20
11:40
12:30
13:20
14:25
15:15
16:05
16:55
17:45
18:40
19:30
20:50
21:40
06:25
07:15
08:05
08:55
09:45
10:35
11:55
12:25
13:55
14:40
15:30
16:20
17:10
18:00
18:50
19:40
21:00
21:50
06:45
07:35
08:25
09:15
10:05
10:55
12:15
13:05
13:55
15:00
15:50
16:40
17:30
18:20
19:10
20:00
21:20
22:10','Active');
INSERT INTO "busTable" VALUES(47,'140','Upper Depot','Pune station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','45 Minutes','1	Rajiv Gandhi Nagar Upper Depot
2	Upper Indiranagar
3	Chintamani Nagar
4	Lower Indiranagar
5	Bibwewadi
6	Kothari Corner
7	Vasant Bag
8	Ganga Dham
9	Marketyard
10	Wakhar Mahamandal Marketyard
11	P and T colony
12	Canol Jhopadpatti
13	Apsara Talkies
14	Ghorpade peth colony
15	Lakud Bajar
16	Sonwane hospital
17	Ramoshi gate
18	Nana peth
19	A D camp chauk
20	Power house
21	KEM hospital
22	Ambedkar bhavan
23	Central building','1	Central building
2	Pune station
3	Sadhu wasvani chauk
4	GPO
5	Zila Parishad
6	KEM hospital
7	Power house
8	A D camp chauk
9	Nana peth
10	Ramoshi gate
11	Sonwane hospital
12	Lakud Bajar
13	Ghorpadi Peth Colony
14	Apsara Talkies
15	Canol Jhopadpatti
16	P and T colony
17	Wakhar Mahamandal Marketyard
18	Marketyard
19	Ganga Dham
20	Vasant Bag
21	Kothari Corner
22	Bibwewadi
23	Lower Indiranagar
24	Chintamani Nagar
25	Upper Indiranagar
26	Rajiv Gandhi Nagar Upper Depot','23','05:30
07:00
08:30
10:00
12:00
13:30
15:00
16:30
18:00
20:00
05:40
07:10
08:40
10:10
12:10
13:40
15:10
16:40
18:10
20:10
05:50
07:20
08:50
10:20
12:20
13:50
15:20
16:50
18:20
20:20
06:00
07:30
09:00
10:30
12:30
14:00
15:30
17:00
18:30
20:30
06:10
07:40
09:10
10:40
12:40
14:10
15:40
17:10
18:40
20:40
06:20
07:50
09:20
10:50
12:50
14:20
15:50
17:20
18:50
20:50
06:30
08:00
09:30
11:00
13:00
14:30
16:00
17:30
19:00
21:00
06:40
08:10
09:40
11:10
13:10
14:40
16:10
17:40
19:10
21:10
06:50
08:20
09:50
11:20
13:20
14:50
16:20
17:50
19:20
21:20','06:15
07:45
09:15
10:45
12:45
14:15
15:45
17:15
18:45
20:40
06:25
07:55
09:25
10:55
12:55
14:25
15:55
17:25
18:55
20:55
06:35
08:05
09:35
11:05
13:05
14:35
16:05
17:35
19:05
21:05
06:45
08:15
09:45
11:15
13:15
14:45
16:15
17:45
19:15
21:15
06:55
08:25
09:55
11:25
13:25
14:55
16:25
17:55
19:25
21:25
07:05
08:35
10:05
11:35
13:35
15:05
16:35
18:05
19:35
21:35
07:15
08:45
10:15
11:45
13:45
15:15
16:45
18:15
19:45
21:45
07:25
08:55
10:25
11:55
13:55
15:25
16:55
18:25
19:55
21:55
07:35
09:05
10:35
12:05
14:05
15:35
17:05
18:35
20:05
22:05','Active');
INSERT INTO "busTable" VALUES(48,'141','Khandoba mandir','Pune station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','49 Minutes','1	Khandoba Mandir
2	Khandoba Mandir Corner
3	Sukhsagar Nagar
4	Somanagar Society
5	Rajiv Gandhi Nagar Upper Depot
6	Kakde Vasti
7	Oswal Estate
8	Aaimata Mandir
9	Ganga Dham
10	Marketyard
11	Wakhar Mahamandal Marketyard
12	P and T colony
13	Canol Jhopadpatti
14	Apsara Talkies
15	Ghorpade peth colony
16	Lakud Bajar
17	Sonwane hospital
18	Ramoshi gate
19	Nana peth
20	A D camp chauk
21	Power house
22	KEM hospital
23	Ambedkar bhavan
24	Sasoon hospital
25	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Zila Parishad
5	KEM hospital
6	Power house
7	A D camp chauk
8	Nana peth
9	Ramoshi gate
10	Sonwane hospital
11	Lakud Bajar
12	Ghorpadi Peth Colony
13	Apsara Talkies
14	Canol Jhopadpatti
15	P and T colony
16	Wakhar Mahamandal Marketyard
17	Marketyard
18	Ganga Dham
19	Aaimata Mandir
20	Oswal Estate
21	Kakde Vasti
22	Rajiv Gandhi Nagar Upper Depot
23	Somanagar Society
24	Sukhsagar Nagar
25	Khandoba Mandir Corner
26	Khandoba Mandir','25','06:00
07:30
09:10
10:50
13:00
14:40
16:20
18:30
20:10
06:45
08:20
10:00
11:40
13:50
15:30
17:10
19:20
21:00','06:40
08:20
10:00
12:10
13:50
15:30
17:40
19:20
21:00
07:30
09:10
10:50
13:00
14:40
16:20
18:30
20:10
21:50','Active');
INSERT INTO "busTable" VALUES(49,'143','Galinde path','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11.3 KMs','60 Minutes','1	Warje jakatnaka
2	Karvenagar
3	Wadache jhad
4	Sahvas Soc
5	Shriman Society
6	Vitthal Mandir Karvenagar
7	Madhusanchay Society
8	Nav Sahyadri Sabhagruha
9	Alankar Police Chowki
10	Ganesh Nagar
11	Prasanna Bungalow
12	Karnataka High school
13	Bhim Jyoti Soc.
14	Date Engineering
15	Mehandale Guarage
16	Mahadeo mandir
17	Dattawadi pul
18	Lokmanya nagar
19	Ganjwewadi
20	Alka talkies
21	Narayan peth police chowky
22	Kesari Wada
23	Ramanbag
24	A B Chowk
25	Dakshinabhimukh Maruti mandir
26	Shaniwar wada
27	Kasaba Police Chowky
28	Lalmahal
29	Phadake Haud
30	RCM
31	Rastewada
32	15 August Lodge Somwar Peth
33	Ambedkar bhavan
34	Sasoon hospital
35	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Zila Parishad
6	15 August Lodge Somwar Peth
7	Rastewada
8	RCM
9	Phadake Houd
10	Lal mahala
11	Vasant talkies
12	A B Chauk Stand
13	Ramanbag
14	Kesari Wada
15	Narayan peth police chowky
16	Alka talkies
17	Ganjwewadi
18	Lokmanya nagar
19	Dattawadi pul
20	Mahadeo mandir
21	Mehendale garage
22	Date Engineering
23	Bhim Jyoti Soc.
24	Karnataka High school
25	Prasanna Bungalow
26	Ganesh Nagar
27	Alankar Police Chowki
28	Nav Sahyadri Sabhagruha
29	Madhusanchay Society
30	Vitthal Mandir Karvenagar
31	Shriman Society
32	Sahvas Soc
33	Wadache Jhad Bhairavnath Mandir
34	Karvenagar
35	Warje Jakatnaka','35','05:30
07:30
09:30
12:05
14:30
16:30
18:35
21:10
07:45
09:45
11:45
14:50
16:50
18:50
06:00
08:00
10:00
12:30
15:05
17:00
19:10
21:45
08:15
10:20
12:55
15:20
17:20
19:25
06:40
08:30
10:40
13:15
15:40
17:35
19:45
22:20
08:50
11:00
13:30
16:00
17:55
20:05
22:40
07:15
09:15
11:20
13:50
16:15
18:15
20:50
22:50','06:30
08:30
10:30
13:05
15:30
17:30
19:35
22:10
08:45
10:45
12:45
15:50
17:50
19:50
07:00
09:00
11:00
13:30
16:00
18:05
20:10
22:45
09:15
11:25
13:55
16:20
18:20
20:25
07:35
09:35
11:40
14:15
16:35
18:40
20:45
23:20
09:55
12:00
14:30
16:55
19:00
21:05
23:40
08:15
10:15
12:20
14:50
17:10
19:15
21:50
23:50','Active');
INSERT INTO "busTable" VALUES(50,'144','Kothrud Stand','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','46 Minutes','1	Kothrud Stand
2	Karve putala
3	Maruti Mandir Karve Road
4	Paud phata dashbhuja mandir
5	SNDT college
6	Nal stop
7	Petrol pump karve road
8	Garware college
9	Deccan corner sambhaji pul
10	Alka talkies
11	Chitrashala
12	Sadashiv Peth Houd
13	Vishrambag wada
14	A B Chowk
15	Dakshinabhimukh Maruti mandir
16	Shaniwar wada
17	Kasaba Police Chowky
18	Lalmahal
19	Phadake Haud
20	RCM
21	Apolo Talkies
22	KEM hospital
23	15 August Lodge Somwar Peth
24	Ambedkar bhavan
25	Sasoon hospital
26	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	15 August Lodge Somwar Peth
6	KEM hospital
7	Apolo talkies
8	RCM
9	Phadake Houd
10	Sonya Maruti Chowk
11	City post
12	Kunte Chauk
13	Gokhale hall
14	Vijay Talkies
15	Alka talkies
16	Deccan Corner Sambhaji Pul Corner
17	Garware college
18	Petrol Pump Karve Road
19	Nal Stop
20	SNDT college
21	Paud Phata Dashabhuja Ganpati
22	Maruti mandir karve road
23	Karve putala
24	Karve putala
25	Kothrud Stand
26	Kothrud Stand','26','05:30
07:00
08:35
10:05
12:15
14:05
15:40
17:15
18:55
21:05
05:50
07:20
08:55
10:30
12:35
14:30
16:00
17:40
19:20
21:30
09:10
10:45
12:50
14:45
17:55
20:05
06:15
07:45
09:20
11:00
13:00
14:55
16:25
18:05
19:45
21:55
08:00
09:35
11:40
13:15
15:10
16:40
18:20
20:30
06:40
08:10
09:45
11:20
13:25
15:20
16:50
18:30
20:40
22:20
08:20
09:55
12:00
13:40
15:30
17:05
18:45
20:55','06:15
07:45
09:20
10:55
13:00
14:50
16:25
18:05
19:40
21:50
06:35
08:05
09:40
11:15
13:20
15:15
16:50
18:30
20:05
22:15
09:55
11:30
13:35
15:30
18:45
20:50
07:00
08:30
10:05
11:45
13:45
15:40
17:10
18:55
20:30
22:40
08:45
10:20
12:25
14:00
15:55
17:30
19:10
21:15
07:25
08:55
10:30
12:05
14:10
16:05
17:40
19:20
21:25
23:05
09:05
10:40
12:45
14:25
16:25
17:55
19:35
21:40','Active');
INSERT INTO "busTable" VALUES(51,'144A','Sai Sayaji nagar','Pune station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13.9 KMs','74 Minutes','1	Sai sayaji nagar
2	Atulnagar gate
3	Popular Nagar Cipla cancer care entre
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Alka talkies
19	Chitrashala
20	Sadashiv Peth Houd
21	Vishrambag wada
22	A B Chowk
23	Dakshinabhimukh Maruti mandir
24	Shaniwar wada
25	Kasaba Police Chowky
26	Lalmahal
27	Phadake Haud
28	RCM
29	Apolo Talkies
30	KEM hospital
31	15 August Lodge Somwar Peth
32	Ambedkar bhavan
33	Sasoon hospital
34	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Zila Parishad
6	15 August Lodge Somwar Peth
7	KEM hospital
8	Apolo talkies
9	RCM
10	Daruwala Pool
11	Sonya Maruti Chowk
12	City post
13	Kunte Chauk
14	Gokhale hall
15	Vijay Talkies
16	Alka talkies
17	Deccan Corner Sambhaji Pul Corner
18	Garware college
19	Petrol Pump Karve Road
20	Nal Stop
21	SNDT college
22	Paud Phata Dashabhuja Ganpati
23	Maruti mandir karve road
24	Karve putala
25	Kothrud Stand
26	Dahanukar colony
27	Wadache Jhad Bhairavnath Mandir
28	Karvenagar
29	Warje Jakatnaka
30	Tapodham
31	Popular Nagar Cipla cancer care entre
32	Atulnagar gate
33	Sai sayaji nagar','34','08:30
11:00
14:00
16:30','09:45
12:15
15:10
17:45','Active');
INSERT INTO "busTable" VALUES(52,'144B','Kumbare Park','Sainathnagar Mundhava','Mon, Tue, Wed, Thu, Fri, Sat, Sun','23.5 KMs','90 Minutes','1	Kumbare Park
2	Guruganesh Nagar
3	Ashish Garden
4	Mahesh Vidyalaya
5	Sahajanand Soc
6	Gandhibhavan Andhshala
7	Dahanukar colony
8	Kothrud Stand
9	Karve putala
10	Maruti Mandir Karve Road
11	Paud phata dashbhuja mandir
12	SNDT college
13	Nal stop
14	Petrol pump karve road
15	Garware college
16	Deccan corner sambhaji pul
17	Alka talkies
18	Chitrashala
19	Sadashiv Peth Houd
20	Vishrambag wada
21	A B Chowk
22	Dakshinabhimukh Maruti mandir
23	Shaniwar wada
24	Kasaba Police Chowky
25	Lalmahal
26	Phadake Haud
27	RCM
28	Apolo Talkies
29	KEM hospital
30	15 August Lodge Somwar Peth
31	Ambedkar bhavan
32	Sasoon hospital
33	Pune station
34	Ruby hall
35	Wadia college
36	Guruprasad bangala
37	Band garden
38	Yerwada
39	wadia bangala
40	Shastri nagar
41	Agakhan palace
42	Ramwadi Jakatnaka
43	Ramwadi
44	Weikfield
45	ISL Company
46	WNC Company
47	Dharmanagar 5 va Mail
48	Tata gaurdroom Kharadi phata
49	Panyachi Taki Chandannagar
50	Salunke hospital
51	Sundarbai shala
52	Sambhaji chauk Ganesh nagar
53	Karehar company
54	Raghuveer Nagar
55	Paranj company Relax hotel
56	Alear weare housing
57	Jog Engineering
58	Vishnu Udyog
59	Sainathnagar Mundhava','1	Sainathnagar Mundhva
2	Vishnu Udyog
3	Jog Engineering
4	Alear Weare Housing
5	Paranj Company Relax Hotel
6	Raghuveer nagar
7	Karehar Company
8	Sambhaji Chowk Ganesh Nagar
9	Sundarabai shala
10	Salunke Hospital
11	Panyachi Taki Chandannagar
12	Tata Guardroom Kharadi Phata
13	Dharmanagar 5 va mail
14	WNC Company
15	ISL Company
16	Weikfield
17	Ramwadi
18	Ramwadi jakatnaka
19	Agakhan palace
20	Shastri nagar
21	Wadia bunglow
22	Yerwada
23	Band garden
24	Guruprasad bangala
25	Jahangir Hospital
26	Alankar Talkies
27	Sadhu wasvani chauk
28	GPO
29	Collector kacheri
30	Zila Parishad
31	15 August Lodge Somwar Peth
32	KEM hospital
33	Apolo talkies
34	RCM
35	Daruwala Pool
36	Sonya Maruti Chowk
37	City post
38	Kunte Chauk
39	Gokhale hall
40	Vijay Talkies
41	Alka talkies
42	Deccan Corner Sambhaji Pul Corner
43	Garware college
44	Petrol Pump Karve Road
45	Nal Stop
46	SNDT college
47	Paud Phata Dashabhuja Ganpati
48	Maruti mandir karve road
49	Karve putala
50	Kothrud Stand
51	Dahanukar colony
52	Andhshala
53	Sahajanand Soc
54	Mahesh vidyalaya
55	Ashish Garden
56	Guruganesh nagar
57	Kumbare Park','59','07:00
10:00
15:30
08:10
11:10
16:40
08:45
11:45
17:15
09:20
12:20
18:50','08:30
11:30
17:00
09:40
12:40
18:10
10:15
13:15
18:45
10:50
13:50
20:20','Active');
INSERT INTO "busTable" VALUES(53,'145','Pune Station','NDA D2','Mon, Tue, Wed, Thu, Fri, Sat, Sun','23 KMs','66 Minutes','1	Pune Station Depot
2	Sadhu wasvani chauk
3	Collector kacheri
4	Ambedkar bhavan
5	Juna Bajar
6	Kumbhar wada
7	PMC
8	Shivaji putala pmc
9	shimala office shivajinagar
10	Masoba gate
11	Pumping station
12	Pune central
13	E square
14	Rangehills Corner
15	Pune Vidyapeeth
16	Police head office
17	Loyala Highschool
18	NCL market
19	NCL
20	Panchwati
21	IITM
22	ARDE bus stop
23	Pashan
24	ARDE Colony
25	Ramnagar Bharat Electronics
26	Bavdhan gaon
27	Shinde Nagar
28	Bavdhan khind
29	Mail Dagad Kramank 8
30	Mail Dagad Kramank 9
31	 Mail Dagad Kramank 10
32	Garware Bungalow
33	Pashan Gate
34	Central School NDA
35	Gol Market NDA
36	Ashok Stambha
37	Stadium NDA
38	Servents Quarters
39	D2 Circle','1	D2 Circle
2	Servents Quarters
3	Stadium NDA
4	Ashok Stambha
5	Gol Market NDA
6	Central School NDA
7	Pashan Gate
8	Garware Bungalow
9	 Mail Dagad Kramank 10
10	Mail Dagad Kramank 9
11	Mail Dagad Kramank 8
12	Bavdhan Khind
13	Shinde Nagar
14	Bavdhan goan
15	Ramnagar Bharat Electronics
16	ARDE Colony
17	Pashan
18	ARDE bus stop
19	IITM
20	Panchwati
21	NCL
22	NCL Market
23	Loyala Highschool
24	Police head office
25	Pune Vidyapeeth
26	Rangehills Corner
27	E Square
28	Pune central
29	Pumping station
30	Masoba gate
31	shimala office shivajinagar
32	Engineering college hostel
33	Shivaji putala
34	PMC Mangala
35	Kumbhar Wada
36	Juna Bajar
37	Ambedkar bhavan
38	Sasoon hospital
39	Pune station
40	Pune Station Depot','39','05:30
07:50
11:00
14:00
16:45
19:10
07:00
09:10
12:30
15:15
17:50
21:00','06:40
09:00
12:00
15:05
17:45
20:20
08:00
10:15
13:30
16:30
19:10
22:00','Active');
INSERT INTO "busTable" VALUES(54,'145A','Pune Station','Sutarwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18 KMs','63 Minutes','1	Pune Station Depot
2	Sadhu wasvani chauk
3	Collector kacheri
4	Zila Parishad
5	15 August Lodge Somwar Peth
6	Apolo Talkies
7	RCM
8	Lalmahal
9	Shaniwar wada
10	PMC mangala
11	Shivaji putala pmc
12	shimala office shivajinagar
13	shimala office shivajinagar
14	Masoba gate
15	Pumping station
16	Pune central
17	E square
18	Rangehills Corner
19	Pune Vidyapeeth
20	Police head office
21	Loyala Highschool
22	NCL market
23	NCL
24	Panchwati
25	IITM
26	ARDE bus stop
27	Pashan
28	Pashan gaon
29	NIV
30	Sai Chauk
31	Abhinav college
32	Sutarwadi','1	Sutarwadi
2	Abhinav college
3	Sai Chauk
4	NIV
5	Pashan gaon
6	Pashan
7	ARDE bus stop
8	IITM
9	Panchwati
10	NCL
11	NCL Market
12	Loyala Highschool
13	Police head office
14	Pune Vidyapeeth
15	Rangehills Corner
16	E Square
17	Pune central
18	Pumping station
19	Masoba gate
20	shimala office shivajinagar
21	Engineering college hostel
22	Shivaji putala
23	PMC Mangala
24	Kasaba Police Chowky
25	Lal mahala
26	RCM
27	Rastewada
28	15 August Lodge Somwar Peth
29	Ambedkar bhavan
30	Sasoon hospital
31	Pune station
32	Pune Station Depot','32','07:25
09:35
11:50
14:40
17:00
08:25
10:35
13:30
15:45
18:00','08:25
10:40
12:55
15:45
18:00
09:25
11:40
14:35
16:50
19:00','Active');
INSERT INTO "busTable" VALUES(55,'146','Pune Station','Gokhalenagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','39 Minutes','1	Jayprakash Stand Pune station
2	Pune station
3	Pune Station Depot
4	Sadhu wasvani chauk
5	Collector kacheri
6	Ambedkar bhavan
7	Juna Bajar
8	Kumbhar wada
9	PMC
10	Balgandharv sambhaji par
11	Deccan Gymkhana
12	Goodluck Chowk
13	F C College
14	Dnyaneshwar Paduka chowk
15	Lakaki Bungalow
16	Model colony
17	Deep Bungalow Chowk
18	Vetal Maharaj chauk
19	Kusalkar Putala
20	Gokhalenagar shala
21	Gokhalenagar
22	Police line Gokhalenagar','1	Police line Gokhalenagar
2	Gokhalenagar
3	Gokhalenagar shala
4	Kusalkar putala
5	Vetal Maharaj chauk
6	Deep Bungalow Chowk
7	Model colony
8	Lakaki Bungalow
9	shimala office shivajinagar
10	Engineering college hostel
11	Shivaji putala
12	PMC Mangala
13	Kumbhar Wada
14	Juna Bajar
15	Ambedkar bhavan
16	Central building
17	Sadhu wasvani chauk
18	Jayprakash Stand Pune station','22','05:15
05:45
07:00
08:50
10:15
11:40
13:00
14:45
16:15
17:50
19:25
21:15
05:35
06:05
07:20
09:10
10:30
11:55
13:15
15:05
16:35
18:10
19:45
21:40
05:50
06:25
07:40
09:30
10:55
12:15
13:35
15:25
16:55
18:30
20:05
22:05
06:45
08:00
10:00
11:25
12:45
14:00
15:40
17:10
18:45
20:25
22:30
08:25
09:45
11:10
12:30
14:25
16:00
17:30
19:05
20:50','05:30
06:15
07:40
09:30
10:55
12:20
13:40
15:30
17:00
18:35
20:05
21:55
05:50
06:35
08:00
09:50
11:10
12:35
13:55
15:50
17:20
18:55
20:30
22:20
06:05
06:55
08:20
10:10
11:35
12:55
14:15
16:10
17:40
19:15
20:55
22:40
07:15
08:40
10:40
12:05
13:25
14:40
16:25
17:55
19:30
21:05
23:10
09:05
10:25
11:50
13:10
15:05
16:45
18:15
19:50
21:25','Active');
INSERT INTO "busTable" VALUES(56,'147','Manapa bhavan','Pimpri','Mon, Tue, Wed, Thu, Fri, Sat, Sun','38 KMs','82 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Ruby hall
8	Wadia college
9	Guruprasad bangala
10	Band garden
11	Yerwada
12	wadia bangala
13	Shastri nagar
14	Agakhan palace
15	Ramwadi Jakatnaka
16	Ramwadi
17	Weikfield
18	ISL Company
19	WNC Company
20	Dharmanagar 5 va Mail
21	Tata Guardroom Kharadi Phata
22	Chandan Nagar
23	Nagarroad Phata Shriramnagar
24	NEI Company
25	Naik bungalow
26	Janakbaba Darga
27	Ramnarayan Bungalow
28	Lieson company
29	Satav High School
30	Wagholi
31	Kesanand phata
32	Pacharne wasti
33	Bharti Jain Sanghatna College
34	Jagtap Dairy Lonikand
35	Lonikand
36	Phulgaon Phata
37	Power House Phulgaon
38	Mail Dagad Kramank 23
39	Perne Phata
40	Walke Wasti
41	Perne Gaon
42	Kadam Wasti
43	Dongergaon Phata
44	Shinde Wasti
45	Bapurao Smarak
46	Dabhade Wasti
47	Gaikwad Wasti
48	Shinde Wasti Burkegaon
49	Harpale wasti Burkegaon
50	Pimpri Saandas
51	Shitole mala
52	Nhavi Sandas','1	Nhavi Sandas
2	Shitole mala
3	Pimpri Saandas
4	Harpale wasti Burkegaon
5	Shinde Wasti Burkegaon
6	Gaikwad Wasti
7	Dabhade Wasti
8	Bapurao Smarak
9	Shinde Wasti
10	Dongergaon Phata
11	Kadam Wasti
12	Perne Gaon
13	Walke Wasti
14	Perne Phata
15	Mail Dagad Kramank 23
16	Power House Phulgaon
17	Phulgaon phata
18	Lonikand
19	Jagtap Dairy Lonikand
20	Bharti Jain Sanghatna College
21	Pacharne wasti
22	Kesanand phata
23	Wagholi
24	Satva high school
25	Lieson Company
26	Ramnarayan Bungalow
27	Janakbaba Darga
28	Naik Bungalow
29	NEI company
30	Nagarroad Phata Shriramnagar
31	Chandan nagar
32	Tata gaurdroom Kharadi phata
33	Dharmanagar 5 va mail
34	WNC Company
35	ISL Company
36	Weikfield
37	Ramwadi
38	Ramwadi jakatnaka
39	Agakhan palace
40	Shastri nagar
41	Wadia bunglow
42	Yerwada
43	Band garden
44	Guruprasad bangala
45	Jahangir Hospital
46	Alankar Talkies
47	Sadhu wasvani chauk
48	GPO
49	Collector kacheri
50	Ambedkar bhavan
51	Juna Bajar
52	Kumbhar wada
53	PMC','52','09:00
14:50
19:10','06:50
11:15
16:40','Active');
INSERT INTO "busTable" VALUES(57,'148','Hadapsar gadital','Pimple gurav','Mon, Tue, Wed, Thu, Fri, Sat, Sun','23 KMs','82 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri
17	Pune station
18	Ruby hall
19	Wadia college
20	Guruprasad bangala
21	Band garden
22	Yerwada
23	Shadal baba Darga
24	Deccan college
25	Holkar Water Supply
26	Mathyadist Church
27	Amunition factory road
28	Suply depot
29	Khadaki bajar
30	Alegaonkar High school
31	Gangaram park
32	Bopodi
33	Bopodi Jakat Naka
34	Buddha Vihar
35	Shivaji putala dapodi
36	Mantri niketan Dapodi
37	Raviraj Hotel
38	Ramkrushna Mangal Karyalaya
39	Pooja hospital
40	Suvarna park
41	Pimple gurav','1	Pimple gurav
2	Suvarna Park
3	Pooja Hospital
4	Ramkrishna mangal karyalay
5	Raviraaj hotel
6	Mantri Niketan Dapodi
7	Shivaji Putala Dapodi
8	Buddha Vihar
9	Bopodi Jakat Naka
10	Bopodi
11	Gangaram park
12	Kirloskar oil engine manaji bag
13	Alegaonkar High school
14	Khadki Bazar
15	Supply Depot
16	Amunition Factory Road
17	Mathyadist Church
18	Holkar Water Supply
19	Deccan college
20	Shadal baba Darga
21	Yerwada
22	Band garden
23	Guruprasad bangala
24	Jahangir Hospital
25	Alankar Talkies
26	Sadhu wasvani chauk
27	General post office
28	West end talkies
29	Bombay garaje
30	juna pul gate
31	Mahatma gandhi stand
32	Race course
33	Bhauraba nala
34	Fatimanagar Municipal shala
35	Kalubai mandir
36	Ram tekadi
37	Vaidwadi
38	Gurushankar math
39	Magarpatta
40	Hadapsar gaon
41	Hadapsar gadital','41','05:20
08:00
11:25
14:15
17:10
20:40
05:30
08:10
11:35
14:30
17:25
20:55
05:40
08:20
11:45
14:40
17:35
21:05
05:50
08:30
11:55
14:50
17:45
21:15
06:00
08:40
12:05
15:00
17:55
21:25
06:10
08:50
12:15
15:10
18:05
21:35
06:20
09:00
12:25
15:20
18:15
21:45
06:30
09:10
12:35
15:30
18:25
21:55
06:40
09:25
12:45
15:40
18:35
22:05
06:50
09:35
12:05
15:50
18:45
22:15
07:00
09:45
13:05
16:05
19:05
22:30
07:15
10:20
13:20
16:20
19:30
23:00
07:30
10:45
13:45
16:35
19:55
23:55
07:45
10:55
13:45
16:50
20:15
23:35','06:40
09:30
12:45
15:40
18:40
22:05
06:50
09:40
12:55
15:55
18:55
22:20
07:00
09:50
13:05
16:05
19:05
22:30
07:10
10:00
13:15
16:15
19:15
22:40
07:20
10:10
13:25
16:25
19:25
22:50
07:30
10:20
13:35
16:35
19:35
23:00
07:40
10:30
13:45
16:45
19:45
23:10
07:50
10:40
13:55
16:55
19:55
23:20
08:00
10:50
14:05
17:05
20:05
23:30
08:10
11:00
14:15
17:15
20:15
23:45
08:20
11:10
14:25
17:30
20:35
23:55
08:30
11:55
14:40
17:45
21:00
08:50
12:10
14:55
18:00
21:25
09:05
12:25
15:05
18:20
21:45','Active');
INSERT INTO "busTable" VALUES(58,'149','Hadapsar gadital','Pimpri chowk Bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','34 KMs','105 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Tilekar wasti
5	Magarpatta school
6	Megarpatta City
7	Bapusaheb Magar wasti
8	Keertane Bag
9	Dhamale wasti Mundhva
10	Mundhva Gaon
11	Sainathnagar Ashok Hotel
12	Thiite Vasti KaluBai Mandir
13	Balaji Palace
14	Pathare Wasti
15	Nagarroad Phata Shriramnagar
16	Chandan nagar
17	Dharmanagar 5 va mail
18	Weikfield
19	Ramwadi
20	Ramwadi jakatnaka
21	Agakhan palace
22	Shastri nagar
23	Wadia bunglow
24	Yerwada
25	White House
26	Netaji school
27	Vikrikar Karyalaya
28	Yerwada post office
29	Shantinagar
30	512 Factory Gate
31	MSEB Khadki
32	Amunition factory road
33	Suply depot
34	Khadaki bajar
35	Alegaonkar High school
36	Kirloskar Oil Engine Manaji Bag
37	Gangaram park
38	Bopodi
39	Dapodi
40	Fugewadi
41	Sandwik
42	Alfa laval atlas company
43	Forbes marshal stop
44	Kasrawadi
45	Deichi company
46	Vallabhnagar
47	HA Factory D Y Patil college
48	Kharalwadi
49	Pimpri chauk Bus stop','1	Pimpri chauk Bus stand
2	Kharalwadi
3	H A Factory
4	Vallabhnagar
5	Deichi Company
6	Nashik phata
7	Kasarwadi
8	Forbes marshal stop
9	Alfa Laval Atlas Company
10	Sandwik
11	Fugewadi
12	Dapodi
13	Bopodi
14	Gangaram park
15	Kirloskar oil engine manaji bag
16	Alegaonkar High school
17	Khadki Bazar
18	Supply Depot
19	Amunition Factory Road
20	MSEB Khadki
21	512 Factory Gate
22	Shantinagar
23	Yerwada post office
24	Vikrikar karyalaya
25	Netaji school
26	White House
27	Yerwada
28	wadia bangala
29	Shastri nagar
30	Agakhan palace
31	Ramwadi Jakatnaka
32	Ramwadi
33	Weikfield
34	Dharmanagar 5 va Mail
35	Chandan Nagar
36	Nagarroad Phata Shriramnagar
37	Pathare Wasti
38	Balaji Palace
39	Thiite Vasti KaluBai Mandir
40	Sainathnagar Ashok Hotel
41	Mundhava Goan
42	Dhamale wasti Mundhava
43	Keertane Bag
44	Bapusaheb Magar Vasti
45	Magarpatta City
46	Magarpatta School
47	Tilekar Wasti
48	Magarpatta
49	Hadapsar gaon
50	Hadapsar gadital','49','05:30
09:25
13:15
17:15
06:05
10:00
13:50
17:50
06:40
10:35
14:25
18:25
07:15
11:15
15:00
19:00
07:50
11:50
15:35
19:35
08:25
12:25
16:10
20:10
09:00
13:00
16:45
20:50','07:05
11:10
15:00
19:00
07:45
11:45
15:35
19:35
08:20
12:20
16:10
20:10
09:00
13:00
16:45
20:45
09:35
13:35
17:20
21:20
10:10
14:15
17:55
21:55
10:45
14:45
18:30
22:40','Active');
INSERT INTO "busTable" VALUES(59,'152','Manapa','Mhaske wasti','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','40 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Mula road bhaiyawadi
11	Pachawadw
12	Holkar Water Supply
13	Sapras post
14	Deccan college
15	Ambedkar Society
16	RTO New
17	Phulenagar
18	MES Water Works
19	Mental Hospital Corner
20	Shantinagar
21	Sathe Biscuit company
22	Vishrantwadi
23	R D colony
24	kalasgaon
25	Mhaske wasti','1	Mhaske wasti
2	Kalasgaon
3	R D colony
4	Vishrantwadi
5	Sathe Biscuit company
6	Shantinagar
7	Mental Hospital Corner
8	MES Water Works
9	Phulenagar
10	RTO New
11	Ambedkar Society
12	Deccan college
13	Sapras post
14	Holkar Water Supply
15	Pachwade
16	Mula bhaiyawadi
17	Poultry Farm Old Mumbai Pune Road
18	Mariaai Gate Old Mumbai Pune Road
19	Bajaj showroom
20	Labor office
21	Patil Estate
22	Engineering college hostel
23	Shivaji putala
24	PMC','24','05:55
07:20
08:40
10:00
11:50
15:50
17:10
18:30
20:20
21:40
06:05
07:30
08:50
10:15
12:00
13:25
16:00
17:20
18:45
20:30
22:00
06:10
07:35
09:00
11:00
12:25
14:40
16:05
17:35
19:35
21:00
06:30
07:50
09:10
10:30
12:20
13:40
15:00
16:20
17:40
19:00
20:50
06:40
08:00
09:20
10:40
12:30
13:45
15:15
16:30
17:50
19:10
21:05
22:15
06:50
08:10
09:30
10:50
12:40
14:00
16:40
18:00
19:20
21:10
22:30
07:00
08:20
09:40
11:30
12:50
14:10
15:30
16:50
18:10
20:00
21:20
22:45','06:35
08:00
09:20
10:40
13:30
16:30
17:50
19:10
21:00
22:25
06:45
08:10
09:30
10:50
12:40
14:05
16:40
18:00
19:20
21:15
22:35
06:50
08:15
09:45
11:45
13:05
15:25
16:50
18:20
20:20
21:30
07:10
08:30
09:50
11:10
13:00
14:20
15:40
17:00
18:20
19:40
21:30
07:20
08:40
10:00
11:20
13:10
14:25
15:50
17:10
18:30
19:50
21:40
23:00
07:30
08:50
10:10
11:30
13:20
14:40
17:20
18:40
20:00
21:50
23:10
07:40
09:00
10:20
12:10
13:30
14:50
16:10
17:30
18:50
20:40
22:00
23:20','Active');
INSERT INTO "busTable" VALUES(60,'155A','Pune Station','Munjaba wasti','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','45 Minutes','1	Pune station
2	Ruby hall
3	Wadia college
4	Guruprasad bangala
5	Band garden
6	Yerwada
7	White House
8	Netaji school
9	Vidi Kamgar Vasahat Yerawada
10	Ahilya Society
11	Ambedkar Society
12	RTO New
13	Phulenagar
14	MES Water Works
15	Mental Hospital Corner
16	Shantinagar
17	Sathe Biscuit company
18	Vishrantwadi
19	Panyachi Taki
20	Bhairavnagar
21	Gokul Nagar
22	Sai Corner
23	Akshay Sunshri
24	Munjaba Vasti','1	Munjaba Vasti
2	Akshay Sunshri
3	Sai Corner
4	Gokul Nagar
5	Bhairavnagar
6	Panyachi Taki
7	Vishrantwadi
8	Sathe Biscuit company
9	Shantinagar
10	Mental Hospital Corner
11	MES Water Works
12	Phulenagar
13	RTO New
14	Ambedkar Society
15	Ahilya Society
16	Vidi Kamgar Vasahat Yerawada
17	Netaji school
18	White House
19	Yerwada
20	Band garden
21	Guruprasad bangala
22	Jahangir Hospital
23	Alankar Talkies
24	Sadhu wasvani chauk
25	Collector kacheri
26	Pune station','24','05:55
07:20
08:40
10:00
11:50
15:50
17:10
18:30
20:20
21:40
06:05
07:30
08:50
10:15
12:00
13:25
16:00
17:20
18:45
20:30
22:00
06:10
07:35
09:00
11:00
12:25
14:40
16:05
17:35
19:35
21:00
06:30
07:50
09:10
10:30
12:20
13:40
15:00
16:20
17:40
19:00
20:50
06:40
08:00
09:20
10:40
12:30
13:45
15:15
16:30
17:50
19:10
21:05
22:15
06:50
08:10
09:30
10:50
12:40
14:00
16:40
18:00
19:20
21:10
22:30
07:00
08:20
09:40
11:30
12:50
14:10
15:30
16:50
18:10
20:00
21:20
22:45','06:35
08:00
09:20
10:40
13:30
16:30
17:50
19:10
21:00
22:25
06:45
08:10
09:30
10:50
12:40
14:05
16:40
18:00
19:20
21:15
22:35
06:50
08:15
09:45
11:45
13:05
15:25
16:50
18:20
20:20
21:30
07:10
08:30
09:50
11:10
13:00
14:20
15:40
17:00
18:20
19:40
21:30
07:20
08:40
10:00
11:20
13:10
14:25
15:50
17:10
18:30
19:50
21:40
23:00
07:30
08:50
10:10
11:30
13:20
14:40
17:20
18:40
20:00
21:50
23:10
07:40
09:00
10:20
12:10
13:30
14:50
16:10
17:30
18:50
20:40
22:00
23:20','Active');
INSERT INTO "busTable" VALUES(61,'157','Swargate','Lohgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','68 Minutes','1	Swargate
2	Swargate
3	Ghorpade peth colony
4	Lakud Bajar
5	Sonwane hospital
6	Ramoshi gate
7	Nana peth
8	A D camp chauk
9	Power house
10	KEM hospital
11	Ambedkar bhavan
12	Sasoon hospital
13	Pune station
14	Alankar Talkies
15	Jahangir Hospital
16	Ruby hall
17	Wadia college
18	Guruprasad bangala
19	Band garden
20	Yerwada
21	Neeta park
22	Gunjan Theature
23	White House
24	Netaji school
25	Vikrikar Karyalaya
26	Yerwada post office
27	Nagpur chawl
28	Guardroom gate
29	Sanjay park
30	Five nine area
31	Burmashell
32	Kalwad
33	Officers mess
34	Central school khese
35	Water tank
36	Lohoan','1	Lohoan
2	Water tank
3	Central School Khese
4	Officers Mess
5	Kalwad
6	Burmashell
7	Five nine area
8	Sanjay park
9	Guardroom gate
10	Nagpur Chawl
11	Yerwada post office
12	Maharashtra Housing Corner
13	Vikrikar karyalaya
14	Netaji school
15	White House
16	Gunjan Theature
17	Neeta park
18	Yerwada
19	Band garden
20	Guruprasad bangala
21	Wadia college
22	Ruby Hall
23	Jahangir Hospital
24	Alankar Talkies
25	Sadhu wasvani chauk
26	GPO
27	Collector kacheri
28	Zila Parishad
29	15 August Lodge Somwar Peth
30	KEM hospital
31	Power house
32	A D camp chauk
33	Nana peth
34	Ramoshi gate
35	Sonwane hospital
36	Lakud Bajar
37	Ghorpadi Peth Colony
38	Swargate police line
39	Swargate
40	Swargate','37','06:00
08:10
11:10
14:00
16:20
19:15
06:35
08:45
11:45
14:35
16:55
19:45
07:10
09:20
12:20
15:10
17:30
20:20
07:40
10:00
13:00
15:45
18:05
21:00','07:00
09:15
12:20
15:10
17:30
20:20
07:35
09:50
12:55
15:45
18:05
20:55
08:15
10:35
13:30
16:20
18:40
21:30
08:45
11:10
14:05
16:55
19:15
22:05','Active');
INSERT INTO "busTable" VALUES(62,'158','Manapa','Lohgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','50 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Alankar Talkies
8	Jahangir Hospital
9	Ruby hall
10	Wadia college
11	Guruprasad bangala
12	Band garden
13	Yerwada
14	Neeta park
15	Gunjan Theature
16	White House
17	Netaji school
18	Vikrikar Karyalaya
19	Yerwada post office
20	Nagpur chawl
21	Guardroom gate
22	Sanjay park
23	Five nine area
24	Burmashell
25	Kalwad
26	Officers mess
27	Central school khese
28	Water tank
29	Lohoan','1	Lohoan
2	Water tank
3	Central School Khese
4	Officers Mess
5	Kalwad
6	Burmashell
7	Five nine area
8	Sanjay park
9	Guardroom gate
10	Nagpur Chawl
11	Yerwada post office
12	Maharashtra Housing Corner
13	Vikrikar karyalaya
14	Netaji school
15	White House
16	Gunjan Theature
17	Neeta park
18	Yerwada
19	Band garden
20	Guruprasad bangala
21	Wadia college
22	Ruby Hall
23	Jahangir Hospital
24	Alankar Talkies
25	Sadhu wasvani chauk
26	GPO
27	Collector kacheri
28	Ambedkar bhavan
29	Juna Bajar
30	Kumbhar wada
31	PMC','39','05:20
07:00
08:40
10:45
12:30
14:20
16:00
17:40
19:45
05:30
07:10
08:50
11:00
12:40
16:10
17:50
20:00
21:40
05:40
07:20
09:00
11:10
12:50
14:40
16:20
18:00
20:10
21:50
05:50
07:30
09:10
11:20
13:00
16:30
18:10
20:20
22:00
06:00
07:40
09:20
11:30
13:10
15:00
16:40
18:20
20:30
22:10
06:10
07:50
09:30
11:40
13:20
16:50
18:30
20:40
22:20
06:20
08:00
09:40
11:50
13:30
15:20
17:00
18:40
20:50
22:30
06:30
08:10
09:55
12:00
13:40
15:30
17:10
18:55
21:00
06:40
08:20
10:30
12:10
13:50
15:40
17:20
19:30
21:10
22:50
06:50
08:30
10:10
12:20
14:05
17:30
19:10
21:20
23:05','06:00
07:50
09:30
11:35
13:20
15:05
16:50
18:30
20:35
06:15
08:00
09:40
11:50
13:30
17:00
18:40
20:50
22:30
06:30
08:10
09:50
12:00
13:40
15:30
17:10
18:50
21:00
22:40
06:40
08:20
10:00
12:10
13:50
17:20
19:00
21:10
22:50
06:50
08:30
10:10
12:20
14:00
15:50
17:30
19:10
21:20
23:00
07:00
08:40
10:20
12:30
14:10
17:40
19:20
21:30
23:10
07:10
08:50
10:30
12:40
14:20
16:10
17:50
19:30
21:40
23:20
07:20
09:00
10:45
12:50
14:30
16:20
18:00
19:45
21:50
07:30
09:10
11:20
13:00
14:40
16:30
18:10
20:20
22:00
23:40
07:40
09:20
11:00
13:10
14:50
18:20
20:00
22:10
23:50','Active');
INSERT INTO "busTable" VALUES(63,'158A','Deccan Gymkhana','Lohgaon Airport','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','52 Minutes','1	Deccan Gymkhana
2	Goodluck Chowk
3	F C College
4	Dnyaneshwar Paduka chowk
5	Police Line Modern College
6	Modern Highschool
7	PMC Mangala
8	Kumbhar Wada
9	Juna Bajar
10	Ambedkar bhavan
11	Sasoon hospital
12	Alankar Talkies
13	Jahangir Hospital
14	Ruby hall
15	Wadia college
16	Guruprasad bangala
17	Band garden
18	Yerwada
19	Neeta park
20	Gunjan Theature
21	White House
22	Netaji school
23	Vikrikar Karyalaya
24	Yerwada post office
25	Nagpur chawl
26	Guardroom gate
27	Sanjay park
28	Five nine area
29	Burmashell
30	Airport','1	Airport
2	Burmashell
3	Five nine area
4	Sanjay park
5	Nagpur Chawl
6	Yerwada post office
7	Vikrikar karyalaya
8	Netaji school
9	White House
10	Yerwada
11	Band garden
12	Guruprasad bangala
13	Jahangir Hospital
14	Alankar Talkies
15	Sadhu wasvani chauk
16	GPO
17	Collector kacheri
18	Ambedkar bhavan
19	Juna Bajar
20	Kumbhar wada
21	PMC
22	Balgandharv sambhaji par
23	Deccan Gymkhana','30','05:50
07:30
09:40
11:30
14:45
16:20
18:10
20:20
21:30','06:50
08:20
10:40
12:30
15:35
17:20
19:00
20:50
22:20','Active');
INSERT INTO "busTable" VALUES(64,'159','Manapa bhavan','Talegaon Dhamdhere','Mon, Tue, Wed, Thu, Fri, Sat, Sun','43.5 KMs','111 Minutes','1	PMC
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Ruby hall
8	Wadia college
9	Guruprasad bangala
10	Band garden
11	Yerwada
12	wadia bangala
13	Shastri nagar
14	Agakhan palace
15	Ramwadi Jakatnaka
16	Ramwadi
17	Weikfield
18	ISL Company
19	WNC Company
20	Dharmanagar 5 va Mail
21	Tata Guardroom Kharadi Phata
22	Chandan Nagar
23	Nagarroad Phata Shriramnagar
24	NEI Company
25	Naik bungalow
26	Janakbaba Darga
27	Ramnarayan Bungalow
28	Lieson company
29	Satav High School
30	Wagholi
31	Kesanand phata
32	Pacharne wasti
33	Bharti Jain Sanghatna College
34	Jagtap Dairy Lonikand
35	Lonikand
36	Phulgaon Phata
37	Power House Phulgaon
38	Mail Dagad Kramank 23
39	Perne Phata
40	Polcompany
41	Waghmare wasti
42	Koregaon Bhima
43	Bafna Industries
44	Ekora Company Kalyani Forbes
45	Darekar Wasti
46	Sanaswadi
47	Jakate wasti
48	Shikrapur Phata
49	ST Stand Chakan Road
50	LakshmiBai Mandir
51	Bhairoba Nagar
52	Talegao Dhamdhere Bazar
53	ST Stand Gram Panchayat Talegaon','1	ST Stand Gram Panchayat Talegaon
2	Talegao Dhamdhere Bazar
3	Bhairoba Nagar
4	LakshmiBai Mandir
5	ST Stand Chakan Road
6	Shikrapur Phata
7	Jakate wasti
8	Sanaswadi
9	Darekar Wasti
10	Ekora Company Kalyani Forbes
11	Bafna Industries
12	Koregaon Bhima
13	Waghmare wasti
14	Polcompany
15	Perne Phata
16	Mail Dagad Kramank 23
17	Power House Phulgaon
18	Phulgaon phata
19	Lonikand
20	Jagtap Dairy Lonikand
21	Bharti Jain Sanghatna College
22	Pacharne wasti
23	Kesanand phata
24	Wagholi
25	Satva high school
26	Lieson Company
27	Ramnarayan Bungalow
28	Janakbaba Darga
29	Naik Bungalow
30	NEI company
31	Nagarroad Phata Shriramnagar
32	Chandan nagar
33	Tata gaurdroom Kharadi phata
34	Dharmanagar 5 va mail
35	WNC Company
36	ISL Company
37	Weikfield
38	Ramwadi
39	Ramwadi jakatnaka
40	Agakhan palace
41	Shastri nagar
42	Wadia bunglow
43	Yerwada
44	Band garden
45	Guruprasad bangala
46	Jahangir Hospital
47	Alankar Talkies
48	Sadhu wasvani chauk
49	GPO
50	Collector kacheri
51	Ambedkar bhavan
52	Juna Bajar
53	Kumbhar wada
54	PMC','54','06:20
11:10
15:20
19:15
07:10
11:30
15:40
19:35
08:00
12:10
16:20
20:15
08:20
12:30
16:40
20:35
09:05
13:15
17:20
21:20
09:25
13:35
17:40
21:40
10:05
14:15
18:20
22:20
10:30
14:40
18:40
22:45
10:50
15:00
19:00','09:30
13:40
17:40
05:40
09:50
14:00
18:00
06:20
10:30
14:40
18:40
06:40
10:50
15:00
19:00
07:25
11:35
15:40
19:45
07:45
11:55
16:00
20:05
08:25
12:35
16:40
20:45
08:50
13:00
17:00
21:10
09:10
13:20
17:20
21:45','Active');
INSERT INTO "busTable" VALUES(65,'15S','Bhosari','Alandi bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','8 KMs','31 Minutes','1	Bhosari gaon
2	Maharashtra chauk
3	Hutatma chauk
4	Shatri chauk
5	Durwankur lawns
6	Dighi Corner Odha
7	Tata stores
8	Bhosari phata
9	Moje vidyalaya
10	Sai madnir
11	Nirma company
12	Gokhale Mala Sankalpa Garden
13	Wadmukhwadi
14	Chincheche jhad
15	Charholi phata
16	Sai Lila nagar Kate Wasti
17	Moshi Phata Dehu Phata
18	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Sai mandir
10	Moje vidyalaya
11	Bhosari phata
12	Tata Stores
13	Didhi corner odha
14	Durvankur Lawns
15	Shastri chowk
16	Hutatma chauk
17	Maharashtra Chowk
18	Bhosari gaon','18','06:00
07:00
08:00
09:00
10:30
11:30
12:30
14:00
15:00
17:00
18:00
19:00
20:00
21:00
06:15
07:15
08:15
09:15
10:45
11:45
12:45
14:15
15:15
16:15
17:15
18:15
19:45
20:45
06:30
07:30
08:30
09:30
11:00
12:00
13:00
14:30
15:30
16:30
17:30
18:30
20:00
21:00','06:30
07:30
08:30
09:30
11:00
12:00
13:00
14:30
16:30
17:30
18:30
19:30
20:30
21:30
06:45
07:45
08:45
10:15
11:15
12:15
13:15
14:45
15:45
16:45
17:45
19:15
20:15
21:15
07:00
08:00
09:00
10:00
11:30
12:30
13:30
15:00
16:00
17:00
18:00
19:30
20:30
21:30','Active');
INSERT INTO "busTable" VALUES(66,'161','Deccan Gymkhana','Gangapuram Mhada','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15.6 KMs','64 Minutes','1	Deccan Gymkhana
2	Goodluck Chowk
3	F C College
4	Dnyaneshwar Paduka chowk
5	Police Line Modern College
6	Modern Highschool
7	PMC Mangala
8	Kumbhar Wada
9	Juna Bajar
10	Ambedkar bhavan
11	Sasoon hospital
12	Pune station
13	Ruby hall
14	Wadia college
15	Guruprasad bangala
16	Band garden
17	Yerwada
18	wadia bangala
19	Shastri nagar
20	Agakhan palace
21	Ramwadi Jakatnaka
22	Ramwadi
23	Weikfield
24	ISL Company
25	Green Oaks Company
26	Mangesh nagar
27	Vimannagar Gate
28	Konark Nagar Corner
29	Konark Nagar
30	Gangapuram Mhada','1	Gangapuram Mhada
2	Konark Nagar
3	Konark Nagar Corner
4	Vimannagar Gate
5	Mangesh nagar
6	Green Oaks Company
7	ISL Company
8	Weikfield
9	Ramwadi
10	Ramwadi jakatnaka
11	Agakhan palace
12	Shastri nagar
13	Wadia bunglow
14	Yerwada
15	Band garden
16	Guruprasad bangala
17	Jahangir Hospital
18	Alankar Talkies
19	Sadhu wasvani chauk
20	GPO
21	Collector kacheri
22	Ambedkar bhavan
23	Juna Bajar
24	Kumbhar wada
25	PMC
26	Balgandharv sambhaji par
27	Deccan Gymkhana','30','05:30
07:35
09:30
12:10
14:00
16:20
19:10
06:40
08:50
10:45
13:20
15:30
17:50
20:45','06:40
08:30
10:35
13:00
15:10
17:30
20:15
07:50
09:50
11:50
14:10
16:40
19:00
21:45','Active');
INSERT INTO "busTable" VALUES(67,'162','Manama bhavan','kharadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','41 KMs','50 Minutes','1	PMC
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Ruby hall
8	Wadia college
9	Guruprasad bangala
10	Band garden
11	Yerwada
12	wadia bangala
13	Shastri nagar
14	Agakhan palace
15	Ramwadi Jakatnaka
16	Ramwadi
17	Weikfield
18	ISL Company
19	WNC Company
20	Dharmanagar 5 va Mail
21	Tata Guardroom Kharadi Phata
22	Chandan Nagar
23	Nagarroad Phata Shriramnagar
24	NEI Company
25	Naik bungalow
26	Janakbaba Darga
27	Ramnarayan Bungalow
28	Lieson company
29	Satav High School
30	Wagholi
31	Kesanand phata
32	Pacharne wasti
33	Bharti Jain Sanghatna College
34	Jagtap Dairy Lonikand
35	Lonikand
36	Phulgaon Phata
37	Power House Phulgaon
38	Mail Dagad Kramank 23
39	Perne Phata
40	Polcompany
41	Waghmare wasti
42	Phadtare Wasti
43	Industrial Company
44	Z F Stearing Company
45	Vishrant Dham
46	Wadhu Bu
47	Bhandari nivas
48	Chaudhri Vasti
49	Bhosale Vasti
50	Wajewadi Chaufula
51	Karandi Phata
52	Panyachi Taki Karandi
53	Karandigaon kaman
54	Karandi gaon','1	Karandi gaon
2	Karandigaon kaman
3	Panyachi Taki Karandi
4	Karandi Phata
5	Wajewadi Chaufula
6	Bhosale Vasti
7	Chaudhri Vasti
8	Bhandari nivas
9	Wadhu Bu
10	Vishrant Dham
11	Z F Stearing Company
12	Industrial Company
13	Phadtare Wasti
14	Koregaon Bhima
15	Waghmare wasti
16	Polcompany
17	Perne Phata
18	Mail Dagad Kramank 23
19	Power House Phulgaon
20	Phulgaon phata
21	Lonikand
22	Jagtap Dairy Lonikand
23	Bharti Jain Sanghatna College
24	Pacharne wasti
25	Kesanand phata
26	Wagholi
27	Satva high school
28	Lieson Company
29	Ramnarayan Bungalow
30	Janakbaba Darga
31	Naik Bungalow
32	NEI company
33	Nagarroad Phata Shriramnagar
34	Chandan nagar
35	Tata gaurdroom Kharadi phata
36	Dharmanagar 5 va mail
37	WNC Company
38	ISL Company
39	Weikfield
40	Ramwadi
41	Ramwadi jakatnaka
42	Agakhan palace
43	Shastri nagar
44	Wadia bunglow
45	Yerwada
46	Band garden
47	Guruprasad bangala
48	Jahangir Hospital
49	Alankar Talkies
50	Sadhu wasvani chauk
51	GPO
52	Collector kacheri
53	Ambedkar bhavan
54	Juna Bajar
55	Kumbhar wada
56	PMC','54','08:40
12:30
15:00
18:45','06:20
10:00
17:00','Active');
INSERT INTO "busTable" VALUES(68,'163','Pune Station','Kharadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','42 Minutes','1	Pune station
2	Ruby hall
3	Guruprasad bangala
4	Band garden
5	Yerwada
6	wadia bangala
7	Shastri nagar
8	Agakhan palace
9	Ramwadi Jakatnaka
10	Ramwadi
11	Weikfield
12	Dharmanagar 5 va Mail
13	Tata Guardroom Kharadi Phata
14	Chandan Nagar
15	Nagarroad Phata Shriramnagar
16	Pathare Wasti
17	Balaji Palace
18	Rakshak Society Kharadi
19	Patil Wasti Kharadi
20	Kharadi Gaon','1	Kharadi Gaon
2	Patil Wasti Kharadi
3	Rakshak Society Kharadi
4	Balaji Palace
5	Pathare Wasti
6	Nagarroad Phata Shriramnagar
7	Chandan nagar
8	Tata gaurdroom Kharadi phata
9	Dharmanagar 5 va mail
10	Weikfield
11	Ramwadi
12	Ramwadi jakatnaka
13	Agakhan palace
14	Shastri nagar
15	Wadia bunglow
16	Yerwada
17	Band garden
18	Guruprasad bangala
19	Jahangir Hospital
20	Alankar Talkies
21	Sadhu wasvani chauk
22	Collector kacheri
23	Pune station','20','05:30
06:40
08:35
10:05
11:30
12:55
14:50
16:15
17:45
19:50
21:15
05:45
07:00
08:15
10:15
11:40
13:10
15:05
16:35
18:35
20:05
21:35
06:00
07:20
09:00
10:30
12:00
13:30
15:20
16:50
18:20
20:20
21:45
23:05
06:15
07:30
08:45
10:45
12:15
13:45
15:35
17:05
19:05
20:35
22:00
23:20
06:30
07:45
09:30
11:00
12:30
14:00
15:50
17:20
18:50
20:50
22:15
06:50
08:00
09:20
11:15
12:45
14:15
16:05
17:35
19:40
21:05
22:30
07:10
08:25
09:50
11:50
13:20
14:40
16:25
17:55
19:25
21:25
22:50','06:05
07:15
09:20
10:45
12:10
13:40
15:30
17:00
18:30
20:35
22:00
06:20
07:35
09:00
11:00
12:25
13:50
15:50
17:20
19:20
20:50
22:10
06:35
07:55
09:45
11:15
12:45
14:10
16:05
17:35
19:05
21:05
22:25
23:45
06:50
08:05
09:30
11:30
13:00
14:25
16:20
17:50
19:50
21:20
22:40
00:00
07:05
08:20
10:15
11:45
13:15
14:40
16:35
18:05
19:35
21:35
22:55
07:25
08:35
10:00
12:00
13:30
14:55
16:50
18:20
20:25
21:50
23:10
07:45
09:10
10:30
12:35
14:00
15:20
17:10
18:40
20:10
22:10
23:30','Active');
INSERT INTO "busTable" VALUES(69,'164','Mahatma gandhi stand','Viman nagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13.5 KMs','54 Minutes','1	Mahatma gandhi stand
2	Juna pul gate
3	Bombay Garage
4	West end talkies
5	GPO
6	Collector kacheri
7	Pune station
8	Ruby hall
9	Wadia college
10	Guruprasad bangala
11	Band garden
12	Yerwada
13	wadia bangala
14	Shastri nagar
15	Agakhan palace
16	Ramwadi Jakatnaka
17	Ramwadi
18	Weikfield
19	ISL Company
20	Green Oaks Company
21	Mangesh nagar
22	Vimannagar Gate
23	Konark Nagar Corner
24	Konark Nagar
25	Gangapuram Mhada','	Gangapuram Mhada
2	Konark Nagar
3	Konark Nagar Corner
4	Vimannagar Gate
5	Mangesh nagar
6	Green Oaks Company
7	ISL Company
8	Weikfield
9	Ramwadi
10	Ramwadi jakatnaka
11	Agakhan palace
12	Shastri nagar
13	Wadia bunglow
14	Yerwada
15	Band garden
16	Guruprasad bangala
17	Jahangir Hospital
18	Alankar Talkies
19	Sadhu wasvani chauk
20	General post office
21	West end talkies
22	Bombay garaje
23	juna pul gate
24	Mahatma gandhi stand','25','06:00
07:45
09:40
12:05
14:10
16:00
18:00
20:30','06:45
08:45
10:30
13:00
15:00
17:00
19:00
21:20','Active');
INSERT INTO "busTable" VALUES(70,'165','Manapa','Wadgaon sheri','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11.4 KMs','43 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Ruby hall
8	Wadia college
9	Guruprasad bangala
10	Band garden
11	Yerwada
12	wadia bangala
13	Shastri nagar
14	Agakhan palace
15	Ramwadi Jakatnaka
16	Ramwadi
17	Weikfield
18	Matchwel company
19	Sainikwadi
20	Datta mandir Wadgaon sheri
21	Wadgao sheri','1	Wadgao sheri
2	Datta mandir wadgaon sheri
3	Sainikwadi
4	Matchwel company
5	Weikfield
6	Ramwadi
7	Ramwadi jakatnaka
8	Agakhan palace
9	Shastri nagar
10	Wadia bunglow
11	Yerwada
12	Band garden
13	Guruprasad bangala
14	Jahangir Hospital
15	Alankar Talkies
16	Sadhu wasvani chauk
17	GPO
18	Collector kacheri
19	Ambedkar bhavan
20	Juna Bajar
21	Kumbhar wada
22	PMC','21','05:20
06:30
08:00
09:30
11:25
14:35
16:10
17:45
19:50
05:30
06:45
08:15
09:40
11:40
13:05
14:50
16:20
17:55
20:00
21:40
06:55
08:20
09:45
11:45
13:15
16:30
18:05
20:10
21:55
05:40
07:00
08:25
09:50
11:50
13:20
15:10
16:40
18:15
20:20
22:05
05:45
07:05
08:30
09:55
11:55
16:50
18:25
20:30
22:15
05:50
07:10
08:35
10:00
12:00
13:30
15:30
17:00
18:35
20:40
22:25
06:00
07:20
08:45
10:10
12:10
17:10
18:45
20:50
22:35
06:05
07:25
08:50
10:15
12:15
13:40
15:50
17:20
18:55
21:00
22:45
07:30
08:55
10:20
12:20
13:50
16:00
17:30
19:35
21:10
06:15
07:35
09:00
10:25
12:25
17:40
19:15
21:20
23:05
07:40
09:05
10:30
12:30
14:00
15:15
16:40
18:00
19:20
21:00
06:25
07:45
09:10
10:40
12:35
15:40
17:00
18:20
19:40
21:30
07:50
09:15
11:10
12:40
14:10
15:45
17:20
18:40
20:00
21:50
07:55
09:20
10:50
12:50
14:25
16:15
17:40
19:00
20:50
22:05','05:55
07:15
08:45
10:10
12:10
15:20
16:55
18:30
20:40
06:10
07:25
08:55
10:20
12:25
13:50
15:30
17:05
18:40
20:50
22:25
07:35
09:00
10:30
12:30
13:55
17:15
18:50
21:00
22:35
06:20
07:40
09:05
10:35
12:35
14:00
15:50
17:25
19:00
21:10
22:45
06:25
07:45
09:10
10:40
12:40
17:35
19:10
21:20
22:55
06:30
07:50
09:15
10:45
12:45
14:10
16:10
17:45
19:20
21:30
23:05
06:40
08:00
09:25
10:55
12:55
17:55
19:30
21:40
23:25
06:45
08:05
09:30
11:00
13:00
14:25
16:30
18:05
19:40
21:50
23:35
08:10
09:35
11:05
13:05
14:30
16:40
18:15
20:20
22:00
06:55
08:15
09:40
11:10
13:10
18:25
20:00
22:10
23:55
08:20
09:45
11:15
13:15
14:40
16:00
17:20
18:40
20:00
21:45
07:05
08:25
09:50
11:20
13:20
16:15
17:40
19:00
20:20
22:05
08:30
09:55
11:55
13:25
14:50
16:40
18:00
19:20
20:40
22:25
08:35
10:00
11:30
13:30
15:05
17:00
18:20
19:40
21:30
22:40','Active');
INSERT INTO "busTable" VALUES(71,'166','Pune Station','Viman nagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','41 Minutes','1	Pune station
2	Ruby hall
3	Wadia college
4	Guruprasad bangala
5	Band garden
6	Yerwada
7	wadia bangala
8	Shastri nagar
9	Agakhan palace
10	Ramwadi Jakatnaka
11	Ramwadi
12	Weikfield
13	ISL Company
14	Green Oaks Company
15	Mangesh nagar
16	Vimannagar Gate
17	Konark Nagar Corner
18	Konark Nagar
19	Gangapuram Mhada','1	Gangapuram Mhada
2	Konark Nagar
3	Konark Nagar Corner
4	Vimannagar Gate
5	Mangesh nagar
6	Green Oaks Company
7	ISL Company
8	Weikfield
9	Ramwadi
10	Ramwadi jakatnaka
11	Agakhan palace
12	Shastri nagar
13	Wadia bunglow
14	Yerwada
15	Band garden
16	Guruprasad bangala
17	Jahangir Hospital
18	Alankar Talkies
19	Sadhu wasvani chauk
20	GPO
21	Collector kacheri
22	Pune station','19','05:40
06:50
08:40
10:15
11:45
13:10
14:35
16:05
17:40
19:15
21:05
06:05
07:15
09:05
10:35
12:05
13:30
15:00
16:30
18:05
19:40
21:30
06:30
07:40
09:30
11:00
12:25
13:50
15:25
16:55
18:30
20:05
21:55
08:10
09:55
11:25
12:50
14:10
15:45
17:15
18:50
20:30
22:25','06:10
07:30
09:15
10:55
12:25
13:50
15:20
16:50
18:25
19:55
21:50
06:35
07:55
09:45
11:15
12:45
14:10
15:45
17:15
18:50
20:20
22:20
07:00
08:20
10:10
11:40
13:05
14:30
16:10
17:40
19:15
20:45
22:45
08:45
10:35
12:05
13:30
14:50
16:30
18:00
19:35
21:10
23:10','Active');
INSERT INTO "busTable" VALUES(72,'167','Hadapsar gadital','Wagholi Kesanand phata','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','46 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Tilekar wasti
5	Magarpatta school
6	Megarpatta City
7	Bapusaheb Magar wasti
8	Keertane Bag
9	Dhamale wasti Mundhva
10	Mundhva Gaon
11	Sainathnagar Ashok Hotel
12	Thiite Vasti KaluBai Mandir
13	Balaji Palace
14	Pathare Wasti
15	Nagarroad Phata Shriramnagar
16	Janakbaba Darga
17	Ramnarayan Bungalow
18	Lieson company
19	Satav High School
20	Wagholi
21	Kesanand phata','1	Kesanand phata
2	Wagholi
3	Satva high school
4	Lieson Company
5	Ramnarayan Bungalow
6	Janakbaba Darga
7	Nagarroad Phata Shriramnagar
8	Pathare Wasti
9	Balaji Palace
10	Thiite Vasti KaluBai Mandir
11	Sainathnagar Ashok Hotel
12	Mundhava Goan
13	Dhamale wasti Mundhava
14	Keertane Bag
15	Bapusaheb Magar Vasti
16	Magarpatta City
17	Magarpatta School
18	Tilekar Wasti
19	Magarpatta
20	Hadapsar gaon
21	Hadapsar gadital','21','05:45
07:15
08:55
10:35
12:45
14:45
16:15
17:55
19:35
21:45
06:00
07:30
09:10
10:50
13:00
15:00
16:30
18:10
19:50
22:00
06:15
07:45
09:25
11:05
13:15
15:15
16:45
18:25
20:05
22:15
06:30
08:00
09:40
11:50
13:30
15:25
16:55
18:35
20:40
06:45
08:15
09:55
12:05
13:45
15:40
17:10
18:50
20:55
07:00
08:30
10:10
12:20
14:00
15:50
17:25
19:05
21:15
07:40
08:50
10:05
11:20
14:30
15:40
16:55
18:10','06:30
08:05
09:45
11:25
13:30
15:30
17:05
18:45
20:25
22:30
06:45
08:20
10:00
11:40
13:45
15:45
17:20
19:00
20:40
22:45
07:00
08:35
10:15
11:55
14:00
16:00
17:35
19:15
20:55
23:00
07:15
08:50
10:30
12:40
14:15
16:10
17:45
19:25
21:30
07:30
09:05
10:45
12:55
14:30
16:25
18:00
19:40
21:45
07:45
09:20
11:00
13:10
14:45
16:40
18:15
19:55
22:00
08:15
09:25
10:40
11:50
15:05
16:15
17:30
18:45','Active');
INSERT INTO "busTable" VALUES(73,'167','Manapa','Keshavnagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','49 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Sadhu wasvani chauk
8	General post office
9	West end talkies
10	Khan Road
11	Family Camp
12	Milletory Depo Mitti Ghar
13	Ghorpadi Post Office
14	Ghorpadi Shala
15	Anant Talkies
16	Army College
17	Pingle Wasti
18	Farshi karkhana
19	Tadi Gupta Wanaspati Sanshodhan Kendra
20	Kachare Wasti
21	Dimond watch company
22	Mundhava goan corner
23	Mundhava Goan
24	Shinde Mundhava
25	Keshavnagar pul
26	Keshavnagar','1	Keshavnagar
2	Keshavnagar Pool
3	Shinde Wasti Mundhva
4	Mundhva Gaon
5	Mundhava Gaon Corner
6	Diamond watch Company
7	Kachare wasti
8	Tadi Gupta Wanaspati Sanshodhan Kendra
9	Farashi Karkhana
10	Pingale wasti
11	Army college
12	Anant Talkies
13	Ghorpadi Shala
14	Ghorpadi Post Office
15	Milletory Depo Mitti Ghar
16	Family camp
17	Khan Road
18	West end talkies
19	GPO
20	Collector kacheri
21	Ambedkar bhavan
22	Juna Bajar
23	Kumbhar wada
24	PMC','26','05:30
07:00
08:35
10:45
12:20
15:40
17:20
19:30
21:05
07:05
08:50
11:00
12:40
14:15
15:55
17:35
19:45
21:25
06:00
07:30
09:05
11:15
12:55
16:10
17:50
20:00
21:40
07:45
09:20
11:30
13:05
14:45
16:25
18:05
20:15
21:55
06:30
08:00
09:35
11:45
13:20
15:00
16:40
18:20
20:30
22:10
08:15
09:50
12:00
13:35
15:15
16:55
18:35
20:45
22:25
08:30
10:05
12:15
13:50
15:30
17:10
18:50
21:00
22:45
07:15
08:45
10:20
12:30
14:05
15:45
17:25
19:05
21:15','06:15
07:45
09:25
11:35
13:10
16:30
18:10
20:20
21:55
07:55
09:40
11:50
13:30
15:05
16:45
18:25
20:35
22:15
06:45
08:15
09:55
12:05
13:45
17:00
18:40
20:50
22:30
08:30
10:05
12:20
14:00
15:35
17:15
18:55
21:05
22:45
07:15
08:45
10:20
12:35
14:15
15:50
17:30
19:10
21:20
23:00
09:00
10:35
12:50
14:30
16:05
17:45
19:25
21:35
23:15
09:15
10:50
13:05
14:45
16:20
18:00
19:40
21:50
23:30
08:00
09:30
11:05
13:20
15:00
16:35
18:15
19:55
22:05','Active');
INSERT INTO "busTable" VALUES(74,'168P','Pune Station','Keshavnagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','40 Minutes','1	Pune Station Depot
2	General post office
3	West end talkies
4	Khan Road
5	Family Camp
6	Milletory Depo Mitti Ghar
7	Ghorpadi Post Office
8	Ghorpadi Shala
9	Anant Talkies
10	Army College
11	Pingle Wasti
12	Farshi karkhana
13	Tadi Gupta Wanaspati Sanshodhan Kendra
14	Kachare Wasti
15	Dimond watch company
16	Mundhava goan corner
17	Mundhava Goan
18	Shinde Mundhava
19	Keshavnagar pul
20	Keshavnagar','1	Keshavnagar
2	Keshavnagar Pool
3	Shinde Wasti Mundhva
4	Mundhva Gaon
5	Mundhava Gaon Corner
6	Diamond watch Company
7	Kachare wasti
8	Tadi Gupta Wanaspati Sanshodhan Kendra
9	Farashi Karkhana
10	Pingale wasti
11	Army college
12	Anant Talkies
13	Ghorpadi Shala
14	Ghorpadi Post Office
15	Milletory Depo Mitti Ghar
16	Family camp
17	Khan Road
18	West end talkies
19	GPO
20	Collector kacheri
21	Pune station','20','06:30
07:50
09:10
11:10
12:35
14:00
15:20
16:45
18:15
19:45
07:05
08:25
09:50
11:50
13:15
14:40
16:05
17:40
19:05
20:30','07:05
08:25
09:50
11:45
13:15
14:40
16:00
17:25
19:00
20:25
07:40
09:05
10:30
12:30
13:55
15:20
16:50
18:25
19:50
21:05','Active');
INSERT INTO "busTable" VALUES(75,'169','Manapa','Keshavnagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','50 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Central building
6	Sadhu wasvani chauk
7	Alankar Talkies
8	Ruby hall
9	Wadia college
10	Blue Diamond hotel
11	Kasturba School Wadia
12	Kalptaru Society
13	Bhairoba Pumping Station
14	Kasturba School north lane
15	Ghorpadi Phata
16	Gulmohar City Military Stadium
17	Dhole Patil Farm
18	Tadi Gupta Wanaspati Sanshodhan Kendra
19	Kachare Wasti
20	Dimond watch company
21	Mundhava goan corner
22	Mundhava Goan
23	Shinde Mundhava
24	Keshavnagar pul
25	Keshavnagar','1	Keshavnagar
2	Keshavnagar Pool
3	Shinde Wasti Mundhva
4	Mundhva Gaon
5	Mundhava Gaon Corner
6	Diamond watch Company
7	Kachare wasti
8	Tadi Gupta Wanaspati Sanshodhan Kendra
9	Dhole Patil Farm
10	Gulmohar city Militory Stadium
11	Ghorpadi phata
12	Kasturba School north lane
13	Bhairoba Pumping Station
14	Kalptaru Society
15	Kasturba School Wadia
16	Blue Diamond Hotel
17	Jahangir Hospital
18	Alankar Talkies
19	Sadhu wasvani chauk
20	GPO
21	Collector kacheri
22	Ambedkar bhavan
23	Juna Bajar
24	Kumbhar wada
25	PMC','25','06:45
08:25
10:05
12:15
13:50
15:25
17:05
18:55
21:10
07:10
08:45
10:25
12:35
14:05
15:45
17:25
19:15
21:30
07:35
09:15
10:55
13:05
14:35
16:15
17:45
19:40
21:55
08:05
09:45
11:25
13:35
15:05
16:45
18:25
20:10
22:20','07:35
09:15
10:55
13:05
14:35
16:15
18:00
19:50
22:00
07:55
09:35
11:15
13:20
14:50
16:35
18:20
20:10
22:20
08:25
10:05
11:45
13:50
15:20
17:05
18:45
20:30
22:45
08:55
10:35
12:15
14:20
15:50
17:35
19:15
21:00
23:10','Active');
INSERT INTO "busTable" VALUES(76,'16S','Alandi bus stand','YCM hospital','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','47 Minutes','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Sai mandir
10	Moje vidyalaya
11	Bhosari phata
12	Tata Stores
13	Didhi corner odha
14	Durvankur Lawns
15	Shastri chowk
16	Hutatma chauk
17	Maharashtra Chowk
18	PCMT chauk
19	Gavane Vasti
20	Landewadi
21	Philips
22	MIDC Bhosari
23	Bhosari police station
24	Phulenagar bhosari
25	YCM','1	YCM
2	Mahesh nagar
3	PCMT
4	Nehrunagar corner
5	Nehrunagar
6	Jyoti school
7	Vishal nagar C ward office
8	Abhi Chemicals
9	Jayanand khira
10	Idrayani nagar corner
11	Tulashi chemikals
12	Landewadi
13	Gavane Vasti
14	PCMT chauk
15	Maharashtra chauk
16	Hutatma chauk
17	Shatri chauk
18	Durwankur lawns
19	Dighi Corner Odha
20	Tata stores
21	Bhosari phata
22	Moje vidyalaya
23	Sai madnir
24	Nirma company
25	Gokhale Mala Sankalpa Garden
26	Wadmukhwadi
27	Chincheche jhad
28	Charholi phata
29	Sai Lila nagar Kate Wasti
30	Moshi Phata Dehu Phata
31	Alandi bus stand','25','07:30
09:10
10:50
13:10
14:50
16:30
08:05
09:45
11:20
13:40
15:20
17:15','08:20
10:00
11:20
14:00
15:40
17:20
08:50
10:30
12:50
14:30
16:10
18:00','Active');
INSERT INTO "busTable" VALUES(77,'17','Shaniwarwada','Narhe Ambegaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','58 Minutes','1	Surya hospital
2	Kasaba Police Chowky
3	Vasant talkies
4	Mandai
5	Shahu chauk
6	Gokul bhavan
7	Swargate
8	Parvati payatha
9	Dandekar pul
10	Pan mala Sinhgad Road
11	Jal Shuddhikarn Kendra Sinhgad Road
12	Ganesh mala
13	Vitbhatti Sinhgad Road
14	Vitthalwadi jakat naka
15	Jaydeo nagar
16	Rajaram pul
17	Vitthalwadi Mandir Hingne
18	Hingne rasta
19	Anand nagar singhgad rd
20	Manik Bag
21	Indian hum company
22	Wadgaon phata
23	Patil colony
24	Dhayari phata
25	Sanas Vidyalaya
26	Gokul nagar
27	Dhayareshwar Industries
28	Manaji nagar
29	JK Industries
30	Narhe Ambegaon','1	Narhe Ambegaon
2	JK Industries
3	Manaji nagar
4	Dhayareshwar Industries
5	Gokul nagar
6	Sanas Vidyalaya
7	Dhayari phata
8	Patil colony
9	Wadgaon phata
10	Indican hyum company
11	Manik bag
12	Anand nagar
13	Hingne rasta
14	Vitthalwadi mandir hingne
15	RajaramPool
16	Jaydeo nagar
17	Vitthalwadi Jakat Naka
18	Vitbhatti singhgad rd
19	Ganesh mala
20	Jal shudhikaran kendra singhroad rd
21	Pan mala siinghgad road
22	Dandekar pul
23	Parvati payatha
24	Sarasbag
25	Bhikardas maruti madnir
26	Shanipar
27	A B Chowk
28	Dakshinabhimukh Maruti mandir
29	Shaniwar wada
30	Surya hospital','30','08:10
10:00
12:30
15:00
17:00
19:00','09:00
11:00
13:30
16:00
18:00
20:00','Active');
INSERT INTO "busTable" VALUES(78,'170','Pune station','Kondhava','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','51 Minutes','1	Pune Station Depot
2	GPO
3	Collector kacheri
4	Sadhu wasvani chauk
5	General post office
6	West end talkies
7	Bombay garaje
8	juna pul gate
9	Mahatma gandhi stand
10	Military Hospital Wanvadi
11	Wanvadi Corner
12	Wanvadi Bazar
13	Netajinagar
14	Lullanagar
15	Mahatma Phule Vasahat
16	N I B M Road
17	Kondhva Shala
18	Kondhava Khurd','1	Kondhva Khurd
2	Kondhava Shala
3	NIBM Road
4	Mahatma Phule wasahat
5	Lullanagar
6	Netajinagar
7	Wanvadi Bazar
8	Wanvadi Corner
9	Military Hospital Wanvadi
10	Mahatma gandhi stand
11	Juna pul gate
12	Bombay Garage
13	West end talkies
14	GPO
15	Collector kacheri
16	Pune Station Depot','18','05:15
06:30
07:50
09:20
11:10
12:30
13:55
15:15
17:05
18:25
19:45
21:05
05:25
06:40
08:00
09:30
15:20
12:40
14:05
15:35
16:55
18:15
20:05
05:35
06:50
08:10
09:40
11:00
12:50
14:15
15:45
17:35
18:55
20:15
21:35
05:45
07:00
08:20
09:50
11:40
13:00
14:25
15:55
17:15
19:05
20:25
21:45
05:55
07:10
08:30
10:00
11:50
13:10
14:35
16:05
17:25
18:45
20:35
21:55
06:05
07:20
08:40
10:10
11:30
13:20
14:45
16:15
18:05
19:25
20:45
22:05
06:15
07:30
08:50
10:20
12:20
14:55
16:25
17:40
19:35
20:55
22:20
07:40
09:00
10:50
12:10
13:30
15:25
16:45
18:35
19:55
21:15
22:35
09:10
10:35
12:00
13:45
15:05
16:35
17:55
19:15
21:25
22:50','05:50
07:05
08:30
10:00
11:50
13:10
14:35
15:55
17:45
19:05
20:25
21:45
06:00
07:15
08:45
10:10
12:00
13:20
14:45
16:15
17:35
18:55
20:45
06:10
07:25
08:50
10:20
11:40
13:30
14:55
16:25
18:15
19:35
20:55
22:15
06:20
07:40
09:00
10:30
12:20
13:40
15:05
16:35
17:55
19:45
21:05
22:25
06:30
07:50
09:10
10:40
12:30
13:50
15:15
16:45
18:05
19:25
21:15
22:35
06:40
08:00
09:20
10:50
12:10
14:00
15:25
16:55
18:45
20:05
21:25
22:45
06:50
08:10
09:30
11:00
13:00
15:35
17:05
18:25
20:15
21:35
23:00
08:20
09:40
11:30
12:50
14:10
16:05
17:25
19:15
20:35
21:55
23:15
09:50
11:15
12:40
14:25
15:45
17:15
18:35
19:55
22:05
23:30','Active');
INSERT INTO "busTable" VALUES(79,'174','Pune Station','NDA gate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','19 KMs','80 Minutes','1	Pune Station Depot
2	GPO
3	Collector kacheri
4	Sadhu wasvani chauk
5	General post office
6	West end talkies
7	Sarabatwala chowk
8	Sachapeer Street
9	Modern Bakery Nana peth
10	Alpana Talkies
11	Sonya Maruti Chowk
12	City post
13	Kunte Chauk
14	Gokhale hall
15	Vijay Talkies
16	Alka talkies
17	Deccan Corner Sambhaji Pul Corner
18	Garware college
19	Petrol Pump Karve Road
20	Nal Stop
21	SNDT college
22	Paud Phata Dashabhuja Ganpati
23	Maruti mandir karve road
24	Karve putala
25	Kothrud Stand
26	Dahanukar colony
27	Wadache Jhad Bhairavnath Mandir
28	Karvenagar
29	Warje Jakatnaka
30	Tapodham
31	Warje Gaon Highway
32	Warje Malwadi
33	Dnanesh society
34	Ganpati matha
35	Dudhane wasti
36	Shivane Gaon
37	Deshmukhwadi
38	Ingale Colony
39	Ahire gate phata
40	Uttamnagar
41	Bhimnagar
42	Kondhava Dhavde
43	NDA gate Kondhva Gate','1	NDA gate Kondhava gate
2	Kondhava dhavade
3	Bhimnagar
4	Uttamanagar
5	Ahire gate Phata
6	Ingale colony
7	Deshmukhwadi
8	Shivane gaon
9	Dudhane wasti
10	Ganpati matha
11	Dnanesh society
12	Warje malwadi
13	Warje gaon highway
14	Tapodham
15	Warje jakatnaka
16	Karvenagar
17	Wadache jhad
18	Dahanukar colony
19	Kothrud Stand
20	Karve putala
21	Maruti Mandir Karve Road
22	Paud phata dashbhuja mandir
23	SNDT college
24	Nal stop
25	Petrol pump karve road
26	Garware college
27	Deccan corner sambhaji pul
28	Chitrashala
29	Sadashiv Peth Houd
30	A B Chowk
31	Dakshinabhimukh Maruti mandir
32	Shaniwar wada
33	Lalmahal
34	RCM
35	Daruwala Pool
36	Alpana Talkies
37	Modern Bakery Nana peth
38	Sachapeer Street
39	West end talkies
40	GPO
41	Collector kacheri
42	Pune Station Depot','43','05:15
08:15
11:15
14:20
17:10
20:00
05:45
08:30
11:30
14:40
17:30
20:20
06:15
08:50
11:45
15:00
17:50
20:40
06:30
09:15
12:05
15:15
18:10
21:00
06:40
09:55
12:40
15:35
18:30
21:20
07:00
09:35
12:25
15:50
18:50
21:40
07:15
10:15
13:00
16:05
19:15
22:00
07:30
10:30
13:20
16:20
19:35
22:30
07:45
11:00
13:40
16:35
08:00
10:45
14:00
16:50','06:15
09:35
12:40
15:45
18:30
21:20
06:35
09:50
13:00
16:05
18:50
21:40
07:00
10:10
13:20
16:20
19:10
22:05
07:25
10:30
13:40
16:40
19:30
22:30
07:55
11:10
13:55
17:00
19:50
22:50
07:45
10:50
14:00
17:15
20:15
23:10
08:25
11:30
14:30
17:30
20:40
23:30
08:40
11:45
14:40
17:45
21:00
23:50
09:00
12:20
15:05
18:00
09:20
12:00
15:25
18:15','Active');
INSERT INTO "busTable" VALUES(80,'174','Swargate','Mohmmadwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.7 KMs','49 Minutes','1	Swargate
2	Swargate
3	Ghorpade peth colony
4	S T Divisional office
5	Meera society
6	Golibar maidan
7	juna pul gate
8	Mahatma gandhi stand
9	Race course
10	Bhauraba nala
11	Fatimanagar
12	Shivarkar Garden
13	Jambhulkar Chauk
14	Jagtap chauk
15	Kedarinagar
16	Kedari corner
17	Kedari Nagar
18	Salunke Vihar
19	Azadnagar
20	Heaven Park
21	Lakshmimata Mandir Mohammadwadi
22	Mahamdwadi Gaon','1	Mahamdwadi Gaon
2	Lakshmimata Mandir Mohammadwadi
3	Heaven Park
4	Azadnagar
5	Salunke Vihar
6	Kedari Nagar
7	Kedari corner
8	Kedarinagar
9	Jagtap chauk
10	Jambhulkar Chauk
11	Shivarkar gardan
12	Fatimanagar
13	Bhauraba nala
14	Race course
15	Mahatma gandhi stand
16	Golibar maidan
17	Meera society
18	S T Divisional office
19	Ghorpadi Peth Colony
20	Swargate police line
21	Swargate','22','06:00
07:30
09:10
11:20
14:10
15:50
17:30
19:45
06:50
08:30
10:10
12:20
14:50
16:30
18:10
20:25','06:45
08:20
10:00
12:10
15:00
16:40
18:20
20:35
07:40
09:20
11:00
13:10
15:40
17:20
19:00
21:10','Active');
INSERT INTO "busTable" VALUES(81,'177','Pune Station','Salunke vihar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','40 Minutes','1	Pune Station Depot
2	GPO
3	Collector kacheri
4	Central building
5	Sadhu wasvani chauk
6	General post office
7	West end talkies
8	Bombay garaje
9	juna pul gate
10	Mahatma gandhi stand
11	Race course
12	Bhauraba nala
13	Fatimanagar
14	Shivarkar gardan
15	Jambhulkar Chauk
16	Jagtap chauk
17	Kedarinagar
18	Kedari corner
19	Kedari Nagar
20	Salunke Vihar
21	Azadnagar','1	Azadnagar
2	Salunke Vihar
3	Kedari Nagar
4	Kedari corner
5	Kedarinagar
6	Jagtap chauk
7	Jambhulkar Chauk
8	Shivarkar Garden
9	Fatimanagar
10	Bhauraba nala
11	Race course
12	Mahatma gandhi stand
13	Juna pul gate
14	Bombay Garage
15	West end talkies
16	GPO
17	Collector kacheri
18	Sasoon hospital
19	Pune station
20	Pune Station Depot','21','05:25
06:40
08:00
10:00
11:40
13:00
15:00
16:30
18:00
19:30
21:00
05:40
07:00
08:30
10:30
12:00
14:00
15:30
17:00
18:30
20:00
05:55
07:15
08:45
10:15
12:15
13:45
15:15
16:45
18:15
19:45
21:20
22:50
06:10
07:30
09:00
11:00
12:30
15:45
17:15
18:45
20:15
21:45
06:25
07:45
09:20
10:45
12:40
14:20
16:00
17:30
19:00
20:30
08:15
09:40
11:20
13:20
14:40
16:15
17:45
19:15
20:45
22:15','05:55
07:20
08:40
10:40
12:20
13:45
15:40
17:10
18:40
20:10
21:45
06:10
07:40
09:10
11:15
12:40
14:45
16:10
17:40
19:10
20:40
06:25
07:55
09:25
11:00
13:00
14:25
15:55
17:25
18:55
20:25
22:05
23:25
06:40
08:10
09:45
11:45
13:15
16:25
17:55
19:25
20:55
22:25
07:00
08:25
10:00
11:30
13:30
15:00
16:40
18:10
19:40
21:10
08:55
10:20
12:00
14:00
15:20
16:55
18:25
19:55
21:25
22:55','Active');
INSERT INTO "busTable" VALUES(82,'179','Mahatma gandhi stand','Wadachi wadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','34 Minutes','1	Mahatma gandhi stand
2	Mammadevi Chowk
3	Military Hospital Wanvadi
4	Wanvadi Corner
5	Wanvadi Bazar
6	Netajinagar
7	Lullanagar
8	Mahatma Phule Vasahat
9	N I B M Road
10	Kondhva Shala
11	Kondhava Khurd
12	Chaitanya Vidyalaya
13	Mangalben company Sai service
14	Talab Farm
15	Somaji Khat Karkhana
16	Khadi Machine
17	Hanuman Mandir Charminar
18	Pisoli Gaon
19	Undrigaon
20	Ghule Wasti
21	Wadachi Wadi','1	Wadachi Wadi
2	Ghule Wasti
3	Undrigaon
4	Pisoli Gaon
5	Hanuman Mandir Charminar
6	Khadi Machine
7	Somaji Khat Karkhana
8	Talab Farm
9	Mangalben company Sai service
10	Chaitanya Vidyalaya
11	Kondhva Khurd
12	Kondhava Shala
13	NIBM Road
14	Mahatma Phule wasahat
15	Lullanagar
16	Netajinagar
17	Wanvadi Bazar
18	Wanvadi Corner
19	Military Hospital Wanvadi
20	Mammadevi Chowk
21	Mahatma gandhi stand','21','06:00
07:10
08:45
10:45
11:15
14:30
16:00
18:00
18:40
20:00
20:40','06:30
08:00
09:30
12:00
15:15
16:40
18:40
19:20
21:20','Active');
INSERT INTO "busTable" VALUES(83,'18','Swargate','Wadgaon budruk','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','36 Minutes','1	Swargate
2	Parvati payatha
3	Dandekar pul
4	Pan mala Sinhgad Road
5	Jal Shuddhikarn Kendra Sinhgad Road
6	Ganesh mala
7	Vitbhatti Sinhgad Road
8	Vitthalwadi jakat naka
9	Jaydeo nagar
10	Rajaram pul
11	Vitthalwadi Mandir Hingne
12	Hingne rasta
13	Damodar nagar
14	Mahadeo nagar
15	Tukai nagar
16	Bhansali complex
17	Chaitanya bangala
18	Wadgaon budruk','1	Wadgaon budruk
2	Chaitanya bangala
3	Bhansali complex
4	Tukai nagar
5	Mahadeo nagar
6	Damodar nagar
7	Hingne rasta
8	Vitthalwadi mandir hingne
9	RajaramPool
10	Jaydeo nagar
11	Vitthalwadi Jakat Naka
12	Vitbhatti singhgad rd
13	Ganesh mala
14	Jal shudhikaran kendra singhroad rd
15	Pan mala siinghgad road
16	Dandekar pul
17	Parvati payatha
18	Sarasbag
19	Hirabag
20	Swargate corner
21	Swargate','21','06:30
07:40
08:55
10:05
11:50
13:05
15:05
16:15
17:35
18:45
20:35
21:45
07:00
08:15
09:25
11:15
12:25
13:40
15:35
16:45
18:05
19:50
21:05
22:15','07:00
08:15
09:25
11:15
12:25
13:40
15:35
16:45
18:05
19:50
21:05
22:15
07:40
08:55
10:05
11:50
13:05
14:15
16:15
17:35
18:45
20:35
21:45
22:45','Active');
INSERT INTO "busTable" VALUES(84,'180','Hadapsar gadital','Narveer Tanaji Wadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','64 Minutes','1	Hadapsar gadital
2	Magarpatta
3	Gurushankar math
4	Vaidwadi
5	Ram tekadi
6	Kalubai mandir solapur road
7	Fatimanagar Municipal shala
8	Bhauraba nala
9	Race course
10	Mahatma gandhi stand
11	New hind school
12	Juna motor stand
13	Kashiwadi
14	Ramoshi gate
15	A D camp chauk
16	Nana peth
17	Power house
18	Apolo Talkies
19	RCM
20	Lalmahal
21	Shaniwar wada
22	PMC mangala
23	Shivaji putala pmc
24	shimala office shivajinagar
25	Shivaji nagar ST Stand
26	N T wadi','1	N T wadi
2	Shivaji nagar S T stand
3	Sancheti Hospital
4	Shivaji putala pmc
5	PMC Mangala
6	Kasaba Police Chowky
7	Lalmahal
8	RCM
9	Apolo Talkies
10	Power house
11	Nana peth
12	A D camp chauk
13	Ramoshi gate
14	Juna motor stand
15	New hind school
16	juna pul gate
17	Mahatma gandhi stand
18	Race course
19	Bhauraba nala
20	Fatimanagar Municipal shala
21	Kalubai mandir
22	Ram tekadi
23	Vaidwadi
24	Gurushankar math
25	Magarpatta
26	Hadapsar gaon
27	Hadapsar gadital','26','05:20
07:25
09:35
12:10
14:30
16:35
18:45
21:20
05:35
07:40
09:50
12:25
14:45
16:50
19:00
21:35
05:50
07:55
10:05
12:40
15:00
17:05
19:15
21:50
06:05
08:10
10:20
12:55
15:15
17:20
19:30
22:05
06:20
08:25
10:35
13:10
15:30
17:35
19:45
22:20
06:35
08:40
10:50
13:25
15:45
17:50
20:00
06:50
08:55
11:10
13:45
16:00
18:05
20:15
07:00
09:05
11:45
13:55
16:10
18:15
20:20
07:15
09:20
11:30
14:10
16:25
18:30
20:45','06:20
08:30
10:40
13:15
15:30
17:40
19:50
22:25
06:35
08:45
10:55
13:30
15:45
17:55
20:05
22:40
06:50
09:00
11:10
13:45
16:00
18:10
20:20
22:55
07:05
09:15
11:25
14:00
16:15
18:25
20:35
23:10
07:20
09:30
11:40
14:15
16:30
18:40
20:50
23:25
07:35
09:45
11:55
14:30
16:45
18:55
21:05
07:50
10:00
12:10
14:45
17:00
19:10
21:25
08:00
10:10
12:50
15:00
17:10
19:20
21:40
08:15
10:25
12:35
15:15
17:25
19:35
21:55','Active');
INSERT INTO "busTable" VALUES(85,'181','Narveer Tanaji Wadi','Somaji Khat Karkhana','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11.2 KMs','64 Minutes','1	N T wadi
2	Shivaji nagar S T stand
3	Lokmangal
4	Engineering college hostel
5	Shivaji putala
6	PMC Mangala
7	Kasaba Police Chowky
8	Lalmahal
9	RCM
10	Apolo Talkies
11	KEM hospital
12	Power house
13	A D camp chauk
14	Nana peth
15	Police Line Padamji
16	Padmji Gate
17	Juna motor stand
18	New hind school
19	juna pul gate
20	Mahatma gandhi stand
21	Military Hospital Wanvadi
22	Wanvadi Corner
23	Wanvadi Bazar
24	Netajinagar
25	Lullanagar
26	Mahatma Phule Vasahat
27	N I B M Road
28	Kondhva Shala
29	Kondhava Khurd
30	Chaitanya Vidyalaya
31	Mangalben company Sai service
32	Talab Farm
33	Somaji Khat Karkhana','1	Somaji Khat Karkhana
2	Talab Farm
3	Mangalben company Sai service
4	Chaitanya Vidyalaya
5	Kondhva Khurd
6	Kondhava Shala
7	NIBM Road
8	Mahatma Phule wasahat
9	Lullanagar
10	Netajinagar
11	Wanvadi Bazar
12	Wanvadi Corner
13	Military Hospital Wanvadi
14	Mahatma gandhi stand
15	Juna pul gate
16	New hind school
17	Juna motor stand
18	Padmji Gate
19	Police Line Padamji
20	Nana peth
21	A D camp chauk
22	Power house
23	KEM hospital
24	Apolo Talkies
25	RCM
26	Lal mahala
27	Shaniwar wada
28	PMC mangala
29	Shivaji putala pmc
30	shimala office shivajinagar
31	Shivaji nagar ST Stand
32	N T wadi','33','05:20
07:15
09:20
11:50
14:00
16:00
18:00
20:30
05:40
07:35
10:05
12:10
14:20
16:20
18:20
20:50
06:05
08:05
10:35
12:35
14:40
16:45
18:45
21:15
06:30
08:30
11:00
13:00
15:10
17:10
19:10
21:40
06:55
08:55
11:25
13:25
15:35
17:35
20:00
22:10
05:35
07:40
09:40
12:25
14:50
16:55
19:40
21:55','06:05
08:15
10:20
12:50
15:00
17:00
19:00
21:30
06:15
08:35
11:00
13:10
15:20
17:20
22:50
21:50
07:05
09:05
11:35
13:35
15:45
17:45
19:45
22:15
07:30
09:30
12:00
14:00
16:10
18:10
20:10
22:40
07:55
09:55
12:25
14:25
16:35
18:35
21:05
23:10
06:35
08:40
10:40
13:30
15:50
18:00
20:45
22:55','Active');
INSERT INTO "busTable" VALUES(86,'183','Hadapsar gadital','Theur factory','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18 KMs','39 Minutes','1	Hadapsar gadital
2	Agrawal Colony
3	Akashwani hadapasar
4	15 number Manjari Gaon Phata
5	Laxmideep colony
6	Rambag solapur rd
7	Manjri farm
8	Phursungi gaon phata
9	Krushi mahavidyalaya
10	Kavadi pat
11	Kavadi rasta
12	Wakvasti
13	Fuel depot
14	Kadam wasti
15	Loni station
16	Loni phata
17	Ramkrushna rasayan karkhana
18	Malyacha mala
19	Borkar wasti
20	Tamnya wasti
21	Theurgaon Phata
22	Green Ekers
23	Panale farm
24	Kunjir mala
25	Kunjir vihir
26	Gosavi wasti
27	Power house theur
28	Theur gaon
29	Theur factory','1	Theur factory
2	Theur gaon
3	Power house theur
4	Gosavi wasti
5	Kunjir vihir
6	Kunjir mala
7	Panale farm
8	Green ekers
9	Theurgaon Phata
10	Tamnya wasti
11	Borkar wasti
12	Malyacha mala
13	Ramkrushna rasayan karkhana
14	Loni phata
15	Loni station
16	Kadam wasti
17	Fuel depot
18	Wakvasti
19	Kavadi rasta
20	Kavadi pat
21	Krushi mahavidyalaya
22	Phursungi gaon phata
23	Manjri farm
24	Rambag solapur rd
25	Laxmideep colony
26	15 number Manjari Gaon Phata
27	Akashwani hadapasar
28	Agrawal colony
29	Hadapsar gadital','29','05:35
07:00
11:30
14:50
16:10
17:30
18:50
20:45
07:20
08:40
10:00
11:50
13:10
15:10
16:30
21:10
06:20
07:35
09:05
10:50
12:10
15:35
16:50
18:10
20:00
21:40
08:00
09:20
11:10
12:35
13:50
15:50
17:15
18:35
20:20
22:10','06:10
07:40
12:10
15:30
16:50
18:10
19:30
21:25
08:00
09:20
10:40
12:30
13:50
15:50
17:10
21:50
07:00
08:20
09:40
11:30
12:50
16:10
17:30
18:50
20:40
22:20
08:40
10:00
11:50
13:10
14:30
16:30
17:50
19:10
21:00
22:50','Active');
INSERT INTO "busTable" VALUES(87,'184','Swargate','Phursungi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','16 KMs','42 Minutes','1	Swargate
2	Ghorpade peth colony
3	S T Divisional office
4	Meera society
5	Golibar maidan
6	juna pul gate
7	Mahatma gandhi stand
8	Race course
9	Bhauraba nala
10	Fatimanagar Municipal shala
11	Kalubai mandir
12	Ram tekadi
13	Vaidwadi
14	Gurushankar math
15	Magarpatta
16	Hadapsar gaon
17	Hadapsar gadital
18	Satavwadi
19	Gondhalenagr
20	ADP pune
21	Bhekrai nagar
22	Power House Phursungi
23	Harpale wasti
24	Jai bhavani godown
25	Phursungi','1	Phursungi
2	Jai bhavani godown
3	Harpale wasti
4	Power house fursungi
5	Bhekarai Nagar
6	ADP hadapasar
7	Gondhalenagar
8	Satavwadi
9	Hadapsar gadital
10	Hadapsar gaon
11	Magarpatta
12	Gurushankar math
13	Vaidwadi
14	Ram tekadi
15	Kalubai mandir solapur road
16	Fatimanagar Municipal shala
17	Bhauraba nala
18	Race course
19	Mahatma gandhi stand
20	Golibar maidan
21	Meera society
22	S T Divisional office
23	Ghorpadi Peth Colony
24	Swargate police line
25	Swargate','25','05:35
14:20
05:45
14:30
05:55
14:45
06:05
15:00
06:15
15:10
06:25
15:20
06:00
07:15
08:35
10:05
11:35
13:15
15:05
16:10
17:40
19:15
20:45
22:20
06:10
07:25
08:45
10:15
11:50
13:35
15:15
16:45
18:20
19:55
21:20
23:00
05:30
07:05
08:45
10:35
12:55
15:00
16:40
18:45
21:20
06:20
07:55
09:40
11:30
13:55
15:50
17:45
19:45
22:10','06:05
07:05
08:15
09:30
11:15
12:25
13:35
14:50
16:00
17:10
18:25
19:45
21:15
22:15
06:15
07:15
08:25
09:40
11:25
12:35
13:45
15:00
16:10
17:20
18:35
19:55
21:25
22:25
06:25
07:25
08:35
09:50
11:35
12:45
13:55
15:15
16:25
17:35
18:50
20:05
21:35
22:40
06:35
07:35
08:45
10:00
11:45
12:55
14:05
15:30
16:40
17:50
19:05
20:15
21:45
22:55
06:45
07:50
09:00
10:15
12:00
13:10
14:15
15:40
16:50
18:00
19:15
20:55
21:55
23:05
06:55
08:00
09:15
10:30
12:15
13:25
14:25
15:50
17:00
18:15
19:30
20:35
22:05
23:15
06:30
07:50
09:20
10:50
12:40
13:50
15:35
16:55
18:30
20:00
21:50
22:50
06:40
08:00
09:30
11:05
13:00
14:10
16:00
17:30
19:10
20:40
22:20
23:30
06:15
07:50
09:40
12:05
13:55
15:50
17:45
20:15
22:10
07:10
08:50
10:35
12:55
14:55
16:40
18:45
21:20
22:45','Active');
INSERT INTO "busTable" VALUES(88,'185','Hadapsar gadital','Manjari','Mon, Tue, Wed, Thu, Fri, Sat, Sun','8 KMs','30 Minutes','1	Hadapsar gadital
2	Agrawal Colony
3	Akashwani hadapasar
4	15 number Manjari Gaon Phata
5	Magar College
6	Mahadeo nagar
7	Ghule wasti
8	Dhere bangala
9	Gopal Patti
10	Railway crossing
11	Rangicha wada
12	Belhekar wasti
13	Malwadi
14	Manjri bu.
15	Maruti mandir ves
16	Annasaheb magar vidya mandir
17	Manjari Khurda Avhalwadi Phata','1	Manjari Khurda Avhalwadi Phata
2	Annasaheb magar vidya mandir
3	Maruti mandir ves
4	Manjri bu.
5	Malwadi
6	Belhekar wasti
7	Rangicha wada
8	Railway crossing
9	Gopal patti
10	Dhere bangala
11	Ghule wasti
12	Mahadeo nagar
13	Magar college
14	15 number Manjari Gaon Phata
15	Akashwani hadapasar
16	Agrawal colony
17	Hadapsar gadital','17','05:30
06:30
07:30
08:30
09:30
10:30
12:00
14:10
15:10
16:10
17:10
18:10
19:10
20:40
06:00
07:00
08:00
09:00
10:00
11:00
12:30
14:40
15:40
16:40
17:40
18:40
20:10
21:10','06:00
07:00
08:00
09:00
10:00
11:00
12:30
14:40
15:40
16:40
17:40
18:40
19:40
21:10
06:30
07:30
08:30
09:30
10:30
11:30
13:00
15:10
16:10
17:10
18:10
19:10
20:40
21:40','Active');
INSERT INTO "busTable" VALUES(89,'187','Hadapsar gadital','Pune station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','50 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Bhatnagar
9	Uday Bag
10	Sopan Bag
11	Railway Crossing Gorpadi
12	Kawade Nagar
13	Kalashankar
14	Vatare mala
15	Shirke Company
16	Anant Talkies
17	Ghorpadi Shala
18	Ghorpadi Post Office
19	Milletory Depo Mitti Ghar
20	Family camp
21	Khan Road
22	West end talkies
23	GPO
24	Collector kacheri
25	Sasoon hospital
26	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	General post office
4	West end talkies
5	Khan Road
6	Family Camp
7	Milletory Depo Mitti Ghar
8	Ghorpadi Post Office
9	Ghorpadi Shala
10	Anant Talkies
11	Shirke Company
12	Vatare mala
13	Kalashankar
14	Kawade Nagar
15	Railway Crossing Gorpadi
16	Sopan Bag
17	Uday Bag
18	Bhatnagar
19	Kalubai mandir
20	Ram tekadi
21	Vaidwadi
22	Gurushankar math
23	Magarpatta
24	Hadapsar gaon
25	Hadapsar gadital','26','06:15
07:55
09:35
11:45
13:25
15:15
16:55
18:35
20:15
22:25
06:50
08:30
10:10
12:20
14:00
15:50
17:30
19:10
21:20
22:50
07:20
09:00
10:40
12:50
14:30
16:20
18:00
19:40
21:50','07:05
08:45
10:25
12:35
14:15
16:05
17:45
19:25
21:05
23:15
07:40
09:20
11:00
13:10
14:50
16:40
18:20
20:00
22:05
23:40
08:10
09:50
11:30
13:40
15:20
17:10
18:50
20:30
22:40','Active');
INSERT INTO "busTable" VALUES(90,'188','Hadapsar gadital','Katraj bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18 KMs','60 Minutes','1	Hadapsar gadital
2	Satavwadi
3	Gondhalenagr
4	ADP pune
5	Bhekrai nagar
6	Power House Phursungi
7	Navlakha Godown
8	Mantar Wadi phata
9	Kachara Depot Undri
10	Queen company
11	Mayur Mangal Karyalaya
12	Undrigaon
13	Pisoli Gaon
14	Hanuman Mandir Charminar
15	Khadi Machine
16	Smashanbhumi Kondhava
17	Hill Villa
18	Shri Shatrunjay jain temple
19	Gokulnagar Katraj
20	Sundarban
21	Sudarshan nagar Katraj
22	Rajas Soc. Corner
23	Katraj bus stand','1	Katraj bus stand
2	Rajas Soc. Corner
3	Sudarshan nagar Katraj
4	Sundarban
5	Gokul Nagar Katraj
6	Shri Shatrunjay Jain Temple
7	Hill Villa
8	Smashanbhumi Kondhava
9	Khadi Machine
10	Hanuman Mandir Charminar
11	Pisoli Gaon
12	Undrigaon
13	Mayuri Mangal Karyalaya
14	Queen company
15	Kachara Depot Undri
16	Mantar Wadi phata
17	Navlakha Godown
18	Power house fursungi
19	Bhekarai Nagar
20	ADP hadapasar
21	Gondhalenagar
22	Satavwadi
23	Hadapsar gadital','23','06:00
08:00
10:00
12:30
15:00
17:00
19:00
06:30
08:30
10:30
13:00
15:30
17:30
19:30
07:00
09:00
11:00
13:30
16:00
18:00
20:00
07:30
09:30
11:30
14:00
16:30
18:30
20:30','07:00
09:00
11:00
13:30
16:00
18:00
20:00
07:30
09:30
11:30
14:00
16:30
18:30
20:30
08:00
10:00
12:00
14:30
17:00
19:00
21:00
08:30
10:30
12:30
15:00
17:30
19:30
21:30','Active');
INSERT INTO "busTable" VALUES(91,'189','Hadapsar gadital','Uruli Devachi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7 KMs','27 Minutes','1	Hadapsar gadital
2	Satavwadi
3	Gondhalenagr
4	ADP pune
5	Bhekrai nagar
6	Power House Phursungi
7	Navlakha Godown
8	Mantar Wadi phata
9	Uruli Devachi Phata
10	Bahiratwadi
11	Raut wasti
12	Uruli Devachi','1	Uruli Devachi
2	Raut wasti
3	Bahiratwadi
4	Uruli Devachi Phata
5	Mantar Wadi phata
6	Navlakha Godown
7	Power house fursungi
8	Bhekarai Nagar
9	ADP hadapasar
10	Gondhalenagar
11	Satavwadi
12	Hadapsar gadital','12','06:00
06:50
07:40
08:30
09:20
10:15
11:45
12:45
14:00
14:50
15:40
16:30
17:50
18:50
19:50
20:50
06:15
07:05
07:55
08:45
09:35
10:30
12:00
13:00
14:15
15:05
15:55
16:45
18:05
19:05
20:05
21:05
06:35
07:25
08:15
09:05
09:55
10:50
12:20
13:20
14:35
15:25
16:15
17:05
18:25
19:25
20:25
21:25','06:25
07:15
08:05
08:55
09:45
10:45
12:15
13:15
14:25
15:15
16:05
16:55
18:20
19:20
20:20
21:20
06:40
07:30
08:20
09:10
10:00
11:00
12:30
13:30
14:40
15:30
16:20
17:10
18:35
19:35
20:35
21:35
07:00
07:50
08:40
09:30
10:20
11:20
12:50
13:50
15:00
15:50
16:40
17:30
18:55
19:55
20:55
21:55','Active');
INSERT INTO "busTable" VALUES(92,'19','Kondhava Hospital','Shivajinagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','16 KMs','66 Minutes','1	Zila Parishad School Yewlewadi
2	Kondhava Hospital
3	Lonkar Wasti
4	Surya Kiran Khat Karkhana
5	Khadi Machine
6	Somaji Khat Karkhana
7	Talab Farm
8	Mangalben company Sai service
9	Chaitanya Vidyalaya
10	Kondhva Khurd
11	Kondhava Shala
12	NIBM Road
13	Mahatma Phule wasahat
14	Lullanagar
15	Mount Convent School
16	Defence Colony
17	Ganga Dham
18	Marketyard
19	Wakhar Mahamandal Marketyard
20	P and T colony
21	Sant namdeo vidyalay
22	Maharshi nagar
23	Mauli bangala
24	Lakshmi narayan theature
25	Swargate
26	Sarasbag
27	Bhikardas maruti madnir
28	Shanipar
29	A B Chowk
30	Dakshinabhimukh Maruti mandir
31	Shaniwar wada
32	PMC mangala
33	Shivaji putala pmc
34	shimala office shivajinagar
35	Shivajinagar Station','1	Shivajinagar Station
2	Engineering college hostel
3	Shivaji putala
4	PMC Mangala
5	Kasaba Police Chowky
6	Vasant talkies
7	Mandai
8	Shahu chauk
9	Gokul bhavan
10	Swargate
11	Lakshi narayan theature
12	Mauli bangala
13	Maharshi nagar
14	Sant namdeo vidyalay
15	P and T colony
16	Wakhar Mahamandal Marketyard
17	Marketyard
18	Ganga Dham
19	Defence Colony
20	Mount Convent School
21	Lullanagar
22	Mahatma Phule Vasahat
23	N I B M Road
24	Kondhva Shala
25	Kondhava Khurd
26	Chaitanya Vidyalaya
27	Mangalben company Sai service
28	Talab Farm
29	Somaji Khat Karkhana
30	Khadi Machine
31	Surya Kiran Khat Karkhana
32	Lonkar Wasti
33	Kondhava Hospital
34	Zila Parishad School Yewlewadi','35','06:00
08:05
10:20
13:05
15:15
17:30
19:45
08:20
10:35
13:20
15:30
17:45
20:00
06:30
08:40
10:55
13:35
15:45
18:00
20:15
09:00
11:15
13:55
16:05
18:20
20:35
07:05
09:20
12:05
14:15
16:25
18:40
21:25
07:20
09:35
12:20
14:30
16:45
19:00
21:45
07:35
09:50
12:35
14:45
17:00
19:15
22:05
07:50
10:05
12:50
15:00
17:15
19:30
22:20','07:00
09:10
11:25
14:10
16:25
18:35
20:55
09:25
11:40
14:25
16:40
18:50
21:10
07:30
09:45
12:00
14:40
16:55
19:05
21:25
10:05
12:20
15:00
17:15
19:25
21:45
08:10
10:25
13:10
15:20
17:35
19:45
22:30
08:25
10:40
13:25
15:40
17:50
20:05
22:45
08:40
10:55
13:40
15:55
18:05
20:25
23:00
08:55
11:10
13:55
16:10
18:20
20:40
23:15','Active');
INSERT INTO "busTable" VALUES(93,'190','Hadapsar gadital','Phursungi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','6 KMs','27 Minutes','1	Hadapsar gadital
2	Satavwadi
3	Gondhalenagr
4	ADP pune
5	Bhekrai nagar
6	Power House Phursungi
7	Harpale wasti
8	Jai bhavani godown
9	Phursungi','1	Phursungi
2	Jai bhavani godown
3	Harpale wasti
4	Power house fursungi
5	Bhekarai Nagar
6	ADP hadapasar
7	Gondhalenagar
8	Satavwadi
9	Hadapsar gadital','9','05:35
06:25
07:15
08:05
09:00
10:00
11:30
12:30
14:15
15:05
15:55
16:45
17:40
18:40
20:10
21:10
06:40
07:30
08:20
09:15
10:15
11:10
12:45
13:45
15:20
16:10
17:00
17:55
18:55
19:50
21:25
22:30
06:00
06:50
07:40
08:30
09:30
10:25
11:55
13:05
14:40
15:30
16:20
17:10
18:10
19:05
20:30
21:35
07:05
07:55
08:45
09:45
10:40
11:40
13:10
14:05
14:55
15:45
16:35
17:25
18:25
19:20
20:50
21:55','06:00
06:50
07:40
08:30
09:30
10:30
12:00
13:00
14:40
15:30
16:20
17:10
18:10
19:10
20:40
21:35
07:05
07:55
08:45
09:45
10:45
11:40
13:15
14:15
15:45
16:35
17:25
18:25
19:25
20:25
21:50
22:50
06:25
07:15
08:05
08:55
09:55
10:55
12:25
13:25
15:05
15:55
16:45
17:35
18:35
19:35
21:00
22:05
07:30
08:20
09:10
10:10
11:10
12:10
13:40
14:25
15:20
16:10
17:00
17:50
18:50
19:50
21:15
22:20','Active');
INSERT INTO "busTable" VALUES(94,'191','Pune Station','Kondhava hospital','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','49 Minutes','1	Pune Station Depot
2	GPO
3	Collector kacheri
4	Sadhu wasvani chauk
5	General post office
6	West end talkies
7	Bombay garaje
8	juna pul gate
9	Mahatma gandhi stand
10	Military Hospital Wanvadi
11	Wanvadi Corner
12	Wanvadi Bazar
13	Netajinagar
14	Lullanagar
15	Mahatma Phule Vasahat
16	N I B M Road
17	Kondhva Shala
18	Kondhava Khurd
19	Chaitanya Vidyalaya
20	Mangalben company Sai service
21	Talab Farm
22	Somaji Khat Karkhana
23	Khadi Machine
24	Surya Kiran Khat Karkhana
25	Lonkar Wasti
26	Kondhava Hospital','1	Kondhava Hospital
2	Lonkar Wasti
3	Surya Kiran Khat Karkhana
4	Khadi Machine
5	Somaji Khat Karkhana
6	Talab Farm
7	Mangalben company Sai service
8	Chaitanya Vidyalaya
9	Kondhva Khurd
10	Kondhava Shala
11	NIBM Road
12	Mahatma Phule wasahat
13	Lullanagar
14	Netajinagar
15	Wanvadi Bazar
16	Wanvadi Corner
17	Military Hospital Wanvadi
18	Mahatma gandhi stand
19	Juna pul gate
20	Bombay Garage
21	West end talkies
22	GPO
23	Collector kacheri
24	Pune Station Depot','24','05:20
06:25
08:10
10:05
12:30
14:45
16:20
18:15
20:40
22:15','05:50
07:15
09:05
11:00
13:25
15:30
17:15
19:10
21:25
23:00','Active');
INSERT INTO "busTable" VALUES(95,'192','Hadapsar gadital','Undrigaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','8 KMs','35 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Mohammadwadi jakat naka
4	Kanifnath Soc.
5	Sasane Nagar
6	Railway Crossing Mohammadwadi
7	sayadnagar
8	Hari Hareshwar mandir
9	Wadkar mala
10	Tarawade wasti
11	Mahamdwadi Gaon
12	Mohammadwadi shala
13	Kadwasti
14	Khole wasti
15	Punekar wasti
16	Undrigaon ','1	Undrigaon
2	Punekar wasti
3	Khole wasti
4	Kadwasti
5	Mohammadwadi shala
6	Mahamdwadi Gaon
7	Tarawade wasti
8	Wadkar mala
9	Hari Hareshwar mandir
10	sayadnagar
11	Railway Crossing Mohammadwadi
12	Sasane Nagar
13	Kanifnath Soc.
14	Mohammadwadi jakat Naka
15	Hadapsar gaon
16	Hadapsar gadital','16','06:30
07:40
08:50
10:00
11:40
12:50
14:15
15:25
16:35
17:45
18:55
20:35
06:50
08:00
09:10
10:20
12:00
13:10
14:35
15:45
16:55
18:05
19:15
20:55
07:15
08:25
09:35
10:45
12:25
13:35
15:00
16:10
17:20
18:30
19:45
21:20','07:05
08:15
09:25
10:35
12:15
13:25
14:50
16:00
17:10
18:20
19:30
21:10
07:25
08:35
09:45
10:55
12:35
13:45
15:10
16:20
17:30
18:40
19:50
21:30
07:50
09:00
10:10
11:20
13:00
14:10
15:35
16:45
17:55
19:05
20:15
21:55','Active');
INSERT INTO "busTable" VALUES(96,'195','Hadapsar gadital','Holkarwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','40 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Mohammadwadi jakat naka
4	Kanifnath Soc.
5	Sasane Nagar
6	Chintamani Nagar
7	Ganga Village
8	Satav Nagar
9	Sawant College
10	Ramya Nagari
11	Gavane Nagar
12	Handewadi gaon
13	Autadewadi Phata
14	Holkarwadi','1	Holkarwadi
2	Autadewadi Phata
3	Handewadi gaon
4	Gavane Nagar
5	Ramya Nagari
6	Sawant College
7	Satav Nagar
8	Ganga Village
9	Chintamani Nagar
10	Sasane Nagar
11	Kanifnath Soc.
12	Mohammadwadi jakat Naka
13	Hadapsar gaon
14	Hadapsar gadital','14','05:50
07:10
08:30
09:50
11:40
13:00
14:20
15:40
17:00
18:20
19:40
21:30
06:30
07:50
09:10
10:30
12:20
13:40
15:00
16:20
17:40
19:00
20:20
22:10','06:30
07:50
09:10
10:30
12:20
13:40
15:00
16:20
17:40
19:00
20:20
22:10
07:10
08:30
09:50
11:10
13:00
14:20
15:40
17:00
18:20
19:40
21:00
22:50','Active');
INSERT INTO "busTable" VALUES(97,'196','Swargate','Kaleboratenagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','51 Minutes','1	Swargate
2	Ghorpade peth colony
3	S T Divisional office
4	Meera society
5	Golibar maidan
6	juna pul gate
7	Mahatma gandhi stand
8	Race course
9	Bhauraba nala
10	Fatimanagar Municipal shala
11	Kalubai mandir
12	Ram tekadi
13	Vaidwadi
14	Gurushankar math
15	Magarpatta
16	Hadapsar gaon
17	Mohammadwadi jakat naka
18	Kanifnath Soc.
19	Sasane Nagar
20	Binawat Township
21	Sasane Hingane township
22	Nirmal Township
23	Ganesh mandir
24	Kaleborate Nagar','1	Kaleborate Nagar
2	Ganesh mandir
3	Nirmal Township
4	Sasane Hingane township
5	Binawat Township
6	Sasane Nagar
7	Kanifnath Soc.
8	Mohammadwadi jakat Naka
9	Hadapsar gaon
10	Magarpatta
11	Gurushankar math
12	Vaidwadi
13	Ram tekadi
14	Kalubai mandir solapur road
15	Fatimanagar Municipal shala
16	Bhauraba nala
17	Race course
18	Mahatma gandhi stand
19	Golibar maidan
20	Meera society
21	S T Divisional office
22	Ghorpadi Peth Colony
23	Swargate police line
24	Swargate','24','06:30
08:00
09:35
11:15
13:25
16:55
18:30
20:10','07:15
08:45
10:25
12:35
14:10
17:40
19:20
21:30','Active');
INSERT INTO "busTable" VALUES(98,'197','Hadapsar gadital','Kothrud Depot','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','81 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	New hind school
14	Juna motor stand
15	Kashiwadi
16	Ramoshi gate
17	A D camp chauk
18	Nana peth
19	Alpana Talkies
20	Sonya Maruti Chowk
21	City post
22	Mandai
23	Kunte Chauk
24	Gokhale hall
25	Vijay Talkies
26	Alka talkies
27	Deccan corner sambhaji pool
28	Garware college
29	Petrol Pump Karve Road
30	Nal Stop
31	SNDT college
32	Paud phata police chauky
33	More vidyalaya
34	LIC colony
35	Anand nagar paud road
36	Vanaz Corner
37	Vanaz company
38	Paramhans corner
39	Kachara depot
40	Bharti nagar
41	kothrud depot','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Anand nagar paud road
7	LIC Colony Paud Road
8	More vidyalaya
9	Paudphata police chowky
10	SNDT college
11	Nal stop
12	Petrol pump karve road
13	Deccan Corner Sambhaji Pul Corner
14	Chitrashala
15	Sadashiv Peth Houd
16	Mandai
17	Gadikhana
18	Shitaladevi chauk
19	Ganjpeth Police Chowky
20	Ramoshi gate
21	Juna motor stand
22	New hind school
23	juna pul gate
24	Mahatma gandhi stand
25	Race course
26	Bhauraba nala
27	Fatimanagar Municipal shala
28	Kalubai mandir
29	Ram tekadi
30	Vaidwadi
31	Gurushankar math
32	Magarpatta
33	Hadapsar gaon
34	Hadapsar gadital','41','05:25
08:05
11:15
14:00
16:40
20:00
05:45
08:25
11:35
14:25
17:05
20:25
06:10
08:45
11:55
14:45
17:25
20:45
06:35
09:10
12:20
15:10
17:50
21:10
06:50
09:35
12:45
15:30
18:10
21:30
07:20
10:05
13:15
16:00
18:40
22:00
07:35
10:20
13:35
16:15
18:55
22:45','06:45
09:25
12:30
15:20
18:10
21:20
07:05
09:45
12:55
15:45
18:35
21:45
07:25
10:05
13:15
16:05
18:55
22:05
07:50
10:30
13:40
16:30
19:20
22:30
08:10
10:55
14:05
16:50
19:40
22:50
08:40
11:25
14:35
17:20
20:10
23:20
08:55
11:45
14:55
17:35
20:25
00:00','Active');
INSERT INTO "busTable" VALUES(99,'197','Hadapsar gadital','Manjri','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','45 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Tilekar wasti
5	Magarpatta school
6	Megarpatta City
7	Bapusaheb Magar wasti
8	Keertane Bag
9	Dhamale wasti Mundhva
10	Mundhva Gaon
11	Shinde Mundhava
12	Keshavnagar pul
13	Shinde wasti
14	KRB Workshop
15	Lonkar wasti
16	Mhasoba wasti
17	Ghavate nagar
18	VSI company
19	Manjri bu.','1	Manjri bu.
2	VSI company
3	Ghavate nagar
4	Mhasoba wasti
5	Lonkar wasti
6	KRB Workshop
7	Shinde wasti
8	Keshavnagar Pool
9	Shinde Wasti Mundhva
10	Mundhava Goan
11	Dhamale wasti Mundhava
12	Keertane Bag
13	Bapusaheb Magar Vasti
14	Magarpatta City
15	Magarpatta School
16	Tilekar Wasti
17	Magarpatta
18	Hadapsar gaon
19	Hadapsar gadital','19','05:50
07:20
08:50
10:50
12:20
14:00
15:30
17:00
18:30
20:30
06:35
08:05
09:35
11:35
13:05
14:45
16:15
17:45
19:15
21:15','06:35
08:05
09:35
11:35
13:05
14:45
16:15
17:45
19:15
21:15
07:20
08:50
10:20
12:20
13:50
15:30
17:00
18:30
20:00
22:00','Active');
INSERT INTO "busTable" VALUES(100,'1R','Hadapsar gadital','Swargate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','37 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Golibar maidan
13	Meera society
14	S T Divisional office
15	Ghorpadi Peth Colony
16	Swargate police line
17	Swargate','1	Swargate
2	Ghorpade peth colony
3	S T Divisional office
4	Meera society
5	Golibar maidan
6	juna pul gate
7	Mahatma gandhi stand
8	Race course
9	Bhauraba nala
10	Fatimanagar Municipal shala
11	Kalubai mandir
12	Ram tekadi
13	Vaidwadi
14	Gurushankar math
15	Magarpatta
16	Hadapsar gaon
17	Hadapsar gadital','17','20:15
21:35
22:55
00:45
01:55
03:05
20:55
22:15
23:40
01:20
02:30
03:40','20:55
22:15
23:35
01:20
02:30
03:40
21:35
22:55
00:15
01:55
03:05
04:15','Active');
INSERT INTO "busTable" VALUES(101,'1S','Bharati Vidyapeeth','Shanipar Mandai','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','41 Minutes','1	PICT Bharati vidyapeeth
2	Rajaram Gas agency
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Bhikardas maruti madnir
17	Shanipar
18	Mandai','1	Mandai
2	Mandai
3	Shahu chauk
4	Gokul bhavan
5	Swargate
6	Lakshi narayan theature
7	Panchami hotel
8	Bhapkar Petrol Pump City pride
9	Aranyeshwar Corner
10	Natu Bag
11	Padmavati corner
12	Vishweshwar Bank KK market
13	Balaji nagar
14	Chaitanya nagar
15	Bharti vidyapeeth gate
16	Katraj dairy Sarpodyan
17	More bag
18	Rajaram Gas agency
19	Chandrabhaga Restaurant
20	Ganpati mandir
21	PICT Bharati vidyapeeth','18','06:45
08:05
09:25
10:45
12:40
15:15
16:35
17:55
19:45
21:15
07:50
09:10
10:30
11:50
13:40
15:00
16:20
17:40
08:40
10:00
11:20
13:10
14:30
15:50
17:10
18:30','07:25
08:45
10:05
11:25
13:30
15:55
17:25
18:35
20:25
21:55
08:30
09:50
11:10
12:30
14:30
15:40
17:00
18:20
09:20
10:40
12:00
13:50
15:10
16:30
17:50
19:10','Active');
INSERT INTO "busTable" VALUES(102,'2','Katraj bus stand','Shivajinagar Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','52 Minutes','1	Katraj bus stand
2	Katraj dairy Sarpodyan
3	Bharti vidyapeeth gate
4	Chaitanya nagar
5	Balaji nagar
6	Vishweshwar Bank KK market
7	Padmavati corner
8	Natu bag
9	Aranyeshwar Corner
10	Bhapkar petrol pump City Pride
11	Panchami hotel
12	Laxmi Narayan Theature
13	Swargate
14	Sarasbag
15	Bhikardas maruti madnir
16	Shanipar
17	A B Chowk
18	Dakshinabhimukh Maruti mandir
19	Shaniwar wada
20	PMC mangala
21	Shivaji putala pmc
22	shimala office shivajinagar
23	Shivajinagar Station','1	Shivajinagar Station
2	Sancheti Hospital
3	Shivaji putala
4	PMC Mangala
5	Kasaba Police Chowky
6	Vasant talkies
7	Mandai
8	Shahu chauk
9	Gokul bhavan
10	Swargate
11	Lakshi narayan theature
12	Panchami hotel
13	Bhapkar Petrol Pump City pride
14	Aranyeshwar Corner
15	Natu Bag
16	Padmavati corner
17	Vishweshwar Bank KK market
18	Balaji nagar
19	Chaitanya nagar
20	Bharti vidyapeeth gate
21	Katraj dairy Sarpodyan
22	Katraj bus stand','23','05:20
07:00
08:45
11:00
12:50
14:20
16:00
17:45
20:10
07:05
08:50
11:10
12:55
16:10
17:55
20:15
22:00
05:30
07:10
08:55
11:15
14:30
16:15
18:00
20:20
05:40
07:20
09:05
11:25
14:40
16:25
18:10
20:30
07:25
09:10
11:30
13:10
16:30
18:15
20:35
22:15
05:50
07:30
09:15
11:35
14:50
16:35
18:20
20:40
07:40
09:25
11:45
13:25
16:45
18:30
20:50
22:30
06:10
07:50
09:35
11:55
15:00
16:50
18:35
20:55
07:55
09:40
12:00
13:40
16:55
18:45
21:05
22:45
06:20
08:00
09:45
12:05
15:10
17:00
18:50
21:10
08:05
09:50
12:10
13:50
15:20
17:10
19:00
21:20
06:30
08:10
09:55
12:15
15:30
17:15
19:05
21:25
08:20
10:35
12:25
14:05
17:20
19:40
21:30
23:15
06:40
08:25
10:10
12:30
15:40
17:25
19:15
21:35
08:30
10:15
12:35
14:15
15:50
17:30
19:55
21:40
06:50
08:35
10:20
12:40
17:35
19:25
21:45
23:30','06:10
07:50
09:40
11:55
13:45
15:10
16:55
18:40
21:00
07:55
09:45
12:00
13:40
17:00
18:50
21:05
22:50
06:20
08:00
09:50
12:05
15:20
17:05
18:55
21:10
06:30
08:10
10:00
12:15
15:30
17:15
19:05
21:20
08:15
10:05
12:20
14:00
17:20
19:10
21:25
23:05
06:40
08:20
10:10
12:25
15:40
17:25
19:15
21:30
08:30
10:20
12:35
14:10
17:35
19:25
21:40
23:20
07:00
08:40
10:30
12:45
15:55
17:40
19:30
21:45
08:45
10:35
12:50
14:30
17:50
19:40
21:55
23:35
07:10
08:50
10:40
12:55
16:05
17:55
19:45
22:05
08:55
10:45
13:00
14:40
16:15
18:05
19:55
22:10
07:20
09:00
10:50
13:05
16:20
18:10
20:00
22:15
09:10
11:30
13:15
14:55
18:15
20:35
22:30
23:55
07:30
09:15
11:05
13:20
16:30
18:20
20:10
22:25
09:20
11:40
13:25
15:05
16:40
18:25
20:45
22:30
07:40
09:25
11:15
13:30
18:30
20:20
22:35
00:20','Active');
INSERT INTO "busTable" VALUES(104,'20','Sahakar Nagar','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','45 Minutes','1	Sahakar Nagar
2	Kranti Society
3	Sarang Society
4	Lakshminagar Corner
5	Bank of Maharashtra Parvati gaon
6	Mitramandal Sabhagruh
7	Laxmi Narayan Theature
8	Swargate
9	Ghorpade peth colony
10	S T Divisional office
11	Meera society
12	Golibar maidan
13	Juna pul gate
14	Bombay Garage
15	West end talkies
16	GPO
17	Collector kacheri
18	Sasoon hospital
19	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	General post office
4	West end talkies
5	Bombay garaje
6	juna pul gate
7	Golibar maidan
8	Meera society
9	S T Divisional office
10	Ghorpadi Peth Colony
11	Swargate police line
12	Swargate
13	Parvati payatha
14	Mitramandal Sabhagruh
15	Bank of Maharashtra Parvati gaon
16	Lakshminagar Corner
17	Sarang Society
18	Kranti Society
19	Sahakar Nagar','19','07:45
09:15
10:45
16:00
17:30','08:30
10:00
11:30
16:45
18:15','Active');
INSERT INTO "busTable" VALUES(105,'200','Swargate','Sadesataranali','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','54 Minutes','1	Swargate
2	Ghorpade peth colony
3	S T Divisional office
4	Meera society
5	Golibar maidan
6	juna pul gate
7	Mahatma gandhi stand
8	Race course
9	Bhauraba nala
10	Fatimanagar Municipal shala
11	Kalubai mandir
12	Ram tekadi
13	Vaidwadi
14	Gurushankar math
15	Magarpatta
16	Hadapsar gaon
17	Smashanbhumi Rasta Hadapsar
18	Sadhana Vidyalaya
19	Sadu nana wasti
20	Vitthalwadi Mandir Sadesataranali
21	Tupe Mala
22	Lukad Wasti
23	Sadesataranali','1	Sadesataranali
2	Lukad Wasti
3	Tupe mala
4	Vitthal mandir Sadesatara nali
5	Sadu nana wasti
6	Sadhana Vidyalay
7	Smashanbhumi rasta Hadapsar
8	Hadapsar gaon
9	Magarpatta
10	Gurushankar math
11	Vaidwadi
12	Ram tekadi
13	Kalubai mandir solapur road
14	Fatimanagar Municipal shala
15	Bhauraba nala
16	Race course
17	Mahatma gandhi stand
18	Golibar maidan
19	Meera society
20	S T Divisional office
21	Ghorpadi Peth Colony
22	Swargate police line
23	Swargate','23','07:20
09:00
10:40
12:50
15:40
17:20
19:50
21:40','08:10
09:50
11:30
13:40
16:30
18:20
20:50
22:40','Active');
INSERT INTO "busTable" VALUES(106,'201','Alandi bus stand','Hadapsar gadital','Mon, Tue, Wed, Thu, Fri, Sat, Sun','33 KMs','94 Minutes','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Dnyaneshwar June Nivas/Sai Mandir
10	Sai mandir
11	Moje vidyalaya
12	Bhosari phata
13	Telco godown
14	Dattanagar
15	Mitra sahkar nagar
16	Dighigaon
17	AIT college
18	Wireless colony
19	Parade ground
20	Mhaske wasti
21	Kalasgaon
22	R D colony
23	Vishrantwadi
24	Vishrantwadi corner
25	Kasturba general hospital
26	Gandhi Acid Company
27	Tingre nagar Shanti nagar
28	Kekan ges agency
29	Five nine area
30	Sanjay park
31	Nagpur Chawl
32	Yerwada post office
33	Vikrikar karyalaya
34	Netaji school
35	White House
36	Yerwada
37	Band garden
38	Guruprasad bangala
39	Wadia college
40	Jahangir Hospital
41	General post office
42	West end talkies
43	Bombay garaje
44	Juna pul gate
45	Mahatma gandhi stand
46	Race course
47	Bhauraba nala
48	Fatimanagar Municipal shala
49	Kalubai mandir
50	Ram tekadi
51	Vaidwadi
52	Gurushankar math
53	Magarpatta
54	Hadapsar gaon
55	Hadapsar gadital','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri
17	Pune station
18	Ruby hall
19	Guruprasad bangala
20	Band garden
21	Yerwada
22	White House
23	Netaji school
24	Vikrikar Karyalaya
25	Yerwada post office
26	Nagpur chawl
27	Sanjay park
28	Five nine area
29	Kekan gas agency
30	Tingre nagar Shanti nagar
31	Gandhi Acid Company
32	Kasturba general hospital
33	Vishrantwadi corner
34	Vishrantwadi
35	R D colony
36	kalasgaon
37	Mhaske wasti
38	Parade ground
39	Wireless colony
40	AIT college
41	Dighigaon
42	Mitra sahakar nagar
43	Dattanagar
44	Telco godown
45	Bhosari phata
46	Moje vidyalaya
47	Sai madnir
48	Nirma company
49	Gokhale Mala Sankalpa Garden
50	Wadmukhwadi
51	Chincheche jhad
52	Charholi phata
53	Sai Lila nagar Kate Wasti
54	Moshi Phata Dehu Phata
55	Alandi bus stand','55','07:00
10:00
13:40
16:45
20:15
07:45
10:45
14:25
17:30
21:00
08:25
11:25
15:05
18:15
21:45
09:10
12:10
15:50
19:00
22:30','05:40
08:30
12:10
15:15
18:45
06:25
09:15
12:55
16:00
19:30
07:05
09:55
13:35
16:45
20:15
07:50
10:40
14:20
17:30
21:00','Active');
INSERT INTO "busTable" VALUES(107,'202','Hadapsar gadital','Ganpati matha','Mon, Tue, Wed, Thu, Fri, Sat, Sun','19 KMs','82 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	New hind school
14	Juna motor stand
15	Kashiwadi
16	Ramoshi gate
17	A D camp chauk
18	Nana peth
19	Alpana Talkies
20	Sonya Maruti Chowk
21	City post
22	Mandai
23	Kunte Chauk
24	Gokhale hall
25	Vijay Talkies
26	Alka talkies
27	Deccan Corner Sambhaji Pul Corner
28	Garware college
29	Petrol Pump Karve Road
30	Nal Stop
31	SNDT college
32	Paud Phata Dashabhuja Ganpati
33	Maruti mandir karve road
34	Karve putala
35	Kothrud Stand
36	Dahanukar colony
37	Wadache Jhad Bhairavnath Mandir
38	Karvenagar
39	Warje Jakatnaka
40	Tapodham
41	Warje Malwadi
42	Dnanesh society
43	Ganpati matha','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Chitrashala
19	Sadashiv Peth Houd
20	Mandai
21	Gadikhana
22	Shitaladevi chauk
23	Ganjpeth Police Chowky
24	Ramoshi gate
25	Juna motor stand
26	New hind school
27	juna pul gate
28	Race course
29	Bhauraba nala
30	Fatimanagar Municipal shala
31	Kalubai mandir
32	Ram tekadi
33	Vaidwadi
34	Gurushankar math
35	Magarpatta
36	Hadapsar gaon
37	Hadapsar gadital','43','05:20
08:00
11:30
14:30
17:25
20:55
05:40
08:20
11:50
14:45
17:40
21:10
05:55
08:35
12:05
15:00
17:55
21:25
06:15
08:55
12:25
15:20
18:15
21:45
06:30
09:10
12:40
15:35
18:35
22:00
06:50
09:30
13:00
15:50
18:45
22:15
07:05
09:45
13:15
16:05
19:00
22:30
07:20
10:30
13:30
16:20
19:30
22:30
07:35
10:10
13:45
16:40
19:55
22:55
07:50
10:55
13:55
17:00
20:20
23:20','06:40
09:30
12:55
15:55
18:55
22:25
07:00
09:50
13:15
16:10
19:10
22:40
07:15
10:05
13:30
16:25
19:25
22:55
07:35
10:25
13:50
16:45
19:45
23:15
07:50
10:40
14:05
17:00
20:00
23:00
08:10
11:00
14:25
17:15
20:15
23:45
08:25
11:15
14:40
17:30
20:30
00:00
08:40
12:00
14:55
17:45
21:00
08:55
11:45
15:10
18:05
21:25
09:10
12:20
15:20
18:25
21:50','Active');
INSERT INTO "busTable" VALUES(108,'203','Phursungi','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','46 Minutes','1	Phursungi
2	Jai bhavani godown
3	Harpale wasti
4	Power house fursungi
5	Bhekarai Nagar
6	ADP hadapasar
7	Gondhalenagar
8	Satavwadi
9	Hadapsar gadital
10	Hadapsar gaon
11	Magarpatta
12	Gurushankar math
13	Vaidwadi
14	Ram tekadi
15	Kalubai mandir solapur road
16	Fatimanagar Municipal shala
17	Bhauraba nala
18	Race course
19	Mahatma gandhi stand
20	Juna pul gate
21	Bombay Garage
22	West end talkies
23	GPO
24	Collector kacheri
25	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	General post office
4	West end talkies
5	Bombay garaje
6	juna pul gate
7	Mahatma gandhi stand
8	Race course
9	Bhauraba nala
10	Fatimanagar Municipal shala
11	Kalubai mandir
12	Ram tekadi
13	Vaidwadi
14	Gurushankar math
15	Magarpatta
16	Hadapsar gaon
17	Hadapsar gadital
18	Satavwadi
19	Gondhalenagr
20	ADP pune
21	Bhekrai nagar
22	Power House Phursungi
23	Harpale wasti
24	Jai bhavani godown
25	Phursungi','25','06:00
07:20
08:40
10:00
11:50
13:10
14:35
15:55
18:35
20:25
21:45
06:30
07:50
09:10
10:30
12:20
13:40
15:05
16:25
17:45
19:05
20:55
22:15
06:55
08:15
09:35
10:55
12:45
14:05
15:30
16:50
18:10
19:30
21:20
22:45
06:45
08:25
10:00
12:15
13:55
16:05
17:40
19:20
21:30
06:45
08:40
11:15
13:15
15:20
17:20
20:10
22:30
07:35
09:35
12:05
14:00
16:05
18:05
20:55','06:40
08:00
09:20
10:40
12:30
13:50
15:15
16:35
19:15
21:05
22:25
07:10
08:30
09:45
11:10
13:00
14:20
15:45
17:05
18:25
19:45
21:35
22:55
07:30
08:55
10:15
11:35
13:25
14:40
16:10
17:25
18:50
20:15
22:00
23:20
07:35
09:15
10:50
13:05
14:45
16:55
18:30
20:10
22:30
07:45
09:45
12:15
14:15
16:20
18:30
21:20
08:35
10:35
13:00
15:00
17:05
19:05
22:05','Active');
INSERT INTO "busTable" VALUES(109,'203P','Pune Station','Hadapsar gadital','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','41 Minutes','1	Central building
2	Sadhu wasvani chauk
3	General post office
4	West end talkies
5	Bombay garaje
6	juna pul gate
7	Mahatma gandhi stand
8	Race course
9	Bhauraba nala
10	Fatimanagar Municipal shala
11	Kalubai mandir
12	Ram tekadi
13	Vaidwadi
14	Gurushankar math
15	Magarpatta
16	Hadapsar gaon
17	Hadapsar gadital','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri','17','06:00
07:05
08:25
09:45
11:05
12:55
14:35
16:00
17:30
19:00
20:30
06:15
07:20
08:40
10:00
11:30
13:30
14:50
16:15
17:45
19:20
06:30
07:35
08:55
10:15
11:50
13:45
15:05
16:30
18:00
19:40
06:45
07:50
09:10
10:30
12:15
14:15
15:40
17:05
18:35
20:05','06:30
07:45
09:05
10:25
11:45
13:35
15:15
16:45
18:15
19:45
21:10
06:45
08:00
09:20
10:40
12:10
14:10
15:30
17:00
18:30
20:05
07:00
08:15
09:35
10:55
12:30
14:25
15:45
17:15
18:45
20:25
07:15
08:30
09:50
11:15
12:55
14:55
16:20
17:50
19:20
20:50','Active');
INSERT INTO "busTable" VALUES(110,'204','Hadapsar gadital','Chinchwad gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','31 KMs','75 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri
17	Ambedkar bhavan
18	Juna Bajar
19	Kumbhar wada
20	PMC
21	Shivaji putala pmc
22	shimala office shivajinagar
23	Masoba gate
24	Pumping station
25	Pune central
26	E square
27	Rangehills Corner
28	Rajbhavan
29	Boys batalian
30	Kasturba vasahat
31	Sindh colony gate 2
32	Bremen chauk
33	Body gate
34	Aundh gaon
35	Sangvi phata
36	Aundh chest hospital
37	Aundh post office
38	ESI Hospital
39	Rakshak chauk
40	Military Stores
41	Wakad phata
42	Jagtap Dairy
43	Kaspate Vasti
44	Kalewadi phata
45	16 Number
46	Laxman nagar
47	Dange chowk
48	Thergaon phata
49	Padmji Paper Mill
50	Dattanagar Chinchwad
51	Birla Hospital
52	Jakatnaka pavanapul
53	Walhekarwadi phata
54	Chafekar chauk
55	Chinchwad gaon','1	Chinchwad gaon
2	Chafekar chauk
3	Jai Hind Vidyalaya
4	Jakatnaka Pavanapool
5	Birla hospital
6	Dattanagar Chinchwad
7	Padmji Paper Mill
8	Thergaon phata
9	Dange chowk
10	Laxman nagar
11	16 Number
12	Kalewadi phata
13	Kaspate Vasti
14	Jagtap Dairy
15	Wakad phata
16	Military Stores
17	Rakshak chauk
18	ESI Hospital
19	Aundh post office
20	Aundh chest hospital
21	Sangvi Phata
22	Aundh gaon
23	Body gate
24	Bremen chauk
25	Sindh Colony Gate2
26	Kasturba vasahat
27	Boys Batalian
28	Pune University Gate
29	Rangehills Corner
30	E Square
31	Pune central
32	Pumping station
33	Masoba gate
34	shimala office shivajinagar
35	Sancheti Hospital
36	Shivaji putala pmc
37	PMC Mangala
38	Kumbhar Wada
39	Juna Bajar
40	Ambedkar bhavan
41	Sadhu wasvani chauk
42	General post office
43	West end talkies
44	Bombay garaje
45	juna pul gate
46	Mahatma gandhi stand
47	Race course
48	Bhauraba nala
49	Fatimanagar Municipal shala
50	Kalubai mandir
51	Ram tekadi
52	Vaidwadi
53	Gurushankar math
54	Magarpatta
55	Hadapsar gaon
56	Hadapsar gadital','55','05:20
08:20
11:50
15:00
18:50
21:50
05:35
08:35
12:05
15:20
19:10
22:10
05:50
08:50
12:20
15:40
19:30
22:30
06:05
09:05
12:35
16:00
19:50
22:50
06:20
09:20
12:50
16:20
20:10
23:10
06:35
09:35
13:05
16:40
20:30
23:30
06:50
09:50
13:20
17:00
20:50
23:50
07:05
10:05
13:35
17:20
21:10
00:10
07:20
10:20
13:50
17:35
21:30
00:30
07:35
10:35
14:05
17:55
21:50
00:50
07:50
10:50
14:20
18:15
22:10
01:10
08:05
11:05
14:35
18:35
22:35
01:30','06:50
09:50
13:20
16:30
20:20
07:05
10:05
13:35
16:50
20:40
07:20
10:20
13:50
17:10
21:00
07:35
10:35
14:05
17:30
21:20
07:50
10:50
14:20
17:50
21:40
08:05
11:05
14:35
18:10
22:00
08:20
11:20
14:50
18:30
22:20
08:35
11:35
15:05
18:50
22:40
08:50
11:50
15:20
19:05
23:00
09:05
12:05
15:35
19:25
23:20
09:20
12:20
15:50
19:45
23:40
09:35
12:35
16:05
20:05
00:00','Active');
INSERT INTO "busTable" VALUES(111,'205','Hadapsar gadital','Sangvi gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','27 KMs','86 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Tilekar wasti
5	Magarpatta school
6	Megarpatta City
7	Bapusaheb Magar wasti
8	Keertane Bag
9	Dhamale wasti Mundhva
10	Mundhva Gaon
11	Mundhava Gaon Corner
12	Diamond watch Company
13	Kachare wasti
14	Tadi Gupta Wanaspati Sanshodhan Kendra
15	Farashi Karkhana
16	Pingale wasti
17	Army college
18	Anant Talkies
19	Ghorpadi Shala
20	Ghorpadi Post Office
21	Family Camp
22	West end talkies
23	GPO
24	Collector kacheri
25	Ambedkar bhavan
26	Juna Bajar
27	Kumbhar wada
28	PMC
29	Shivaji putala pmc
30	shimala office shivajinagar
31	Masoba gate
32	Pumping station
33	Pune central
34	E square
35	Rangehills Corner
36	Pune University Gate
37	chavan nagar university road
38	Sakal nagar
39	Sindh colony
40	Baner phata
41	Sanewadi
42	Anand park sindhi colony
43	ITI parihar Chauk
44	Police workshop
45	Body gate
46	Aundh gaon
47	Sangvi Phata
48	Nurses Quarters
49	Ba ra gholap
50	Navi Sangvi
51	Panyachi taki sangvi
52	shitole nagar corner
53	Anand nagar
54	Sangvi goan
55	Vasantdada Putala','1	Vasantdada Putala
2	Sangvi goan
3	Anand nagar
4	shitole nagar corner
5	panyachi takai sangvi
6	Navi Sangvi
7	Bara gholap
8	Nurses Quarters
9	Sangvi Phata
10	Aundh gaon
11	Body gate
12	ITI parihar chauk
13	Aanand park sindhi colony
14	Sanewadi
15	Baner phata
16	Sindh colony
17	Sakal nagar
18	Chavan Nagar University Road
19	Pune University Gate
20	Rangehills Corner
21	E Square
22	Pune central
23	Pumping station
24	Masoba gate
25	shimala office shivajinagar
26	Sancheti Hospital
27	Shivaji putala pmc
28	PMC Mangala
29	Kumbhar Wada
30	Juna Bajar
31	Ambedkar bhavan
32	Collector kacheri
33	Sadhu wasvani chauk
34	General post office
35	West end talkies
36	Family camp
37	Ghorpadi Post Office
38	Ghorpadi Shala
39	Anant Talkies
40	Army College
41	Pingle Wasti
42	Farshi karkhana
43	Tadi Gupta Wanaspati Sanshodhan Kendra
44	Kachare Wasti
45	Dimond watch company
46	Mundhava goan corner
47	Mundhava Goan
48	Dhamale wasti Mundhava
49	Keertane Bag
50	Bapusaheb Magar Vasti
51	Magarpatta City
52	Magarpatta School
53	Tilekar Wasti
54	Magarpatta
55	Hadapsar gaon
56	Hadapsar gadital','55','05:30
08:15
11:40
15:00
18:30
06:15
09:00
12:25
15:45
19:15
06:55
09:40
13:05
16:30
20:00
07:40
10:25
13:50
17:15
20:45','06:50
09:40
13:05
16:30
20:00
07:35
10:25
13:50
17:15
20:45
08:15
11:05
14:30
18:00
21:30
09:00
11:50
15:15
18:45
22:15','Active');
INSERT INTO "busTable" VALUES(112,'207','Swargate','Saswad','Mon, Tue, Wed, Thu, Fri, Sat, Sun','33 KMs','82 Minutes','1	Swargate
2	Ghorpade peth colony
3	S T Divisional office
4	Meera society
5	Golibar maidan
6	juna pul gate
7	Mahatma gandhi stand
8	Race course
9	Bhauraba nala
10	Fatimanagar Municipal shala
11	Kalubai mandir
12	Ram tekadi
13	Vaidwadi
14	Gurushankar math
15	Magarpatta
16	Hadapsar gaon
17	Hadapsar gadital
18	Satavwadi
19	Gondhalenagr
20	ADP pune
21	Bhekrai nagar
22	Power House Phursungi
23	Navlakha Godown
24	Mantar Wadi phata
25	Uruli Devachi Phata
26	Bhadale Wasti Devachi Uruli
27	Jalindre Bag
28	Wadi 10 Mail Phata
29	Wadaki nala
30	Rangan Khor
31	Zendewadi
32	Jadhavwadi
33	Kalewadi
34	Dumewadi
35	Divegaon phata
36	Pawarwadi
37	Kirloskar company
38	Waghere college
39	Saswad Bus stand
40	Saswad stand','1	Saswad stand
2	Saswad Bus stand
3	Waghere college
4	Kirloskar company
5	Pawarwadi
6	Divegaon phata
7	Dumewadi
8	Kalewadi
9	Jadhavwadi
10	Zendewadi
11	Rangan Khor
12	Wadaki nala
13	Wadi 10 Mail Phata
14	Jalindre Bag
15	Bhadale Wasti Devachi Uruli
16	Uruli Devachi Phata
17	Mantar Wadi phata
18	Navlakha Godown
19	Power house fursungi
20	Bhekarai Nagar
21	ADP hadapasar
22	Gondhalenagar
23	Satavwadi
24	Hadapsar gadital
25	Hadapsar gaon
26	Magarpatta
27	Gurushankar math
28	Vaidwadi
29	Ram tekadi
30	Kalubai mandir solapur road
31	Fatimanagar Municipal shala
32	Bhauraba nala
33	Race course
34	Mahatma gandhi stand
35	Golibar maidan
36	Meera society
37	S T Divisional office
38	Ghorpadi Peth Colony
39	Swargate police line
40	Swargate','40','06:00
08:35
12:00
14:45
17:45
21:15
06:30
09:05
12:30
15:20
18:20
21:45
07:00
09:35
13:00
15:55
18:55
23:15
07:30
10:10
13:30
16:30
19:35
08:05
10:45
14:05
17:10
20:15','07:15
10:05
13:25
16:15
19:10
22:35
07:50
10:35
13:55
16:45
19:50
23:00
08:15
11:35
14:25
17:25
20:25
23:45
06:00
08:50
12:05
14:55
18:05
21:00
09:20
12:40
15:25
18:40
21:30','Active');
INSERT INTO "busTable" VALUES(113,'207A','Hadapsar gadital','Saswad','Mon, Tue, Wed, Thu, Fri, Sat, Sun','23 KMs','54 Minutes','1	Hadapsar gadital
2	Satavwadi
3	Gondhalenagr
4	ADP pune
5	Bhekrai nagar
6	Power House Phursungi
7	Navlakha Godown
8	Mantar Wadi phata
9	Uruli Devachi Phata
10	Bhadale Wasti Devachi Uruli
11	Jalindre Bag
12	Wadi 10 Mail Phata
13	Wadaki nala
14	Rangan Khor
15	Zendewadi
16	Jadhavwadi
17	Kalewadi
18	Dumewadi
19	Divegaon phata
20	Pawarwadi
21	Kirloskar company
22	Waghere college
23	Saswad Bus stand
24	Saswad stand','1	Saswad stand
2	Saswad Bus stand
3	Waghere college
4	Kirloskar company
5	Pawarwadi
6	Divegaon phata
7	Dumewadi
8	Kalewadi
9	Jadhavwadi
10	Zendewadi
11	Rangan Khor
12	Wadaki nala
13	Wadi 10 Mail Phata
14	Jalindre Bag
15	Bhadale Wasti Devachi Uruli
16	Uruli Devachi Phata
17	Mantar Wadi phata
18	Navlakha Godown
19	Power house fursungi
20	Bhekarai Nagar
21	ADP hadapasar
22	Gondhalenagar
23	Satavwadi
24	Hadapsar gadital','24','05:30
07:20
09:10
11:30
14:30
16:20
18:10
20:30
05:45
07:35
09:25
11:45
14:40
16:30
18:20
20:45
05:55
07:45
09:35
11:55
14:50
16:40
18:30
21:00
06:10
08:00
09:50
12:10
15:00
16:50
18:40
21:15
06:20
08:10
10:00
12:20
15:10
17:00
18:50
21:30
06:35
08:25
10:15
12:35
15:25
17:15
19:05
21:45
06:45
08:35
10:25
12:45
15:40
17:30
19:20
22:00
07:00
08:50
10:40
13:00
15:55
17:45
19:35
22:15
07:10
09:00
10:50
13:10
16:10
18:00
19:50
22:30','06:25
08:10
10:00
12:25
15:20
17:15
19:05
21:25
06:35
08:30
10:20
12:35
15:35
17:20
19:15
21:40
06:50
08:40
10:30
12:50
15:45
17:35
19:25
21:55
07:05
08:55
10:45
13:05
15:55
17:45
19:35
22:10
07:10
09:05
10:55
13:15
16:05
17:55
19:45
22:25
07:30
09:15
11:10
13:30
16:20
18:10
20:00
22:40
07:40
09:30
11:20
13:40
16:35
18:25
20:15
22:55
07:55
09:45
11:30
13:50
16:50
18:35
20:30
23:10
08:05
09:55
11:45
14:05
17:05
18:55
20:45
23:25','Active');
INSERT INTO "busTable" VALUES(114,'21','Swargate','Sangvi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','59 Minutes','1	Swargate
2	Sarasbag
3	Bhikardas maruti madnir
4	Shanipar
5	A B Chowk
6	Dakshinabhimukh Maruti mandir
7	Shaniwar wada
8	PMC mangala
9	Shivaji putala pmc
10	shimala office shivajinagar
11	Masoba gate
12	Pumping station
13	Pune central
14	E square
15	Rangehills Corner
16	Pune University Gate
17	chavan nagar university road
18	Sakal nagar
19	Sindh colony
20	Baner phata
21	Sanewadi
22	Anand park sindhi colony
23	ITI parihar Chauk
24	Police workshop
25	Body gate
26	Aundh gaon
27	Sangvi phata
28	Sangvi Phata
29	Nurses Quarters
30	Ba ra gholap
31	Navi Sangvi
32	Panyachi taki sangvi
33	shitole nagar corner
34	Anand nagar
35	Sangvi goan','1	Sangvi goan
2	Anand nagar
3	shitole nagar corner
4	panyachi takai sangvi
5	Navi Sangvi
6	Bara gholap
7	Nurses Quarters
8	Sangvi Phata
9	Aundh gaon
10	Body gate
11	ITI parihar chauk
12	Aanand park sindhi colony
13	Sanewadi
14	Baner phata
15	Sindh colony
16	Sakal nagar
17	Chavan Nagar University Road
18	Pune University Gate
19	Rangehills Corner
20	E Square
21	Pune central
22	Pumping station
23	Masoba gate
24	shimala office shivajinagar
25	Engineering college hostel
26	Shivaji putala
27	PMC Mangala
28	Kasaba Police Chowky
29	Vasant talkies
30	Mandai
31	Shahu chauk
32	Gokul bhavan
33	Swargate','35','05:20
07:20
09:20
11:45
14:15
16:15
18:15
20:45
07:35
09:35
12:00
14:30
16:30
05:45
07:45
09:45
12:15
14:40
16:40
18:40
20:10
06:00
08:00
10:00
12:30
14:55
16:55
18:55
21:25
06:15
08:15
10:15
12:45
15:10
17:10
19:10
21:40
06:25
08:25
10:15
12:55
15:20
17:20
19:20
21:50
06:40
08:40
10:40
13:10
15:35
17:35
19:35
22:05
06:55
08:55
10:55
13:25
15:50
17:50
20:20
22:20
07:05
09:05
11:10
13:40
16:00
18:00
20:00
22:35','06:05
08:20
10:20
12:45
15:15
17:15
19:15
21:40
08:35
10:35
13:00
15:30
17:30
06:35
08:45
10:45
13:10
15:40
17:40
19:40
22:05
06:55
09:00
11:00
13:25
15:55
17:55
19:55
22:20
07:10
09:15
11:15
13:40
16:10
18:10
20:10
22:35
07:25
09:25
11:25
13:50
16:20
18:20
20:20
22:45
07:40
09:40
11:40
14:05
16:35
18:35
20:35
23:00
07:55
09:55
11:55
14:20
16:50
18:50
21:20
23:15
08:05
10:05
12:10
14:35
17:00
19:00
21:00
23:30','Active');
INSERT INTO "busTable" VALUES(115,'215','Ganesh Chowk','Sarasbag','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7 KMs','30 Minutes','1	Ganesh Chowk
2	Durvankur soc
3	Mohan Nagar
4	Shivshankar Chowk
5	Rajmudra Soc
6	Devendra Mangal Karyalaya
7	Balaji nagar
8	Vishweshwar Bank KK market
9	Padmavati corner
10	Natu bag
11	Aranyeshwar Corner
12	Bhapkar petrol pump City Pride
13	Panchami hotel
14	Laxmi Narayan Theature
15	Swargate
16	Sarasbag','1	Sarasbag
2	Hirabag
3	Swargate corner
4	Swargate
5	Lakshi narayan theature
6	Panchami hotel
7	Bhapkar Petrol Pump City pride
8	Aranyeshwar Corner
9	Natu Bag
10	Padmavati corner
11	Vishweshwar Bank KK market
12	Balaji nagar
13	Devendra Mangal Karyalaya
14	Rajmudra Soc
15	Shivshankar Chowk
16	Mohan Nagar
17	Durvankur soc
18	Ganesh Chowk','16','07:00
08:00
09:00
10:00
11:00
12:30
13:30
15:00
16:00
17:00
18:00
19:00
20:30
21:30','07:30
08:30
09:30
10:30
12:00
13:00
14:00
15:30
16:30
17:30
18:30
20:00
21:00
22:00','Active');
INSERT INTO "busTable" VALUES(116,'216','Ambegaon','Shaniwar wada','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','53 Minutes','1	Ambegaon
2	Gaimukh Ambegaon Phata
3	Ramnagar Katraj
4	Dattanagar Katraj
5	Chandrabhaga Restaurant
6	Ganpati mandir
7	PICT Bharati vidyapeeth
8	Rajaram Gas agency
9	Katraj dairy Sarpodyan
10	Bharti vidyapeeth gate
11	Chaitanya nagar
12	Balaji nagar
13	Vishweshwar Bank KK market
14	Padmavati corner
15	Natu bag
16	Aranyeshwar Corner
17	Bhapkar petrol pump City Pride
18	Panchami hotel
19	Laxmi Narayan Theature
20	Swargate
21	Sarasbag
22	Bhikardas maruti madnir
23	Shanipar
24	A B Chowk
25	Dakshinabhimukh Maruti mandir
26	Shaniwar wada
27	Surya hospital','1	Surya hospital
2	Kasaba Police Chowky
3	Vasant talkies
4	Mandai
5	Shahu chauk
6	Gokul bhavan
7	Swargate
8	Lakshi narayan theature
9	Panchami hotel
10	Bhapkar Petrol Pump City pride
11	Aranyeshwar Corner
12	Natu Bag
13	Padmavati corner
14	Vishweshwar Bank KK market
15	Balaji nagar
16	Chaitanya nagar
17	Bharti vidyapeeth gate
18	Katraj dairy Sarpodyan
19	Rajaram Gas agency
20	PICT Bharati vidyapeeth
21	Ganpati mandir
22	Chandrabhaga Restaurant
23	Dattanagar Katraj
24	Ramnagar Katraj
25	Gaimukh Ambegaon Phata
26	Ambegaon','27','06:45
08:25
10:05
11:45
14:30
16:20
18:20
20:30','07:35
09:15
10:55
13:05
15:20
17:25
19:45
21:20','Active');
INSERT INTO "busTable" VALUES(117,'216','Jambulwadi','Gujarwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7 KMs','218 Minutes','1	Jambhul Wadi
2	Jambhalkar Wasti
3	Pimplekar wasti
4	Datta Mandir
5	Lipanewasti
6	Telco Colony
7	Chakan Oil mill
8	Dattanagar Katraj
9	Santoshnagar
10	Katraj bus stand
11	Gujarwadi Phata
12	Sai Industries Company
13	Shivshankar Super market
14	Khadi Machine Gujarwadi
15	Gujarwadi','1	Gujarwadi
2	Khadi Machine Gujarwadi
3	Shivshankar super market
4	Sai Industries
5	Gujarwadi phata
6	Katraj bus stand
7	Santoshnagar
8	Dattanagar Katraj
9	Chakan Oil mill
10	Telco Colony
11	Lipanewasti
12	Datta Mandir
13	Pimplekar wasti
14	Jambhalkar Wasti
15	Jambhul Wadi','27','06:55
08:30
10:20
12:35
14:25
16:15
18:05
21:15','07:40
09:20
11:15
13:30
15:20
17:10
19:00
20:10','Active');
INSERT INTO "busTable" VALUES(118,'21N','Swargate','Pimple Nilakh','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','69 Minutes','1	Swargate
2	Swargate
3	Sarasbag
4	Bhikardas maruti madnir
5	Shanipar
6	A B Chowk
7	Dakshinabhimukh Maruti mandir
8	Shaniwar wada
9	PMC mangala
10	Shivaji putala pmc
11	shimala office shivajinagar
12	Masoba gate
13	Pumping station
14	Pune central
15	E square
16	Rangehills Corner
17	Pune University Gate
18	chavan nagar university road
19	Sakal nagar
20	Sindh colony
21	Baner phata
22	Sanewadi
23	Anand park sindhi colony
24	ITI parihar Chauk
25	Police workshop
26	Body gate
27	Aundh gaon
28	Sangvi phata
29	Aundh chest hospital
30	Aundh post office
31	ESI Hospital
32	Rakshak chauk
33	Rakshak Soc.
34	Pimple Nilakh Shala
35	Pimple Nilakh','1	Pimple Nilakh
2	Pimple Nilakh Shala
3	Rakshak Soc. Ganpati mandir
4	Rakshak chauk
5	ESI Hospital
6	Aundh post office
7	Aundh chest hospital
8	Sangvi Phata
9	Aundh gaon
10	Body gate
11	ITI parihar chauk
12	Aanand park sindhi colony
13	Sanewadi
14	Baner phata
15	Sindh colony
16	Sakal nagar
17	Chavan Nagar University Road
18	Pune University Gate
19	Rangehills Corner
20	E Square
21	Pune central
22	Pumping station
23	Masoba gate
24	shimala office shivajinagar
25	Engineering college hostel
26	Shivaji putala
27	PMC Mangala
28	Kasaba Police Chowky
29	Vasant talkies
30	Mandai
31	Shahu chauk
32	Gokul bhavan
33	Swargate','35','06:00
08:15
11:10
14:00
16:20
19:10
07:00
09:15
12:10
15:10
17:35
20:25','07:05
09:25
12:20
15:10
17:30
20:20
08:05
10:25
13:20
16:20
18:45
21:30','Active');
INSERT INTO "busTable" VALUES(119,'22','Sukhsagar','Shaniwar wada','Mon, Tue, Wed, Thu, Fri, Sat, Sun','8 KMs','16 Minutes','1	Sukhsagar Nagar
2	Somanagar Society
3	Rajiv Gandhi Nagar Upper Depot
4	Upper Indiranagar
5	Chintamani Nagar
6	Lower Indiranagar
7	Bibwewadi
8	Kothari Corner
9	Vasant Bag
10	Pushp Mangal karyalaya
11	Aranyeshwar Corner
12	Bhapkar petrol pump City Pride
13	Panchami hotel
14	Laxmi Narayan Theature
15	Swargate
16	Sarasbag
17	Bhikardas maruti madnir
18	Shanipar
19	A B Chowk
20	Dakshinabhimukh Maruti mandir
21	Shaniwar wada
22	Surya hospital','1	Shaniwar wada
2	Kasaba Police Chowky
3	Vasant talkies
4	Mandai
5	Shahu chauk
6	Gokul bhavan
7	Swargate
8	Lakshi narayan theature
9	Panchami hotel
10	Bhapkar Petrol Pump City pride
11	Aranyeshwar Corner
12	Pushp Mangal karyalaya
13	Vasant Bag
14	Kothari Corner
15	Bibwewadi
16	Lower Indiranagar
17	Chintamani Nagar
18	Upper Indiranagar
19	Rajiv Gandhi Nagar Upper Depot
20	Somanagar Society
21	Sukhsagar Nagar','22','07:00
08:10
09:25
11:15
12:30
12:30
13:50
15:00
16:20
17:40
19:30
20:50
07:10
08:20
09:35
11:25
12:40
14:00
15:10
16:30
17:50
19:40
21:00
08:30
09:45
11:05
12:50
14:10
15:25
16:45
18:05
07:30
08:45
10:00
11:50
13:10
14:25
16:55
18:15
19:55
21:15
08:55
10:15
18:35
13:20
14:35
15:50
17:10
18:30
07:50
09:05
10:50
12:10
13:30
14:45
17:20
19:10
20:25
21:45
08:00
09:15
10:30
12:20
13:40
14:55
17:30
18:50
20:40
22:00
14:40
18:50
15:05
19:15
15:30
15:40','15:10
19:20
15:35
19:45
16:00
16:10','Active');
INSERT INTO "busTable" VALUES(120,'225','Swargate','Wakadgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17.4 KMs','68 Minutes','1	Swargate
2	Swargate
3	Sarasbag
4	Bhikardas maruti madnir
5	Shanipar
6	A B Chowk
7	Dakshinabhimukh Maruti mandir
8	Shaniwar wada
9	PMC mangala
10	Shivaji putala pmc
11	shimala office shivajinagar
12	Masoba gate
13	Pumping station
14	Pune central
15	E square
16	Rangehills Corner
17	Rajbhavan
18	Boys batalian
19	Kasturba vasahat
20	Sindh colony gate 2
21	Bremen chauk
22	Body gate
23	Aundh gaon
24	Sangvi phata
25	Aundh chest hospital
26	Aundh post office
27	ESI Hospital
28	Rakshak chauk
29	Military Stores
30	Wakad phata
31	Vikasnagar Corner
32	Maruti Mandir Wakad
33	Kaspate Vasti
34	Wakad Chowk','1	Wakad Chowk
2	Kaspate Vasti
3	Maruti Mandir Wakad
4	Vikasnagar Corner
5	Wakad phata
6	Military Stores
7	Rakshak chauk
8	ESI Hospital
9	Aundh post office
10	Aundh chest hospital
11	Sangvi Phata
12	Aundh gaon
13	Body gate
14	Bremen chauk
15	Sindh Colony Gate2
16	Kasturba vasahat
17	Boys Batalian
18	Pune University Gate
19	Rangehills Corner
20	E Square
21	Pune central
22	Pumping station
23	Masoba gate
24	shimala office shivajinagar
25	Engineering college hostel
26	Shivaji putala
27	PMC Mangala
28	Kasaba Police Chowky
29	Vasant talkies
30	Mandai
31	Shahu chauk
32	Mamledar kacheri
33	Gokul bhavan
34	Swargate','34','06:30
08:50
11:40
15:40
18:00
20:45','07:35
10:00
12:50
16:50
19:10
21:50','Active');
INSERT INTO "busTable" VALUES(121,'226','Pune Station','Dhayari','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17.4 KMs','61 Minutes','1	Pune Station Depot
2	Sadhu wasvani chauk
3	Collector kacheri
4	Zila Parishad
5	15 August Lodge Somwar Peth
6	Sadanand Nagar
7	Kamala nehru hospital
8	Daruwala Pool
9	Sonya Maruti Chowk
10	City post
11	Kunte Chauk
12	Gokhale hall
13	Vijay Talkies
14	Alka talkies
15	Alka talkies
16	Ganjwewadi
17	Lokmanya nagar
18	Dattawadi pul
19	Mhasoba Chowk
20	Raksha Lekha Society
21	Ganesh mala
22	Vitbhatti Sinhgad Road
23	Vitthalwadi jakat naka
24	Jaydeo nagar
25	Rajaram pul
26	Vitthalwadi Mandir Hingne
27	Hingne rasta
28	Anand nagar singhgad rd
29	Manik Bag
30	Indian hum company
31	Wadgaon phata
32	Patil colony
33	Dhayari phata
34	Sanas Vidyalaya
35	Dangat wasti
36	Gar mala
37	Dhayarai gaon
38	Raykar wasti
39	Poultry farm singhgad road
40	Maruti Mandir
41	Dhayreshwar Mandir','1	Dhayreshwar Mandir
2	Maruti Mandir
3	Poultry Farm Sinhgadh Road
4	Raykar wasti
5	Dhayari Gaon
6	Gar mala
7	Dangat wasti
8	Sanas Vidyalaya
9	Dhayari phata
10	Patil colony
11	Wadgaon phata
12	Indican hyum company
13	Manik bag
14	Anand nagar
15	Hingne rasta
16	Vitthalwadi mandir hingne
17	RajaramPool
18	Jaydeo nagar
19	Vitthalwadi Jakat Naka
20	Vitbhatti singhgad rd
21	Ganesh mala
22	Raksha Lekha Society
23	Mhasoba Chowk
24	Dattawadi pul
25	Lokmanya nagar
26	Ganjwewadi
27	Alka talkies
28	Chitrashala
29	Sadashiv Peth Houd
30	Shanipar
31	Govind Halwai Chowk
32	Sonwane hospital
33	Ramoshi gate
34	Nana peth
35	A D camp chauk
36	Power house
37	KEM hospital
38	Ambedkar bhavan
39	Sasoon hospital
40	Pune station
41	Pune Station Depot','41','07:00
08:20
11:20
13:30
15:55
18:00
20:45','07:30
09:20
12:20
14:55
16:55
19:15
21:45','Active');
INSERT INTO "busTable" VALUES(122,'227','Market yard','Marnewadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','34 KMs','83 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	Godown Marketyard
4	Shivaji Putala Kalubai Mandir
5	Mafco Company
6	Panchami hotel
7	Laxmi Narayan Theature
8	Swargate
9	Sarasbag
10	Mahila Mandal
11	Petrol Pump Rajendranagar
12	Lokmanya nagar
13	Ganjwewadi
14	Alka talkies
15	Deccan Corner Sambhaji Pul Corner
16	Garware college
17	Petrol Pump Karve Road
18	Nal Stop
19	SNDT college
20	Paud phata police chauky
21	More vidyalaya
22	LIC colony
23	Anand nagar paud road
24	Jai bhavani
25	Vanaz Corner
26	Vanaz company
27	Paramhans corner
28	Kachara depot
29	Bharti nagar
30	kothrud depot
31	Shinde farm
32	Chandani chauk
33	Mail Dagad Kramank 8
34	Rajwade banglaow
35	Dagade wasti
36	Bhagwat wasti
37	Deshmukh wasti
38	Mariaai Mandir Bhugaon
39	Daulat Garden
40	Bhugoan
41	Chukate wasti
42	Mathalwadi
43	Tangde Bandhu Mala
44	Mail Dagad Kramank 18
45	Nerolac Paint Company
46	Bhukoom Ashram
47	Bandal farm
48	Ashram
49	Mail dagad kramank 21
50	Mail Dagad Kramank 22
51	Lavale Phata
52	ST stand pirangut
53	Ghotawale phata
54	Minilek company
55	Kirloskar
56	GAF Filters
57	Khale banglaow
58	Urawade gaon
59	Ambegaon Phata
60	Lalghar
61	Datta Mandir Marnewadi
62	Marnewadi','1	Marnewadi
2	Datta Mandir Marnewadi
3	Lalghar
4	Ambegaon phata
5	Urwade gaon
6	Khale Bangala
7	GAF filters
8	Kirloskar
9	Minilek Company
10	Ghotawade Phata
11	Viskar India Company
12	ST stand Pirangut
13	Lavale phata
14	Mail Dagad Kramank 22
15	Mail Dagad Kramank 21
16	Ashram
17	Bandal Farm
18	Bhukoom ashram
19	Nerolac paint company
20	Mail dagad no.18
21	Tangade bandhu mala
22	Mathalwadi
23	Chutke wasti
24	Bhugaon
25	Daulat garden
26	Mariaai mandir bhugaon
27	Deshmukh wasti
28	Bhagwat wasti
29	Dagade wasti
30	Rajwade Bungalow
31	Mail Dagad Kramank 8
32	Chandani chauk
33	Shinde Farm
34	Kothrud depot
35	Bharti nagar
36	kachra depot
37	Paramhansa Corner
38	Vanaz corner
39	Jai bhavani
40	Anand nagar paud road
41	LIC Colony Paud Road
42	More vidyalaya
43	Paudphata police chowky
44	SNDT college
45	Nal stop
46	Petrol pump karve road
47	Garware college
48	Deccan corner sambhaji pul
49	Alka talkies
50	Ganjwewadi
51	Lokmanya nagar
52	Petrol pump rajendranagar
53	Mahila mandal
54	Hirabag
55	Swargate corner
56	Swargate
57	Lakshi narayan theature
58	Panchami hotel
59	Mafco Company
60	Shivaji putala Kalubai mandir
61	Godown Marketyard
62	Wakhar Mahamandal Marketyard
63	Marketyard','62','05:45
08:30
14:55
18:40','06:50
09:55
16:25
20:10','Active');
INSERT INTO "busTable" VALUES(123,'228','Katraj bus stand','Telegaon Dabhade','Mon, Tue, Wed, Thu, Fri, Sat, Sun','49 KMs','108 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Madiwale colony
17	S P college
18	Maharashtra mandal
19	Sahitya parishad peru gate
20	Goodluck Chowk
21	F C College
22	Dnyaneshwar Paduka chowk
23	Masoba gate
24	Pumping station
25	Pune central
26	E square
27	Rangehills Corner
28	Pune University Gate
29	chavan nagar university road
30	Sakal nagar
31	Sindh colony
32	Baner phata
33	Green Park hotel
34	Trimurti bunglow
35	Ambedkar nagar
36	Murkute wasti
37	Baner gaon
38	Baner odha
39	Balewadi Phata
40	Kalamkar wasti
41	Samadhi mandir
42	Insureance company
43	Mhalunge corner
44	Chha. Shivaji Krida Sankul
45	Mutha Pool Balewadi
46	Wakad Highway
47	BU Bhandari Showroom
48	Wakad Police Chowky
49	Indira Institute
50	Shirole Petrol Pump
51	Tathawade Phata
52	Vittbhatti XPS Company
53	Punavale Corner
54	Pawana pul Rawet
55	Dharmaraj Mangal Karyalaya Ravet
56	Poultry farm Indrayani dhaba
57	Kivale phata
58	Indraprabha mamurdi
59	Petrol pump vikasnagar
60	Central Restaurant
61	Krushna Mandir Dehu Road
62	Mata Amardevi temple
63	Amarjai Begdewadi phata
64	Shankarwadi
65	Shelarwadi
66	Pune poultry farm
67	Somatne Phata
68	Talegaon Khind
69	Talegoan phata
70	Bhandari hospital
71	Jijamata chowk Talegaon
72	Talegaon nagar parishad
73	Paranjpe Hospital
74	Talegaon station
75	Egale Plax Petrol Pump
76	Bharat Petrol Pump
77	Samartha Vidyalaya Wadgaon Maval
78	Paisa Phand Kach Karkhana
79	Wadgaon Maval Phata','1	Wadgaon Maval Phata
2	Paisa phand kach karkhana
3	Samarth vidyalaya Wadgaon maval
4	Bharat petrol pump
5	Egale Plax Petrol Pump
6	Talegaon Station
7	Paranjape Hospital
8	Talegaon Nagarparishad
9	Jijamata chauk talegoan
10	Bhandari Hospital
11	Talegoan phata
12	Talegoan khind
13	Somatne Phata
14	Pune poultry farm
15	Shelarwadi
16	Shankarwadi
17	Amarjai begdewadi phata
18	Mata amardevi temple
19	Krishan mandir dehu road
20	Central restaurant
21	Petrol Pump Vikasnagar
22	Indraprabha Mamurdi
23	Kiwale phata
24	Poultry Farm Indrayani dhaba
25	Dharmraj mangal karyalay rawet
26	Pavna Pool Ravet
27	Punawale corner
28	Vittbhatti XPS Company
29	Tathawade Phata
30	Shirole Petrol Pump
31	Indira Institute
32	Wakad Police Chowky
33	BU Bhandari Showroom
34	Wakad Highway
35	Mutha Pool Balewadi
36	Chh.Shivaji krida sankul
37	Mhalunge corner
38	Insurance company
39	Samadhimandir
40	Kalamkar Vasti
41	Balewadi Phata
42	Baner odha
43	Baner Gaon
44	Murkutewasti Pavitra hotel
45	Ambedkar Nagar
46	Trimurti Bungalow
47	Green park hotel
48	Baner phata
49	Sindh colony
50	Sakal nagar
51	Chavan Nagar University Road
52	Pune University Gate
53	Rangehills Corner
54	E Square
55	Pune central
56	Pumping station
57	Masoba gate
58	shimala office shivajinagar
59	Sancheti Hospital
60	Modern Highschool
61	Balgandharv sambhaji par
62	Deccan Gymkhana
63	Sahitya Parishad Peru Gate
64	Maharashtra mandal
65	S P college
66	Madiwale colony
67	Hirabag
68	Swargate corner
69	Swargate
70	Lakshi narayan theature
71	Panchami hotel
72	Bhapkar Petrol Pump City pride
73	Aranyeshwar Corner
74	Natu Bag
75	Padmavati corner
76	Vishweshwar Bank KK market
77	Balaji nagar
78	Chaitanya nagar
79	Bharti vidyapeeth gate
80	Katraj dairy Sarpodyan
81	More bag
82	Katraj bus stand','79','10:00
14:00
18:30
07:15
12:00
16:20
20:50','07:15
12:00
16:20
20:30
09:30
14:00
18:20','Active');
INSERT INTO "busTable" VALUES(124,'229','Bharti Vidyapeeth','VishrantwadiPrint','Mon, Tue, Wed, Thu, Fri, Sat, Sun','19 KMs','61 Minutes','1	PICT Bharati vidyapeeth
2	Rajaram Gas agency
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Bhikardas maruti madnir
17	Shanipar
18	A B Chowk
19	Dakshinabhimukh Maruti mandir
20	Shaniwar wada
21	PMC mangala
22	Shivaji putala pmc
23	shimala office shivajinagar
24	Lokmangal
25	College of engineering pune
26	Patil Estate
27	Labour office
28	Bajaj showroom wakadewadi
29	Mariaai Gate Old Mumbai Pune Road
30	Poultry Farm Old Mumbai Pune Road
31	Mula road bhaiyawadi
32	Pachawadw
33	Holkar Water Supply
34	Sapras post
35	Deccan college
36	Ambedkar Society
37	RTO New
38	Phulenagar
39	MES Water Works
40	Mental Hospital Corner
41	Shantinagar
42	Sathe Biscuit company
43	Vishrantwadi','1	Vishrantwadi
2	Sathe Biscuit company
3	Shantinagar
4	Mental Hospital Corner
5	MES Water Works
6	Phulenagar
7	RTO New
8	Ambedkar Society
9	Deccan college
10	Sapras post
11	Holkar Water Supply
12	Pachwade
13	Mula bhaiyawadi
14	Poultry Farm Old Mumbai Pune Road
15	Mariaai Gate Old Mumbai Pune Road
16	Bajaj showroom
17	Labor office
18	Patil Estate
19	College of engineering pune
20	Sancheti Hospital
21	Shivaji putala
22	PMC Mangala
23	Kasaba Police Chowky
24	Vasant talkies
25	Mandai
26	Shahu chauk
27	Gokul bhavan
28	Swargate
29	Lakshi narayan theature
30	Panchami hotel
31	Bhapkar Petrol Pump City pride
32	Aranyeshwar Corner
33	Natu Bag
34	Padmavati corner
35	Vishweshwar Bank KK market
36	Balaji nagar
37	Chaitanya nagar
38	Bharti vidyapeeth gate
39	Katraj dairy Sarpodyan
40	More bag
41	Rajaram Gas agency
42	Chandrabhaga Restaurant
43	Ganpati mandir
44	PICT Bharati vidyapeeth','44','05:30
07:15
09:45
11:50
14:45
17:40
19:50','06:20
08:15
10:45
12:55
15:50
18:45
20:50','Active');
INSERT INTO "busTable" VALUES(125,'23','Upper Depot','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','70 Minutes','1	Rajiv Gandhi Nagar Upper Depot
2	Upper Indiranagar
3	Chintamani Nagar
4	Lower Indiranagar
5	Bibwewadi
6	Kothari Corner
7	Vasant Bag
8	Pushp Mangal karyalaya
9	Aranyeshwar Corner
10	Bhapkar petrol pump City Pride
11	Panchami hotel
12	Laxmi Narayan Theature
13	Swargate
14	Ghorpade peth colony
15	Lakud Bajar
16	Sonwane hospital
17	Subhanshah Darga
18	Phadake Houd
19	RCM
20	Kamala nehru hospital
21	Sadanand nagar
22	15 August Lodge Somwar Peth
23	Ambedkar bhavan
24	Sasoon hospital
25	Pune station','1	Pune station
2	Alankar Talkies
3	Sadhu wasvani chauk
4	GPO
5	Collector kacheri
6	Zila Parishad
7	Sadanand Nagar
8	Kamala nehru hospital
9	RCM
10	Daruwala Pool
11	Ganesh Peth
12	Govind Halwai Chowk
13	Ganjpeth Police Chowky
14	Mominpura
15	Ghorpade Peth
16	Swargate police line
17	Swargate
18	Lakshi narayan theature
19	Panchami hotel
20	Bhapkar Petrol Pump City pride
21	Aranyeshwar Corner
22	Pushp Mangal karyalaya
23	Vasant Bag
24	Kothari Corner
25	Bibwewadi
26	Lower Indiranagar
27	Chintamani Nagar
28	Upper Indiranagar
29	Rajiv Gandhi Nagar Upper Depot','25','15:00
16:50
18:40
21:00
06:00
07:40
09:25
11:40
13:25
15:30
17:30
19:10
21:30
06:40
08:15
10:05
12:15
14:00
15:55
17:45
19:35
21:55
07:10
08:50
10:35
12:50
14:35
16:25
18:15
20:40
22:30','15:55
17:45
19:35
21:50
06:50
08:30
10:15
12:30
14:10
16:25
18:15
20:05
22:20
07:25
09:05
10:50
13:05
14:50
16:50
18:40
20:30
22:45
08:00
09:40
11:25
13:40
01:25
17:20
19:10
21:30
23:15','Active');
INSERT INTO "busTable" VALUES(126,'230','Bharti vidyapeeth','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','52 Minutes','1	PICT Bharati vidyapeeth
2	Rajaram Gas agency
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Ghorpade peth colony
16	Lakud Bajar
17	Sonwane hospital
18	Ramoshi gate
19	A D camp chauk
20	Power house
21	KEM hospital
22	Ambedkar bhavan
23	Sasoon hospital
24	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Zila Parishad
6	KEM hospital
7	Power house
8	A D camp chauk
9	Ramoshi gate
10	Sonwane hospital
11	Lakud Bajar
12	Ghorpadi Peth Colony
13	Swargate police line
14	Swargate
15	Lakshi narayan theature
16	Panchami hotel
17	Bhapkar Petrol Pump City pride
18	Aranyeshwar Corner
19	Natu Bag
20	Padmavati corner
21	Vishweshwar Bank KK market
22	Balaji nagar
23	Chaitanya nagar
24	Bharti vidyapeeth gate
25	Katraj dairy Sarpodyan
26	Rajaram Gas agency
27	Chandrabhaga Restaurant
28	Ganpati mandir
29	PICT Bharati vidyapeeth','24','05:45
07:25
09:15
11:30
14:00
15:40
17:25
19:45','06:35
08:20
10:10
12:20
14:50
16:30
18:20
20:35','Active');
INSERT INTO "busTable" VALUES(127,'233','Market yard','Paudgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','35 KMs','80 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	Godown Marketyard
4	Shivaji Putala Kalubai Mandir
5	Mafco Company
6	Bhapkar petrol pump City Pride
7	Panchami hotel
8	Laxmi Narayan Theature
9	Swargate
10	Swargate
11	Sarasbag
12	Mahila Mandal
13	Petrol Pump Rajendranagar
14	Lokmanya nagar
15	Ganjwewadi
16	Alka talkies
17	Deccan corner sambhaji pool
18	Garware college
19	Petrol Pump Karve Road
20	Nal Stop
21	SNDT college
22	Paud phata police chauky
23	More vidyalaya
24	LIC colony
25	Anand nagar paud road
26	Jai bhavani
27	Vanaz Corner
28	Vanaz company
29	Paramhans corner
30	Kachara depot
31	Bharti nagar
32	kothrud depot
33	Shinde farm
34	Chandani chauk
35	Mail Dagad Kramank 8
36	Rajwade banglaow
37	Dagade wasti
38	Bhagwat wasti
39	Deshmukh wasti
40	Mariaai Mandir Bhugaon
41	Daulat Garden
42	Bhugoan
43	Chukate wasti
44	Mathalwadi
45	Tangde Bandhu Mala
46	Mail Dagad Kramank 18
47	Nerolac Paint Company
48	Bhukoom Ashram
49	Bandal farm
50	Ashram
51	Mail dagad kramank 21
52	Mail Dagad Kramank 22
53	Lavale Phata
54	ST stand pirangut
55	Vishkar India company
56	Ghotawale phata
57	Shindewadi Ghotawale
58	Kasar amboli
59	Cable company
60	Sutarwadi paudroad
61	Nursery
62	Amralewadi phata
63	Mukund shobha udyan dattamandir
64	Sanakata company
65	Santi company
66	Balkavade wasti
67	Vitthalwadi phata
68	Forest Office Road
69	Manik press road
70	ST stand Paudgaon
71	Shaskiya vishramgrah paud road
72	Paudgoan','1	Paudgoan
2	Shaskiy Vishramgruha Paud Road
3	ST stand paudgaon
4	Manik Press Road
5	Forest office road
6	Vitthalwadi phata
7	Balkawdewasti
8	Santi Company
9	Sanakata Company
10	Mukund Shobha Udyan Dattamandir
11	Amralewadi Phata
12	Nursery
13	Sutarwadi Paudroad
14	Cable Company
15	Kasar Amboli
16	Shindewadi Ghotawade
17	Ghotawade Phata
18	Viskar India Company
19	ST stand Pirangut
20	Lavale phata
21	Mail Dagad Kramank 22
22	Mail Dagad Kramank 21
23	Ashram
24	Bandal Farm
25	Bhukoom ashram
26	Nerolac paint company
27	Mail dagad no.18
28	Tangade bandhu mala
29	Mathalwadi
30	Chutke wasti
31	Bhugaon
32	Daulat garden
33	Mariaai mandir bhugaon
34	Deshmukh wasti
35	Bhagwat wasti
36	Dagade wasti
37	Rajwade Bungalow
38	Mail Dagad Kramank 8
39	Chandani chauk
40	Shinde Farm
41	Kothrud depot
42	Bharti nagar
43	kachra depot
44	Paramhansa Corner
45	Vanaz corner
46	Jai bhavani
47	Anand nagar paud road
48	LIC Colony Paud Road
49	More vidyalaya
50	Paudphata police chowky
51	SNDT college
52	Nal stop
53	Petrol pump karve road
54	Garware college
55	Deccan corner sambhaji pul
56	Alka talkies
57	Ganjwewadi
58	Lokmanya nagar
59	Petrol pump rajendranagar
60	Mahila mandal
61	Hirabag
62	Swargate corner
63	Swargate
64	Lakshi narayan theature
65	Panchami hotel
66	Bhapkar Petrol Pump City pride
67	Mafco Company
68	Shivaji putala Kalubai mandir
69	Godown Marketyard
70	Wakhar Mahamandal Marketyard
71	Marketyard','72','08:00
11:30
15:30
19:05
06:20
09:00
12:30
16:40
20:05
07:20
10:00
13:30
17:40
21:10','06:35
09:35
13:00
17:00
20:30
07:30
10:30
13:55
18:10
21:35
08:30
11:30
14:55
19:10','Active');
INSERT INTO "busTable" VALUES(128,'234','Manapa','Kharadi gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','50 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Ruby hall
8	Wadia college
9	Guruprasad bangala
10	Band garden
11	Yerwada
12	wadia bangala
13	Shastri nagar
14	Agakhan palace
15	Ramwadi Jakatnaka
16	Ramwadi
17	Weikfield
18	ISL Company
19	WNC Company
20	Dharmanagar 5 va Mail
21	Tata Guardroom Kharadi Phata
22	Chandan Nagar
23	Vidi Kamgar Vasahat
24	Tukaramnagar
25	Rakshak Society Kharadi
26	Patil Wasti Kharadi
27	Kharadi Gaon','1	Kharadi Gaon
2	Patil Wasti Kharadi
3	Rakshak Society Kharadi
4	Tukaramnagar
5	Vidi Kamgar Vasahat
6	Chandan nagar
7	Tata gaurdroom Kharadi phata
8	Dharmanagar 5 va mail
9	WNC Company
10	ISL Company
11	Weikfield
12	Ramwadi
13	Ramwadi jakatnaka
14	Agakhan palace
15	Shastri nagar
16	Wadia bunglow
17	Yerwada
18	Band garden
19	Guruprasad bangala
20	Jahangir Hospital
21	Alankar Talkies
22	Sadhu wasvani chauk
23	GPO
24	Collector kacheri
25	Ambedkar bhavan
26	Juna Bajar
27	Kumbhar wada
28	PMC','27','05:30
07:10
08:50
11:00
12:40
14:30
16:10
17:50
20:00
21:40
06:00
07:40
09:20
11:30
13:10
15:00
16:40
18:50
20:30
22:10
06:30
08:10
09:50
12:00
13:40
15:30
17:10
19:20
21:00','06:20
08:00
09:40
11:50
13:30
15:20
17:00
18:40
20:50
22:30
06:50
08:30
10:10
12:20
14:00
15:50
17:30
19:40
21:20
23:00
07:20
09:00
10:40
12:50
14:30
16:20
18:00
20:10
21:50','Active');
INSERT INTO "busTable" VALUES(129,'235','Katraj bus stand','Kharadi gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','23 KMs','79 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Ghorpade peth colony
16	Sonwane hospital
17	Ramoshi gate
18	Nana peth
19	A D camp chauk
20	Power house
21	KEM hospital
22	15 August Lodge Somwar Peth
23	Ambedkar bhavan
24	Sasoon hospital
25	Pune station
26	Ruby hall
27	Wadia college
28	Guruprasad bangala
29	Band garden
30	Yerwada
31	wadia bangala
32	Shastri nagar
33	Agakhan palace
34	Ramwadi Jakatnaka
35	Ramwadi
36	Weikfield
37	Dharmanagar 5 va Mail
38	Tata Guardroom Kharadi Phata
39	Chandan Nagar
40	Vidi Kamgar Vasahat
41	Tukaramnagar
42	Rakshak Society Kharadi
43	Patil Wasti Kharadi
44	Kharadi Gaon','1	Kharadi Gaon
2	Patil Wasti Kharadi
3	Rakshak Society Kharadi
4	Tukaramnagar
5	Vidi Kamgar Vasahat
6	Chandan nagar
7	Tata gaurdroom Kharadi phata
8	Dharmanagar 5 va mail
9	Weikfield
10	Ramwadi
11	Ramwadi jakatnaka
12	Agakhan palace
13	Shastri nagar
14	Wadia bunglow
15	Yerwada
16	Band garden
17	Guruprasad bangala
18	Jahangir Hospital
19	Alankar Talkies
20	Sadhu wasvani chauk
21	GPO
22	Collector kacheri
23	15 August Lodge Somwar Peth
24	KEM hospital
25	Power house
26	A D camp chauk
27	Nana peth
28	Ramoshi gate
29	Sonwane hospital
30	Ghorpadi Peth Colony
31	Swargate police line
32	Swargate
33	Lakshi narayan theature
34	Panchami hotel
35	Bhapkar Petrol Pump City pride
36	Aranyeshwar Corner
37	Natu Bag
38	Padmavati corner
39	Vishweshwar Bank KK market
40	Balaji nagar
41	Chaitanya nagar
42	Bharti vidyapeeth gate
43	Katraj dairy Sarpodyan
44	More bag
45	Katraj bus stand','44','05:35
08:00
11:15
14:00
16:40
19:50
06:45
09:20
12:35
15:15
17:50
21:05','06:45
09:20
12:35
15:15
18:05
21:05
08:05
10:45
13:55
16:30
19:15
22:20','Active');
INSERT INTO "busTable" VALUES(130,'235','Manapa','Khulewadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13.7 KMs','49 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Ruby hall
8	Wadia college
9	Guruprasad bangala
10	Band garden
11	Yerwada
12	wadia bangala
13	Shastri nagar
14	Agakhan palace
15	Ramwadi Jakatnaka
16	Ramwadi
17	Weikfield
18	ISL Company
19	WNC Company
20	Dharmanagar 5 va Mail
21	Tata Guardroom Kharadi Phata
22	Chandan Nagar
23	NEI Company
24	Khule Wadi','1	Khule Wadi
2	NEI Company
3	Chandan nagar
4	Tata gaurdroom Kharadi phata
5	Dharmanagar 5 va mail
6	WNC Company
7	ISL Company
8	Weikfield
9	Ramwadi
10	Ramwadi jakatnaka
11	Agakhan palace
12	Shastri nagar
13	Wadia bunglow
14	Yerwada
15	Band garden
16	Guruprasad bangala
17	Jahangir Hospital
18	Alankar Talkies
19	Sadhu wasvani chauk
20	GPO
21	Collector kacheri
22	Ambedkar bhavan
23	Juna Bajar
24	Kumbhar wada
25	PMC','24','05:50
07:30
09:10
11:40
14:00
15:40
17:30
19:50
06:30
08:20
10:10
12:30
14:50
16:30
18:20
20:45','06:40
08:20
10:05
12:20
14:50
16:30
18:20
20:40
07:20
09:10
11:05
13:20
15:40
17:20
19:10
21:25','Active');
INSERT INTO "busTable" VALUES(131,'24','Katraj bus stand','Maharashtra housing board','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18 KMs','69 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Ghorpade peth colony
16	Lakud Bajar
17	Sonwane hospital
18	Ramoshi gate
19	Modern Bakery Nana peth
20	Alpana Talkies
21	Sonya Maruti Chowk
22	Phadake Houd
23	RCM
24	Kamala nehru hospital
25	Sadanand nagar
26	15 August Lodge Somwar Peth
27	Zila Parishad
28	Sasoon hospital
29	Pune station
30	Ruby hall
31	Wadia college
32	Guruprasad bangala
33	Band garden
34	Yerwada
35	White House
36	Netaji school
37	Vikrikar Karyalaya
38	Yerwada post office
39	M23
40	Moze Adhyapak Vidyalaya Yerwada
41	Maharashtra Housing Yerwada','1	Maharashtra Housing Yerwada
2	Moje adhyapak vidyalaya Yerwada
3	M23
4	Yerwada post office
5	Vikrikar karyalaya
6	Netaji school
7	White House
8	Yerwada
9	Band garden
10	Guruprasad bangala
11	Jahangir Hospital
12	Alankar Talkies
13	Sadhu wasvani chauk
14	Collector kacheri
15	15 August Lodge Somwar Peth
16	Sadanand Nagar
17	Kamala nehru hospital
18	RCM
19	Daruwala Pool
20	Ganesh Peth
21	Govind Halwai Chowk
22	Naik Hospital
23	Shitaladevi chauk
24	Ganjpeth Police Chowky
25	Mominpura
26	Ghorpade Peth
27	Swargate police line
28	Swargate
29	Lakshi narayan theature
30	Panchami hotel
31	Bhapkar Petrol Pump City pride
32	Aranyeshwar Corner
33	Natu Bag
34	Padmavati corner
35	Vishweshwar Bank KK market
36	Balaji nagar
37	Chaitanya nagar
38	Bharti vidyapeeth gate
39	Katraj dairy Sarpodyan
40	More bag
41	Katraj bus stand','41','05:30
07:50
10:40
13:40
16:25
19:05
05:40
08:00
11:00
13:55
16:50
19:20
05:50
08:10
11:10
14:05
17:00
19:30
06:00
08:20
11:20
14:15
17:10
19:40
06:10
08:30
11:30
14:25
17:20
19:50
06:20
08:40
11:40
14:35
17:30
20:00
06:30
08:50
11:50
14:45
17:40
20:10
06:40
09:00
12:00
14:55
17:50
20:20
06:50
09:10
12:10
15:05
18:00
20:30
07:00
09:20
12:20
15:15
18:10
20:40
07:10
09:30
12:30
15:25
18:20
20:50
07:20
09:40
12:40
15:40
18:35
21:05
07:30
10:20
12:55
15:50
18:45
21:15
07:40
10:00
13:10
16:05
18:55
21:30
07:00
09:15
12:15
14:40
17:00
19:25
07:25
09:40
12:40
15:05
17:25
19:50
07:55
10:10
13:10
15:35
17:55
20:20
08:20
10:35
13:35
16:00
18:20
20:45
08:50
11:10
14:05
16:30
18:50
21:25','06:30
09:00
11:50
14:50
17:45
20:10
06:45
09:10
12:05
15:05
18:00
20:25
06:55
09:20
12:15
15:15
18:10
20:35
07:05
09:30
12:25
15:25
18:20
20:45
07:15
09:40
13:35
15:35
18:30
20:55
07:25
09:50
12:45
15:45
18:40
21:05
07:35
10:00
12:55
15:55
18:50
21:15
07:45
10:10
13:05
16:05
19:00
21:40
07:55
10:20
13:15
16:15
19:10
21:35
08:05
10:30
13:25
16:25
19:20
21:45
08:15
10:40
13:35
16:35
19:30
21:55
08:25
10:50
13:45
16:50
19:45
22:10
08:35
11:30
14:00
17:00
19:55
22:20
08:50
11:10
14:15
17:10
20:05
22:35
08:05
10:30
13:20
15:50
18:10
20:35
08:30
10:55
13:45
16:15
18:35
21:00
09:00
11:25
14:15
16:45
19:05
21:30
09:25
11:50
14:40
17:10
19:30
21:55
09:55
12:25
15:10
17:40
20:00
22:30','Active');
INSERT INTO "busTable" VALUES(132,'24','Marketyard','Khanapur','Mon, Tue, Wed, Thu, Fri, Sat, Sun','26 KMs','77 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	Godown Marketyard
4	Shivaji Putala Kalubai Mandir
5	Mafco Company
6	Bhapkar petrol pump City Pride
7	Panchami hotel
8	Laxmi Narayan Theature
9	Swargate
10	Swargate
11	Parvati payatha
12	Dandekar pul
13	Pan mala Sinhgad Road
14	Jal Shuddhikarn Kendra Sinhgad Road
15	Ganesh mala
16	Vitbhatti Sinhgad Road
17	Vitthalwadi jakat naka
18	Jaydeo nagar
19	Vitthalwadi Mandir Hingne
20	Hingne rasta
21	Anand nagar singhgad rd
22	Manik Bag
23	Indian hum company
24	Wadgaon phata
25	Patil colony
26	Dhayari phata
27	Lagad wasti
28	Mate Pat Sasa company
29	Nanded Phata
30	Jadhavwadi Andh shala
31	CWPRS gate no.1
32	Nandoshi Phata
33	Kolhewadi
34	Khadakwasla Gaon
35	Khadakwasla Dharan
36	Childrens School
37	IAT Gate Girinagar
38	Sant Dharmaji Samadhi
39	Gorhe Budruk
40	Gorhe bu. jeevan shikshan mandir
41	Donje Goan Phata
42	Paygude wasti Donje
43	Venkatesh poultry farm
44	Gorhe khurd
45	Malatwadi
46	Khanapur','1	Khanapur
2	Malatwadi
3	Gorhe Khurd
4	Venkatesh Poultry Farm
5	Paygide wasti Donje
6	Donje gaon phata
7	Gorhe Bu Jeevan Shikshan Mandir
8	Gorhe Budruk
9	Saint Dharmaji Samadhi
10	IAT Gate Girinagar
11	Childrens school
12	Khadakwasala Dharan
13	Khadakwasala gaon
14	Kolhewadi
15	Nandoshi phata
16	CWPRS Gate no.1
17	Jadhavwadi Andh shala
18	Nanded phata
19	Mate Pat Sasa company
20	Lagad wasti
21	Dhayari phata
22	Patil colony
23	Wadgaon phata
24	Indican hyum company
25	Manik bag
26	Anand nagar
27	Hingne rasta
28	Vitthalwadi mandir hingne
29	Jaydeo nagar
30	Vitthalwadi Jakat Naka
31	Vitbhatti singhgad rd
32	Ganesh mala
33	Jal shudhikaran kendra singhroad rd
34	Pan mala siinghgad road
35	Dandekar pul
36	Parvati payatha
37	Swargate
38	Lakshi narayan theature
39	Panchami hotel
40	Mafco Company
41	Shivaji putala Kalubai mandir
42	Godown Marketyard
43	Wakhar Mahamandal Marketyard
44	Marketyard','46','05:15
07:30
10:45
13:30
16:05
19:25
06:15
08:45
12:00
14:45
17:50
20:35','06:15
08:50
12:05
14:45
17:30
20:45
07:25
10:10
13:15
16:00
19:10
21:55','Active');
INSERT INTO "busTable" VALUES(133,'25','Upper Depot','Pune Vidyapeeth','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14.5 KMs','63 Minutes','1	Rajiv Gandhi Nagar Upper Depot
2	Upper Indiranagar
3	Chintamani Nagar
4	Lower Indiranagar
5	Bibwewadi
6	Kothari Corner
7	Vasant Bag
8	Pushp Mangal karyalaya
9	Aranyeshwar Corner
10	Bhapkar petrol pump City Pride
11	Panchami hotel
12	Laxmi Narayan Theature
13	Swargate
14	Sarasbag
15	Madiwale colony
16	S P college
17	Maharashtra mandal
18	Sahitya parishad peru gate
19	Deccan Corner Sambhaji Pul Corner
20	Jaykara bangalow
21	Film Institute
22	Law college
23	Bhandarkar Institute
24	Symbiosis college
25	Sheti mahamandal
26	Vetal Maharaj chauk
27	Shivaji housing board bus stop
28	ICC bus stop
29	Chatushringi payatha
30	Pune University Gate
31	Gents hostel university
32	Vidyapeeth Press
33	Ladies Hostel Pune University
34	Pune University Main Building','1	Pune University Main Building
2	Ladies Hostel Pune University
3	Vidyapeeth Press
4	Gents hostel university
5	Pune University Gate
6	Chatushringi payatha
7	ICC bus stop
8	Shivaji housing board bus stop
9	Vetal Maharaj chauk
10	Sheti mahamandal
11	Symbiosis college
12	Bhandarkar Institute
13	Law college
14	Film institute
15	Jaykar Bungalow
16	Nandanvan Bungalow
17	Deccan corner sambhaji pul
18	Sahitya Parishad Peru Gate
19	Maharashtra mandal
20	S P college
21	Madiwale colony
22	Hirabag
23	Swargate corner
24	Swargate
25	Lakshi narayan theature
26	Panchami hotel
27	Bhapkar Petrol Pump City pride
28	Pushp Mangal karyalaya
29	Vasant Bag
30	Kothari Corner
31	Bibwewadi
32	Lower Indiranagar
33	Chintamani Nagar
34	Upper Indiranagar
35	Rajiv Gandhi Nagar Upper Depot','34','06:30
10:40
13:20
15:05
17:15
20:00','07:30
12:15
14:30
16:10
18:20
20:50','Active');
INSERT INTO "busTable" VALUES(134,'252','Manapa','Charholi Alandi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','30 KMs','70 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Mula road bhaiyawadi
11	Pachawadw
12	Holkar Water Supply
13	Sapras post
14	Deccan college
15	Ambedkar Society
16	RTO New
17	Phulenagar
18	MES Water Works
19	Mental Hospital Corner
20	Shantinagar
21	Sathe Biscuit company
22	Vishrantwadi
23	R D colony
24	kalasgaon
25	Mhaske wasti
26	Parade ground
27	Wireless colony
28	AIT college
29	Dighigaon
30	Mitra sahakar nagar
31	Dattanagar
32	Telco godown
33	Bhosari phata
34	Moje vidyalaya
35	Sai madnir
36	Nirma company
37	Gokhale Mala Sankalpa Garden
38	Wadmukhwadi
39	Chincheche jhad
40	Charholi phata
41	Azadnagar Charholi
42	Tapkir Bungalow
43	Dabhade Wasti Charholi
44	Charholi Gaon
45	Charholi Gaon
46	Dabhade Wasti Charholi
47	Tapkir Bungalow
48	Azadnagar Charholi
49	Charholi phata
50	Sai Lila nagar Kate Wasti
51	Moshi Phata Dehu Phata
52	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Azadnagar Charholi
6	Tapkir Bungalow
7	Dabhade Wasti Charholi
8	Charholi Gaon
9	Charholi Gaon
10	Dabhade Wasti Charholi
11	Tapkir Bungalow
12	Azadnagar Charholi
13	Charholi phata
14	Chincheche jhad
15	Wadmukhwadi
16	Gokhale mala sankalp garden
17	Nirma company
18	Sai mandir
19	Moje vidyalaya
20	Bhosari phata
21	Telco godown
22	Dattanagar
23	Mitra sahkar nagar
24	Dighigaon
25	AIT college
26	Wireless colony
27	Parade ground
28	Mhaske wasti
29	Kalasgaon
30	R D colony
31	Vishrantwadi
32	Sathe Biscuit company
33	Shantinagar
34	Mental Hospital Corner
35	MES Water Works
36	Phulenagar
37	RTO New
38	Ambedkar Society
39	Deccan college
40	Sapras post
41	Holkar Water Supply
42	Pachwade
43	Mula bhaiyawadi
44	Poultry Farm Old Mumbai Pune Road
45	Mariaai Gate Old Mumbai Pune Road
46	Bajaj showroom
47	Labor office
48	Patil Estate
49	Engineering college hostel
50	Shivaji putala
51	PMC','52','05:30
07:50
16:00
18:50','06:40
09:00
17:10
20:00','Active');
INSERT INTO "busTable" VALUES(135,'253','Manapa','Vidyanagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.6 KMs','38 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Mula road bhaiyawadi
11	Pachawadw
12	Holkar Water Supply
13	Sapras post
14	Deccan college
15	Ambedkar Society
16	RTO New
17	Phulenagar
18	MES Water Works
19	Mental Hospital Corner
20	Shantinagar
21	Sathe Biscuit company
22	Vishrantwadi
23	Vishrantwadi corner
24	Kasturba general hospital
25	Gandhi Acid Company
26	Tingre nagar Shanti nagar
27	Medical Stores
28	Grampanchayat Tingrenagar
29	Vidyanagar Swapnaganga bangalow','1	Vidyanagar Swapnaganga bangalow
2	Grampanchayat Tingrenagar
3	Medical stores
4	Tingre nagar Shanti nagar
5	Gandhi Acid Company
6	Kasturba general hospital
7	Vishrantwadi corner
8	Vishrantwadi chauk
9	Sathe Biscuit company
10	Shantinagar
11	Mental Hospital Corner
12	MES Water Works
13	Phulenagar
14	RTO New
15	Ambedkar Society
16	Deccan college
17	Sapras post
18	Holkar Water Supply
19	Pachwade
20	Mula bhaiyawadi
21	Poultry Farm Old Mumbai Pune Road
22	Mariaai Gate Old Mumbai Pune Road
23	Bajaj showroom
24	Labor office
25	Patil Estate
26	Engineering college hostel
27	Shivaji putala
28	PMC','29','05:30
07:05
08:25
10:15
11:35
12:55
14:25
15:45
17:05
18:50
20:20
06:10
07:30
08:55
10:45
12:00
13:20
14:55
16:15
17:35
19:25
20:45
06:40
08:00
09:20
11:10
12:30
13:50
15:25
16:45
18:05
19:55
21:20','06:10
07:45
09:05
10:45
12:15
13:30
15:00
16:30
17:45
19:30
21:00
06:50
08:15
09:40
11:20
12:40
14:00
15:35
16:55
18:05
19:55
21:20
07:10
08:40
10:00
11:50
13:10
14:30
16:05
17:25
18:35
20:25
22:00','Active');
INSERT INTO "busTable" VALUES(136,'256','Manapa','Balewadi Mojhe vidyalay','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13.5 KMs','42 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Masoba gate
5	Pumping station
6	Pune central
7	E square
8	Rangehills Corner
9	Pune University Gate
10	chavan nagar university road
11	Sakal nagar
12	Sindh colony
13	Baner phata
14	Green Park hotel
15	Trimurti bunglow
16	Ambedkar nagar
17	Murkute wasti
18	Baner gaon
19	Baner odha
20	Balewadi Phata
21	Chakankar mala
22	Deasi poultry farm
23	Balewadi
24	Bharat English school
25	Mojhe Vidyalay','1	Mojhe Vidyalay
2	Bharat English School
3	Balewadi
4	Desai Poultry Farm
5	Chakankar Mala
6	Balewadi Phata
7	Baner odha
8	Baner Gaon
9	Murkutewasti Pavitra hotel
10	Ambedkar Nagar
11	Trimurti Bungalow
12	Green park hotel
13	Baner phata
14	Sindh colony
15	Sakal nagar
16	Chavan Nagar University Road
17	Pune University Gate
18	Pune University Gate
19	Rangehills Corner
20	E Square
21	Pune central
22	Pumping station
23	Masoba gate
24	shimala office shivajinagar
25	Engineering college hostel
26	Shivaji putala
27	PMC','25','05:50
07:10
08:30
10:35
12:00
14:30
15:50
17:20
19:30
20:50
06:00
07:20
08:40
10:10
12:10
14:40
16:00
17:30
19:05
21:00
06:10
07:30
08:50
11:00
12:25
14:50
16:10
17:40
19:45
21:10
06:20
07:40
09:00
11:10
12:35
15:00
16:20
17:50
20:00
21:25
06:30
07:50
09:10
11:20
12:45
15:10
16:30
18:00
20:10
21:35
06:40
08:00
09:20
11:30
12:55
15:20
16:40
18:10
20:20
21:45
06:50
08:10
09:35
11:40
13:05
15:30
16:50
18:25
20:35
21:55
07:00
08:20
09:45
11:50
13:15
15:40
17:05
18:40
20:40
22:10','06:30
07:50
09:20
11:25
12:40
15:10
16:35
18:05
20:10
21:30
06:40
08:00
09:30
11:00
12:50
15:20
16:45
18:20
19:50
21:40
06:50
08:10
09:40
11:40
13:00
15:30
16:55
18:30
20:35
21:50
07:00
08:20
09:50
11:50
13:10
15:40
17:05
18:40
20:45
22:00
07:10
08:30
10:00
12:00
13:20
15:50
17:15
18:50
20:55
22:10
07:20
08:40
10:10
12:10
13:30
16:00
17:25
19:00
21:05
22:20
07:30
08:50
10:20
12:20
13:40
16:25
17:35
19:10
21:15
22:30
07:40
09:00
10:35
12:30
13:50
16:15
17:50
19:25
21:25
22:40','Active');
INSERT INTO "busTable" VALUES(137,'257','Manapa','Markal gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','34.2 KMs','67 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Ruby hall
8	Guruprasad bangala
9	Band garden
10	Yerwada
11	wadia bangala
12	Shastri nagar
13	Agakhan palace
14	Ramwadi Jakatnaka
15	Ramwadi
16	Weikfield
17	ISL Company
18	WNC Company
19	Dharmanagar 5 va Mail
20	Tata Guardroom Kharadi Phata
21	Chandan Nagar
22	NEI Company
23	Nagarroad Phata Shriramnagar
24	NEI Company
25	Naik bungalow
26	Janakbaba Darga
27	Ramnarayan Bungalow
28	Lieson company
29	Satav High School
30	Wagholi
31	Kesanand phata
32	Pacharne wasti
33	Bharti Jain Sanghatna College
34	Jagtap Dairy Lonikand
35	Lonikand
36	Phulgaon Phata
37	Power house markal
38	Kukkut palan kendra
39	Raysoni farm
40	Sakore mala
41	Malwadi Phulgaon
42	Phulgaon
43	Balsadan
44	Tulapur
45	Indrayani pul
46	Markal Gaon','1	Markal Gaon
2	Indrayani Nadi Pool
3	Tulapur
4	Balsadan
5	Phulgaon
6	Malwadi Phulgaon
7	Sakore Mala
8	Raysoni Farm
9	Kukut Palan Kendra
10	Power House Markal
11	Phulgaon phata
12	Lonikand
13	Jagtap Dairy Lonikand
14	Bharti Jain Sanghatna College
15	Pacharne wasti
16	Kesanand phata
17	Wagholi
18	Satva high school
19	Lieson Company
20	Ramnarayan Bungalow
21	Janakbaba Darga
22	Naik Bungalow
23	NEI company
24	Nagarroad Phata Shriramnagar
25	NEI Company
26	Chandan nagar
27	Tata gaurdroom Kharadi phata
28	Dharmanagar 5 va mail
29	WNC Company
30	ISL Company
31	Weikfield
32	Ramwadi
33	Ramwadi jakatnaka
34	Agakhan palace
35	Shastri nagar
36	Wadia bunglow
37	Yerwada
38	Band garden
39	Guruprasad bangala
40	Jahangir Hospital
41	Alankar Talkies
42	Sadhu wasvani chauk
43	GPO
44	Collector kacheri
45	Ambedkar bhavan
46	Juna Bajar
47	Kumbhar wada
48	PMC','46','05:30
08:45
11:30
14:20
17:35
20:20','06:50
10:05
12:50
15:40
18:55','Active');
INSERT INTO "busTable" VALUES(138,'26','Dhankavadi','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','60 Minutes','1	Dhankawadi
2	Pratibhanagar
3	Gulabnagar
4	Balaji nagar
5	Vishweshwar Bank KK market
6	Padmavati corner
7	Natu bag
8	Aranyeshwar Corner
9	Bhapkar petrol pump City Pride
10	Panchami hotel
11	Laxmi Narayan Theature
12	Swargate
13	Sarasbag
14	Madiwale colony
15	S P college
16	Maharashtra mandal
17	Sahitya parishad peru gate
18	Goodluck Chowk
19	F C College
20	Dnyaneshwar Paduka chowk
21	Police Line Modern College
22	shimala office shivajinagar
23	Lokmangal
24	RTO wellesley road
25	Juna Bajar
26	Ambedkar bhavan
27	Sasoon hospital
28	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	Collector kacheri
4	Ambedkar bhavan
5	Juna Bajar
6	RTO wellesley road
7	Engineering college hostel
8	Modern Highschool
9	Balgandharv sambhaji par
10	Deccan Gymkhana
11	Sahitya Parishad Peru Gate
12	Maharashtra mandal
13	S P college
14	Madiwale colony
15	Hirabag
16	Swargate corner
17	Swargate
18	Lakshi narayan theature
19	Panchami hotel
20	Bhapkar Petrol Pump City pride
21	Aranyeshwar Corner
22	Natu Bag
23	Padmavati corner
24	Vishweshwar Bank KK market
25	Balaji nagar
26	Gulabnagar
27	Pratibhanagar
28	Dhankawadi','28','06:00
07:50
10:05
12:50
15:10
17:30
20:30
06:30
08:30
10:35
15:45
18:00
20:00
07:00
08:55
11:05
13:50
16:20
18:40
21:40
09:30
11:45
13:20
16:55
19:05
21:15','06:50
08:55
11:40
13:50
16:15
18:35
21:40
07:10
09:30
11:30
16:35
19:05
20:55
07:55
10:00
12:45
14:50
17:25
20:25
22:50
10:35
12:35
14:45
18:00
20:25
22:05','Active');
INSERT INTO "busTable" VALUES(139,'262','Manapa','Dehu gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','31.3 KMs','66 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Deichi company
25	Vallabhnagar
26	HA Factory D Y Patil college
27	Kharalwadi
28	Pimpri chauk Bus stop
29	Finolex
30	Premier company
31	Chinchwad station
32	Mehta hospital
33	Kalbhor nagar bus stop
34	Rustan company
35	Akurdi khandoba chauk
36	Bajaj auto
37	Pradhikaran Chowk
38	Nigadi jakat naka
39	Cantonment jakat naka
40	Kohima line
41	B sub depot
42	Kendriya vidyalaya
43	Garden city
44	CISV
45	Dehu phata highway
46	Dehuroad railway staion
47	Dehu road railway station
48	Dehu phata highway
49	Ashoknagar Dehuroad
50	Chincholi
51	Paduka mandir
52	COD Corner
53	Zhende mala
54	Kudba kruti Manmohan
55	Malwadi Dehu
56	Dehugaon grampanchayat
57	Dehugaon','1	Dehugaon
2	Dehugaon Grampanchayat
3	Malwadi Dehu
4	Kudba Kruti Manmohan
5	Zhende mala
6	COD corner
7	Paduka Mandir
8	Chincholi
9	Ashoknagar Dehuroad
10	Dehu phata highway
11	Dehuroad railway staion
12	Dehu road railway station
13	Dehu phata highway
14	CISV
15	Garden City
16	Kendriya Vidyalaya
17	B Sub Depot
18	Kohima Line
19	Cantonment Jakat Naka
20	Nigadi jakat naka
21	Nigadi
22	Pradhikaran Chowk
23	Bajaj auto
24	Akurdi Khandoba Chowk
25	Ruston Company
26	Kalbhor nahar bus stop
27	Mehta hospital
28	chinchwad station
29	Chinchwad chauk
30	Premier company
31	Finolex
32	Pimpri chauk Bus stand
33	Kharalwadi
34	H A Factory
35	Vallabhnagar
36	Deichi Company
37	Nashik phata
38	Kasarwadi
39	Forbes marshal stop
40	Alfa Laval Atlas Company
41	Sandwik
42	Fugewadi
43	Dapodi
44	Bopodi Jakat Naka
45	Khadaki
46	Khadaki railway station
47	Khadaki church stop
48	Khadaki post office
49	Raja bangalow
50	Krutrim Reshim Paidas Kendra
51	Poultry Farm Old Mumbai Pune Road
52	Mariaai Gate Old Mumbai Pune Road
53	Bajaj showroom
54	Labor office
55	Patil Estate
56	Engineering college hostel
57	Shivaji putala
58	PMC','57','07:50
11:15
14:20
17:40
20:35
07:20
10:00
13:20
16:10
18:35
21:30','06:30
09:10
12:45
15:50
19:00
08:40
11:20
14:45
17:20
19:50','Active');
INSERT INTO "busTable" VALUES(140,'264','Manapa','Bahul gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','38 KMs','70 Minutes','1	PMC
2	shimala office shivajinagar
3	Lokmangal
4	Patil Estate
5	Labour office
6	Bajaj showroom wakadewadi
7	Mariaai Gate Old Mumbai Pune Road
8	Poultry Farm Old Mumbai Pune Road
9	Mula road bhaiyawadi
10	Pachawadw
11	Holkar Water Supply
12	Sapras post
13	Deccan college
14	Ambedkar Society
15	RTO New
16	Phulenagar
17	MES Water Works
18	Mental Hospital Corner
19	Shantinagar
20	Sathe Biscuit company
21	Vishrantwadi
22	R D colony
23	kalasgaon
24	Mhaske wasti
25	Parade ground
26	Wireless colony
27	AIT college
28	Dighigaon
29	Mitra sahakar nagar
30	Dattanagar
31	Telco godown
32	Bhosari phata
33	Moje vidyalaya
34	Sai madnir
35	Nirma company
36	Gokhale Mala Sankalpa Garden
37	Wadmukhwadi
38	Chincheche jhad
39	Charholi phata
40	Sai Lila nagar Kate Wasti
41	Moshi Phata Dehu Phata
42	Alandi jakat naka
43	Navin ST stand
44	Dnyaneshwar Bhint
45	Devpari Maharaj Mandir
46	Thakur Wasti
47	Rechared Company
48	Gavane Vasti
49	Pawar Wasti
50	Wadgaon Ghenand Shala
51	Ghenand wasti
52	Koyali Phata
53	Chakan Phata
54	Shel Pimpalgaon
55	Rajsthan Hostel
56	Chincholi Phata
57	Mohitewadi
58	Bahulgaon Phata
59	Subhash Vidyalaya
60	Bahulgaon','1	Bahulgaon
2	Subhash Vidyalaya
3	Bahulgaon Phata
4	Mohitewadi
5	Chincholi Phata
6	Rajsthan Hostel
7	Shel Pimpalgaon
8	Chakan Phata
9	Koyali Phata
10	Ghenand wasti
11	Wadgaon Ghenand Shala
12	Pawar Wasti
13	Gavane Vasti
14	Rechared Company
15	Thakur Wasti
16	Devpari Maharaj Mandir
17	Dnyaneshwar Bhint
18	Alandi bus stand
19	Dehu phata
20	Sai lila nagar kate wasti
21	Charholi phata
22	Chincheche jhad
23	Wadmukhwadi
24	Gokhale mala sankalp garden
25	Nirma company
26	Dnyaneshwar June Nivas/Sai Mandir
27	Sai mandir
28	Moje vidyalaya
29	Bhosari phata
30	Telco godown
31	Dattanagar
32	Mitra sahkar nagar
33	Dighigaon
34	AIT college
35	Wireless colony
36	Parade ground
37	Mhaske wasti
38	Kalasgaon
39	R D colony
40	Vishrantwadi
41	Sathe Biscuit company
42	Shantinagar
43	Mental Hospital Corner
44	MES Water Works
45	Phulenagar
46	RTO New
47	Ambedkar Society
48	Deccan college
49	Sapras post
50	Holkar Water Supply
51	Pachwade
52	Mula bhaiyawadi
53	Poultry Farm Old Mumbai Pune Road
54	Mariaai Gate Old Mumbai Pune Road
55	Bajaj showroom
56	Labor office
57	Patil Estate
58	Engineering college hostel
59	Shivaji putala
60	PMC','60','09:30
15:00
18:50','07:15
11:15
16:45','Active');
INSERT INTO "busTable" VALUES(141,'27','Bharti Vidyapeeth','Shivajinagar Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','49 Minutes','1	PICT Bharati vidyapeeth
2	Rajaram Gas agency
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Madiwale colony
17	S P college
18	Maharashtra mandal
19	Sahitya parishad peru gate
20	Goodluck Chowk
21	F C College
22	Dnyaneshwar Paduka chowk
23	shimala office shivajinagar
24	Shivajinagar Station','1	Shivajinagar Station
2	Sancheti Hospital
3	Modern Highschool
4	Balgandharv sambhaji par
5	Deccan Gymkhana
6	Sahitya Parishad Peru Gate
7	Maharashtra mandal
8	S P college
9	Madiwale colony
10	Hirabag
11	Swargate corner
12	Swargate
13	Lakshi narayan theature
14	Panchami hotel
15	Bhapkar Petrol Pump City pride
16	Aranyeshwar Corner
17	Natu Bag
18	Padmavati corner
19	Vishweshwar Bank KK market
20	Balaji nagar
21	Chaitanya nagar
22	Bharti vidyapeeth gate
23	Katraj dairy Sarpodyan
24	Rajaram Gas agency
25	Chandrabhaga Restaurant
26	Ganpati mandir
27	PICT Bharati vidyapeeth','24','06:00
07:45
09:30
11:45
13:40
15:20
17:00
19:20
06:30
08:20
10:10
12:25
15:55
17:35
19:50
21:30
07:05
08:55
10:45
13:00
14:45
16:25
18:05
20:30','06:50
08:35
10:20
12:35
14:35
16:10
17:50
20:10
07:20
09:10
11:00
13:05
16:45
18:25
20:40
22:00
07:55
09:45
11:35
13:50
15:35
17:15
19:00
21:20','Active');
INSERT INTO "busTable" VALUES(142,'276','Warje malwadi','Chinchwad gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','24.9 KMs','78 Minutes','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Law college
15	Bhandarkar Institute
16	Symbiosis college
17	Sheti mahamandal
18	Vetal Maharaj chauk
19	Shivaji housing board bus stop
20	ICC bus stop
21	Chatushringi payatha
22	Rajbhavan
23	Boys batalian
24	Kasturba vasahat
25	Sindh colony gate 2
26	Bremen chauk
27	Body gate
28	Aundh gaon
29	Sangvi phata
30	Aundh chest hospital
31	Aundh post office
32	ESI Hospital
33	Rakshak chauk
34	Military Stores
35	Wakad phata
36	Jagtap Dairy
37	Kaspate Vasti
38	Kalewadi phata
39	16 Number
40	Laxman nagar
41	Dange chowk
42	Thergaon phata
43	Padmji Paper Mill
44	Dattanagar Chinchwad
45	Birla Hospital
46	Jakatnaka pavanapul
47	Walhekarwadi phata
48	Chafekar chauk
49	Chinchwad gaon','1	Chinchwad gaon
2	Chafekar chauk
3	Walhekarwadi Phata
4	Jakatnaka Pavanapool
5	Birla hospital
6	Dattanagar Chinchwad
7	Padmji Paper Mill
8	Thergaon phata
9	Dange chowk
10	Laxman nagar
11	16 Number
12	Kalewadi phata
13	Kaspate Vasti
14	Jagtap Dairy
15	Wakad phata
16	Military Stores
17	Rakshak chauk
18	ESI Hospital
19	Aundh post office
20	Aundh chest hospital
21	Sangvi Phata
22	Aundh gaon
23	Body gate
24	Bremen chauk
25	Sindh Colony Gate2
26	Kasturba vasahat
27	Boys Batalian
28	Pune University Gate
29	Chatushringi payatha
30	ICC bus stop
31	Shivaji housing board bus stop
32	Vetal Maharaj chauk
33	Sheti mahamandal
34	Symbiosis college
35	Bhandarkar Institute
36	Law college
37	SNDT college
38	Paud Phata Dashabhuja Ganpati
39	Maruti mandir karve road
40	Karve putala
41	Kothrud Stand
42	Dahanukar colony
43	Wadache Jhad Bhairavnath Mandir
44	Karvenagar
45	Warje Jakatnaka
46	Tapodham
47	Warje Malwadi
48	Dnanesh society
49	Ganpati matha','49','05:40
08:10
11:30
14:30
17:05
20:30
06:05
08:35
11:55
15:00
17:35
21:00
06:30
09:00
12:20
15:25
18:00
21:30
06:55
09:30
12:45
15:50
18:30
07:20
10:00
13:15
16:15
19:00
07:45
10:30
13:45
16:40
19:30','06:50
09:35
12:45
15:40
18:30
21:50
07:15
10:00
13:10
16:10
19:00
22:20
07:40
10:25
13:35
16:35
19:30
22:45
08:10
10:55
14:00
17:00
20:00
08:35
11:25
14:25
17:30
20:30
09:05
11:55
14:55
18:00
21:00','Active');
INSERT INTO "busTable" VALUES(143,'277','NDA gate','Khadki Bazar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','24 KMs','78 Minutes','1	NDA gate Kondhava gate
2	Kondhava dhavade
3	Bhimnagar
4	Uttamanagar
5	Ahire gate Phata
6	Ingale colony
7	Deshmukhwadi
8	Shivane gaon
9	Dudhane wasti
10	Ganpati matha
11	Dnanesh society
12	Warje malwadi
13	Tapodham
14	Warje jakatnaka
15	Karvenagar
16	Wadache jhad
17	Dahanukar colony
18	Kothrud Stand
19	Karve putala
20	Maruti Mandir Karve Road
21	Paud phata dashbhuja mandir
22	SNDT college
23	Law college
24	Bhandarkar Institute
25	Symbiosis college
26	Sheti mahamandal
27	Vetal Maharaj chauk
28	Shivaji housing board bus stop
29	ICC bus stop
30	Chatushringi payatha
31	Pune University Gate
32	Gents hostel university
33	Vidyapeeth Press
34	Ladies Hostel Pune University
35	Pune University Main Building
36	HM Hostel
37	Queen Mary Technical
38	Khadaki railway station
39	LIC Colony Khadki
40	40 aundh road
41	Bhaurao Patil Chowk
42	Bopodi Gaon
43	Bopodi Jakat Naka
44	Gangaram park
45	Kirloskar oil engine manaji bag
46	Alegaonkar High school
47	Khadki Bazar','1	Khadaki bajar
2	Alegaonkar High school
3	Kirloskar Oil Engine Manaji Bag
4	Gangaram park
5	Bopodi
6	Bopodi Gaon
7	Bhaurao Patil Chowk
8	40 Aundh Road
9	LIC Colony Khadaki
10	Khadaki railway station
11	Queen Mary Technical
12	HM Hostel
13	Pune University Main Building
14	Ladies Hostel Pune University
15	Vidyapeeth Press
16	Gents hostel university
17	Pune University Gate
18	Chatushringi payatha
19	ICC bus stop
20	Shivaji housing board bus stop
21	Vetal Maharaj chauk
22	Sheti mahamandal
23	Symbiosis college
24	Bhandarkar Institute
25	Law college
26	Nal Stop
27	SNDT college
28	Paud Phata Dashabhuja Ganpati
29	Maruti mandir karve road
30	Karve putala
31	Karve putala
32	Kothrud Stand
33	Dahanukar colony
34	Wadache Jhad Bhairavnath Mandir
35	Karvenagar
36	Warje Jakatnaka
37	Tapodham
38	Warje Malwadi
39	Dnanesh society
40	Ganpati matha
41	Dudhane wasti
42	Shivane Gaon
43	Deshmukhwadi
44	Ingale Colony
45	Ahire gate phata
46	Uttamnagar
47	Bhimnagar
48	Kondhava Dhavde
49	NDA gate Kondhva Gate','47','05:55
08:20
11:30
14:20
17:00
07:00
09:25
12:35
15:20
18:00','07:00
09:40
12:50
15:40
18:20
08:10
10:50
13:50
16:40
19:20','Active');
INSERT INTO "busTable" VALUES(144,'278','Katraj bus stand','Kothrud Depot','Mon, Tue, Wed, Thu, Fri, Sat, Sun','16 KMs','57 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati Bus stand
9	Power house Padmavati
10	Date Bus stop
11	Nandadeep
12	Gandhi Training Corner
13	Sarang Society
14	Lakshminagar Corner
15	Laxminagar police chauki
16	Bank of Maharashtra Parvati gaon
17	Mitramandal Sabhagruh
18	Parvati payatha
19	Sarasbag
20	Madiwale colony
21	S P college
22	Maharashtra mandal
23	Sahitya parishad peru gate
24	Deccan corner sambhaji pool
25	Garware college
26	Petrol Pump Karve Road
27	Nal Stop
28	SNDT college
29	Paud phata police chauky
30	More vidyalaya
31	LIC colony
32	Anand nagar paud road
33	Jai bhavani
34	Vanaz Corner
35	Vanaz company
36	Kachara depot
37	Bharti nagar
38	kothrud depot','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Sahitya Parishad Peru Gate
17	Maharashtra mandal
18	S P college
19	Madiwale colony
20	Hirabag
21	Swargate corner
22	Parvati payatha
23	Mitramandal Sabhagruh
24	Bank of Maharashtra Parvati gaon
25	Laxminagar police chauki
26	Lakshminagar Corner
27	Sarang Society
28	Gandhi Training Corner
29	Nandadeep
30	Date Bus stop
31	Power house Padmavati
32	Padmavati Bus stand
33	Vishweshwar Bank KK market
34	Balaji nagar
35	Chaitanya nagar
36	Bharti vidyapeeth gate
37	Katraj dairy Sarpodyan
38	More bag
39	Katraj bus stand','38','08:00
10:20
16:40','09:00
11:30
17:50','Active');
INSERT INTO "busTable" VALUES(145,'28','Bharti Vidyapeeth','Pune Vidyapeeth','Mon, Tue, Wed, Thu, Fri, Sat, Sun','16 KMs','63 Minutes','1	PICT Bharati vidyapeeth
2	Rajaram Gas agency
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Padmavati Bus stand
10	Power house Padmavati
11	Date Bus stop
12	Nandadeep
13	Gandhi Training Corner
14	Lakshminagar Corner
15	Bank of Maharashtra Parvati gaon
16	Mitramandal Sabhagruh
17	Parvati payatha
18	Dandekar pul
19	Petrol Pump Rajendranagar
20	Lokmanya nagar
21	Dattawadi pul
22	Mahadeo mandir
23	Mehandale Guarage
24	Film Institute
25	Law college
26	Bhandarkar Institute
27	Symbiosis college
28	Sheti mahamandal
29	Vetal Maharaj chauk
30	Shivaji housing board bus stop
31	ICC bus stop
32	Chatushringi payatha
33	Pune University Gate
34	Gents hostel university
35	Vidyapeeth Press
36	Ladies Hostel Pune University
37	Pune University Main Building','1	Pune University Main Building
2	Ladies Hostel Pune University
3	Vidyapeeth Press
4	Gents hostel university
5	Pune University Gate
6	Chatushringi payatha
7	ICC bus stop
8	Shivaji housing board bus stop
9	Vetal Maharaj chauk
10	Sheti mahamandal
11	Symbiosis college
12	Bhandarkar Institute
13	Law college
14	Film institute
15	Mehandale Guarage
16	Mahadeo mandir
17	Dattawadi pul
18	Lokmanya nagar
19	Petrol pump rajendranagar
20	Dandekar pul
21	Parvati payatha
22	Mitramandal Sabhagruh
23	Bank of Maharashtra Parvati gaon
24	Lakshminagar Corner
25	Gandhi Training Corner
26	Nandadeep
27	Date Bus stop
28	Power house Padmavati
29	Padmavati Bus stand
30	Padmavati corner
31	Vishweshwar Bank KK market
32	Balaji nagar
33	Chaitanya nagar
34	Bharti vidyapeeth gate
35	Katraj dairy Sarpodyan
36	Rajaram Gas agency
37	Chandrabhaga Restaurant
38	Ganpati mandir
39	PICT Bharati vidyapeeth','37','09:10
11:40
04:50','10:20
12:20
06:10','Active');
INSERT INTO "busTable" VALUES(146,'281','Warje Malwadi','Nigdi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','28.1 KMs','91 Minutes','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Goodluck Chowk
19	F C College
20	Dnyaneshwar paduka chauk
21	shimala office shivajinagar
22	Lokmangal
23	Patil Estate
24	Labour office
25	Bajaj showroom wakadewadi
26	Mariaai Gate Old Mumbai Pune Road
27	Poultry Farm Old Mumbai Pune Road
28	Krutrim reshim paidas kendra
29	Raja Bungalow
30	Khadaki post office
31	Khadki church stop
32	Khadaki railway station
33	Khadaki
34	Bopodi
35	Dapodi
36	Fugewadi
37	Sandwik
38	Alfa laval atlas company
39	Forbes marshal stop
40	Kasrawadi
41	Nashik phata
42	Deichi company
43	Vallabhnagar
44	HA Factory D Y Patil college
45	Kharalwadi
46	Pimpri chauk Bus stop
47	Finolex
48	Premier company
49	Chinchwad station
50	Mehta hospital
51	Kalbhor nagar bus stop
52	Rustan company
53	Akurdi khandoba chauk
54	Bajaj auto
55	Pradhikaran Chowk
56	Nigadi jakat naka
57	Bhakti shakti depot','1	Bhakti shakti depot
2	Nigadi jakat naka
3	Nigadi
4	Bajaj auto
5	Akurdi Khandoba Chowk
6	Ruston Company
7	Kalbhor nahar bus stop
8	Mehta hospital
9	chinchwad station
10	Chinchwad chauk
11	Premier company
12	Finolex
13	Pimpri chauk Bus stand
14	Kharalwadi
15	H A Factory
16	Vallabhnagar
17	Deichi Company
18	Nashik phata
19	Kasarwadi
20	Forbes marshal stop
21	Alfa Laval Atlas Company
22	Sandwik
23	Fugewadi
24	Dapodi
25	Bopodi Jakat Naka
26	Bopodi
27	Khadaki
28	Khadaki railway station
29	Khadaki church stop
30	Khadaki post office
31	Raja bangalow
32	Krutrim Reshim Paidas Kendra
33	Poultry Farm Old Mumbai Pune Road
34	Mariaai Gate Old Mumbai Pune Road
35	Bajaj showroom
36	Labor office
37	Patil Estate
38	Engineering college hostel
39	Modern Highschool
40	Deccan Gymkhana
41	Deccan corner sambhaji pool
42	Garware college
43	Petrol Pump Karve Road
44	Nal Stop
45	SNDT college
46	Paud Phata Dashabhuja Ganpati
47	Maruti mandir karve road
48	Karve putala
49	Kothrud Stand
50	Dahanukar colony
51	Wadache Jhad Bhairavnath Mandir
52	Karvenagar
53	Warje Jakatnaka
54	Tapodham
55	Warje Malwadi
56	Dnanesh society
57	Ganpati matha','57','05:35
08:30
12:00
14:50
18:50
06:20
09:15
12:45
15:35
19:30
07:05
10:00
13:30
16:15
20:20
07:55
11:20
14:20
17:10
21:10
10:40
13:50
18:15
22:10','07:00
10:00
13:15
16:35
20:25
07:50
10:45
14:05
17:10
21:15
08:30
11:30
14:45
17:50
21:55
09:25
12:55
15:45
18:45
22:45
12:15
15:15
19:45
23:45','Active');
INSERT INTO "busTable" VALUES(147,'282','Warje Malwadi','Bhosari','Mon, Tue, Wed, Thu, Fri, Sat, Sun','27 KMs','88 Minutes','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Goodluck Chowk
19	F C College
20	Dnyaneshwar paduka chauk
21	shimala office shivajinagar
22	Lokmangal
23	Patil Estate
24	Labour office
25	Bajaj showroom wakadewadi
26	Mariaai Gate Old Mumbai Pune Road
27	Poultry Farm Old Mumbai Pune Road
28	Krutrim reshim paidas kendra
29	Raja Bungalow
30	Khadaki post office
31	Khadki church stop
32	Khadaki railway station
33	Khadaki
34	Bopodi
35	Dapodi
36	Fugewadi
37	Sandwik
38	Alfa laval atlas company
39	Forbes marshal stop
40	Kasrawadi
41	Nashik phata
42	Bhosari police station
43	MIDC bhosari
44	Philips
45	Landewadi
46	Gavane Vasti
47	Bhosari gaon','1	Bhosari gaon
2	Gavane Vasti
3	Landewadi
4	Philips
5	MIDC Bhosari
6	Bhosari police station
7	Nashik phata
8	Kasarwadi
9	Forbes marshal stop
10	Alfa Laval Atlas Company
11	Sandwik
12	Fugewadi
13	Dapodi
14	Bopodi Jakat Naka
15	Bopodi
16	Khadaki
17	Khadaki railway station
18	Khadaki church stop
19	Khadaki post office
20	Raja bangalow
21	Krutrim Reshim Paidas Kendra
22	Poultry Farm Old Mumbai Pune Road
23	Mariaai Gate Old Mumbai Pune Road
24	Bajaj showroom
25	Labor office
26	Patil Estate
27	Engineering college hostel
28	Modern Highschool
29	Balgandharv sambhaji par
30	Deccan Gymkhana
31	Deccan Corner Sambhaji Pul Corner
32	Garware college
33	Petrol Pump Karve Road
34	Nal Stop
35	SNDT college
36	Paud Phata Dashabhuja Ganpati
37	Maruti mandir karve road
38	Karve putala
39	Kothrud Stand
40	Dahanukar colony
41	Wadache Jhad Bhairavnath Mandir
42	Karvenagar
43	Warje Jakatnaka
44	Tapodham
45	Warje Malwadi
46	Dnanesh society
47	Ganpati matha','47','05:50
08:30
12:00
14:50
18:20
06:30
09:05
12:35
15:25
18:55
07:00
09:40
13:10
16:00
19:30
07:30
10:15
13:45
16:35
20:35
08:00
10:50
14:20
17:10
08:45
11:35
15:05
17:45','07:00
10:00
13:15
16:35
20:05
07:45
10:35
13:50
17:10
20:40
08:15
11:10
14:25
17:45
21:15
08:45
11:45
15:00
18:20
22:20
09:20
12:20
15:35
18:55
10:15
13:35
16:20
19:10','Active');
INSERT INTO "busTable" VALUES(148,'283','Kumbre park','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.5 KMs','58 Minutes','1	Kumbare Park
2	Guruganesh Nagar
3	Ashish Garden
4	Mahesh Vidyalaya
5	Sahajanand Soc
6	Gandhibhavan Andhshala
7	Dahanukar colony
8	Kothrud Stand
9	Karve putala
10	Maruti Mandir Karve Road
11	Paud phata dashbhuja mandir
12	SNDT college
13	Nal stop
14	Petrol pump karve road
15	Garware college
16	Deccan corner sambhaji pul
17	Alka talkies
18	Chitrashala
19	Sadashiv Peth Houd
20	Vishrambag wada
21	A B Chowk
22	Dakshinabhimukh Maruti mandir
23	Shaniwar wada
24	Kasaba Police Chowky
25	Lalmahal
26	Phadake Haud
27	RCM
28	KEM hospital
29	15 August Lodge Somwar Peth
30	Ambedkar bhavan
31	Sasoon hospital
32	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Zila Parishad
6	15 August Lodge Somwar Peth
7	KEM hospital
8	Apolo talkies
9	RCM
10	Daruwala Pool
11	Sonya Maruti Chowk
12	City post
13	Kunte Chauk
14	Gokhale hall
15	Vijay Talkies
16	Alka talkies
17	Deccan Corner Sambhaji Pul Corner
18	Garware college
19	Petrol Pump Karve Road
20	Nal Stop
21	SNDT college
22	Paud Phata Dashabhuja Ganpati
23	Maruti mandir karve road
24	Karve putala
25	Kothrud Stand
26	Dahanukar colony
27	Andhshala
28	Sahajanand Soc
29	Mahesh vidyalaya
30	Ashish Garden
31	Guruganesh nagar
32	Kumbare Park','32','06:05
07:55
09:50
12:25
14:25
16:15
18:15
20:45
06:50
08:40
10:45
13:15
15:10
17:10
19:45','06:55
08:50
10:50
13:15
15:20
17:15
19:15
21:45
07:40
09:45
11:50
14:15
16:10
18:10
20:45','Active');
INSERT INTO "busTable" VALUES(149,'284','Kothrud depot','Nigdi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','26.3 KMs','88 Minutes','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Goodluck Chowk
17	F C College
18	Dnyaneshwar paduka chauk
19	shimala office shivajinagar
20	Lokmangal
21	Patil Estate
22	Labour office
23	Bajaj showroom wakadewadi
24	Mariaai Gate Old Mumbai Pune Road
25	Poultry Farm Old Mumbai Pune Road
26	Krutrim reshim paidas kendra
27	Raja Bungalow
28	Khadaki post office
29	Khadki church stop
30	Khadaki railway station
31	Khadaki
32	Bopodi
33	Dapodi
34	Fugewadi
35	Sandwik
36	Alfa laval atlas company
37	Forbes marshal stop
38	Kasrawadi
39	Nashik phata
40	Deichi company
41	Vallabhnagar
42	HA Factory D Y Patil college
43	Kharalwadi
44	Pimpri chauk Bus stop
45	Finolex
46	Premier company
47	Chinchwad station
48	Mehta hospital
49	Kalbhor nagar bus stop
50	Rustan company
51	Akurdi khandoba chauk
52	Bajaj auto
53	Pradhikaran Chowk
54	Nigadi jakat naka
55	Bhakti shakti depot','1	Bhakti shakti depot
2	Nigadi jakat naka
3	Nigadi
4	Bajaj auto
5	Akurdi Khandoba Chowk
6	Ruston Company
7	Kalbhor nahar bus stop
8	Mehta hospital
9	chinchwad station
10	Chinchwad chauk
11	Premier company
12	Finolex
13	Pimpri chauk Bus stand
14	Kharalwadi
15	H A Factory
16	Vallabhnagar
17	Deichi Company
18	Nashik phata
19	Kasarwadi
20	Forbes marshal stop
21	Alfa Laval Atlas Company
22	Sandwik
23	Fugewadi
24	Dapodi
25	Bopodi Jakat Naka
26	Bopodi
27	Khadaki
28	Khadaki railway station
29	Khadaki church stop
30	Khadaki post office
31	Raja bangalow
32	Krutrim Reshim Paidas Kendra
33	Poultry Farm Old Mumbai Pune Road
34	Mariaai Gate Old Mumbai Pune Road
35	Bajaj showroom
36	Labor office
37	Patil Estate
38	Engineering college hostel
39	Modern Highschool
40	Balgandharv sambhaji par
41	Deccan Gymkhana
42	Deccan corner sambhaji pool
43	Garware college
44	Petrol Pump Karve Road
45	Nal Stop
46	SNDT college
47	Paud phata police chauky
48	More vidyalaya
49	LIC colony
50	Anand nagar paud road
51	Jai bhavani
52	Pratik nagar
53	Vanaz Corner
54	Paramhans corner
55	Kachara depot
56	Bharti nagar
57	kothrud depot','55','05:20
08:15
11:55
15:00
18:00
21:35
05:50
08:45
12:25
15:30
18:30
22:05
06:20
09:10
12:55
16:00
19:00
22:35
06:50
09:45
13:25
16:30
19:35
07:20
10:20
13:55
17:00
20:05
07:50
11:15
14:25
17:30
20:35','06:40
09:45
13:25
16:25
19:30
23:00
07:10
10:15
13:55
16:55
20:00
23:30
07:40
10:40
14:25
17:25
20:35
00:00
08:10
11:15
14:55
18:00
21:05
08:45
11:50
15:25
18:30
21:35
09:15
12:45
15:55
19:00
22:05','Active');
INSERT INTO "busTable" VALUES(150,'29','Swargate','Alandi bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','27 KMs','80 Minutes','1	Swargate
2	Swargate
3	Ghorpade peth colony
4	S T Divisional office
5	Meera society
6	Golibar maidan
7	Juna pul gate
8	Bombay Garage
9	West end talkies
10	GPO
11	Collector kacheri
12	Sasoon hospital
13	Pune station
14	Ruby hall
15	Wadia college
16	Guruprasad bangala
17	Band garden
18	Yerwada
19	Shadal baba Darga
20	Deccan college
21	Ambedkar Society
22	RTO New
23	Phulenagar
24	MES Water Works
25	Mental Hospital Corner
26	Shantinagar
27	Sathe Biscuit company
28	Vishrantwadi
29	R D colony
30	kalasgaon
31	Mhaske wasti
32	Parade ground
33	Wireless colony
34	AIT college
35	Dighigaon
36	Mitra sahakar nagar
37	Dattanagar
38	Telco godown
39	Bhosari phata
40	Moje vidyalaya
41	Sai madnir
42	Nirma company
43	Gokhale Mala Sankalpa Garden
44	Wadmukhwadi
45	Chincheche jhad
46	Charholi phata
47	Sai Lila nagar Kate Wasti
48	Moshi Phata Dehu Phata
49	Alandi jakat naka
50	Navin ST stand
51	Dnyaneshwar Bhint
52	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Dnyaneshwar June Nivas/Sai Mandir
10	Sai mandir
11	Moje vidyalaya
12	Bhosari phata
13	Telco godown
14	Dattanagar
15	Mitra sahkar nagar
16	Dighigaon
17	AIT college
18	Wireless colony
19	Parade ground
20	Mhaske wasti
21	Kalasgaon
22	R D colony
23	Vishrantwadi
24	Sathe Biscuit company
25	Shantinagar
26	Mental Hospital Corner
27	MES Water Works
28	Phulenagar
29	RTO New
30	Ambedkar Society
31	Deccan college
32	Shadal baba Darga
33	Yerwada
34	Band garden
35	Guruprasad bangala
36	Jahangir Hospital
37	Alankar Talkies
38	Sadhu wasvani chauk
39	General post office
40	West end talkies
41	Bombay garaje
42	juna pul gate
43	Golibar maidan
44	Meera society
45	S T Divisional office
46	Ghorpadi Peth Colony
47	Swargate police line
48	Swargate
49	Swargate','52','08:25
11:30
14:30
17:10
20:30
05:40
08:45
11:50
14:45
17:30
20:50
05:55
09:05
12:05
15:05
17:45
21:10
06:15
09:25
12:25
15:20
18:00
21:30
06:30
09:40
12:40
15:40
18:20
21:45
06:50
10:00
13:00
15:55
18:35
22:00
07:05
10:15
13:15
16:15
18:55
22:15
07:25
10:35
13:35
16:30
19:15
22:30
07:45
10:55
13:55
16:50
19:40
22:45
08:05
11:15
14:15
17:20
20:05
23:15','06:15
09:50
12:55
15:50
18:30
21:50
06:40
10:15
13:10
16:05
18:55
22:10
07:05
10:35
13:25
16:25
19:15
22:30
07:30
10:55
13:45
16:40
19:30
22:50
07:45
11:10
14:00
17:00
19:50
23:05
08:05
11:30
14:20
17:15
20:05
23:20
08:20
11:45
14:35
17:35
20:25
23:35
08:40
12:05
14:55
17:50
20:40
23:50
09:00
12:25
15:15
18:10
21:00
00:05
09:20
12:40
15:35
18:45
21:30','Active');
INSERT INTO "busTable" VALUES(151,'291','Hadapsar','Katraj bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','56 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar
9	Shivarkar gardan
10	Jambhulkar Chauk
11	Jagtap chauk
12	Kedarinagar
13	Kedari corner
14	Indiranagar
15	Mahatma Phule Vasahat
16	N I B M Road
17	Kondhva Shala
18	Kondhava Khurd
19	Chaitanya Vidyalaya
20	Mangalben company Sai service
21	Talab Farm
22	Somaji Khat Karkhana
23	Khadi Machine
24	Smashanbhumi Kondhava
25	Hill Villa
26	Shri Shatrunjay jain temple
27	Gokulnagar Katraj
28	Sundarban
29	Sudarshan nagar Katraj
30	Rajas Soc. Corner
31	Katraj bus stand','1	Katraj bus stand
2	Rajas Soc. Corner
3	Sudarshan nagar Katraj
4	Sundarban
5	Gokul Nagar Katraj
6	Shri Shatrunjay Jain Temple
7	Hill Villa
8	Smashanbhumi Kondhava
9	Khadi Machine
10	Somaji Khat Karkhana
11	Talab Farm
12	Mangalben company Sai service
13	Chaitanya Vidyalaya
14	Kondhva Khurd
15	Kondhava Shala
16	NIBM Road
17	Mahatma Phule wasahat
18	Indiranagar
19	Kedari corner
20	Kedarinagar
21	Jagtap chauk
22	Jambhulkar Chauk
23	Shivarkar Garden
24	Fatimanagar
25	Kalubai mandir
26	Ram tekadi
27	Vaidwadi
28	Gurushankar math
29	Magarpatta
30	Hadapsar gaon
31	Hadapsar gadital','31','05:40
07:20
09:15
11:40
15:15
17:10
19:10
21:30
06:00
07:40
09:35
12:00
15:45
17:40
19:40
22:00
05:30
07:20
09:40
11:40
13:50
15:45
17:40
20:00
05:40
07:30
09:20
11:50
14:00
15:55
17:50
20:15
05:50
07:40
10:00
12:00
14:10
16:05
18:00
20:25
06:00
07:50
10:10
12:10
14:30
16:25
18:20
20:45
06:10
08:00
10:20
12:20
14:40
16:35
18:30
20:55
06:20
08:10
10:30
12:30
15:00
16:55
18:50
21:15
06:40
08:30
10:50
12:50
15:10
17:05
19:00
21:25
07:00
08:50
11:10
13:10
15:20
17:15
19:40
21:35
07:10
09:00
11:20
13:20
15:30
17:25
19:20
21:45
07:15
09:10
11:30
13:30
15:40
17:35
19:30
22:00','06:30
08:20
10:40
12:40
16:15
18:10
20:35
22:25
06:50
08:40
11:00
13:00
16:25
18:40
21:05
22:50
06:20
08:15
10:40
12:35
14:45
16:40
18:40
21:00
06:30
08:25
10:20
12:45
14:55
16:50
18:50
21:10
06:40
08:35
11:00
12:55
15:05
17:00
19:00
21:20
06:50
08:45
11:10
13:05
15:25
17:20
19:20
21:40
07:00
08:55
11:20
13:15
15:35
17:30
19:30
21:50
07:10
09:05
11:30
13:25
15:55
17:50
19:50
22:10
07:30
09:25
11:50
13:45
16:05
18:00
20:00
22:20
07:50
09:45
12:10
14:05
16:15
18:10
20:40
22:30
08:00
10:00
12:20
14:15
16:25
18:25
20:20
22:40
08:10
10:10
12:30
14:25
16:35
18:35
20:30
22:50','Active');
INSERT INTO "busTable" VALUES(152,'291A','Bibvewadi','Hadapsar gadital','Mon, Tue, Wed, Thu, Fri, Sat, Sun','16 KMs','61 Minutes','1	Bibwewadi
2	Lower Indiranagar
3	Chintamani Nagar
4	Upper Indiranagar
5	Rajiv Gandhi Nagar Upper Depot
6	Somanagar Society
7	Sukhsagar Nagar
8	Khandoba Mandir Corner
9	Ladies Hostel
10	Shri Shatrunjay Jain Temple
11	Hill Villa
12	Smashanbhumi Kondhava
13	Khadi Machine
14	Somaji Khat Karkhana
15	Talab Farm
16	Mangalben company Sai service
17	Chaitanya Vidyalaya
18	Kondhva Khurd
19	Kondhava Shala
20	NIBM Road
21	Mahatma Phule wasahat
22	Indiranagar
23	Kedari corner
24	Kedarinagar
25	Jagtap chauk
26	Jambhulkar Chauk
27	Shivarkar Garden
28	Fatimanagar
29	Kalubai mandir
30	Ram tekadi
31	Vaidwadi
32	Gurushankar math
33	Magarpatta
34	Hadapsar gaon
35	Hadapsar gadital','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar
9	Shivarkar gardan
10	Jambhulkar Chauk
11	Jagtap chauk
12	Kedarinagar
13	Kedari corner
14	Indiranagar
15	Mahatma Phule Vasahat
16	N I B M Road
17	Kondhva Shala
18	Kondhava Khurd
19	Chaitanya Vidyalaya
20	Mangalben company Sai service
21	Talab Farm
22	Somaji Khat Karkhana
23	Khadi Machine
24	Smashanbhumi Kondhava
25	Hill Villa
26	Shri Shatrunjay jain temple
27	Ladies Hostel
28	Khandoba Mandir Corner
29	Sukhsagar Nagar
30	Somanagar Society
31	Rajiv Gandhi Nagar Upper Depot
32	Upper Indiranagar
33	Chintamani Nagar
34	Lower Indiranagar
35	Bibwewadi','35','07:55
09:50
11:50
15:30
17:30
08:55
10:50
12:50
16:30
18:30','08:55
10:55
12:50
16:30
18:30
09:55
11:50
13:55
17:30
19:25','Active');
INSERT INTO "busTable" VALUES(153,'293','Swaragate','Khed Shivapur','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','68 Minutes','1	Katraj bus stand
2	Gujarwadi Phata
3	Mangdewadi Petrol Pump
4	Mangdewadi Phata
5	Bhilarewadi
6	Stage kramank 6
7	Stage kramank 7
8	Waghjai Mandir
9	Ghat utaar Walan
10	Gogalwadi Phata
11	Adlar Engineering
12	Shindewadi Gujarwadi
13	Velugoan Phata
14	Grand Hotel
15	Shivapur Bag Post office
16	Kodhanpur Phata
17	Khedshivapur Highschool','1	Khedshivapur Highschool
2	Kondhanpur phata
3	Shivapur Bag Post office
4	Grand hotel
5	Velugaon phata
6	Shindewadi Gujarwadi
7	Adlar Engineering
8	Gogalwadi phata
9	Ghat utar walan
10	Waghjai mandir
11	Stage no.7
12	Stage no.6
13	Bhilarewadi
14	Mangdewadi Phata
15	Gujarwadi phata
16	Katraj bus stand','17','07:00
08:50
11:15
13:20
16:10
18:05
19:55
22:20','07:00
08:50
11:15
13:20
16:10
18:05
19:55
22:20','Active');
INSERT INTO "busTable" VALUES(154,'294','Katraj bus stand','Khadakwasla Dharan','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','51 Minutes','1	Katraj bus stand
2	Dattanagar Katraj
3	Ramnagar Katraj
4	Gaimukh Ambegaon Phata
5	Bhumkar Nagar
6	Narhe Gaon
7	Bhumkar Complex
8	Ajinkyatara
9	Parikh complex
10	Radhika Soc
11	Poultry farm singhgad road
12	Raykar wasti
13	Dhayari Gaon
14	Gar mala
15	Dangat wasti
16	Sanas Vidyalaya
17	Lagad wasti
18	Mate Pat Sasa company
19	Nanded Phata
20	Jadhavwadi Andh shala
21	CWPRS gate no.1
22	Nandoshi Phata
23	Kolhewadi
24	Khadakwasla Gaon
25	Khadakwasla Dharan','1	Khadakwasala Dharan
2	Khadakwasala gaon
3	Kolhewadi
4	Nandoshi phata
5	CWPRS Gate no.1
6	Jadhavwadi Andh shala
7	Nanded phata
8	Mate Pat Sasa company
9	Lagad wasti
10	Sanas Vidyalaya
11	Dangat wasti
12	Gar mala
13	Dhayarai gaon
14	Raykar wasti
15	Poultry Farm Sinhgadh Road
16	Radhika soc
17	Parikh Complex
18	AjinkyaTara
19	Bhumkar complex
20	Narhe gaon
21	Bhumkar nagar
22	Gaimukh Ambegaon Phata
23	Ramnagar Katraj
24	Dattanagar Katraj
25	Katraj bus stand','25','06:15
08:00
09:25
12:00
14:15
16:00
17:45
20:00
06:50
08:35
10:20
12:35
14:50
16:35
18:20
20:35
07:25
09:10
10:55
13:10
15:25
17:10
18:55
21:10','07:05
08:50
10:35
12:50
15:05
16:50
18:35
20:50
07:40
09:25
11:10
13:25
15:40
17:25
19:10
21:25
08:15
10:00
11:45
14:00
16:15
18:00
19:45
22:00','Active');
INSERT INTO "busTable" VALUES(155,'294','Katraj bus stand','Khadakwasala','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','51 Minutes','1	Katraj bus stand
2	Dattanagar Katraj
3	Ramnagar Katraj
4	Gaimukh Ambegaon Phata
5	Bhumkar Nagar
6	Narhe Gaon
7	Bhumkar Complex
8	Ajinkyatara
9	Parikh complex
10	Radhika Soc
11	Poultry farm singhgad road
12	Raykar wasti
13	Dhayari Gaon
14	Gar mala
15	Dangat wasti
16	Sanas Vidyalaya
17	Lagad wasti
18	Mate Pat Sasa company
19	Nanded Phata
20	Jadhavwadi Andh shala
21	CWPRS gate no.1
22	Nandoshi Phata
23	Kolhewadi
24	Khadakwasla Gaon
25	Khadakwasla Dharan','1	Khadakwasala Dharan
2	Khadakwasala gaon
3	Kolhewadi
4	Nandoshi phata
5	CWPRS Gate no.1
6	Jadhavwadi Andh shala
7	Nanded phata
8	Mate Pat Sasa company
9	Lagad wasti
10	Sanas Vidyalaya
11	Dangat wasti
12	Gar mala
13	Dhayarai gaon
14	Raykar wasti
15	Poultry Farm Sinhgadh Road
16	Radhika soc
17	Parikh Complex
18	AjinkyaTara
19	Bhumkar complex
20	Narhe gaon
21	Bhumkar nagar
22	Gaimukh Ambegaon Phata
23	Ramnagar Katraj
24	Dattanagar Katraj
25	Katraj bus stand','25','06:15
08:00
09:25
12:00
14:15
16:00
17:45
20:00
06:50
08:35
10:20
12:35
14:50
16:35
18:20
20:35
07:25
09:10
10:55
13:10
15:25
17:10
18:55
21:10','07:05
08:50
10:35
12:50
15:05
16:50
18:35
20:50
07:40
09:25
11:10
13:25
15:40
17:25
19:10
21:25
08:15
10:00
11:45
14:00
16:15
18:00
19:45
22:00','Active');
INSERT INTO "busTable" VALUES(156,'295','Katraj bus stand','Pune station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','50 Minutes','1	Katraj bus stand
2	Rajas Soc. Corner
3	Sudarshan nagar Katraj
4	Sundarban
5	Gokul Nagar Katraj
6	Shri Shatrunjay Jain Temple
7	Ladies Hostel
8	Gajanan Nagar
9	Kakde Vasti
10	Oswal Estate
11	Aaimata Mandir
12	Ganga Dham
13	Marketyard
14	Wakhar Mahamandal Marketyard
15	P and T colony
16	Canol Jhopadpatti
17	Apsara Talkies
18	Ghorpade peth colony
19	Lakud Bajar
20	Sonwane hospital
21	Ramoshi gate
22	Nana peth
23	A D camp chauk
24	Power house
25	Zila Parishad
26	Sasoon hospital
27	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	Collector kacheri
4	Zila Parishad
5	Power house
6	A D camp chauk
7	Nana peth
8	Ramoshi gate
9	Sonwane hospital
10	Lakud Bajar
11	Ghorpadi Peth Colony
12	Apsara Talkies
13	Canol Jhopadpatti
14	P and T colony
15	Wakhar Mahamandal Marketyard
16	Marketyard
17	Ganga Dham
18	Aaimata Mandir
19	Oswal Estate
20	Kakde Vasti
21	Gajanan Nagar
22	Ladies Hostel
23	Shri Shatrunjay jain temple
24	Gokulnagar Katraj
25	Sundarban
26	Sudarshan nagar Katraj
27	Rajas Soc. Corner
28	Katraj bus stand','27','06:15
08:00
09:45
12:00
14:15
16:00
17:45
20:00
07:25
09:10
10:55
13:10
15:25
17:10
18:55
21:10','07:05
08:50
10:35
12:50
15:05
16:50
18:35
20:50
08:15
10:00
11:45
14:00
16:13
18:00
19:45
22:00','Active');
INSERT INTO "busTable" VALUES(157,'296','Jambhulwadi','Shivajinagar Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','76 Minutes','1	Jambhul Wadi
2	Jambhalkar Wasti
3	Pimplekar wasti
4	Datta Mandir
5	Lipanewasti
6	Telco Colony
7	Chakan Oil mill
8	Dattanagar Katraj
9	Santoshnagar
10	Katraj bus stand
11	More bag
12	Katraj dairy Sarpodyan
13	Bharti vidyapeeth gate
14	Chaitanya nagar
15	Balaji nagar
16	Vishweshwar Bank KK market
17	Padmavati corner
18	Natu bag
19	Aranyeshwar Corner
20	Bhapkar petrol pump City Pride
21	Panchami hotel
22	Laxmi Narayan Theature
23	Swargate
24	Sarasbag
25	Bhikardas maruti madnir
26	Shanipar
27	A B Chowk
28	Dakshinabhimukh Maruti mandir
29	Shaniwar wada
30	PMC mangala
31	Shivaji putala pmc
32	shimala office shivajinagar
33	Shivajinagar Station','1	Shivajinagar Station
2	Sancheti Hospital
3	Shivaji putala
4	PMC Mangala
5	Kasaba Police Chowky
6	Vasant talkies
7	Mandai
8	Shahu chauk
9	Gokul bhavan
10	Swargate
11	Lakshi narayan theature
12	Panchami hotel
13	Bhapkar Petrol Pump City pride
14	Aranyeshwar Corner
15	Natu Bag
16	Padmavati corner
17	Vishweshwar Bank KK market
18	Balaji nagar
19	Chaitanya nagar
20	Bharti vidyapeeth gate
21	Katraj dairy Sarpodyan
22	More bag
23	Katraj bus stand
24	Santoshnagar
25	Dattanagar Katraj
26	Chakan Oil mill
27	Telco Colony
28	Lipanewasti
29	Datta Mandir
30	Pimplekar wasti
31	Jambhalkar Wasti
32	Jambhul Wadi','33','07:15
09:55
12:15
15:00
17:10
20:00','08:45
11:05
13:20
16:00
18:50
21:10','Active');
INSERT INTO "busTable" VALUES(158,'297','Rajas Soc','Shivajinagar Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','54 Minutes','1	Rajas Soc.
2	Bhushan Soc
3	Rajas Soc. Corner
4	Katraj bus stand
5	More bag
6	Katraj dairy Sarpodyan
7	Bharti vidyapeeth gate
8	Chaitanya nagar
9	Balaji nagar
10	Vishweshwar Bank KK market
11	Padmavati corner
12	Natu bag
13	Aranyeshwar Corner
14	Bhapkar petrol pump City Pride
15	Panchami hotel
16	Laxmi Narayan Theature
17	Swargate
18	Sarasbag
19	Bhikardas maruti madnir
20	Shanipar
21	A B Chowk
22	Dakshinabhimukh Maruti mandir
23	Shaniwar wada
24	PMC mangala
25	Shivaji putala pmc
26	shimala office shivajinagar
27	Shivajinagar Station','1	Shivajinagar Station
2	Sancheti Hospital
3	Shivaji putala
4	PMC Mangala
5	Kasaba Police Chowky
6	Vasant talkies
7	Mandai
8	Shahu chauk
9	Gokul bhavan
10	Swargate
11	Lakshi narayan theature
12	Panchami hotel
13	Bhapkar Petrol Pump City pride
14	Aranyeshwar Corner
15	Natu Bag
16	Padmavati corner
17	Vishweshwar Bank KK market
18	Balaji nagar
19	Chaitanya nagar
20	Bharti vidyapeeth gate
21	Katraj dairy Sarpodyan
22	More bag
23	Katraj bus stand
24	Rajas Soc. Corner
25	Bhushan Soc
26	Rajas Soc.','27','05:40
07:20
09:35
11:35
14:40
16:35
18:40
20:50','06:30
08:45
10:35
12:30
15:30
17:40
20:00
21:40','Active');
INSERT INTO "busTable" VALUES(159,'298','Katraj bus stand','Chinchwad gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','29 KMs','87 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Padmavati Bus stand
10	Power house Padmavati
11	Date Bus stop
12	Nandadeep
13	Gandhi Training Corner
14	Sarang Society
15	Lakshminagar Corner
16	Laxminagar police chauki
17	Bank of Maharashtra Parvati gaon
18	Mitramandal Sabhagruh
19	Sarasbag
20	Bhikardas maruti madnir
21	Shanipar
22	A B Chowk
23	Dakshinabhimukh Maruti mandir
24	Shaniwar wada
25	PMC mangala
26	Shivaji putala pmc
27	shimala office shivajinagar
28	Masoba gate
29	Pumping station
30	Pune central
31	E square
32	Rangehills Corner
33	Rajbhavan
34	Boys batalian
35	Kasturba vasahat
36	Sindh colony gate 2
37	Bremen chauk
38	Body gate
39	Aundh gaon
40	Sangvi phata
41	Aundh chest hospital
42	Aundh post office
43	ESI Hospital
44	Rakshak chauk
45	Military Stores
46	Wakad phata
47	Jagtap Dairy
48	Kaspate Vasti
49	Kalewadi phata
50	16 Number
51	Laxman nagar
52	Dange chowk
53	Thergaon phata
54	Padmji Paper Mill
55	Dattanagar Chinchwad
56	Birla Hospital
57	Jakatnaka pavanapul
58	Walhekarwadi phata
59	Chafekar chauk
60	Chinchwad gaon','1	Chinchwad gaon
2	Chafekar chauk
3	Walhekarwadi Phata
4	Jakatnaka Pavanapool
5	Birla hospital
6	Dattanagar Chinchwad
7	Padmji Paper Mill
8	Thergaon phata
9	Dange chowk
10	Laxman nagar
11	16 Number
12	Kalewadi phata
13	Kaspate Vasti
14	Jagtap Dairy
15	Wakad phata
16	Military Stores
17	Rakshak chauk
18	ESI Hospital
19	Aundh post office
20	Aundh chest hospital
21	Sangvi Phata
22	Aundh gaon
23	Body gate
24	Bremen chauk
25	Sindh Colony Gate2
26	Kasturba vasahat
27	Boys Batalian
28	Pune University Gate
29	Rangehills Corner
30	E Square
31	Pune central
32	Pumping station
33	Masoba gate
34	shimala office shivajinagar
35	Sancheti Hospital
36	Shivaji putala
37	PMC Mangala
38	Kasaba Police Chowky
39	Vasant talkies
40	Mandai
41	Shahu chauk
42	Gokul bhavan
43	Swargate
44	Mitramandal Sabhagruh
45	Bank of Maharashtra Parvati gaon
46	Laxminagar police chauki
47	Lakshminagar Corner
48	Sarang Society
49	Gandhi Training Corner
50	Nandadeep
51	Date Bus stop
52	Power house Padmavati
53	Padmavati Bus stand
54	Padmavati corner
55	Vishweshwar Bank KK market
56	Balaji nagar
57	Chaitanya nagar
58	Bharti vidyapeeth gate
59	Katraj dairy Sarpodyan
60	More bag
61	Katraj bus stand','60','05:30
08:40
11:45
14:30
19:00
05:50
09:05
12:05
15:05
19:30
06:15
09:30
12:30
15:35
20:00
06:35
09:50
12:50
16:10
20:30
06:55
10:10
13:10
16:40
21:00
07:20
10:35
13:35
17:15
21:30
07:40
10:55
13:55
17:50
22:00
08:00
11:15
14:15
17:10
22:30','06:30
10:15
13:10
16:00
20:30
07:10
10:35
13:30
16:35
21:00
07:35
11:00
13:55
17:05
21:30
07:55
11:20
14:15
17:40
22:00
08:15
11:40
14:35
18:10
22:30
08:40
12:05
15:00
18:45
23:00
09:00
12:25
15:20
19:20
23:30
09:20
12:45
15:40
19:00
00:00','Active');
INSERT INTO "busTable" VALUES(160,'298','Katraj bus stand','Bhosari','Mon, Tue, Wed, Thu, Fri, Sat, Sun','27 KMs','83 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Parvati payatha
16	Dandekar pul
17	Petrol Pump Rajendranagar
18	Lokmanya nagar
19	Ganjwewadi
20	Alka talkies
21	Goodluck Chowk
22	F C College
23	Dnyaneshwar Paduka chowk
24	Lokmangal
25	College of engineering pune
26	Patil Estate
27	Labour office
28	Bajaj showroom wakadewadi
29	Mariaai Gate Old Mumbai Pune Road
30	Poultry Farm Old Mumbai Pune Road
31	Krutrim reshim paidas kendra
32	Raja Bungalow
33	Khadaki post office
34	Khadki church stop
35	Khadaki railway station
36	Khadaki
37	Bopodi
38	Dapodi
39	Fugewadi
40	Sandwik
41	Alfa laval atlas company
42	Forbes marshal stop
43	Kasrawadi
44	Nashik phata
45	Bhosari police station
46	MIDC bhosari
47	Philips
48	Landewadi
49	Century Enka Colony
50	Bhosari gaon','1	Bhosari gaon
2	Century Enka Colony
3	Landewadi
4	Philips
5	MIDC Bhosari
6	Bhosari police station
7	Nashik phata
8	Kasarwadi
9	Forbes marshal stop
10	Alfa Laval Atlas Company
11	Sandwik
12	Fugewadi
13	Dapodi
14	Bopodi
15	Khadaki
16	Khadaki railway station
17	Khadaki church stop
18	Khadaki post office
19	Raja bangalow
20	Krutrim Reshim Paidas Kendra
21	Poultry Farm Old Mumbai Pune Road
22	Mariaai Gate Old Mumbai Pune Road
23	Bajaj showroom
24	Labor office
25	Patil Estate
26	Engineering college hostel
27	Modern Highschool
28	Balgandharv sambhaji par
29	Deccan Gymkhana
30	Alka talkies
31	Ganjwewadi
32	Lokmanya nagar
33	Petrol pump rajendranagar
34	Dandekar pul
35	Parvati payatha
36	Sarasbag
37	Hirabag
38	Swargate corner
39	Swargate
40	Lakshi narayan theature
41	Panchami hotel
42	Bhapkar Petrol Pump City pride
43	Aranyeshwar Corner
44	Natu Bag
45	Padmavati corner
46	Vishweshwar Bank KK market
47	Balaji nagar
48	Chaitanya nagar
49	Bharti vidyapeeth gate
50	Katraj dairy Sarpodyan
51	More bag
52	Katraj bus stand','50','05:40
08:15
11:15
15:00
19:00
06:00
08:45
11:55
15:50
19:50
06:35
09:20
12:30
16:40
20:40
07:10
09:55
13:05
17:30
21:35
07:45
10:35
13:45
18:20
22:35
08:30
11:40
14:20
17:00','06:50
09:35
12:40
16:30
20:30
07:20
10:05
13:15
17:20
21:20
07:55
10:40
13:50
18:10
22:15
08:30
11:15
14:25
19:00
23:05
09:05
11:50
15:05
19:50
00:05
09:50
13:00
15:40
18:20','Active');
INSERT INTO "busTable" VALUES(161,'2R','Katraj bus stand','Shivajinagar Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','38 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Bhikardas maruti madnir
17	Shanipar
18	A B Chowk
19	Dakshinabhimukh Maruti mandir
20	Shaniwar wada
21	PMC mangala
22	Shivaji putala pmc
23	shimala office shivajinagar
24	Shivajinagar Station','1	Shivajinagar Station
2	Sancheti Hospital
3	Shivaji putala
4	PMC Mangala
5	Kasaba Police Chowky
6	Vasant talkies
7	Mandai
8	Shahu chauk
9	Gokul bhavan
10	Swargate
11	Lakshi narayan theature
12	Panchami hotel
13	Bhapkar Petrol Pump City pride
14	Aranyeshwar Corner
15	Natu Bag
16	Padmavati corner
17	Vishweshwar Bank KK market
18	Balaji nagar
19	Chaitanya nagar
20	Bharti vidyapeeth gate
21	Katraj dairy Sarpodyan
22	More bag
23	Katraj bus stand','24','23:40
00:50
03:40
04:50','00:20
01:30
04:20
05:20','Active');
INSERT INTO "busTable" VALUES(162,'2S','Katraj bus stand','Balewadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','19 KMs','67 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Bhikardas maruti madnir
17	Shanipar
18	A B Chowk
19	Dakshinabhimukh Maruti mandir
20	Shaniwar wada
21	PMC mangala
22	Shivaji putala pmc
23	shimala office shivajinagar
24	Masoba gate
25	Pumping station
26	Pune central
27	E square
28	Rangehills Corner
29	Pune University Gate
30	chavan nagar university road
31	Sakal nagar
32	Sindh colony
33	Baner phata
34	Green Park hotel
35	Trimurti bunglow
36	Ambedkar nagar
37	Murkute wasti
38	Baner gaon
39	Baner odha
40	Balewadi Phata
41	Chakankar mala
42	Deasi poultry farm
43	Balewadi','1	Balewadi
2	Desai Poultry Farm
3	Chakankar Mala
4	Balewadi Phata
5	Baner odha
6	Baner Gaon
7	Murkutewasti Pavitra hotel
8	Ambedkar Nagar
9	Trimurti Bungalow
10	Green park hotel
11	Baner phata
12	Sindh colony
13	Sakal nagar
14	Chavan Nagar University Road
15	Pune University Gate
16	Pune University Gate
17	Rangehills Corner
18	E Square
19	Pune central
20	Pumping station
21	Masoba gate
22	shimala office shivajinagar
23	Sancheti Hospital
24	Shivaji putala
25	PMC Mangala
26	Kasaba Police Chowky
27	Vasant talkies
28	Mandai
29	Shahu chauk
30	Mamledar kacheri
31	Gokul bhavan
32	Swargate
33	Lakshi narayan theature
34	Panchami hotel
35	Bhapkar Petrol Pump City pride
36	Aranyeshwar Corner
37	Natu Bag
38	Padmavati corner
39	Vishweshwar Bank KK market
40	Balaji nagar
41	Chaitanya nagar
42	Bharti vidyapeeth gate
43	Katraj dairy Sarpodyan
44	More bag
45	Katraj bus stand','43','08:15
10:20
13:00
15:10
17:25
09:15
11:30
14:05
16:15
18:40','09:15
11:30
14:05
16:15
18:40
10:20
12:35
15:10
17:25
19:50','Active');
INSERT INTO "busTable" VALUES(163,'3','Swaragte','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7 KMs','42 Minutes','1	Swargate
2	Sarasbag
3	Madiwale colony
4	S P college
5	Maharashtra mandal
6	Sahitya parishad peru gate
7	Chitrashala
8	Sadashiv Peth Houd
9	Ahilyadevi Shala
10	Shaniwar wada
11	Surya hopsital
12	Pawale chauk
13	Kamala nehru hospital
14	Sadanand nagar
15	Ambedkar bhavan
16	Sasoon hospital
17	Pune station','1	Pune station
2	Alankar Talkies
3	Sadhu wasvani chauk
4	GPO
5	Collector kacheri
6	Zila Parishad
7	Sadanand Nagar
8	Kamala nehru hospital
9	Pawale chauk
10	Surya hopsital
11	Kasaba Police Chowky
12	Ahilyadevi Shala
13	Peru Gate
14	S P college
15	Madiwale colony
16	Hirabag
17	Swargate corner
18	Swargate','17','06:00
07:50
09:15
10:40
12:00
14:30
15:50
17:15
18:45
20:40','06:40
08:30
10:00
11:20
12:40
15:10
16:30
18:00
19:30
21:20','Active');
INSERT INTO "busTable" VALUES(164,'30','Market yard','Ghotawade phata','Mon, Tue, Wed, Thu, Fri, Sat, Sun','32 KMs','87 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	Godown Marketyard
4	Shivaji Putala Kalubai Mandir
5	Mafco Company
6	Bhapkar petrol pump City Pride
7	Panchami hotel
8	Laxmi Narayan Theature
9	Swargate
10	Sarasbag
11	Bhikardas maruti madnir
12	Shanipar
13	A B Chowk
14	Dakshinabhimukh Maruti mandir
15	Shaniwar wada
16	PMC mangala
17	Shivaji putala pmc
18	shimala office shivajinagar
19	Masoba gate
20	Pumping station
21	Pune central
22	E square
23	Rangehills Corner
24	Pune Vidyapeeth
25	Police head office
26	Loyala Highschool
27	NCL market
28	NCL
29	Panchwati
30	IITM
31	ARDE bus stop
32	Pashan
33	Pashan gaon
34	NIV
35	Sai Chauk
36	Abhinav college
37	Soos phata
38	Pandavnagar
39	Abhinav kala vidyalaya
40	Ranware wasti
41	Ravinagar Tapkir wasti
42	Soos gaon
43	Shitole wasti Soos
44	Symbiosis college phata Soos
45	Sanjay Nilgiri Garden Shinde Wast
46	Dhamale wasti Soos road
47	Nandegaon
48	Gaikwad wasti Nandegaon
49	Shitole wasti Nandegaon
50	Gawade wasti
51	Satav wasti
52	Lawale wasti
53	Rautwadi
54	Mail Dagad Kramank 22
55	Lavale Phata
56	ST stand pirangut
57	Vishkar India company
58	Ghotawale phata','1	Ghotawade Phata
2	Viskar India Company
3	ST stand Pirangut
4	Lavale phata
5	Mail Dagad Kramank 22
6	Rautwadi
7	Lawale wasti
8	Satav wasti
9	Gawade wasti
10	Shitole wasti Nandegaon
11	Gaikwad wasti Nandegoan
12	Nandegoan
13	Dhamale wasti Soos Road
14	Sanjay Nilgiri Garden Shinde Wast
15	Symbiosis college phata Soos
16	Shitole wasti Soos
17	Soos goan
18	Ravinagar Tapkir wasti
19	Ranaware wasti
20	Abhinav Kala Vidyalaya
21	Pandavnagar
22	Soos Phata
23	Abhinav college
24	Sai Chauk
25	NIV
26	Pashan gaon
27	Pashan
28	ARDE bus stop
29	IITM
30	Panchwati
31	NCL
32	NCL Market
33	Loyala Highschool
34	Police head office
35	Pune Vidyapeeth
36	Pune University Gate
37	Rangehills Corner
38	E Square
39	Pune central
40	Pumping station
41	Masoba gate
42	shimala office shivajinagar
43	Engineering college hostel
44	Shivaji putala
45	PMC Mangala
46	Kasaba Police Chowky
47	Vasant talkies
48	Mandai
49	Shahu chauk
50	Gokul bhavan
51	Swargate
52	Lakshi narayan theature
53	Panchami hotel
54	Bhapkar Petrol Pump City pride
55	Mafco Company
56	Shivaji putala Kalubai mandir
57	Godown Marketyard
58	Wakhar Mahamandal Marketyard
59	Marketyard','58','08:05
11:45
15:30
19:10
05:50
08:40
12:20
16:05
19:45
06:25
09:15
12:55
16:40
20:20
07:00
09:50
13:30
17:15
20:55
07:35
10:25
14:05
17:50
21:30
06:15
07:50
11:00
14:45
18:30','06:30
09:40
13:15
17:05
20:45
07:15
10:15
13:50
17:40
21:20
07:50
10:50
14:25
18:15
22:00
08:25
11:25
15:00
18:50
22:35
09:00
12:00
15:35
19:25
07:00
09:00
12:35
16:20
20:05','Active');
INSERT INTO "busTable" VALUES(165,'301K','Katraj bus stand','Hadapsar gadital','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','64 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Ghorpade peth colony
16	S T Divisional office
17	Meera society
18	Golibar maidan
19	juna pul gate
20	Mahatma gandhi stand
21	Race course
22	Bhauraba nala
23	Fatimanagar Municipal shala
24	Kalubai mandir
25	Ram tekadi
26	Vaidwadi
27	Gurushankar math
28	Magarpatta
29	Hadapsar gaon
30	Hadapsar gadital','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Golibar maidan
13	Meera society
14	S T Divisional office
15	Ghorpadi Peth Colony
16	Swargate police line
17	Swargate
18	Lakshi narayan theature
19	Panchami hotel
20	Bhapkar Petrol Pump City pride
21	Aranyeshwar Corner
22	Natu Bag
23	Padmavati corner
24	Vishweshwar Bank KK market
25	Balaji nagar
26	Chaitanya nagar
27	Bharti vidyapeeth gate
28	Katraj dairy Sarpodyan
29	More bag
30	Katraj bus stand','30','05:30
07:30
09:30
12:00
14:05
16:25
19:10
05:50
07:50
09:50
12:20
14:20
16:40
19:30
06:00
08:00
10:00
12:30
14:50
17:10
20:00
06:10
08:10
10:10
12:40
15:15
17:35
20:25
06:20
08:20
10:20
12:50
15:25
17:45
20:35
06:40
08:40
10:40
13:10
15:40
18:00
20:50
06:50
08:50
10:50
13:20
15:50
18:10
21:00
07:10
09:10
11:40
13:40
16:05
18:50
21:15
07:15
09:15
11:10
13:45
16:10
18:30
21:20
07:25
09:25
11:20
13:55
16:20
18:40
21:35
05:40
07:40
09:40
12:10
14:15
16:35
19:20
05:55
07:55
09:55
12:25
14:30
16:50
19:40
06:05
08:05
10:05
12:35
14:40
17:00
19:50
06:15
08:15
10:15
12:45
14:55
17:15
20:05
06:25
08:25
10:25
12:55
15:10
17:30
20:20
06:35
08:35
10:35
13:05
15:20
17:40
20:30
06:45
08:45
10:45
13:15
15:30
17:50
20:40
06:55
08:55
10:55
13:25
15:45
18:05
20:55
07:05
09:05
11:30
13:35
16:00
18:20
21:10
07:20
09:20
11:50
13:50
16:15
19:00
21:25','06:30
08:30
10:30
13:00
15:15
17:35
20:20
06:50
08:50
10:50
13:20
15:30
17:50
20:40
07:00
09:00
11:00
13:30
16:00
18:20
21:10
07:10
09:10
11:10
13:40
16:25
18:45
21:35
07:20
09:20
11:20
13:50
16:35
18:55
21:45
07:40
09:40
11:40
14:10
16:50
19:10
22:00
07:50
09:50
11:50
14:20
17:00
19:20
22:10
08:10
10:10
12:40
14:40
17:15
20:00
22:25
08:15
10:15
12:10
14:45
17:20
19:40
22:30
08:25
10:25
12:20
14:55
17:30
19:50
22:40
06:40
08:40
10:40
13:10
15:25
17:45
20:30
06:55
08:55
10:55
13:25
15:40
18:00
20:50
07:05
09:05
11:05
13:35
15:50
18:10
21:00
07:15
09:15
11:15
13:45
16:05
18:25
21:15
07:25
09:25
11:25
13:55
16:20
18:40
21:30
07:35
09:35
11:35
14:05
16:30
18:50
21:40
07:45
09:45
11:45
14:15
16:40
19:00
21:50
07:55
09:55
11:55
14:25
16:55
19:15
22:05
08:05
10:05
12:35
14:35
17:10
19:30
22:20
08:20
10:20
12:50
14:50
17:25
20:10
22:35','Active');
INSERT INTO "busTable" VALUES(166,'302','Pimpri gaon','Bhosari','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','36 Minutes','1	Pimprigaon
2	Ashok Talkies
3	Jaihind School
4	Delux
5	Karachi chauk
6	Lalmandir
7	Bhatnagar
8	Finolex
9	Pimpri chauk Bus stand
10	Nehrunagar corner
11	Nehrunagar
12	Jyoti school
13	Vishal nagar C ward office
14	Abhi Chemicals
15	Jayanand khira
16	Idrayani nagar corner
17	Tulashi chemikals
18	Landewadi
19	Gavane Vasti
20	PCMT chauk','1	PCMT chauk
2	Gavane Vasti
3	Landewadi
4	Tulsi Chemical
5	Indrayani nagar Corner Jayanand Road
6	Jayanand Khira
7	Abhi chemicals
8	Vishalnagar C Ward office
9	Jyoti School
10	Nehrunagar
11	Nehrunagar corner
12	Pimpri chauk Bus stop
13	Finolex
14	Shagun chauk
15	Karachi chowk
16	Delux
17	Jaihind School
18	Ashok Talkies
19	PMC School Pimpri
20	Pimprigaon','30','06:10
07:20
08:30
09:40
11:20
12:30
13:40
14:50
16:00
17:10
18:50
20:00
21:10
06:20
07:30
08:40
09:50
11:30
12:40
13:50
15:00
16:10
17:20
18:30
20:10
21:20
22:25
06:30
07:40
08:50
10:00
11:40
12:50
14:00
15:10
16:20
17:30
18:40
20:20
05:35
06:45
07:55
09:05
10:15
11:55
13:05
14:15
15:25
16:35
17:45
19:25
20:35
05:50
07:00
08:05
09:20
11:00
12:10
13:20
14:30
15:40
16:50
18:00
19:10
20:50
06:00
07:10
08:20
09:30
11:10
12:20
13:30
14:40
15:50
17:00
18:10
19:50
21:00
06:15
08:10
12:45
13:55
15:05
16:15
18:20
20:50
21:55','06:45
07:55
09:05
10:15
11:55
13:05
14:15
15:25
16:35
17:45
19:25
20:35
21:50
06:55
08:05
09:15
10:25
12:05
13:15
14:25
15:35
16:45
17:55
19:05
20:45
21:55
22:55
07:05
08:15
09:25
10:35
12:15
13:25
14:35
15:45
16:45
18:05
19:15
20:55
06:10
07:20
08:30
09:40
11:20
12:30
13:40
14:50
16:00
17:10
18:20
20:00
21:10
06:25
07:30
08:45
09:55
11:35
12:45
13:55
15:05
16:15
17:25
18:35
20:15
21:25
06:35
07:45
08:55
10:05
11:45
12:55
14:05
15:15
16:25
17:35
18:45
20:25
21:35
07:05
09:10
13:20
14:30
15:40
17:25
19:25
21:25
22:30','Active');
INSERT INTO "busTable" VALUES(167,'303','Nigadi','Alandi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','30 KMs','87 Minutes','1	Bhakti shakti depot
2	Nigadi jakat naka
3	Transport Nagari
4	Appu Ghar
5	Mukbadhir shala
6	Big India
7	Sindhunagar Corner
8	Geetabhavan
9	Ashoka
10	Mhalsakant Chowk
11	Ganganagar
12	Giriraj Corner
13	Prachi
14	Akurdi rly stn
15	Akurdi Police Chowky
16	Sambhaji chowk
17	Patil chauk
18	Railway quarters
19	Bijlinagar
20	Chinchwade Nagar Corner Akurdi Road
21	Chaitanya sabhagruha
22	Om Sairam complex
23	Chafekar chauk
24	Elpro Company
25	Prekshagruha
26	Lokmanya Hospital
27	Chinchwad station
28	MIDC Chinchwad
29	Mohan Nagar
30	Morwadi Phata
31	Sanghavi College
32	KSB chauk
33	Telco company
34	Telco hostel
35	Yashwant Nagar Telco Road
36	Gavalimatha
37	Power house Bhosari
38	Indrayani nagar Corner
39	Century Company
40	Electronic Sadan
41	Landewadi
42	Gavane Vasti
43	PCMT chauk
44	Bhosari gaon
45	Maharashtra chauk
46	Hutatma chauk
47	Shatri chauk
48	Durwankur lawns
49	Dighi Corner Odha
50	Tata stores
51	Bhosari phata
52	Moje vidyalaya
53	Sai madnir
54	Nirma company
55	Gokhale Mala Sankalpa Garden
56	Wadmukhwadi
57	Chincheche jhad
58	Charholi phata
59	Sai Lila nagar Kate Wasti
60	Moshi Phata Dehu Phata
61	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Sai mandir
10	Moje vidyalaya
11	Bhosari phata
12	Tata Stores
13	Didhi corner odha
14	Durvankur Lawns
15	Shastri chowk
16	Hutatma chauk
17	Maharashtra Chowk
18	PCMT chauk
19	Gavane Vasti
20	Landewadi
21	Electronic sadan
22	Century company
23	Indrayani nagar corner
24	Power house bhosari
25	Gavalimatha
26	Yashwant nagar telco road
27	Telco hostel
28	Telco company
29	KSB Chowk
30	Sanghavi College
31	Morwadi Phata
32	Mohan Nagar
33	MIDC Chinchwad
34	Chinchwad station
35	Chinchwad chauk
36	Lokmanya Hospital
37	Prekshagruha
38	Elpro Company
39	Chafekar chauk
40	Om sairam complex
41	Chaitnya sabhagrah
42	Chinchwade nagar corner Akurdi road
43	Bijali nagar
44	Railway quarters
45	Patil Chowk
46	Sambhaji chauk
47	Akurdi police chauky
48	Akurdi rly stn
49	Prachi
50	Giriraj corner
51	Ganganagar
52	Mhalasakant chauk
53	Ashoka
54	Geetabhavan
55	Sindhunagar corner
56	Big India
57	Mukbadhir Shala
58	Appu Ghar
59	Transport nagar
60	Nigadi jakat naka
61	Nigadi','61','06:30
09:20
12:50
15:50
19:30
07:30
10:10
13:40
16:30
08:30
11:10
14:40
17:35','07:50
11:20
14:20
17:15
21:15
08:50
12:10
15:10
17:50
09:50
13:10
16:10
18:55','Active');
INSERT INTO "busTable" VALUES(168,'304','Bhosari','Chinchwad gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','40 Minutes','1	PCMT chauk
2	Gavane Vasti
3	Landewadi
4	Electronic sadan
5	Century company
6	Indrayani nagar corner
7	Power house bhosari
8	Gavalimatha
9	Yashwant nagar telco road
10	Telco hostel
11	Telco company
12	KSB Chowk
13	Sanghavi College
14	Morwadi Phata
15	Mohan Nagar
16	MIDC Chinchwad
17	Chinchwad station
18	Chinchwad chauk
19	Lokmanya Hospital
20	Prekshagruha
21	Elpro Company
22	Chafekar chauk
23	Chinchwad gaon','1	Chinchwad gaon
2	Chafekar chauk
3	Elpro Company
4	Prekshagruha
5	Lokmanya Hospital
6	Chinchwad station
7	MIDC Chinchwad
8	Mohan Nagar
9	Morwadi Phata
10	Sanghavi College
11	KSB chauk
12	Telco company
13	Telco hostel
14	Yashwant Nagar Telco Road
15	Gavalimatha
16	Power house Bhosari
17	Indrayani nagar Corner
18	Century Company
19	Electronic Sadan
20	Landewadi
21	Gavane Vasti
22	PCMT chauk','23','05:40
07:10
08:30
09:50
11:40
13:00
14:40
16:00
17:20
18:40
20:30
06:00
07:20
08:40
10:00
11:50
13:10
14:50
16:10
17:30
18:50
20:40
22:00
06:10
07:30
08:50
10:10
12:00
13:20
15:00
16:20
17:40
19:00
20:50
06:20
07:40
09:00
10:20
12:10
13:30
15:10
16:30
17:50
19:10
21:00
06:30
07:50
09:10
10:30
12:20
13:40
15:20
16:40
18:00
19:20
21:10
22:35
06:40
08:00
09:20
10:40
12:30
13:50
15:35
16:50
18:10
19:30
21:20
06:50
08:10
09:30
11:20
12:40
14:00
17:00
18:20
20:10
21:30
23:00
00:10
07:00
08:20
09:40
11:00
12:50
14:10
15:50
17:10
18:30
19:50
21:40','06:30
07:50
09:10
10:30
12:20
13:40
15:20
16:40
18:00
19:20
21:10
06:40
08:00
09:20
10:40
12:30
13:50
15:30
16:50
18:10
19:30
21:20
22:40
06:50
08:10
09:30
10:50
12:40
14:00
15:40
17:00
18:20
19:40
21:30
07:00
08:20
09:40
11:00
12:50
14:10
15:50
17:10
18:30
19:50
21:50
07:10
08:30
09:50
11:10
13:00
14:20
16:00
17:20
18:40
20:00
21:50
23:10
07:20
08:40
10:00
11:20
13:10
14:30
16:15
17:30
18:50
20:10
22:00
07:30
08:50
10:10
12:00
13:20
14:40
17:40
19:00
20:50
22:10
23:35
00:45
07:40
09:00
10:20
11:40
13:30
14:50
16:30
17:50
19:10
20:30
22:20','Active');
INSERT INTO "busTable" VALUES(169,'305','Nigadi','Wadgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','22 KMs','61 Minutes','1	Nigadi
2	Nigadi jakat naka
3	Cantonment jakat naka
4	Kohima line
5	B sub depot
6	Kendriya vidyalaya
7	Garden city
8	CISV
9	Dehu phata highway
10	Dehuroad railway staion
11	Dehuroad bajar
12	Gurudwara dehu road
13	Dehu road police station
14	Central Restaurant
15	Krushna Mandir Dehu Road
16	Mata Amardevi temple
17	Amarjai Begdewadi phata
18	Shankarwadi
19	Shelarwadi
20	Pune poultry farm
21	Somatne Phata
22	Talegaon Khind
23	Talegoan phata
24	Bhandari hospital
25	Jijamata chowk Talegaon
26	Talegaon nagar parishad
27	Paranjpe Hospital
28	Talegaon station
29	Egale Plax Petrol Pump
30	Bharat Petrol Pump
31	Samartha Vidyalaya Wadgaon Maval
32	Paisa Phand Kach Karkhana
33	Wadgaon Maval Phata','1	Wadgaon Maval Phata
2	Paisa phand kach karkhana
3	Samarth vidyalaya Wadgaon maval
4	Bharat petrol pump
5	Egale Plax Petrol Pump
6	Talegaon Station
7	Paranjape Hospital
8	Talegaon Nagarparishad
9	Jijamata chauk talegoan
10	Bhandari Hospital
11	Talegoan phata
12	Talegoan khind
13	Somatne Phata
14	Pune poultry farm
15	Shelarwadi
16	Shankarwadi
17	Amarjai begdewadi phata
18	Mata amardevi temple
19	Krishan mandir dehu road
20	Central restaurant
21	Dehu road police station
22	Gurudwara Dehu Road
23	Dehuroad Bazar
24	Dehu road railway station
25	Dehu phata highway
26	CISV
27	Garden City
28	Kendriya Vidyalaya
29	B Sub Depot
30	Kohima Line
31	Cantonment Jakat Naka
32	Nigadi jakat naka
33	Nigadi','33','05:25
07:15
09:20
11:50
14:05
16:05
18:35
20:35
05:40
07:30
09:30
12:00
14:20
16:25
18:20
20:50
06:00
07:55
09:55
12:05
14:35
16:35
18:35
21:05
06:10
08:10
10:10
12:40
15:00
17:05
19:05
21:35
06:20
08:20
10:20
12:50
15:20
17:20
19:25
21:50
05:50
08:15
11:15
13:45
15:45
18:50
06:30
08:30
10:30
13:00
15:35
17:30
20:00
22:00
06:40
08:40
10:40
13:10
15:40
17:40
19:40
22:10
06:50
09:10
12:15
14:45
17:15
20:20
07:00
09:00
11:00
13:30
15:50
17:50
20:20
22:20','06:15
08:15
10:15
12:45
15:05
17:05
19:35
21:35
06:30
08:30
10:30
13:00
15:20
17:20
19:50
21:50
06:55
08:55
10:55
13:25
15:35
17:35
20:05
22:05
07:10
09:10
11:10
13:40
16:05
18:05
20:35
22:35
07:20
09:20
11:20
13:50
16:20
18:20
20:50
22:50
07:00
09:35
12:15
14:45
17:00
20:00
07:30
09:30
12:00
14:00
16:30
18:30
21:00
23:00
07:40
09:40
11:40
14:10
16:40
18:40
21:10
23:10
08:00
10:30
13:15
16:00
18:30
21:15
08:00
10:00
12:30
14:30
16:50
18:50
21:20
23:20','Active');
INSERT INTO "busTable" VALUES(170,'306','Moshi','Chinchwad gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','60 Minutes','1	Moshi goan
2	Chaudhari dhaba
3	Bankar Vasti Moshi
4	Borate wasti
5	Juna Jakat naka
6	Tan Protex
7	Wakhar Mahamandal Bhosari
8	Panjarpol
9	Sadgurunagar PCMT depot
10	Bhosari gaon
11	PCMT chauk
12	Gavane Vasti
13	Landewadi
14	Electronic sadan
15	Century company
16	Indrayani nagar corner
17	Power house bhosari
18	Gavalimatha
19	Yashwant nagar telco road
20	Telco hostel
21	Telco company
22	KSB Chowk
23	Sanghavi College
24	Morwadi Phata
25	Mohan Nagar
26	MIDC Chinchwad
27	Chinchwad station
28	Chinchwad chauk
29	Lokmanya Hospital
30	Prekshagruha
31	Elpro Company
32	Chinchwad gaon','1	Chinchwad gaon
2	Elpro Company
3	Prekshagruha
4	Lokmanya Hospital
5	Chinchwad chauk
6	Chinchwad station
7	MIDC Chinchwad
8	Mohan Nagar
9	Morwadi Phata
10	Sanghavi College
11	KSB chauk
12	Telco company
13	Telco hostel
14	Yashwant Nagar Telco Road
15	Gavalimatha
16	Power house Bhosari
17	Indrayani nagar Corner
18	Century Company
19	Electronic Sadan
20	Landewadi
21	Gavane Vasti
22	PCMT chauk
23	Bhosari gaon
24	Sadgurunagar PCMT depot
25	Panjarpol
26	Wakhar mahamandal bhosari
27	Tan protex
28	Juna jakat naka
29	Borate Vasti
30	Bankar wasti moshi
31	Chaudhari dhaba
32	Moshi goan','32','05:45
07:45
09:45
12:15
14:45
16:45
19:15
06:15
08:15
10:15
12:45
15:15
17:15
19:45
06:45
08:45
10:45
13:15
15:45
17:45
20:15
07:15
09:15
11:15
13:45
16:15
18:15
20:45','06:45
08:45
11:15
13:15
15:45
17:45
21:15
07:15
09:15
11:45
13:45
16:15
18:15
20:45
07:45
09:45
12:15
14:15
16:45
18:45
21:15
08:15
10:15
12:45
14:45
17:15
19:15
21:45','Active');
INSERT INTO "busTable" VALUES(171,'307','Pimpri Manapa','Chintamani Chowk','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','37 Minutes','1	Pimpri Manapa
2	Bhatnagar
3	Link road
4	Manik Colony
5	Darshan hall
6	Chinchwad gaon
7	Chafekar chauk
8	Chinchwade Nagar Corner Chinchwad Road
9	Chinchwade Farm
10	Aher garden
11	Walhekarwadi
12	Matoshri nagar
13	D.Y.Patil corner
14	D Y Patil college Akrdi
15	D Y Patil Chowk
16	Gurudwara Chowk
17	Mimli Garden
18	Atharva Park
19	Chintamani Chowk','1	Chintamani chauk
2	Atharv park
3	Mimli garden
4	Gurudwara chauk
5	Akurdi rly stn backside
6	D Y Patil Chowk
7	D Y Patil College
8	D Y Patil Corner
9	Matoshri Nagar
10	Walhekarwadi
11	Aher Garden
12	Chinchwade farm
13	Chinchwade nagar corner chinchwad rd
14	Chafekar chauk
15	Chinchwad gaon
16	Darshan hall
17	Manik colony
18	Link Road
19	Bhatnagar
20	Finolex
21	Pimpri Manapa','19','05:50
07:05
08:25
09:45
11:35
12:50
13:50
15:05
16:25
17:45
19:35
20:55
06:30
07:45
09:05
10:25
12:15
13:35
14:30
15:45
17:05
18:25
20:15
21:35','06:25
07:45
09:00
10:55
12:15
13:10
14:25
15:45
17:05
18:55
20:15
21:30
07:05
08:20
09:40
11:35
12:55
13:50
15:05
16:25
17:45
19:35
20:55
22:20','Active');
INSERT INTO "busTable" VALUES(172,'308','Nigadi','Bebad ohal','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','95 Minutes','1	Nigadi
2	Nigadi jakat naka
3	Cantonment jakat naka
4	Kohima line
5	B sub depot
6	Kendriya vidyalaya
7	Garden city
8	CISV
9	Dehu phata highway
10	Dehuroad railway staion
11	Dehuroad bajar
12	Gurudwara dehu road
13	Dehu road police station
14	Central Restaurant
15	Krushna Mandir Dehu Road
16	Mata Amardevi temple
17	Amarjai Begdewadi phata
18	Shankarwadi
19	Shelarwadi
20	Pune poultry farm
21	Somatne Phata
22	Shamal Rose Nursery
23	Parandhwadi
24	Urse Phata
25	Bebadohal','1	Bebadohal
2	Urse phata
3	Parandhwadi
4	Shamal rose nursery
5	Somatne Phata
6	Pune poultry farm
7	Shelarwadi
8	Shankarwadi
9	Amarjai begdewadi phata
10	Mata amardevi temple
11	Krishan mandir dehu road
12	Central restaurant
13	Dehu road police station
14	Gurudwara Dehu Road
15	Dehuroad Bazar
16	Dehu road railway station
17	Dehu phata highway
18	CISV
19	Garden City
20	Kendriya Vidyalaya
21	B Sub Depot
22	Kohima Line
23	Cantonment Jakat Naka
24	Nigadi jakat naka
25	Nigadi','25','05:55
07:35
09:15
11:25
13:25
15:05
16:45
18:55
06:45
08:25
10:05
00:15
14:15
15:55
17:35
19:45','06:45
08:25
10:05
12:15
14:15
15:55
17:35
19:45
07:35
09:15
10:55
13:05
15:05
16:45
18:25
20:35','Active');
INSERT INTO "busTable" VALUES(173,'309','Dehugaon','Alandi bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','49 Minutes','1	Dehugaon
2	Dehugaon Grampanchayat
3	Canbay Corner
4	Chikhali
5	Moshi phata chikhali
6	Alhat wasti
7	Moshi phata chimboli phata
8	Hood company
9	Moshi Phata Dehu Phata
10	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Hood company
4	Moshi Phata Chimbli Phata
5	Alhat Vasti
6	Moshi phata Chikhli
7	Chikhali
8	Canbay Corner
9	Dehugaon grampanchayat
10	Dehugaon','10','06:00
07:30
09:10
11:20
14:05
15:35
17:15
19:25
06:45
08:15
09:55
12:05
14:50
16:20
18:00
20:10','06:45
08:20
10:00
12:10
14:50
16:25
18:05
20:15
07:30
09:05
10:45
12:55
15:35
17:10
18:50
21:00','Active');
INSERT INTO "busTable" VALUES(174,'31','Padmavati','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','48 Minutes','1	Padmavati Bus stand
2	Power house Padmavati
3	Date Bus stop
4	Nandadeep
5	Gandhi Training Corner
6	Sarang Society
7	Lakshminagar Corner
8	Parvati darshan vasahat
9	Laxmi Narayan Theature
10	Swargate
11	Ghorpade peth colony
12	Lakud Bajar
13	Sonwane hospital
14	Ramoshi gate
15	Subhanshah Darga
16	Phadake Houd
17	Kamala nehru hospital
18	Sadanand nagar
19	15 August Lodge Somwar Peth
20	Sasoon hospital
21	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	Collector kacheri
4	Zila Parishad
5	15 August Lodge Somwar Peth
6	Sadanand Nagar
7	Kamala nehru hospital
8	Daruwala Pool
9	Ganesh Peth
10	Govind Halwai Chowk
11	Naik Hospital
12	Shitaladevi chauk
13	Ganjpeth Police Chowky
14	Mominpura
15	Ghorpade Peth
16	Swargate police line
17	Swargate
18	Lakshi narayan theature
19	Panchami hotel
20	Parvati darshan vasahat
21	Lakshminagar Corner
22	Sarang Society
23	Gandhi Training Corner
24	Nandadeep
25	Date Bus stop
26	Power house Padmavati
27	Padmavati Bus stand','21','05:30
07:00
08:50
10:35
12:15
14:00
15:30
17:00
18:55
20:45
05:40
07:10
09:10
10:45
12:25
14:10
15:40
17:10
19:15
21:00
05:50
07:20
09:20
10:55
12:35
14:20
15:50
17:20
19:25
21:10
09:00
10:25
16:00
17:30
06:15
07:45
09:45
11:20
13:00
14:45
16:15
17:45
19:50
21:35
06:25
07:55
09:55
11:30
13:10
14:55
16:25
17:55
20:00
21:45
06:35
08:05
10:05
11:40
13:20
15:05
16:35
18:35
20:10
21:55
06:45
08:15
10:15
11:50
13:30
06:05
08:05
10:05
12:40
15:55
17:55
20:25
22:25','06:15
07:45
09:35
11:20
13:00
14:45
16:15
17:50
19:45
21:30
06:25
07:55
09:55
11:35
13:10
14:55
16:25
18:00
20:00
21:45
06:35
08:05
10:05
11:45
13:20
15:05
16:35
18:10
20:10
21:55
09:45
11:10
16:45
18:20
07:00
08:30
10:30
12:10
13:45
15:30
17:00
18:35
20:35
22:20
07:10
08:40
10:40
12:20
13:55
15:40
17:10
18:45
20:45
22:30
07:20
08:50
10:50
12:30
14:05
15:50
17:20
19:25
20:55
22:40
07:20
09:00
11:00
12:40
14:10
07:05
09:05
11:40
13:35
16:55
19:30
21:25
23:25','Active');
INSERT INTO "busTable" VALUES(175,'310','Pimpri gaon','Vikasnagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','16.5 KMs','45 Minutes','1	Pimprigaon
2	PMC School Pimpri
3	Ashok Talkies
4	Jaihind School
5	Delux
6	Karachi chauk
7	Lalmandir
8	Bhatnagar
9	Link road
10	Manik Colony
11	Darshan hall
12	Chinchwad gaon
13	Chafekar chauk
14	Chinchwade Nagar Corner Chinchwad Road
15	Chinchwade Farm
16	Aher garden
17	Walhekarwadi
18	Matoshri nagar
19	D.Y.Patil corner
20	Water Supply Ravet
21	Rawet
22	Dharmaraj Mangal Karyalaya Ravet
23	Kiwale
24	Poultry farm Indrayani dhaba
25	Adarshnagar Corner
26	Indraprabha mamurdi
27	Petrol pump vikasnagar
28	Medical shop
29	Vikasnagar','1	Vikasnagar
2	Medical Shop
3	Petrol Pump Vikasnagar
4	Indraprabha Mamurdi
5	Adarshnagar corner
6	Poultry Farm Indrayani dhaba
7	Kiwale
8	Dharmraj mangal karyalay rawet
9	Rawet
10	Water supply rawet
11	D Y Patil Corner
12	Matoshri Nagar
13	Walhekarwadi
14	Aher Garden
15	Chinchwade farm
16	Chinchwade nagar corner chinchwad rd
17	Chafekar chauk
18	Chinchwad gaon
19	Darshan hall
20	Manik colony
21	Link Road
22	Bhatnagar
23	Shagun chowk
24	Karachi chowk
25	Delux
26	Jaihind School
27	Ashok Talkies
28	PMC School Pimpri
29	Pimprigaon','29','05:30
07:10
09:30
11:20
13:45
15:30
17:50
19:50
05:45
06:30
07:30
08:30
10:00
14:15
15:15
16:15
17:45
19:15
20:15
06:20
08:15
10:35
12:25
14:50
16:35
19:00
21:00','06:20
08:05
10:25
12:15
14:40
16:25
18:50
20:50
06:00
07:00
08:00
09:00
10:30
14:45
15:45
16:45
18:30
19:45
21:00
07:10
09:10
11:30
13:20
15:45
17:30
20:00
21:55','Active');
INSERT INTO "busTable" VALUES(176,'311','Pimpri gaon','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','22.5 KMs','74 Minutes','1	Pimprigaon
2	PMC School Pimpri
3	Ashok Talkies
4	Jaihind School
5	Delux
6	Lalmandir
7	Bhatnagar
8	Finolex
9	Pimpri chauk Bus stand
10	Kharalwadi
11	H A Factory
12	PCMT
13	Mahesh nagar
14	YCM
15	Wadilal
16	Vallabhnagar
17	Deichi Company
18	Nashik phata
19	Kasarwadi
20	Forbes marshal stop
21	Alfa Laval Atlas Company
22	Sandwik
23	Fugewadi
24	Dapodi
25	Bopodi
26	Gangaram park
27	Kirloskar oil engine manaji bag
28	Alegaonkar High school
29	Khadki Bazar
30	Supply Depot
31	Amunition Factory Road
32	Mathyadist Church
33	Holkar Water Supply
34	Sapras post
35	Deccan college
36	Shadal baba Darga
37	Yerwada
38	Band garden
39	Guruprasad bangala
40	Jahangir Hospital
41	Alankar Talkies
42	Pune Station Depot','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Pune station
6	Ruby hall
7	Wadia college
8	Guruprasad bangala
9	Band garden
10	Yerwada
11	Shadal baba Darga
12	Deccan college
13	Sapras post
14	Holkar Water Supply
15	Mathyadist Church
16	Amunition factory road
17	Suply depot
18	Khadaki bajar
19	Alegaonkar High school
20	Kirloskar Oil Engine Manaji Bag
21	Gangaram park
22	Bopodi
23	Dapodi
24	Fugewadi
25	Sandwik
26	Alfa laval atlas company
27	Forbes marshal stop
28	Kasrawadi
29	Nashik phata
30	Deichi company
31	Vallabhnagar
32	YCM
33	Mahesh nagar
34	HA Factory D Y Patil college
35	Kharalwadi
36	Pimpri chauk Bus stop
37	Finolex
38	Bhatnagar
39	Shagun chauk
40	Karachi chowk
41	Delux
42	Jaihind School
43	Ashok Talkies
44	PMC School Pimpri
45	Pimprigaon','42','06:45
09:15
12:15
14:45
17:15
20:15
06:25
08:55
11:55
14:25
16:55
19:55
08:00
10:30
13:35
16:00
18:30
21:30
07:40
10:10
13:05
15:40
18:10
21:10','08:00
10:30
13:30
16:00
18:30
21:30
07:40
10:10
12:55
15:40
18:10
21:15
09:15
11:50
14:40
17:15
19:45
22:45
08:55
11:20
14:20
16:55
19:25
22:25','Active');
INSERT INTO "busTable" VALUES(177,'312A','Chinchwad gaon','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','22 KMs','78 Minutes','1	Chinchwad gaon
2	Elpro Company
3	Prekshagruha
4	Lokmanya Hospital
5	chinchwad station
6	Chinchwad chauk
7	Premier company
8	Finolex
9	Pimpri chauk Bus stand
10	Kharalwadi
11	H A Factory
12	PCMT
13	Mahesh nagar
14	YCM
15	Wadilal
16	Vallabhnagar
17	Deichi Company
18	Nashik phata
19	Kasarwadi
20	Forbes marshal stop
21	Alfa Laval Atlas Company
22	Sandwik
23	Fugewadi
24	Dapodi
25	Bopodi Jakat Naka
26	Bopodi
27	Gangaram park
28	Kirloskar oil engine manaji bag
29	Alegaonkar High school
30	Khadki Bazar
31	Supply Depot
32	Amunition Factory Road
33	Mathyadist Church
34	Holkar Water Supply
35	Sapras post
36	Deccan college
37	Shadal baba Darga
38	Yerwada
39	Band garden
40	Guruprasad bangala
41	Jahangir Hospital
42	Alankar Talkies
43	Pune Station Depot','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Sasoon hospital
6	Pune station
7	Alankar Talkies
8	Ruby hall
9	Wadia college
10	Guruprasad bangala
11	Band garden
12	Yerwada
13	Shadal baba Darga
14	Deccan college
15	Sapras post
16	Holkar Water Supply
17	Mathyadist Church
18	Amunition factory road
19	Suply depot
20	Khadaki bajar
21	Alegaonkar High school
22	Kirloskar Oil Engine Manaji Bag
23	Gangaram park
24	Bopodi
25	Dapodi
26	Fugewadi
27	Sandwik
28	Alfa laval atlas company
29	Forbes marshal stop
30	Kasrawadi
31	Nashik phata
32	Deichi company
33	Vallabhnagar
34	Wadilal
35	YCM
36	Mahesh nagar
37	PCMT
38	HA Factory D Y Patil college
39	Kharalwadi
40	Pimpri chauk Bus stop
41	Finolex
42	Premier company
43	Chinchwad station
44	Lokmanya Hospital
45	Prekshagruha
46	Elpro Company
47	Chinchwad gaon','43','05:30
08:00
11:05
13:45
16:20
19:30
05:55
08:25
11:30
14:10
16:45
20:00
06:20
08:50
11:55
14:35
17:10
20:25','06:45
09:20
12:25
15:05
17:40
20:40
07:10
09:45
12:50
15:30
18:00
21:10
07:35
10:10
13:15
15:55
18:35
21:35','Active');
INSERT INTO "busTable" VALUES(178,'315','Bhosari','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18 KMs','62 Minutes','1	Bhosari gaon
2	Landewadi
3	Philips
4	MIDC bhosari
5	Bhosari police station
6	Bhosari Police Station
7	Nashik phata
8	Kasarwadi
9	Forbes marshal stop
10	Alfa Laval Atlas Company
11	Sandwik
12	Fugewadi
13	Dapodi
14	Bopodi Jakat Naka
15	Bopodi
16	Gangaram park
17	Kirloskar oil engine manaji bag
18	Alegaonkar High school
19	Khadki Bazar
20	Supply Depot
21	Amunition Factory Road
22	Mathyadist Church
23	Holkar Water Supply
24	Sapras post
25	Deccan college
26	Shadal baba Darga
27	Yerwada
28	Band garden
29	Guruprasad bangala
30	Ruby hall
31	Jahangir Hospital
32	Alankar Talkies
33	Pune Station Depot','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Pune station
6	Wadia college
7	Guruprasad bangala
8	Band garden
9	Yerwada
10	Shadal baba Darga
11	Deccan college
12	Sapras post
13	Holkar Water Supply
14	Mathyadist Church
15	Amunition factory road
16	Suply depot
17	Khadaki bajar
18	Alegaonkar High school
19	Kirloskar Oil Engine Manaji Bag
20	Gangaram park
21	Bopodi
22	Dapodi
23	Fugewadi
24	Sandwik
25	Alfa laval atlas company
26	Forbes marshal stop
27	Kasrawadi
28	Nashik phata
29	Bhosari Police Station
30	Bhosari police station
31	MIDC Bhosari
32	Philips
33	Landewadi
34	Bhosari gaon','33','05:10
06:45
09:15
11:05
13:00
15:05
17:20
20:00
07:15
09:40
11:30
13:30
15:25
17:45
20:25
08:05
10:35
12:25
14:15
16:25
18:35
21:20
08:25
10:55
12:45
14:30
16:45
19:00
21:55','05:55
07:45
10:15
12:00
14:10
16:10
18:30
21:10
06:15
08:15
10:35
12:25
14:25
16:35
18:55
21:35
07:10
09:05
11:30
13:20
15:20
17:25
19:45
22:25
07:30
09:25
11:50
13:40
15:40
17:55
20:10
22:50','Active');
INSERT INTO "busTable" VALUES(179,'315A','Bhosari','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17.3 KMs','63 Minutes','1	Bhosari gaon
2	Maharashtra chauk
3	Hutatma chauk
4	Shatri chauk
5	Durwankur lawns
6	Dighi Corner Odha
7	Tata stores
8	Bhosari phata
9	Telco godown
10	Dattanagar
11	Mitra sahkar nagar
12	Dighigaon
13	AIT college
14	Wireless colony
15	Parade ground
16	Mhaske wasti
17	Kalasgaon
18	R D colony
19	Vishrantwadi
20	Sathe Biscuit company
21	Shantinagar
22	Mental Hospital Corner
23	MES Water Works
24	Phulenagar
25	RTO New
26	Ambedkar Society
27	Deccan college
28	Shadal baba Darga
29	Yerwada
30	Band garden
31	Guruprasad bangala
32	Jahangir Hospital
33	Alankar Talkies
34	Sadhu wasvani chauk
35	GPO
36	Collector kacheri
37	Sasoon hospital','1	Sasoon hospital
2	Pune station
3	Alankar Talkies
4	Ruby hall
5	Wadia college
6	Guruprasad bangala
7	Band garden
8	Yerwada
9	Shadal baba Darga
10	Deccan college
11	Ambedkar Society
12	RTO New
13	Phulenagar
14	MES Water Works
15	Mental Hospital Corner
16	Shantinagar
17	Sathe Biscuit company
18	Vishrantwadi
19	R D colony
20	kalasgaon
21	Mhaske wasti
22	Parade ground
23	Wireless colony
24	AIT college
25	Dighigaon
26	Mitra sahakar nagar
27	Dattanagar
28	Telco godown
29	Bhosari phata
30	Tata Stores
31	Didhi corner odha
32	Durvankur Lawns
33	Shastri chowk
34	Hutatma chauk
35	Maharashtra Chowk
36	Bhosari gaon','37','06:00
07:40
09:40
12:10
14:10
16:30
18:50
06:15
08:00
10:00
12:30
14:35
16:55
19:15
06:30
08:20
10:20
12:45
15:00
17:20
19:40
06:45
08:40
10:10
13:00
15:25
17:45
20:05
07:00
09:00
11:30
13:15
15:50
18:10
20:30
07:20
09:20
11:50
13:35
16:10
18:30
20:50','06:50
08:35
11:10
13:00
15:20
17:40
20:30
07:05
09:00
11:30
13:20
15:45
18:05
20:55
07:20
09:20
11:45
13:45
16:10
18:30
21:20
07:35
09:40
12:05
13:50
16:35
18:55
21:45
07:55
10:00
12:20
14:05
17:00
19:20
22:10
08:15
10:20
12:40
14:25
17:20
19:40
22:30','Active');
INSERT INTO "busTable" VALUES(180,'317','Sambhajinagar','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','24 KMs','73 Minutes','1	Sambhaji Nagar
2	Maruti Mandir
3	Krushnanagar Corner
4	Kasturi market
5	Ajantha nagar corner
6	Thermax
7	Akurdi Khandoba Chowk
8	Ruston Company
9	Kalbhor nahar bus stop
10	Mehta hospital
11	chinchwad station
12	Chinchwad chauk
13	Premier company
14	Finolex
15	Pimpri chauk Bus stand
16	Kharalwadi
17	H A Factory
18	Vallabhnagar
19	Deichi Company
20	Nashik phata
21	Kasarwadi
22	Forbes marshal stop
23	Alfa Laval Atlas Company
24	Sandwik
25	Fugewadi
26	Dapodi
27	Bopodi Jakat Naka
28	Khadaki
29	Khadaki railway station
30	Khadaki church stop
31	Khadaki post office
32	Raja bangalow
33	Krutrim Reshim Paidas Kendra
34	Poultry Farm Old Mumbai Pune Road
35	Mariaai Gate Old Mumbai Pune Road
36	Bajaj showroom
37	Labor office
38	Patil Estate
39	College of engineering pune
40	RTO wellesley road
41	Raja Bahadur mill
42	Alankar Talkies
43	Pune Station Depot','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Sasoon hospital
6	Pune station
7	Alankar Talkies
8	Raja bahadur mill
9	RTO wellesley road
10	College of engineering pune
11	Patil Estate
12	Labour office
13	Bajaj showroom wakadewadi
14	Mariaai Gate Old Mumbai Pune Road
15	Poultry Farm Old Mumbai Pune Road
16	Krutrim reshim paidas kendra
17	Raja Bungalow
18	Khadaki post office
19	Khadki church stop
20	Khadaki railway station
21	Khadaki
22	Bopodi
23	Dapodi
24	Fugewadi
25	Sandwik
26	Alfa laval atlas company
27	Forbes marshal stop
28	Kasrawadi
29	Nashik phata
30	Deichi company
31	Vallabhnagar
32	HA Factory D Y Patil college
33	Kharalwadi
34	Pimpri chauk Bus stop
35	Finolex
36	Premier company
37	Chinchwad station
38	Mehta hospital
39	Kalbhor nagar bus stop
40	Rustan company
41	Akurdi khandoba chauk
42	Thermax
43	Ajanta Nagar Corner
44	Kasturi Market
45	Krushnanaga corner
46	Maruti Mandir
47	Sambhaji Nagar','43','05:30
07:50
10:50
14:10
16:35
19:35
05:50
08:10
11:10
14:30
16:55
19:55
06:10
08:30
11:30
14:50
17:15
20:15
06:30
08:50
11:50
15:10
17:35
20:35
06:50
09:10
12:10
15:30
17:55
20:55
07:10
09:30
12:30
15:50
18:15
21:15
07:30
09:55
12:55
16:15
18:40
21:40','06:40
09:05
12:05
15:20
17:50
20:45
07:00
09:25
12:25
15:40
18:10
21:05
07:20
09:45
12:45
16:00
18:30
21:25
07:40
10:05
13:05
16:20
18:50
21:45
08:00
10:25
13:25
16:40
19:10
22:05
08:20
10:45
13:45
17:00
19:30
22:25
08:40
11:10
14:10
17:25
19:55
22:50','Active');
INSERT INTO "busTable" VALUES(181,'318','Krushnanagar','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','25 KMs','75 Minutes','1	Krushnanagar
2	Sane chauk
3	Krushnanagar Corner
4	Kasturi market
5	Ajantha nagar corner
6	Thermax
7	Akurdi Khandoba Chowk
8	Chafekar chauk
9	Walhekarwadi phata
10	Jakatnaka pavanapul
11	Birla Hospital
12	Dattanagar Chinchwad
13	Padmji Paper Mill
14	Thergaon phata
15	Dange chowk
16	Laxman nagar
17	16 Number
18	Kalewadi phata
19	Kaspate Vasti
20	Jagtap Dairy
21	Wakad phata
22	Military Stores
23	Rakshak chauk
24	ESI Hospital
25	Aundh post office
26	Aundh chest hospital
27	Sangvi Phata
28	Aundh gaon
29	Body gate
30	Bremen chauk
31	Sindh Colony Gate2
32	Kasturba vasahat
33	Boys Batalian
34	Pune University Gate
35	Rangehills Corner
36	E Square
37	Pune central
38	Pumping station
39	Masoba gate
40	shimala office shivajinagar
41	Lokmangal
42	College of engineering pune
43	RTO wellesley road
44	Juna Bajar
45	Ambedkar bhavan
46	Sasoon hospital
47	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Ambedkar bhavan
6	Juna Bajar
7	RTO wellesley road
8	College of engineering pune
9	shimala office shivajinagar
10	Masoba gate
11	Pumping station
12	Pune central
13	E square
14	Rangehills Corner
15	Rajbhavan
16	Boys batalian
17	Kasturba vasahat
18	Sindh colony gate 2
19	Bremen chauk
20	Body gate
21	Aundh gaon
22	Sangvi phata
23	Aundh chest hospital
24	Aundh post office
25	ESI Hospital
26	Rakshak chauk
27	Military Stores
28	Wakad phata
29	Jagtap Dairy
30	Kaspate Vasti
31	Kalewadi phata
32	16 Number
33	Laxman nagar
34	Dange chowk
35	Thergaon phata
36	Padmji Paper Mill
37	Dattanagar Chinchwad
38	Birla hospital
39	Jai Hind Vidyalaya
40	Chafekar chauk
41	Akurdi khandoba chauk
42	Thermax
43	Ajanta Nagar Corner
44	Kasturi Market
45	Krushnanaga corner
46	Sane chowk
47	Krushnanagar','47','07:45
10:15
13:15
15:45
05:50
08:20
11:20
14:40
17:10
20:10
06:10
08:45
11:45
16:00
18:30
21:30','09:00
11:30
14:30
17:00
07:05
10:00
12:40
15:55
18:25
21:25
07:30
10:30
13:00
17:15
19:45
22:45','Active');
INSERT INTO "busTable" VALUES(182,'319','Sangvi','Shirgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','33.3 KMs','100 Minutes','1	Vasantdada Putala
2	PWD gate
3	ST workshop
4	Mantri niketan Dapodi
5	Dapodi Gaon
6	Shitaladevi Mandir
7	Raviraj Hotel
8	Ramkrushna Mangal Karyalaya
9	Pooja hospital
10	Suvarna park
11	Panyachi Taki Pimple Gurav
12	Pimple gurav
13	Vaiduvasti
14	Bhairavnagar pimple gurav
15	Sudarshan nagar
16	Swaraj mazda
17	Pimpale Saudagar Chowk
18	Shivshakti mandir
19	Pimpale Saudagar
20	Rahatani gaon
21	Ramnagar rahatani
22	akate wasti
23	Saurabh company tambe company
24	Rahatani phata
25	Shrinagar
26	Dhangar Nagar Kalewadi
27	Tapgir nagar
28	M M shala
29	Avinash Mangal Karyalaya
30	Dhangar nagar kalewadi
31	Vijaynagar
32	Ingale hospital
33	Krushnamandir Corner
34	Delux
35	Karachi chauk
36	Lalmandir
37	Bhatnagar
38	Finolex
39	Premier company
40	Chinchwad station
41	Mehta hospital
42	Kalbhor nagar bus stop
43	Rustan company
44	Akurdi khandoba chauk
45	Bajaj auto
46	Pradhikaran Chowk
47	Nigadi jakat naka
48	Cantonment jakat naka
49	Kohima line
50	B sub depot
51	Kendriya vidyalaya
52	Garden city
53	CISV
54	Dehu phata highway
55	Dehuroad railway staion
56	Dehuroad bajar
57	Gurudwara dehu road
58	Dehu road police station
59	Central Restaurant
60	Krushna Mandir Dehu Road
61	Mata Amardevi temple
62	Amarjai Begdewadi phata
63	Shankarwadi
64	Shelarwadi
65	Pune poultry farm
66	Somatne Phata
67	Ramchandra Mangal Karyalaya
68	Express highway phata
69	Shirgaon','1	Shirgaon
2	Express highway phata
3	Ramchandra Mangal Karyalaya
4	Somatne Phata
5	Pune poultry farm
6	Shelarwadi
7	Shankarwadi
8	Amarjai begdewadi phata
9	Mata amardevi temple
10	Krishan mandir dehu road
11	Central restaurant
12	Dehu road police station
13	Gurudwara Dehu Road
14	Dehuroad Bazar
15	Dehu road railway station
16	Dehu phata highway
17	CISV
18	Garden City
19	Kendriya Vidyalaya
20	B Sub Depot
21	Kohima Line
22	Cantonment Jakat Naka
23	Nigadi jakat naka
24	Nigadi
25	Pradhikaran Chowk
26	Bajaj auto
27	Akurdi Khandoba Chowk
28	Ruston Company
29	Kalbhor nahar bus stop
30	Mehta hospital
31	chinchwad station
32	Chinchwad chauk
33	Premier company
34	Finolex
35	Shagun chowk
36	Karachi chowk
37	Delux
38	Krushnamandir corner
39	Ingale Hospital
40	Vijaynagar
41	Dhangar Nagar Kalewadi
42	Avinash mangal karyalay
43	M M Shala
44	Tapkir Nagar
45	Dhangar Nagar Kalewadi
46	Shrinagar
47	Rahatani phata
48	Saurabh company Tambe Shala
49	Nakate wasti
50	Ramnagar rahatni
51	Rahatani gaon
52	Pimpale Saudagar
53	Shivshakti Mandir
54	Pimple saudagar chauk
55	Swaraj Mazda
56	Sudarshan nagar
57	Bhairavnagar Pimple Gurav
58	Vaiduwasti
59	Pimple gurav
60	Panyachi Taki Pimple Gurav
61	Suvarna Park
62	Pooja Hospital
63	Ramkrishna mangal karyalay
64	Raviraaj hotel
65	Shitaladevi Mandir
66	Dapodi Gaon
67	Mantri Niketan Dapodi
68	S T Workshop
69	P W D Gate
70	Vasantdada Putala','69','05:50
09:10
13:50
17:10
06:30
09:50
14:30
17:50','07:30
11:20
15:30
19:20
08:10
12:00
16:10
20:00','Active');
INSERT INTO "busTable" VALUES(183,'32','Jyoti park','Shivajinagar station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','40 Minutes','1	Ramchandranagar
2	Chavan Nagar Sambhajinagar
3	Padmavati Bus stand
4	Power house Padmavati
5	Date Bus stop
6	Nandadeep
7	Gandhi Training Corner
8	Aranyeshwar mandir
9	Santnagar Chowk Taware Colony
10	Shivdarshan Vasahat
11	Parvati darshan vasahat
12	Mitramandal Sabhagruh
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Bhikardas maruti madnir
17	Shanipar
18	A B Chowk
19	Dakshinabhimukh Maruti mandir
20	Shaniwar wada
21	PMC mangala
22	Shivaji putala pmc
23	shimala office shivajinagar
24	Shivajinagar Station','1	Shivajinagar Station
2	Sancheti Hospital
3	Shivaji putala
4	PMC Mangala
5	Kasaba Police Chowky
6	Vasant talkies
7	Mandai
8	Gokul bhavan
9	Swargate
10	Mitramandal Sabhagruh
11	Parvati darshan vasahat
12	Shivdarshan Vasahat
13	Santnagar Chowk Taware Colony
14	Aranyeshwar mandir
15	Gandhi Training Corner
16	Nandadeep
17	Date Bus stop
18	Power house Padmavati
19	Padmavati Bus stand
20	Chavan Nagar Sambhajinagar
21	Ramchandranagar','24','08:30
09:55
11:15
17:10
18:20','09:10
10:35
11:55
17:50
19:00','Active');
INSERT INTO "busTable" VALUES(184,'320','Alandi bus stand','Mhalunge Gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','30 KMs','87 Minutes','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Sai mandir
10	Moje vidyalaya
11	Bhosari phata
12	Tata Stores
13	Didhi corner odha
14	Durvankur Lawns
15	Shastri chowk
16	Hutatma chauk
17	Maharashtra Chowk
18	Bhosari gaon
19	PCMT chauk
20	Century Enka Colony
21	Landewadi
22	Philips
23	MIDC Bhosari
24	Bhosari police station
25	Nashik phata
26	Deichi company
27	Vallabhnagar
28	HA Factory D Y Patil college
29	Kharalwadi
30	Pimpri chauk Bus stop
31	Finolex
32	Premier company
33	Chinchwad station
34	Lokmanya Hospital
35	Prekshagruha
36	Elpro Company
37	Chafekar chauk
38	Jai Hind Vidyalaya
39	Jakatnaka Pavanapool
40	Birla hospital
41	Dattanagar Chinchwad
42	Padmji Paper Mill
43	Thergaon phata
44	Dange chowk
45	Wakad Chowk
46	Wakad Highway
47	Mutha Pool Balewadi
48	Chh.Shivaji krida sankul
49	Mhalunge corner
50	Mhalunge Gaon','1	Mhalunge Gaon
2	Mhalunge corner
3	Chha. Shivaji Krida Sankul
4	Mutha Pool Balewadi
5	Wakad Highway
6	Wakad Chowk
7	Dange chowk
8	Thergaon phata
9	Padmji Paper Mill
10	Dattanagar Chinchwad
11	Birla Hospital
12	Jakatnaka pavanapul
13	Walhekarwadi phata
14	Chafekar chauk
15	Elpro Company
16	Prekshagruha
17	Lokmanya Hospital
18	Chinchwad station
19	Chinchwad chauk
20	Premier company
21	Finolex
22	Pimpri chauk Bus stand
23	Kharalwadi
24	H A Factory
25	Vallabhnagar
26	Deichi Company
27	Nashik phata
28	Bhosari police station
29	MIDC bhosari
30	Philips
31	Landewadi
32	Century Enka Colony
33	Bhosari gaon
34	Maharashtra chauk
35	Hutatma chauk
36	Shatri chauk
37	Durwankur lawns
38	Dighi Corner Odha
39	Tata stores
40	Bhosari phata
41	Moje vidyalaya
42	Sai madnir
43	Nirma company
44	Gokhale Mala Sankalpa Garden
45	Wadmukhwadi
46	Chincheche jhad
47	Charholi phata
48	Sai Lila nagar Kate Wasti
49	Moshi Phata Dehu Phata
50	Alandi bus stand','50','07:20
10:40
13:30
16:20
19:50','08:45
12:05
14:55
17:50
21:20','Active');
INSERT INTO "busTable" VALUES(185,'322','Akurdi rly stn','Katraj bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','31 KMs','106 Minutes','1	Akurdi rly stn
2	Akurdi Police Chowky
3	Sambhaji chowk
4	Patil Chowk
5	Railway quarters
6	Bijlinagar
7	Chinchwade Nagar Corner Akurdi Road
8	Chaitanya sabhagruha
9	Om Sairam complex
10	Chafekar chauk
11	Chinchwad gaon
12	Rama Bistake park
13	Morya Gosavi raj park
14	M M Shala
15	Tapkir Nagar
16	Dhangar Nagar Kalewadi
17	Shrinagar
18	Rahatani Phata
19	Saurabh company Tambe Shala
20	Nakate wasti
21	Ramnagar rahatni
22	Rahatani gaon
23	Pimpale Saudagar
24	Shivshakti Mandir
25	Pimple saudagar chauk
26	Swaraj Mazda
27	Sudarshan nagar
28	Bhairavnagar Pimple Gurav
29	Vaiduwasti
30	Pimple gurav
31	New pmc school
32	Katepuram
33	Krishna bajar
34	Sai chauk
35	Panyachi taki
36	Navi Sangvi
37	Bara gholap
38	Nurses Quarters
39	Sangvi Phata
40	Aundh gaon
41	Body gate
42	Bremen chauk
43	Sindh Colony Gate2
44	Kasturba vasahat
45	Boys Batalian
46	Pune University Gate
47	Rangehills Corner
48	E Square
49	Pune central
50	Pumping station
51	Masoba gate
52	shimala office shivajinagar
53	Engineering college hostel
54	Shivaji putala
55	PMC Mangala
56	Kasaba Police Chowky
57	Vasant talkies
58	Mandai
59	Shahu chauk
60	Mamledar kacheri
61	Gokul bhavan
62	Swargate
63	Lakshi narayan theature
64	Panchami hotel
65	Bhapkar Petrol Pump City pride
66	Aranyeshwar Corner
67	Natu Bag
68	Padmavati corner
69	Vishweshwar Bank KK market
70	Balaji nagar
71	Chaitanya nagar
72	Bharti vidyapeeth gate
73	Katraj dairy Sarpodyan
74	More bag
75	Katraj bus stand','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Bhikardas maruti madnir
17	Shanipar
18	A B Chowk
19	Dakshinabhimukh Maruti mandir
20	Shaniwar wada
21	PMC mangala
22	Shivaji putala pmc
23	shimala office shivajinagar
24	Masoba gate
25	Pumping station
26	Pune central
27	E square
28	Rangehills Corner
29	Rajbhavan
30	Boys batalian
31	Kasturba vasahat
32	Sindh colony gate 2
33	Bremen chauk
34	Body gate
35	Aundh gaon
36	Sangvi phata
37	Sangvi Phata
38	Nurses Quarters
39	Ba ra gholap
40	Navi Sangvi
41	Panyachi taki
42	Sai chauk
43	Krishna bajar
44	Katepuram
45	New pmc school
46	Pimple gurav
47	Vaiduvasti
48	Bhairavnagar pimple gurav
49	Sudarshan nagar
50	Swaraj mazda
51	Pimpale Saudagar Chowk
52	Shivshakti mandir
53	Pimpale Saudagar
54	Rahatani gaon
55	Ramnagar rahatani
56	akate wasti
57	Saurabh company tambe company
58	Rahatani phata
59	Shrinagar
60	Dhangar Nagar Kalewadi
61	Tapgir nagar
62	M M shala
63	Morya Gosavi Raj park
64	Rama bistake park
65	Chinchwad gaon
66	Chafekar chauk
67	Om sairam complex
68	Chaitnya sabhagrah
69	Chinchwade nagar corner Akurdi road
70	Bijali nagar
71	Railway quarters
72	Patil chauk
73	Sambhaji chauk
74	Akurdi police chauky
75	Akurdi rly stn','75','05:35
09:05
13:40
17:20
06:30
10:00
14:30
18:10
07:20
10:50
15:25
19:05
08:20
11:50
16:25
20:05','07:15
11:15
15:30
19:35
08:10
12:10
16:20
20:25
09:00
13:00
17:15
21:20
10:00
14:00
18:15
22:20','Active');
INSERT INTO "busTable" VALUES(186,'322A','Akurdi rly stn','Warje Malwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','29 KMs','104 Minutes','1	Akurdi rly stn
2	Akurdi Police Chowky
3	Sambhaji chowk
4	Patil Chowk
5	Railway quarters
6	Bijlinagar
7	Chinchwade Nagar Corner Akurdi Road
8	Chaitanya sabhagruha
9	Om Sairam complex
10	Chafekar chauk
11	Chinchwad gaon
12	Darshan hall
13	Manik colony
14	Link Road
15	Bhatnagar
16	Shagun chowk
17	Karachi chowk
18	Delux
19	Jaihind School
20	Ashok Talkies
21	PMC School Pimpri
22	Pimprigaon
23	Nanekar park
24	Waghire height
25	Pimple saudagar chauk
26	Swaraj Mazda
27	Sudarshan nagar
28	Bhairavnagar Pimple Gurav
29	Vaiduwasti
30	Pimple gurav
31	New pmc school
32	Katepuram
33	Krishna bajar
34	Sai chauk
35	Panyachi taki
36	Navi Sangvi
37	Bara gholap
38	Nurses Quarters
39	Sangvi Phata
40	Aundh gaon
41	Body gate
42	Bremen chauk
43	Sindh Colony Gate2
44	Kasturba vasahat
45	Boys Batalian
46	Pune University Gate
47	Chatushringi payatha
48	ICC bus stop
49	Shivaji housing board bus stop
50	Vetal Maharaj chauk
51	Sheti mahamandal
52	Symbiosis college
53	Bhandarkar Institute
54	Law college
55	Nal Stop
56	SNDT college
57	Paud Phata Dashabhuja Ganpati
58	Maruti mandir karve road
59	Karve putala
60	Kothrud Stand
61	Dahanukar colony
62	Wadache Jhad Bhairavnath Mandir
63	Karvenagar
64	Warje Jakatnaka
65	Tapodham
66	Warje Malwadi
67	Dnanesh society
68	Ganpati matha','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	Law college
14	Bhandarkar Institute
15	Symbiosis college
16	Sheti mahamandal
17	Vetal Maharaj chauk
18	Shivaji housing board bus stop
19	ICC bus stop
20	Chatushringi payatha
21	Rajbhavan
22	Boys batalian
23	Kasturba vasahat
24	Sindh colony gate 2
25	Bremen chauk
26	Body gate
27	Aundh gaon
28	Sangvi phata
29	Sangvi Phata
30	Nurses Quarters
31	Ba ra gholap
32	Navi Sangvi
33	Panyachi taki
34	Sai chauk
35	Krishna bajar
36	Katepuram
37	New pmc school
38	Pimple gurav
39	Vaiduvasti
40	Bhairavnagar pimple gurav
41	Sudarshan nagar
42	Swaraj mazda
43	Pimpale Saudagar Chowk
44	Waghire height
45	Nanekar park
46	Pimprigaon
47	PMC School Pimpri
48	Ashok Talkies
49	Jaihind School
50	Delux
51	Karachi chauk
52	Lalmandir
53	Bhatnagar
54	Link road
55	Manik Colony
56	Darshan hall
57	Chinchwad gaon
58	Chafekar chauk
59	Om sairam complex
60	Chaitnya sabhagrah
61	Chinchwade nagar corner Akurdi road
62	Bijali nagar
63	Railway quarters
64	Patil chauk
65	Sambhaji chauk
66	Akurdi police chauky
67	Akurdi rly stn','68','05:50
09:20
14:00
17:40
06:45
10:15
14:45
18:25
07:40
11:10
15:45
19:25
08:35
12:05
16:45
20:25','07:30
11:30
15:50
19:55
08:25
12:25
16:35
20:40
09:20
13:20
17:35
21:40
10:15
14:15
18:35
22:40','Active');
INSERT INTO "busTable" VALUES(187,'322B','Akurdi Rly Station','Hadapsar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','24 KMs','104 Minutes','1	Akurdi rly stn
2	Akurdi Police Chowky
3	Sambhaji chowk
4	Patil Chowk
5	Railway quarters
6	Bijlinagar
7	Chinchwade Nagar Corner Akurdi Road
8	Chaitanya sabhagruha
9	Om Sairam complex
10	Chafekar chauk
11	Chinchwad gaon
12	Rama Bistake park
13	Morya Gosavi raj park
14	M M Shala
15	Tapkir Nagar
16	Dhangar Nagar Kalewadi
17	Shrinagar
18	Rahatani Phata
19	Saurabh company Tambe Shala
20	Nakate wasti
21	Ramnagar rahatni
22	Rahatani gaon
23	Pimpale Saudagar
24	Shivshakti Mandir
25	Pimple saudagar chauk
26	Swaraj Mazda
27	Sudarshan nagar
28	Bhairavnagar Pimple Gurav
29	Vaiduwasti
30	Pimple gurav
31	New pmc school
32	Katepuram
33	Krishna bajar
34	Sai chauk
35	Panyachi taki
36	Navi Sangvi
37	Bara gholap
38	Nurses Quarters
39	Sangvi Phata
40	Aundh gaon
41	Body gate
42	Bremen chauk
43	Sindh Colony Gate2
44	Kasturba vasahat
45	Boys Batalian
46	Pune University Gate
47	Rangehills Corner
48	E Square
49	Pune central
50	Pumping station
51	Masoba gate
52	shimala office shivajinagar
53	Lokmangal
54	College of engineering pune
55	RTO wellesley road
56	Juna Bajar
57	Ambedkar bhavan
58	Sasoon hospital
59	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Ambedkar bhavan
6	Juna Bajar
7	RTO wellesley road
8	College of engineering pune
9	Engineering college hostel
10	shimala office shivajinagar
11	Masoba gate
12	Pumping station
13	Pune central
14	E square
15	Rangehills Corner
16	Rajbhavan
17	Boys batalian
18	Kasturba vasahat
19	Sindh colony gate 2
20	Bremen chauk
21	Body gate
22	Aundh gaon
23	Sangvi phata
24	Sangvi Phata
25	Nurses Quarters
26	Ba ra gholap
27	Panyachi taki
28	Sai chauk
29	Krishna bajar
30	Katepuram
31	New pmc school
32	Pimple gurav
33	Vaiduvasti
34	Bhairavnagar pimple gurav
35	Sudarshan nagar
36	Swaraj mazda
37	Pimpale Saudagar Chowk
38	Shivshakti mandir
39	Pimpale Saudagar
40	Rahatani gaon
41	Ramnagar rahatani
42	akate wasti
43	Saurabh company tambe company
44	Rahatani phata
45	Shrinagar
46	Dhangar Nagar Kalewadi
47	Tapgir nagar
48	M M shala
49	Morya Gosavi Raj park
50	Rama bistake park
51	Chinchwad gaon
52	Chafekar chauk
53	Om sairam complex
54	Chaitnya sabhagrah
55	Chinchwade nagar corner Akurdi road
56	Bijali nagar
57	Railway quarters
58	Patil chauk
59	Sambhaji chauk
60	Akurdi police chauky
61	Akurdi rly stn','59','05:20
08:50
13:20
17:00
06:10
09:40
14:15
17:55
07:00
10:30
15:05
18:45
08:00
11:30
16:05
19:45','07:00
11:00
15:10
19:15
07:50
11:50
16:05
20:10
08:40
12:40
16:55
21:00
09:40
13:40
17:55
22:00','Active');
INSERT INTO "busTable" VALUES(188,'323','Chikhali','Manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','23.4 KMs','74 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Deichi company
25	Vallabhnagar
26	Wadilal
27	YCM
28	Mahesh nagar
29	Nehrunagar corner
30	Zero boys
31	Master Bakery
32	Swapna nagari
33	Yashwant nagar corner
34	Yashwant nagar telco road
35	New Life
36	Agarwal Container
37	Sukhwani
38	Ahire wadi
39	Jadhav wadi
40	Jadhavwadi phata
41	Moshi phata Chikhli
42	Chikhali','1	Chikhali
2	Moshi phata chikhali
3	Jadhav wadi phata
4	Jadhav wadi
5	Ahire wadi
6	Sukhwani
7	Agarwal Container
8	New Life
9	Yashwant Nagar Telco Road
10	Yashwant nagar corner
11	Swapna nagari
12	Master bakery
13	Zero Boys
14	Nehrunagar corner
15	PCMT
16	Mahesh nagar
17	YCM
18	Wadilal
19	Vallabhnagar
20	Deichi Company
21	Nashik phata
22	Kasarwadi
23	Forbes marshal stop
24	Alfa Laval Atlas Company
25	Sandwik
26	Fugewadi
27	Dapodi
28	Bopodi Jakat Naka
29	Bopodi
30	Khadaki
31	Khadaki railway station
32	Petrol Pump Khadki
33	Khadaki church stop
34	Khadaki post office
35	Raja bangalow
36	Krutrim Reshim Paidas Kendra
37	Poultry Farm Old Mumbai Pune Road
38	Mariaai Gate Old Mumbai Pune Road
39	Bajaj showroom
40	Labor office
41	Patil Estate
42	Engineering college hostel
43	Modern Highschool
44	PMC','44','07:15
09:45
12:35
15:10
17:30
20:30
08:15
10:45
13:45
16:10
18:30
21:30','06:00
08:30
11:25
13:50
16:20
19:15
07:00
09:30
12:30
15:00
17:20
20:15','Active');
INSERT INTO "busTable" VALUES(189,'325','Masulkar colony','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18 KMs','65 Minutes','1	Masulkar Colony
2	Ajmer school
3	Vitthalwadi Mandir Masulkar
4	Wastu Udyog
5	Master Bakery
6	Zero Boys
7	Nehrunagar corner
8	PCMT
9	Mahesh nagar
10	YCM
11	Wadilal
12	Vallabhnagar
13	Deichi Company
14	Nashik phata
15	Kasarwadi
16	Forbes marshal stop
17	Alfa Laval Atlas Company
18	Sandwik
19	Fugewadi
20	Dapodi
21	Bopodi Jakat Naka
22	Bopodi
23	Khadaki
24	Khadaki railway station
25	Petrol Pump Khadki
26	Khadaki church stop
27	Khadaki post office
28	Raja bangalow
29	Krutrim Reshim Paidas Kendra
30	Poultry Farm Old Mumbai Pune Road
31	Mariaai Gate Old Mumbai Pune Road
32	Bajaj showroom
33	Labor office
34	Patil Estate
35	College of engineering pune
36	RTO wellesley road
37	Juna Bajar
38	Ambedkar bhavan
39	Sasoon hospital
40	Pune station
41	Alankar Talkies
42	Pune Station Depot','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Ambedkar bhavan
6	Juna Bajar
7	RTO wellesley road
8	College of engineering pune
9	Patil Estate
10	Labour office
11	Bajaj showroom wakadewadi
12	Mariaai Gate Old Mumbai Pune Road
13	Poultry Farm Old Mumbai Pune Road
14	Krutrim reshim paidas kendra
15	Raja Bungalow
16	Khadaki post office
17	Khadki church stop
18	Khadaki railway station
19	Khadaki
20	Bopodi
21	Dapodi
22	Fugewadi
23	Sandwik
24	Alfa laval atlas company
25	Forbes marshal stop
26	Kasrawadi
27	Nashik phata
28	Deichi company
29	Vallabhnagar
30	YCM
31	Mahesh nagar
32	PCMT
33	Nehrunagar corner
34	Zero boys
35	Master bakery
36	Wastu Udyog
37	Vitthalwadi Mandir Masulkar
38	Ajmer school
39	Masulkar Colony','42','06:10
08:05
10:15
12:55
15:05
17:15
20:05
06:40
08:55
11:35
13:45
15:50
18:05
20:55
23:00
07:35
09:40
12:20
14:30
16:35
18:50
21:40','07:05
09:10
11:20
14:00
16:10
18:25
21:15
07:50
10:00
12:40
14:50
16:55
19:15
22:00
00:00
08:35
10:45
13:25
15:35
17:40
20:00
22:45','Active');
INSERT INTO "busTable" VALUES(190,'326A','Pimpri gaon','Chikhali','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','44 Minutes','1	Pimprigaon
2	Ashok Talkies
3	Jaihind School
4	Delux
5	Karachi chauk
6	Lalmandir
7	Bhatnagar
8	Finolex
9	KSB chauk
10	Jadhavwadi phata
11	Moshi phata chikhali
12	Chikhali','1	Chikhali
2	Moshi phata Chikhli
3	Jadhav wadi phata
4	KSB Chowk
5	Finolex
6	Shagun chauk
7	Karachi chowk
8	Jaihind School
9	PMC School Pimpri
10	Pimprigaon','12','06:05
07:35
10:35
12:00
14:50
16:15
19:35
06:35
08:00
09:35
11:00
13:00
15:15
16:45
18:15
20:15
21:45','06:45
08:15
11:15
12:45
15:30
17:00
20:25
07:20
08:45
10:15
12:15
13:45
16:00
17:30
19:30
21:00
22:30','Active');
INSERT INTO "busTable" VALUES(191,'327','Hinjewadi phase2','Alandi bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','32 KMs','89 Minutes','1	Infosys Phase 2
2	Hinjewadi Gaon
3	Wakad Highway
4	Wakad Chowk
5	Dange chowk
6	Thergaon phata
7	Padmji Paper Mill
8	Dattanagar Chinchwad
9	Birla Hospital
10	Jakatnaka pavanapul
11	Walhekarwadi phata
12	Chafekar chauk
13	Elpro Company
14	Prekshagruha
15	Lokmanya Hospital
16	chinchwad station
17	Chinchwad chauk
18	Premier company
19	Finolex
20	Pimpri chauk Bus stand
21	Kharalwadi
22	H A Factory
23	Vallabhnagar
24	Deichi Company
25	Nashik phata
26	Bhosari police station
27	MIDC bhosari
28	Philips
29	Landewadi
30	Gavane Vasti
31	PCMT chauk
32	Maharashtra chauk
33	Hutatma chauk
34	Shatri chauk
35	Durwankur lawns
36	Dighi Corner Odha
37	Tata stores
38	Bhosari phata
39	Moje vidyalaya
40	Sai madnir
41	Nirma company
42	Gokhale Mala Sankalpa Garden
43	Wadmukhwadi
44	Chincheche jhad
45	Charholi phata
46	Sai Lila nagar Kate Wasti
47	Moshi Phata Dehu Phata
48	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Sai mandir
10	Moje vidyalaya
11	Bhosari phata
12	Tata Stores
13	Didhi corner odha
14	Durvankur Lawns
15	Shastri chowk
16	Hutatma chauk
17	Maharashtra Chowk
18	PCMT chauk
19	Gavane Vasti
20	Landewadi
21	Philips
22	MIDC Bhosari
23	Bhosari police station
24	Nashik phata
25	Deichi company
26	Vallabhnagar
27	HA Factory D Y Patil college
28	Kharalwadi
29	Pimpri chauk Bus stop
30	Finolex
31	Premier company
32	Chinchwad station
33	Lokmanya Hospital
34	Prekshagruha
35	Elpro Company
36	Chafekar chauk
37	Jai Hind Vidyalaya
38	Jakatnaka Pavanapool
39	Birla hospital
40	Dattanagar Chinchwad
41	Padmji Paper Mill
42	Thergaon phata
43	Dange chowk
44	Wakad Chowk
45	Wakad Highway
46	Hinjewadi Gaon
47	Hinjewadi Police Station
48	Infosys company
49	Wipro company Circle
50	Infosys Phase 2','48','08:45
12:15
18:05
21:40
08:00
11:30
14:30
17:20
20:55
06:20
09:30
13:00
16:00
19:30
07:15
10:15
16:35
20:15','07:15
10:15
13:45
20:15
23:00
06:30
09:30
13:00
16:00
19:30
22:15
08:00
11:30
14:30
17:30
21:00
08:45
12:15
18:20
21:35','Active');
INSERT INTO "busTable" VALUES(192,'328','Manapa','Rupinagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','75 Minutes','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Deichi company
25	Vallabhnagar
26	HA Factory D Y Patil college
27	Kharalwadi
28	Pimpri chauk Bus stop
29	Finolex
30	Premier company
31	Chinchwad station
32	Mehta hospital
33	Kalbhor nagar bus stop
34	Rustan company
35	Akurdi khandoba chauk
36	Bajaj auto
37	Pradhikaran Chowk
38	Nigadi jakat naka
39	Ambedkar vasahat
40	Ankush chauk
41	Rupinagar','1	Rupinagar
2	Ankush chauk
3	Ambedkar vasahat
4	Nigadi jakat naka
5	Nigadi
6	Pradhikaran Chowk
7	Bajaj auto
8	Akurdi Khandoba Chowk
9	Ruston Company
10	Kalbhor nahar bus stop
11	Mehta hospital
12	chinchwad station
13	Chinchwad chauk
14	Premier company
15	Finolex
16	Pimpri chauk Bus stand
17	Kharalwadi
18	H A Factory
19	Vallabhnagar
20	Deichi Company
21	Nashik phata
22	Kasarwadi
23	Forbes marshal stop
24	Alfa Laval Atlas Company
25	Sandwik
26	Fugewadi
27	Dapodi
28	Bopodi Jakat Naka
29	Bopodi
30	Khadaki
31	Khadaki railway station
32	Petrol Pump Khadki
33	Khadaki church stop
34	Khadaki post office
35	Raja bangalow
36	Krutrim Reshim Paidas Kendra
37	Poultry Farm Old Mumbai Pune Road
38	Mariaai Gate Old Mumbai Pune Road
39	Bajaj showroom
40	Labor office
41	Patil Estate
42	Engineering college hostel
43	Modern Highschool
44	PMC','41','07:25
09:50
12:45
15:35
18:00
20:55','06:15
08:35
11:30
14:25
16:45
19:40','Active');
INSERT INTO "busTable" VALUES(193,'328A','Rupinagar','Nigadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','3 KMs','20 Minutes','1	Rupinagar
2	Ankush chauk
3	Ambedkar vasahat
4	Nigadi jakat naka
5	Nigadi','1	Pradhikaran Chowk
2	Nigadi jakat naka
3	Ambedkar vasahat
4	Ankush chauk
5	Rupinagar','5','06:00
06:40
07:20
08:00
08:45
09:25
10:05
11:15
11:55
12:35
13:30
14:10
14:50
15:30
16:10
16:55
17:35
18:15
19:25
20:05','06:20
07:00
07:40
08:20
09:05
09:45
10:55
11:35
12:15
12:55
13:50
14:30
15:10
15:50
16:30
17:15
17:55
19:05
19:45
20:25','Active');
INSERT INTO "busTable" VALUES(194,'329','Dehugaon','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','32 KMs','84 Minutes','1	Dehugaon
2	Dehugaon Grampanchayat
3	Malwadi Dehu
4	Kudba Kruti Manmohan
5	Zhende mala
6	COD corner
7	Paduka Mandir
8	Chincholi
9	Ashoknagar Dehuroad
10	Dehu road railway station
11	Dehu phata highway
12	CISV
13	Garden City
14	Kendriya Vidyalaya
15	B Sub Depot
16	Kohima Line
17	Cantonment Jakat Naka
18	Nigadi jakat naka
19	Nigadi
20	Pradhikaran Chowk
21	Bajaj auto
22	Akurdi Khandoba Chowk
23	Ruston Company
24	Kalbhor nahar bus stop
25	Mehta hospital
26	chinchwad station
27	Chinchwad chauk
28	Premier company
29	Finolex
30	Pimpri chauk Bus stand
31	Kharalwadi
32	H A Factory
33	Vallabhnagar
34	Deichi Company
35	Nashik phata
36	Kasarwadi
37	Forbes marshal stop
38	Alfa Laval Atlas Company
39	Sandwik
40	Fugewadi
41	Dapodi
42	Bopodi Jakat Naka
43	Bopodi
44	Khadaki
45	Khadaki railway station
46	Petrol Pump Khadki
47	Khadaki church stop
48	Khadaki post office
49	Raja bangalow
50	Krutrim Reshim Paidas Kendra
51	Poultry Farm Old Mumbai Pune Road
52	Mariaai Gate Old Mumbai Pune Road
53	Bajaj showroom
54	Labor office
55	Patil Estate
56	College of engineering pune
57	RTO wellesley road
58	Raja Bahadur mill
59	Alankar Talkies
60	Pune Station Depot','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Pune station
6	Alankar Talkies
7	Raja bahadur mill
8	RTO wellesley road
9	College of engineering pune
10	Patil Estate
11	Labour office
12	Bajaj showroom wakadewadi
13	Mariaai Gate Old Mumbai Pune Road
14	Poultry Farm Old Mumbai Pune Road
15	Krutrim reshim paidas kendra
16	Raja Bungalow
17	Khadaki post office
18	Khadki church stop
19	Khadaki railway station
20	Khadaki
21	Bopodi
22	Dapodi
23	Fugewadi
24	Sandwik
25	Alfa laval atlas company
26	Forbes marshal stop
27	Kasrawadi
28	Nashik phata
29	Deichi company
30	Vallabhnagar
31	HA Factory D Y Patil college
32	Kharalwadi
33	Pimpri chauk Bus stop
34	Finolex
35	Premier company
36	Chinchwad station
37	Mehta hospital
38	Kalbhor nagar bus stop
39	Rustan company
40	Akurdi khandoba chauk
41	Bajaj auto
42	Pradhikaran Chowk
43	Nigadi jakat naka
44	Cantonment jakat naka
45	Kohima line
46	B sub depot
47	Kendriya vidyalaya
48	Garden city
49	CISV
50	Dehu phata highway
51	Dehuroad railway staion
52	Ashoknagar Dehuroad
53	Chincholi
54	Paduka mandir
55	COD Corner
56	Zhende mala
57	Kudba kruti Manmohan
58	Malwadi Dehu
59	Dehugaon grampanchayat
60	Dehugaon','60','06:00
09:00
12:30
15:30
19:00
06:30
09:30
13:00
16:00
19:30
07:00
10:00
13:30
16:30
20:00','07:30
11:00
14:00
17:00
20:30
08:00
11:30
14:30
17:30
21:00
08:30
12:00
15:00
18:00','Active');
INSERT INTO "busTable" VALUES(195,'33','Padmavati','Narveer Tanaji Wadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','48 Minutes','1	Padmavati Bus stand
2	Power house Padmavati
3	Date Bus stop
4	Nandadeep
5	Gandhi Training Corner
6	Sarang Society
7	Lakshminagar Corner
8	Parvati darshan vasahat
9	Mitramandal Sabhagruh
10	Laxmi Narayan Theature
11	Swargate
12	Sarasbag
13	Bhikardas maruti madnir
14	Shanipar
15	A B Chowk
16	Dakshinabhimukh Maruti mandir
17	Shaniwar wada
18	PMC mangala
19	Shivaji putala pmc
20	shimala office shivajinagar
21	Shivaji nagar ST Stand
22	N T wadi','1	N T wadi
2	Shivaji nagar S T stand
3	Sancheti Hospital
4	Shivaji putala
5	PMC Mangala
6	Kasaba Police Chowky
7	Vasant talkies
8	Mandai
9	Shahu chauk
10	Gokul bhavan
11	Swargate
12	Mitramandal Sabhagruh
13	Parvati darshan vasahat
14	Lakshminagar Corner
15	Sarang Society
16	Gandhi Training Corner
17	Nandadeep
18	Date Bus stop
19	Power house Padmavati
20	Padmavati Bus stand','22','06:30
08:00
09:25
11:45
13:30
15:30
17:00
19:30
07:00
08:20
10:00
12:15
14:00
16:00
17:30
20:15
08:15
09:45
11:05
16:45
18:15
07:30
09:00
10:25
12:45
15:00
16:30
18:00
21:00','07:20
08:50
10:20
12:30
14:20
16:20
17:50
20:20
07:40
09:20
10:50
13:00
14:50
16:50
18:20
21:05
09:00
10:15
11:40
17:30
19:05
08:10
09:50
11:20
13:30
15:50
17:10
18:50
21:50','Active');
INSERT INTO "busTable" VALUES(196,'331','Rahatani gaon','Charholi Gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','22 KMs','72 Minutes','1	Rahatani gaon
2	Ramnagar rahatani
3	akate wasti
4	Saurabh company tambe company
5	Rahatani phata
6	Shrinagar
7	Dhangar Nagar Kalewadi
8	Tapgir nagar
9	M M shala
10	Avinash Mangal Karyalaya
11	Dhangar nagar kalewadi
12	Vijaynagar
13	Ingale hospital
14	Krushnamandir Corner
15	Delux
16	Karachi chauk
17	Lalmandir
18	Bhatnagar
19	Finolex
20	Pimpri chauk Bus stop
21	Nehrunagar corner
22	Nehrunagar
23	Jyoti school
24	Vishal nagar C ward office
25	Abhi Chemicals
26	Jayanand khira
27	Idrayani nagar corner
28	Tulashi chemikals
29	Philips
30	Landewadi
31	Gavane Vasti
32	PCMT chauk
33	Maharashtra chauk
34	Hutatma chauk
35	Shatri chauk
36	Durwankur lawns
37	Dighi Corner Odha
38	Tata stores
39	Bhosari phata
40	Moje vidyalaya
41	Sai madnir
42	Nirma company
43	Gokhale Mala Sankalpa Garden
44	Wadmukhwadi
45	Chincheche jhad
46	Charholi phata
47	Azadnagar Charholi
48	Tapkir Bungalow
49	Dabhade Wasti Charholi
50	Charholi Gaon','1	Charholi Gaon
2	Dabhade Wasti Charholi
3	Tapkir Bungalow
4	Azadnagar Charholi
5	Charholi phata
6	Chincheche jhad
7	Wadmukhwadi
8	Gokhale mala sankalp garden
9	Nirma company
10	Sai mandir
11	Moje vidyalaya
12	Bhosari phata
13	Tata Stores
14	Didhi corner odha
15	Durvankur Lawns
16	Shastri chowk
17	Hutatma chauk
18	Maharashtra Chowk
19	PCMT chauk
20	Gavane Vasti
21	Landewadi
22	Philips
23	Tulsi Chemical
24	Indrayani nagar Corner Jayanand Road
25	Jayanand Khira
26	Abhi chemicals
27	Vishalnagar C Ward office
28	Jyoti School
29	Nehrunagar
30	Nehrunagar corner
31	Pimpri Manapa
32	Pimpri chauk Bus stand
33	Shagun chauk
34	Karachi chowk
35	Delux
36	Krushnamandir corner
37	Ingale Hospital
38	Vijaynagar
39	Dhangar Nagar Kalewadi
40	Avinash mangal karyalay
41	M M Shala
42	Tapkir Nagar
43	Dhangar Nagar Kalewadi
44	Shrinagar
45	Rahatani Phata
46	Saurabh company Tambe Shala
47	Nakate wasti
48	Ramnagar rahatni
49	Rahatani gaon','50','06:15
08:35
11:30
14:00
16:20
19:10
07:25
09:45
12:35
15:10
17:30','07:25
10:15
12:45
15:10
17:30
20:25
08:35
11:25
14:00
16:20
19:10','Active');
INSERT INTO "busTable" VALUES(197,'331A','Bhosari','Rahatani gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','46 Minutes','1	PCMT chauk
2	Gavane Vasti
3	Philips
4	Tulsi Chemical
5	Indrayani nagar Corner Jayanand Road
6	Jayanand Khira
7	Abhi chemicals
8	Vishalnagar C Ward office
9	Jyoti School
10	Nehrunagar
11	Nehrunagar corner
12	Pimpri Manapa
13	Pimpri chauk Bus stand
14	Shagun chauk
15	Karachi chowk
16	Delux
17	Krushnamandir corner
18	Ingale Hospital
19	Vijaynagar
20	Dhangar Nagar Kalewadi
21	Avinash mangal karyalay
22	M M Shala
23	Tapkir Nagar
24	Dhangar Nagar Kalewadi
25	Shrinagar
26	Rahatani Phata
27	Saurabh company Tambe Shala
28	Nakate wasti
29	Ramnagar rahatni
30	Rahatani gaon','1	Rahatani gaon
2	Ramnagar rahatani
3	akate wasti
4	Saurabh company tambe company
5	Rahatani phata
6	Shrinagar
7	Dhangar Nagar Kalewadi
8	Tapgir nagar
9	M M shala
10	Avinash Mangal Karyalaya
11	Dhangar nagar kalewadi
12	Vijaynagar
13	Ingale hospital
14	Krushnamandir Corner
15	Delux
16	Karachi chauk
17	Lalmandir
18	Bhatnagar
19	Finolex
20	Pimpri chauk Bus stop
21	Nehrunagar corner
22	Nehrunagar
23	Jyoti school
24	Vishal nagar C ward office
25	Abhi Chemicals
26	Jayanand khira
27	Idrayani nagar corner
28	Tulashi chemikals
29	Philips
30	Gavane Vasti
31	PCMT chauk','30','05:40
07:15
08:50
10:55
12:35
14:10
15:45
17:20
19:00
21:15
06:00
07:25
09:00
11:10
12:50
14:20
15:55
17:30
19:20
21:30
06:15
07:40
09:10
11:25
13:00
14:40
16:10
17:50
19:30
21:40
06:30
08:00
09:30
11:40
13:20
14:55
16:30
18:00
19:45
22:00
06:40
08:10
09:45
12:00
13:35
15:10
16:40
18:15
20:05
22:10
06:50
08:25
10:30
12:10
13:45
15:20
16:50
18:30
20:50
22:25
07:00
08:35
10:10
12:20
14:00
15:30
17:05
18:50
20:30
22:45','06:25
08:00
09:35
11:45
13:20
14:55
16:30
18:10
19:50
21:55
06:40
08:15
09:50
12:00
13:35
15:05
16:45
18:25
20:05
22:10
06:55
08:30
10:05
12:15
13:50
15:25
17:00
18:40
20:20
22:25
07:10
08:45
10:20
12:30
14:05
15:40
17:15
18:55
20:35
22:40
07:20
09:00
10:35
12:40
14:20
15:55
17:25
19:05
20:50
22:55
07:35
09:10
11:20
12:55
14:30
16:05
17:40
19:20
21:35
23:10
07:45
09:20
10:55
13:05
14:40
16:15
17:55
19:35
21:15
23:25','Active');
INSERT INTO "busTable" VALUES(198,'332B','Pimpri manpa','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','24 KMs','74 Minutes','1	Pimpri Manapa
2	Pimpri chauk Bus stand
3	Shagun chauk
4	Karachi chowk
5	Delux
6	Krushnamandir corner
7	Ingale Hospital
8	Vijaynagar
9	Dhangar Nagar Kalewadi
10	Avinash mangal karyalay
11	M M Shala
12	Tapkir Nagar
13	Dhangar Nagar Kalewadi
14	Shrinagar
15	Rahatani Phata
16	Saurabh company Tambe Shala
17	Nakate wasti
18	Ramnagar rahatni
19	Rahatani gaon
20	Sindhu Park
21	Shivar Chowk
22	Jagtap Dairy
23	Wakad phata
24	Military Stores
25	Rakshak chauk
26	ESI Hospital
27	Aundh post office
28	Aundh chest hospital
29	Sangvi Phata
30	Aundh gaon
31	Body gate
32	Bremen chauk
33	Sindh Colony Gate2
34	Kasturba vasahat
35	Boys Batalian
36	Pune University Gate
37	Rangehills Corner
38	E Square
39	Pune central
40	Pumping station
41	Masoba gate
42	shimala office shivajinagar
43	Lokmangal
44	College of engineering pune
45	RTO wellesley road
46	Juna Bajar
47	Ambedkar bhavan
48	Sasoon hospital
49	Pune station
50	Alankar Talkies
51	Pune Station Depot','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Central building
5	Pune station
6	Ambedkar bhavan
7	Juna Bajar
8	RTO wellesley road
9	College of engineering pune
10	Engineering college hostel
11	shimala office shivajinagar
12	Masoba gate
13	Pumping station
14	Pune central
15	E square
16	Rangehills Corner
17	Rajbhavan
18	Boys batalian
19	Kasturba vasahat
20	Sindh colony gate 2
21	Bremen chauk
22	Body gate
23	Aundh gaon
24	Sangvi phata
25	Aundh chest hospital
26	Aundh post office
27	ESI Hospital
28	Rakshak chauk
29	Military Stores
30	Wakad phata
31	Jagtap Dairy
32	Shivar Chowk
33	Sindhu Park
34	Rahatani gaon
35	Ramnagar rahatani
36	akate wasti
37	Saurabh company tambe company
38	Rahatani phata
39	Shrinagar
40	Dhangar Nagar Kalewadi
41	Tapgir nagar
42	M M shala
43	Avinash Mangal Karyalaya
44	Dhangar nagar kalewadi
45	Vijaynagar
46	Ingale hospital
47	Krushnamandir Corner
48	Delux
49	Karachi chauk
50	Lalmandir
51	Bhatnagar
52	Finolex
53	Pimpri chauk Bus stand
54	Pimpri Manapa','30','05:45
08:15
11:20
14:20
16:55
20:10
06:35
09:05
12:10
15:15
18:50
21:05
07:25
10:20
13:00
16:05
18:45
22:00','07:00
09:30
12:40
15:35
18:15
21:30
07:50
10:20
13:30
16:30
19:10
22:25
08:40
11:40
14:20
17:20
20:05
23:20','Active');
INSERT INTO "busTable" VALUES(199,'333','Pune Station','Hinjewadi Phase3','Mon, Tue, Wed, Thu, Fri, Sat, Sun','28 KMs','74 Minutes','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Ambedkar bhavan
6	Juna Bajar
7	Kumbhar wada
8	PMC
9	Shivaji putala pmc
10	shimala office shivajinagar
11	Masoba gate
12	Pumping station
13	Pune central
14	E square
15	Rangehills Corner
16	Rajbhavan
17	Boys batalian
18	Kasturba vasahat
19	Sindh colony gate 2
20	Bremen chauk
21	Body gate
22	Aundh gaon
23	Sangvi phata
24	Aundh chest hospital
25	Aundh post office
26	ESI Hospital
27	Rakshak chauk
28	Military Stores
29	Wakad phata
30	Vikasnagar Corner
31	Maruti Mandir Wakad
32	Kaspate Vasti
33	Wakad Chowk
34	Wakad Highway
35	Hinjewadi Gaon
36	Infosys Phase 2
37	Power House IT Park
38	Tata Motors IT Park
39	Circle IT Park
40	Infosys Phase 3 Gawarwadi','1	Infosys Phase 3 Gawarwadi
2	Circle IT Park
3	Tata Motors IT Park
4	Power House IT Park
5	Infosys Phase 2
6	Hinjewadi Gaon
7	Wakad Highway
8	Wakad Chowk
9	Kaspate Vasti
10	Maruti Mandir Wakad
11	Vikasnagar Corner
12	Wakad phata
13	Military Stores
14	Rakshak chauk
15	ESI Hospital
16	Aundh post office
17	Aundh chest hospital
18	Sangvi Phata
19	Aundh gaon
20	Body gate
21	Bremen chauk
22	Sindh Colony Gate2
23	Kasturba vasahat
24	Boys Batalian
25	Pune University Gate
26	Rangehills Corner
27	E Square
28	Pune central
29	Pumping station
30	Masoba gate
31	shimala office shivajinagar
32	Engineering college hostel
33	Shivaji putala
34	PMC Mangala
35	Kumbhar Wada
36	Juna Bajar
37	Ambedkar bhavan
38	Sasoon hospital
39	Pune station
40	Pune Station Depot','40','05:30
07:30
10:05
13:30
16:00
18:30
06:05
08:10
10:40
14:05
16:35
19:05
06:35
08:55
11:25
14:45
17:15
20:15
07:10
09:35
12:05
15:25
17:55
20:55','06:25
08:50
11:50
14:45
17:15
20:15
07:05
09:25
12:25
15:20
17:50
20:50
07:40
10:10
13:10
16:05
18:30
21:30
08:20
10:55
13:50
16:40
19:10
22:10','Active');
INSERT INTO "busTable" VALUES(200,'335','Jambhe','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','25 KMs','73 Minutes','1	Jambhe
2	Jambhe Prathamik Shala
3	Nerhe Phata
4	Tajane Vasti
5	Punavale Corner
6	Punavale
7	Kudale Farm
8	Tathwade
9	Dairy Farm
10	Dange chowk
11	Laxman nagar
12	16 Number
13	Kalewadi phata
14	Kaspate Vasti
15	Jagtap Dairy
16	Wakad phata
17	Military Stores
18	Rakshak chauk
19	ESI Hospital
20	Aundh post office
21	Aundh chest hospital
22	Sangvi Phata
23	Aundh gaon
24	Body gate
25	Bremen chauk
26	Sindh Colony Gate2
27	Kasturba vasahat
28	Boys Batalian
29	Pune University Gate
30	Rangehills Corner
31	E Square
32	Pune central
33	Pumping station
34	Masoba gate
35	shimala office shivajinagar
36	Lokmangal
37	College of engineering pune
38	RTO wellesley road
39	Juna Bajar
40	Ambedkar bhavan
41	Sasoon hospital
42	Pune station
43	Alankar Talkies
44	Pune Station Depot','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Pune station
6	Ambedkar bhavan
7	Juna Bajar
8	RTO wellesley road
9	College of engineering pune
10	shimala office shivajinagar
11	Masoba gate
12	Pumping station
13	Pune central
14	E square
15	Rangehills Corner
16	Rajbhavan
17	Boys batalian
18	Kasturba vasahat
19	Sindh colony gate 2
20	Bremen chauk
21	Body gate
22	Aundh gaon
23	Sangvi phata
24	Aundh chest hospital
25	Aundh post office
26	ESI Hospital
27	Rakshak chauk
28	Military Stores
29	Wakad phata
30	Jagtap Dairy
31	Kaspate Vasti
32	Kalewadi phata
33	16 Number
34	Laxman nagar
35	Dange chowk
36	Dairy farm
37	Tathwade
38	Kudale farm
39	Punavale
40	Punawale corner
41	Tajane Vasti
42	Nerhe Phata
43	Jambhe Prathamik Shala
44	Jambhe','44','06:20
08:40
11:30
15:30
17:50
20:40
07:55
10:15
13:35
16:10
09:25
12:15
14:35
17:00','07:30
09:50
12:40
16:40
19:00
21:50
09:05
11:25
14:50
17:20
11:05
13:25
15:45
18:10','Active');
INSERT INTO "busTable" VALUES(201,'337','Pune Station','Pimple Saudagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18 KMs','60 Minutes','1	Pune Station Depot
2	GPO
3	Collector kacheri
4	Ambedkar bhavan
5	Juna Bajar
6	RTO wellesley road
7	College of engineering pune
8	Engineering college hostel
9	shimala office shivajinagar
10	Masoba gate
11	Pumping station
12	Pune central
13	E square
14	Rangehills Corner
15	Rajbhavan
16	Boys batalian
17	Kasturba vasahat
18	Sindh colony gate 2
19	Bremen chauk
20	Body gate
21	Aundh gaon
22	Sangvi phata
23	Aundh chest hospital
24	Aundh post office
25	ESI Hospital
26	Rakshak chauk
27	Kate Wasti
28	Pimpale Saudagar Chowk
29	Shivshakti mandir
30	Pimpale Saudagar','1	Pimpale Saudagar
2	Shivshakti Mandir
3	Pimple saudagar chauk
4	Kate Wasti
5	Rakshak chauk
6	ESI Hospital
7	Aundh post office
8	Aundh chest hospital
9	Sangvi Phata
10	Aundh gaon
11	Body gate
12	Bremen chauk
13	Sindh Colony Gate2
14	Kasturba vasahat
15	Boys Batalian
16	Pune University Gate
17	Rangehills Corner
18	E Square
19	Pune central
20	Pumping station
21	Masoba gate
22	shimala office shivajinagar
23	College of engineering pune
24	RTO wellesley road
25	Juna Bajar
26	Ambedkar bhavan
27	Sasoon hospital
28	Pune station
29	Pune Station Depot','30','05:15
07:15
09:15
11:45
14:00
16:00
18:00
20:30
06:10
08:10
10:40
12:45
15:00
17:00
19:30
21:25','06:15
08:15
10:45
12:45
15:00
17:00
19:30
21:30
07:10
09:10
11:40
13:45
16:00
18:00
20:30
22:30','Active');
INSERT INTO "busTable" VALUES(202,'339A','Indrayani nagar','Manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','72 Minutes','1	Idrayani nagar bhosari
2	Samartha Vidyalaya Indrayani Nagar
3	Sadgurunagar
4	Dhavde Vasti
5	Atlas Company
6	Century Company
7	Electronic Sadan
8	Landewadi
9	Philips
10	MIDC Bhosari
11	Bhosari police station
12	Bhosari Police Station
13	Nashik phata
14	Kasarwadi
15	Forbes marshal stop
16	Alfa Laval Atlas Company
17	Sandwik
18	Fugewadi
19	Dapodi
20	Bopodi Jakat Naka
21	Bopodi
22	Khadaki
23	Khadaki railway station
24	Petrol Pump Khadki
25	Khadaki church stop
26	Khadaki post office
27	Raja bangalow
28	Krutrim Reshim Paidas Kendra
29	Poultry Farm Old Mumbai Pune Road
30	Mariaai Gate Old Mumbai Pune Road
31	Bajaj showroom
32	Labor office
33	Patil Estate
34	Engineering college hostel
35	Modern Highschool
36	PMC','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Bhosari Police Station
25	Bhosari police station
26	MIDC bhosari
27	Philips
28	Landewadi
29	Electronic sadan
30	Century company
31	Atlas company
32	Dhavade wasti
33	Sadgurunagar
34	Samartha Vidyalaya Indrayani Nagar
35	Indrayani Nagar Bhosari','36','06:00
08:10
11:00
14:00
16:10
19:00','07:00
09:50
12:10
15:00
17:20
20:10','Active');
INSERT INTO "busTable" VALUES(203,'339B','Indrayani nagar','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','60 Minutes','1	Idrayani nagar bhosari
2	Samartha Vidyalaya Indrayani Nagar
3	Sadgurunagar PCMT depot
4	Bhosari gaon
5	Century Enka Colony
6	Landewadi
7	Philips
8	MIDC Bhosari
9	Bhosari police station
10	Nashik phata
11	Kasarwadi
12	Forbes marshal stop
13	Alfa Laval Atlas Company
14	Sandwik
15	Fugewadi
16	Dapodi
17	Bopodi Jakat Naka
18	Bopodi
19	Khadaki
20	Khadaki railway station
21	Petrol Pump Khadki
22	Khadaki church stop
23	Khadaki post office
24	Raja bangalow
25	Krutrim Reshim Paidas Kendra
26	Poultry Farm Old Mumbai Pune Road
27	Mariaai Gate Old Mumbai Pune Road
28	Bajaj showroom
29	Labor office
30	Patil Estate
31	College of engineering pune
32	RTO wellesley road
33	Juna Bajar
34	Ambedkar bhavan
35	Sasoon hospital
36	Pune station','1	Pune station
2	Ambedkar bhavan
3	Juna Bajar
4	RTO wellesley road
5	College of engineering pune
6	Patil Estate
7	Labour office
8	Bajaj showroom wakadewadi
9	Mariaai Gate Old Mumbai Pune Road
10	Poultry Farm Old Mumbai Pune Road
11	Krutrim reshim paidas kendra
12	Raja Bungalow
13	Khadaki post office
14	Khadki church stop
15	Khadaki railway station
16	Khadaki
17	Bopodi
18	Dapodi
19	Fugewadi
20	Sandwik
21	Alfa laval atlas company
22	Forbes marshal stop
23	Kasrawadi
24	Nashik phata
25	Bhosari police station
26	MIDC bhosari
27	Philips
28	Landewadi
29	Century Enka Colony
30	Bhosari gaon
31	Sadgurunagar PCMT depot
32	Samartha Vidyalaya Indrayani Nagar
33	Indrayani Nagar Bhosari','36','07:00
09:00
11:30
15:00
17:00
19:30','08:00
10:00
12:30
16:00
18:00
20:30','Active');
INSERT INTO "busTable" VALUES(204,'339C','Indrayani nagar','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','63 Minutes','1	Idrayani nagar bhosari
2	Samartha Vidyalaya Indrayani Nagar
3	Sadgurunagar
4	Dhavade wasti
5	Atlas Company
6	Century Company
7	Electronic Sadan
8	Landewadi
9	Philips
10	MIDC Bhosari
11	Bhosari police station
12	Nashik phata
13	Kasarwadi
14	Forbes marshal stop
15	Alfa Laval Atlas Company
16	Sandwik
17	Fugewadi
18	Dapodi
19	Bopodi Jakat Naka
20	Bopodi
21	Khadaki
22	Khadaki railway station
23	Petrol Pump Khadki
24	Khadaki church stop
25	Khadaki post office
26	Raja bangalow
27	Krutrim Reshim Paidas Kendra
28	Poultry Farm Old Mumbai Pune Road
29	Mariaai Gate Old Mumbai Pune Road
30	Bajaj showroom
31	Labor office
32	Patil Estate
33	Engineering college hostel
34	Modern Highschool
35	PMC','1	PMC
2	Shivaji putala pmc
3	shimala office shivajinagar
4	Lokmangal
5	Patil Estate
6	Labour office
7	Bajaj showroom wakadewadi
8	Mariaai Gate Old Mumbai Pune Road
9	Poultry Farm Old Mumbai Pune Road
10	Krutrim reshim paidas kendra
11	Raja Bungalow
12	Khadaki post office
13	Khadki church stop
14	Khadaki railway station
15	Khadaki
16	Bopodi
17	Dapodi
18	Fugewadi
19	Sandwik
20	Alfa laval atlas company
21	Forbes marshal stop
22	Kasrawadi
23	Nashik phata
24	Bhosari police station
25	MIDC bhosari
26	Philips
27	Landewadi
28	Electronic sadan
29	Century company
30	Atlas company
31	Dhavde Vasti
32	Sadgurunagar
33	Samartha Vidyalaya Indrayani Nagar
34	Indrayani Nagar Bhosari','35','06:30
08:30
10:30
13:00
15:30
17:50','07:30
09:30
12:00
14:00
16:40
19:00','Active');
INSERT INTO "busTable" VALUES(205,'34','Katraj bus stand','Pune Vidyapeeth','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','69 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati Bus stand
9	Power house Padmavati
10	Date Bus stop
11	Nandadeep
12	Gandhi Training Corner
13	Sarang Society
14	Lakshminagar Corner
15	Parvati darshan vasahat
16	Mitramandal Sabhagruh
17	Sarasbag
18	Bhikardas maruti madnir
19	Shanipar
20	A B Chowk
21	Dakshinabhimukh Maruti mandir
22	Shaniwar wada
23	PMC mangala
24	Shivaji putala pmc
25	shimala office shivajinagar
26	Masoba gate
27	Pumping station
28	Pune central
29	E square
30	Rangehills Corner
31	Pune University Gate
32	Gents hostel university
33	Vidyapeeth Press
34	Ladies Hostel Pune University
35	Pune University Main Building','1	Pune University Main Building
2	Ladies Hostel Pune University
3	Vidyapeeth Press
4	Gents hostel university
5	Pune University Gate
6	Rangehills Corner
7	E Square
8	Pune central
9	Pumping station
10	Masoba gate
11	shimala office shivajinagar
12	Sancheti Hospital
13	Shivaji putala
14	PMC Mangala
15	Kasaba Police Chowky
16	Vasant talkies
17	Mandai
18	Shahu chauk
19	Gokul bhavan
20	Swargate
21	Mitramandal Sabhagruh
22	Parvati darshan vasahat
23	Lakshminagar Corner
24	Sarang Society
25	Gandhi Training Corner
26	Nandadeep
27	Date Bus stop
28	Power house Padmavati
29	Padmavati Bus stand
30	Vishweshwar Bank KK market
31	Balaji nagar
32	Chaitanya nagar
33	Bharti vidyapeeth gate
34	Katraj dairy Sarpodyan
35	More bag
36	Katraj bus stand','35','06:30
09:20
11:20
13:50
16:45
19:15','07:40
10:20
12:30
15:00
18:00
20:25','Active');
INSERT INTO "busTable" VALUES(206,'341','Mohan nagar','Manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','24 KMs','66 Minutes','1	Mohan Nagar
2	MIDC Chinchwad
3	Chinchwad station
4	Lokmanya Hospital
5	Prekshagruha
6	Elpro Company
7	Chafekar chauk
8	Walhekarwadi phata
9	Jakatnaka pavanapul
10	Birla hospital
11	Dattanagar Chinchwad
12	Padmji Paper Mill
13	Thergaon phata
14	Dange chowk
15	Laxman nagar
16	16 Number
17	Kalewadi phata
18	Kaspate Vasti
19	Jagtap Dairy
20	Wakad phata
21	Military Stores
22	Rakshak chauk
23	ESI Hospital
24	Aundh post office
25	Aundh chest hospital
26	Sangvi Phata
27	Aundh gaon
28	Body gate
29	Bremen chauk
30	Sindh Colony Gate2
31	Kasturba vasahat
32	Boys Batalian
33	Pune University Gate
34	Rangehills Corner
35	E Square
36	Pune central
37	Pumping station
38	Masoba gate
39	shimala office shivajinagar
40	Engineering college hostel
41	Modern Highschool
42	PMC','1	PMC
2	PMC mangala
3	Shivaji putala pmc
4	shimala office shivajinagar
5	Masoba gate
6	Pumping station
7	Pune central
8	E square
9	Rangehills Corner
10	Rajbhavan
11	Boys batalian
12	Kasturba vasahat
13	Sindh colony gate 2
14	Bremen chauk
15	Body gate
16	Aundh gaon
17	Sangvi phata
18	Aundh chest hospital
19	Aundh post office
20	ESI Hospital
21	Rakshak chauk
22	Military Stores
23	Wakad phata
24	Jagtap Dairy
25	Kaspate Vasti
26	Kalewadi phata
27	16 Number
28	Laxman nagar
29	Dange chowk
30	Thergaon phata
31	Padmji Paper Mill
32	Dattanagar Chinchwad
33	Birla Hospital
34	Jakatnaka pavanapul
35	Walhekarwadi phata
36	Chafekar chauk
37	Elpro Company
38	Prekshagruha
39	Lokmanya Hospital
40	Chinchwad station
41	MIDC Chinchwad
42	Mohan Nagar','42','06:30
08:30
10:30
13:05
15:35
17:45
20:15','07:30
09:30
12:00
14:30
16:40
19:15
21:30','Active');
INSERT INTO "busTable" VALUES(207,'344','Pimple Nilakh','Alandi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','26 KMs','81 Minutes','1	Pimple Nilakh
2	Pimple Nilakh Shala
3	Rakshak Soc. Ganpati mandir
4	Rakshak chauk
5	Military Stores
6	Wakad phata
7	Vikasnagar Corner
8	Maruti Mandir Wakad
9	Kaspate Vasti
10	Kalewadi phata
11	Rahatani phata
12	Shrinagar
13	Dhangar Nagar Kalewadi
14	Tapgir nagar
15	M M shala
16	Avinash Mangal Karyalaya
17	Dhangar nagar kalewadi
18	Vijaynagar
19	Ingale hospital
20	Krushnamandir Corner
21	Delux
22	Karachi chauk
23	Lalmandir
24	Bhatnagar
25	Finolex
26	Pimpri chauk Bus stand
27	Nehrunagar corner
28	PCMT
29	Mahesh nagar
30	YCM
31	Phulenagar Bhosari
32	Bhosari police station
33	MIDC bhosari
34	Philips
35	Landewadi
36	Gavane Vasti
37	PCMT chauk
38	Maharashtra chauk
39	Hutatma chauk
40	Shatri chauk
41	Durwankur lawns
42	Dighi Corner Odha
43	Tata stores
44	Bhosari phata
45	Moje vidyalaya
46	Sai madnir
47	Nirma company
48	Gokhale Mala Sankalpa Garden
49	Wadmukhwadi
50	Chincheche jhad
51	Charholi phata
52	Sai Lila nagar Kate Wasti
53	Moshi Phata Dehu Phata
54	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Sai mandir
10	Moje vidyalaya
11	Bhosari phata
12	Tata Stores
13	Didhi corner odha
14	Durvankur Lawns
15	Shastri chowk
16	Hutatma chauk
17	Maharashtra Chowk
18	PCMT chauk
19	Gavane Vasti
20	Landewadi
21	Philips
22	MIDC Bhosari
23	Bhosari police station
24	Phulenagar bhosari
25	YCM
26	Mahesh nagar
27	PCMT
28	Nehrunagar corner
29	Pimpri chauk Bus stop
30	Shagun chauk
31	Karachi chowk
32	Delux
33	Krushnamandir corner
34	Ingale Hospital
35	Vijaynagar
36	Dhangar Nagar Kalewadi
37	Avinash mangal karyalay
38	M M Shala
39	Tapkir Nagar
40	Dhangar Nagar Kalewadi
41	Shrinagar
42	Rahatani phata
43	Kalewadi phata
44	Kaspate Vasti
45	Maruti Mandir Wakad
46	Vikasnagar Corner
47	Wakad phata
48	Military Stores
49	Rakshak chauk
50	Rakshak Soc.
51	Pimple Nilakh Shala
52	Pimple Nilakh','54','07:45
11:05
16:55
20:15
09:50
12:30
15:50
18:40','09:10
12:30
18:20
21:40
11:05
14:25
17:15
19:40','Active');
INSERT INTO "busTable" VALUES(208,'346','Hadapsar','Bhosari','Mon, Tue, Wed, Thu, Fri, Sat, Sun','28 KMs','94 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri
17	Pune station
18	Ruby hall
19	Guruprasad bangala
20	Band garden
21	Yerwada
22	Shadal baba Darga
23	Deccan college
24	Holkar Water Supply
25	Mathyadist Church
26	Amunition factory road
27	Suply depot
28	Khadaki bajar
29	Alegaonkar High school
30	Kirloskar Oil Engine Manaji Bag
31	Gangaram park
32	Bopodi
33	Dapodi
34	Fugewadi
35	Sandwik
36	Alfa laval atlas company
37	Forbes marshal stop
38	Kasrawadi
39	Nashik phata
40	Bhosari police station
41	MIDC bhosari
42	Philips
43	Landewadi
44	Century Enka Colony
45	Bhosari gaon','1	Bhosari gaon
2	Century Enka Colony
3	Landewadi
4	Philips
5	MIDC Bhosari
6	Bhosari police station
7	Nashik phata
8	Kasarwadi
9	Forbes marshal stop
10	Alfa Laval Atlas Company
11	Sandwik
12	Fugewadi
13	Dapodi
14	Bopodi
15	Gangaram park
16	Kirloskar oil engine manaji bag
17	Alegaonkar High school
18	Khadki Bazar
19	Supply Depot
20	Amunition Factory Road
21	Mathyadist Church
22	Holkar Water Supply
23	Deccan college
24	Shadal baba Darga
25	Yerwada
26	Band garden
27	Guruprasad bangala
28	Wadia college
29	Jahangir Hospital
30	Alankar Talkies
31	Sadhu wasvani chauk
32	General post office
33	West end talkies
34	Bombay garaje
35	juna pul gate
36	Mahatma gandhi stand
37	Race course
38	Bhauraba nala
39	Fatimanagar Municipal shala
40	Kalubai mandir
41	Ram tekadi
42	Vaidwadi
43	Gurushankar math
44	Magarpatta
45	Hadapsar gaon
46	Hadapsar gadital','45','06:20
09:00
12:20
15:15
18:45
07:00
09:45
13:00
16:15
19:45
07:40
10:30
13:50
17:05
20:30
08:20
11:10
14:30
17:55
21:55','07:40
10:20
13:50
17:00
21:00
08:20
11:10
14:30
18:00
22:00
09:00
12:30
15:20
18:50
22:50
09:45
13:10
16:00
19:40
23:35','Active');
INSERT INTO "busTable" VALUES(209,'346A','Bhosari','Hadapsar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','28 KMs','92 Minutes','1	Bhosari gaon
2	Century Enka Colony
3	Landewadi
4	Philips
5	MIDC Bhosari
6	Bhosari police station
7	Bhosari Police Station
8	Nashik phata
9	Kasarwadi
10	Forbes marshal stop
11	Alfa Laval Atlas Company
12	Sandwik
13	Fugewadi
14	Dapodi
15	Bopodi Jakat Naka
16	Bopodi
17	Gangaram park
18	Kirloskar oil engine manaji bag
19	Alegaonkar High school
20	Khadki Bazar
21	Supply Depot
22	Amunition Factory Road
23	Mathyadist Church
24	Holkar Water Supply
25	Sapras post
26	Deccan college
27	Shadal baba Darga
28	Yerwada
29	Band garden
30	Guruprasad bangala
31	Jahangir Hospital
32	Alankar Talkies
33	Sadhu wasvani chauk
34	General post office
35	West end talkies
36	Bombay garaje
37	juna pul gate
38	Mahatma gandhi stand
39	Race course
40	Bhauraba nala
41	Fatimanagar Municipal shala
42	Kalubai mandir
43	Ram tekadi
44	Vaidwadi
45	Gurushankar math
46	Magarpatta
47	Hadapsar gaon
48	Hadapsar gadital','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri
17	Sasoon hospital
18	Alankar Talkies
19	Ruby hall
20	Wadia college
21	Guruprasad bangala
22	Band garden
23	Yerwada
24	Shadal baba Darga
25	Deccan college
26	Sapras post
27	Holkar Water Supply
28	Mathyadist Church
29	Amunition factory road
30	Suply depot
31	Khadaki bajar
32	Alegaonkar High school
33	Kirloskar Oil Engine Manaji Bag
34	Gangaram park
35	Bopodi
36	Dapodi
37	Fugewadi
38	Sandwik
39	Alfa laval atlas company
40	Forbes marshal stop
41	Kasrawadi
42	Nashik phata
43	Bhosari Police Station
44	Bhosari police station
45	MIDC bhosari
46	Philips
47	Landewadi
48	Century Enka Colony
49	Bhosari gaon','48','06:00
08:40
12:10
15:00
18:30
06:40
09:20
12:50
15:45
19:15
07:20
10:00
13:30
16:40
20:10
08:00
10:40
14:10
18:30
22:00','07:20
10:10
13:30
16:45
20:45
08:00
10:50
14:10
17:30
21:30
08:40
11:30
14:50
18:25
22:25
09:20
12:05
15:30
20:15
00:15','Active');
INSERT INTO "busTable" VALUES(210,'347','Dapodi Gaon','Alandi bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','32 KMs','82 Minutes','1	Dapodi Gaon
2	Mantri Niketan Dapodi
3	S T Workshop
4	P W D Gate
5	Vasantdada Putala
6	Sangvi goan
7	Anand nagar
8	shitole nagar corner
9	panyachi takai sangvi
10	Navi Sangvi
11	Bara gholap
12	Nurses Quarters
13	Sangvi Phata
14	Aundh chest hospital
15	Aundh post office
16	ESI Hospital
17	Rakshak chauk
18	Military Stores
19	Wakad phata
20	Jagtap Dairy
21	Shivar Chowk
22	Sindhu Park
23	Rahatani gaon
24	Ramnagar rahatani
25	akate wasti
26	Saurabh company tambe company
27	Rahatani phata
28	Shrinagar
29	Dhangar Nagar Kalewadi
30	Tapgir nagar
31	M M shala
32	Avinash Mangal Karyalaya
33	Dhangar nagar kalewadi
34	Vijaynagar
35	Ingale hospital
36	Krushnamandir Corner
37	Delux
38	Lalmandir
39	Bhatnagar
40	Finolex
41	Pimpri chauk Bus stand
42	Nehrunagar corner
43	Nehrunagar
44	Jyoti school
45	Vishal nagar C ward office
46	Abhi Chemicals
47	Jayanand khira
48	Idrayani nagar corner
49	Tulashi chemikals
50	Landewadi
51	Gavane Vasti
52	PCMT chauk
53	Maharashtra chauk
54	Hutatma chauk
55	Shatri chauk
56	Durwankur lawns
57	Dighi Corner Odha
58	Tata stores
59	Bhosari phata
60	Moje vidyalaya
61	Sai madnir
62	Nirma company
63	Gokhale Mala Sankalpa Garden
64	Wadmukhwadi
65	Chincheche jhad
66	Charholi phata
67	Sai Lila nagar Kate Wasti
68	Moshi Phata Dehu Phata
69	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Sai mandir
10	Moje vidyalaya
11	Bhosari phata
12	Tata Stores
13	Didhi corner odha
14	Durvankur Lawns
15	Shastri chowk
16	Hutatma chauk
17	Maharashtra Chowk
18	PCMT chauk
19	Gavane Vasti
20	Landewadi
21	Tulsi Chemical
22	Indrayani nagar Corner Jayanand Road
23	Jayanand Khira
24	Abhi chemicals
25	Vishalnagar C Ward office
26	Jyoti School
27	Nehrunagar
28	Nehrunagar corner
29	Pimpri chauk Bus stop
30	Shagun chauk
31	Karachi chowk
32	Delux
33	Krushnamandir corner
34	Ingale Hospital
35	Vijaynagar
36	Dhangar Nagar Kalewadi
37	Avinash mangal karyalay
38	M M Shala
39	Tapkir Nagar
40	Dhangar Nagar Kalewadi
41	Shrinagar
42	Rahatani phata
43	Saurabh company Tambe Shala
44	Nakate wasti
45	Ramnagar rahatni
46	Rahatani gaon
47	Sindhu Park
48	Shivar Chowk
49	Jagtap Dairy
50	Wakad phata
51	Military Stores
52	Rakshak chauk
53	ESI Hospital
54	Aundh post office
55	Aundh chest hospital
56	Sangvi Phata
57	Nurses Quarters
58	Ba ra gholap
59	Navi Sangvi
60	Panyachi taki sangvi
61	shitole nagar corner
62	Anand nagar
63	Sangvi goan
64	Vasantdada Putala
65	PWD gate
66	ST workshop
67	Mantri niketan Dapodi
68	Dapodi Gaon','69','06:15
09:55
12:45
15:45
19:15
07:55
11:25
14:30
17:25
20:55','07:15
11:15
14:15
17:15
20:40
06:25
09:55
12:55
15:55
19:25
22:20','Active');
INSERT INTO "busTable" VALUES(211,'348','Nigadi','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','24 KMs','72 Minutes','1	Nigadi
2	Bajaj auto
3	Akurdi Khandoba Chowk
4	Chafekar chauk
5	Walhekarwadi phata
6	Jakatnaka pavanapul
7	Birla Hospital
8	Dattanagar Chinchwad
9	Padmji Paper Mill
10	Thergaon phata
11	Dange chowk
12	Laxman nagar
13	16 Number
14	Kalewadi phata
15	Kaspate Vasti
16	Jagtap Dairy
17	Wakad phata
18	Military Stores
19	Rakshak chauk
20	ESI Hospital
21	Aundh post office
22	Aundh chest hospital
23	Sangvi Phata
24	Aundh gaon
25	Body gate
26	Bremen chauk
27	Sindh Colony Gate2
28	Kasturba vasahat
29	Boys Batalian
30	Pune University Gate
31	Rangehills Corner
32	E Square
33	Pune central
34	Pumping station
35	Masoba gate
36	shimala office shivajinagar
37	Lokmangal
38	College of engineering pune
39	RTO wellesley road
40	Juna Bajar
41	Ambedkar bhavan
42	Sasoon hospital
43	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Ambedkar bhavan
6	Juna Bajar
7	RTO wellesley road
8	College of engineering pune
9	shimala office shivajinagar
10	Masoba gate
11	Pumping station
12	Pune central
13	E square
14	Rangehills Corner
15	Rajbhavan
16	Boys batalian
17	Kasturba vasahat
18	Sindh colony gate 2
19	Bremen chauk
20	Body gate
21	Aundh gaon
22	Sangvi phata
23	Aundh chest hospital
24	Aundh post office
25	ESI Hospital
26	Rakshak chauk
27	Military Stores
28	Wakad phata
29	Jagtap Dairy
30	Kaspate Vasti
31	Kalewadi phata
32	16 Number
33	Laxman nagar
34	Dange chowk
35	Thergaon phata
36	Padmji Paper Mill
37	Dattanagar Chinchwad
38	Birla hospital
39	Jakatnaka Pavanapool
40	Jai Hind Vidyalaya
41	Chafekar chauk
42	Akurdi khandoba chauk
43	Bajaj auto
44	Pradhikaran Chowk
45	Nigadi','43','05:20
07:35
10:35
13:10
15:35
18:30
05:35
07:50
10:50
13:25
15:50
18:45
05:50
08:05
11:05
13:40
16:05
19:00
06:05
08:20
11:20
13:55
16:20
19:15
06:20
08:35
11:35
14:10
16:35
19:20
06:35
08:50
11:50
14:25
16:50
19:45
06:50
09:05
12:05
14:40
17:05
20:00
07:05
09:20
12:20
14:55
17:20
20:15
07:20
09:35
12:35
15:10
17:35
20:30
07:45
10:00
12:50
15:40
18:10
21:10','06:20
08:55
11:50
14:20
16:50
19:45
06:35
09:05
12:05
14:35
17:05
20:00
06:50
09:20
12:20
14:50
17:20
20:15
07:05
09:35
12:35
15:05
17:35
20:30
07:30
09:50
12:50
15:20
17:50
20:45
07:35
10:05
13:05
15:35
18:05
21:00
07:50
10:20
13:20
15:50
18:20
21:15
08:05
10:35
13:35
16:05
18:35
21:30
08:20
10:50
13:50
16:20
18:50
21:45
08:45
11:10
14:05
16:55
19:25
22:20','Active');
INSERT INTO "busTable" VALUES(212,'349','Pimpri gaon','Vishrantwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','20 KMs','63 Minutes','1	Pimprigaon
2	PMC School Pimpri
3	Ashok Talkies
4	Jaihind School
5	Delux
6	Lalmandir
7	Bhatnagar
8	Finolex
9	Pimpri chauk Bus stand
10	Nehrunagar corner
11	Nehrunagar
12	Jyoti school
13	Vishal nagar C ward office
14	Abhi Chemicals
15	Jayanand khira
16	Idrayani nagar corner
17	Tulashi chemikals
18	Landewadi
19	Gavane Vasti
20	PCMT chauk
21	Maharashtra chauk
22	Hutatma chauk
23	Shatri chauk
24	Durwankur lawns
25	Dighi Corner Odha
26	Tata stores
27	Bhosari phata
28	Telco godown
29	Dattanagar
30	Mitra sahkar nagar
31	Dighigaon
32	AIT college
33	Wireless colony
34	Parade ground
35	Mhaske wasti
36	Kalasgaon
37	R D colony
38	Vishrantwadi','1	Vishrantwadi
2	R D colony
3	kalasgaon
4	Mhaske wasti
5	Parade ground
6	Wireless colony
7	AIT college
8	Dighigaon
9	Mitra sahakar nagar
10	Dattanagar
11	Telco godown
12	Bhosari phata
13	Tata Stores
14	Didhi corner odha
15	Durvankur Lawns
16	Shastri chowk
17	Hutatma chauk
18	Maharashtra Chowk
19	PCMT chauk
20	Gavane Vasti
21	Landewadi
22	Tulsi Chemical
23	Indrayani nagar Corner Jayanand Road
24	Jayanand Khira
25	Abhi chemicals
26	Vishalnagar C Ward office
27	Jyoti School
28	Nehrunagar
29	Nehrunagar corner
30	Pimpri chauk Bus stop
31	Shagun chauk
32	Karachi chowk
33	Delux
34	Jaihind School
35	Ashok Talkies
36	PMC School Pimpri
37	Pimprigaon','38','06:10
08:00
10:00
12:30
14:30
16:30
19:00
06:30
08:30
10:30
13:00
15:00
17:00
19:30
07:05
09:00
11:30
13:30
15:30
17:30
20:00
07:30
09:30
12:00
14:00
16:00
18:00
20:30','07:05
09:00
11:35
13:35
15:30
17:35
20:05
07:35
09:35
12:00
14:05
16:05
18:05
20:30
08:00
10:05
12:35
14:35
16:30
18:35
21:00
08:35
10:30
13:00
15:05
17:05
19:00
21:35','Active');
INSERT INTO "busTable" VALUES(213,'350','Nigadi','Dehugaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','34 Minutes','1	Nigadi
2	Sweet mart
3	LIC Corner
4	Yamunanagar corner
5	Yamuna Nagar
6	Jyotiba Nagar
7	Talwade
8	Canbay Corner
9	Dehugaon grampanchayat
10	Dehugaon','1	Dehugaon
2	Dehugaon Grampanchayat
3	Canbay Corner
4	Talawade
5	Jyotiba nagar
6	Yamuna nagar
7	Yamunanagar Corner
8	LIC corner
9	Sweet mart
10	Nigadi','10','06:40
07:45
08:45
09:55
11:35
12:50
14:15
15:15
16:20
17:30
18:45
20:40
07:15
08:15
09:20
10:30
12:10
13:30
14:45
15:50
16:50
18:10','07:10
08:15
09:20
10:30
12:10
13:25
14:45
15:50
16:50
18:10
19:20
21:20
07:45
08:45
09:55
11:05
12:50
14:10
15:15
16:20
17:30
18:45','Active');
INSERT INTO "busTable" VALUES(214,'351','Alandi bus stand','Jambhe','Mon, Tue, Wed, Thu, Fri, Sat, Sun','32 KMs','85 Minutes','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Sai mandir
10	Moje vidyalaya
11	Bhosari phata
12	Tata Stores
13	Didhi corner odha
14	Durvankur Lawns
15	Shastri chowk
16	Hutatma chauk
17	Maharashtra Chowk
18	Century Enka Colony
19	Landewadi
20	Philips
21	MIDC Bhosari
22	Bhosari Police Station
23	Nashik phata
24	Deichi company
25	Vallabhnagar
26	HA Factory D Y Patil college
27	Kharalwadi
28	Pimpri chauk Bus stop
29	Finolex
30	Premier company
31	Chinchwad station
32	Lokmanya Hospital
33	Prekshagruha
34	Elpro Company
35	Chafekar chauk
36	Jai Hind Vidyalaya
37	Jakatnaka Pavanapool
38	Birla hospital
39	Dattanagar Chinchwad
40	Padmji Paper Mill
41	Thergaon phata
42	Dange chowk
43	Dairy farm
44	Tathwade
45	Kudale farm
46	Punavale
47	Punawale corner
48	Tajane Vasti
49	Nerhe Phata
50	Jambhe Prathamik Shala
51	Jambhe','1	Jambhe
2	Jambhe Prathamik Shala
3	Nerhe Phata
4	Tajane Vasti
5	Punavale Corner
6	Punavale
7	Kudale Farm
8	Tathwade
9	Dairy Farm
10	Dange chowk
11	Thergaon phata
12	Padmji Paper Mill
13	Dattanagar Chinchwad
14	Birla Hospital
15	Jakatnaka pavanapul
16	Walhekarwadi phata
17	Chafekar chauk
18	Elpro Company
19	Prekshagruha
20	Lokmanya Hospital
21	Chinchwad station
22	Chinchwad chauk
23	Premier company
24	Finolex
25	Pimpri chauk Bus stand
26	Kharalwadi
27	H A Factory
28	Vallabhnagar
29	Deichi Company
30	Nashik phata
31	Bhosari Police Station
32	MIDC bhosari
33	Philips
34	Landewadi
35	Century Enka Colony
36	Maharashtra chauk
37	Hutatma chauk
38	Shatri chauk
39	Durwankur lawns
40	Dighi Corner Odha
41	Tata stores
42	Bhosari phata
43	Moje vidyalaya
44	Sai madnir
45	Nirma company
46	Gokhale Mala Sankalpa Garden
47	Wadmukhwadi
48	Chincheche jhad
49	Charholi phata
50	Sai Lila nagar Kate Wasti
51	Moshi Phata Dehu Phata
52	Alandi bus stand','52','06:10
09:05
15:40
19:10','07:35
11:10
17:20
20:40','Active');
INSERT INTO "busTable" VALUES(215,'353','Pimprigaon','Dehugaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','68 Minutes','1	Pimprigaon
2	Nanekar park
3	Jaihind School
4	Delux
5	Karachi chowk
6	Lalmandir
7	Bhatnagar
8	Link road
9	Manik Colony
10	Darshan hall
11	Chinchwad gaon
12	Chafekar chauk
13	Om sairam complex
14	Chaitnya sabhagrah
15	Chinchwade nagar corner Akurdi road
16	Bijali nagar
17	Railway quarters
18	Patil chauk
19	Sambhaji chauk
20	Mhalasakant chauk
21	Akurdi khandoba chauk
22	Bajaj auto
23	Pradhikaran Chowk
24	Sweet mart
25	LIC Corner
26	Yamunanagar corner
27	Yamuna Nagar
28	Jyotiba Nagar
29	Talwade
30	Canbay Corner
31	Dehugaon grampanchayat
32	Dehugaon','1	Dehugaon
2	Dehugaon Grampanchayat
3	Canbay Corner
4	Talawade
5	Jyotiba nagar
6	Yamuna nagar
7	Yamunanagar Corner
8	LIC corner
9	Sweet mart
10	Pradhikaran Chowk
11	Bajaj auto
12	Akurdi Khandoba Chowk
13	Mhalsakant Chowk
14	Sambhaji chowk
15	Patil Chowk
16	Railway quarters
17	Bijlinagar
18	Chinchwade Nagar Corner Akurdi Road
19	Chaitanya sabhagruha
20	Om Sairam complex
21	Chafekar chauk
22	Chinchwad gaon
23	Darshan hall
24	Manik colony
25	Link Road
26	Bhatnagar
27	Shagun chowk
28	Delux
29	Jaihind School
30	Nanekar park
31	Pimprigaon','31','05:45
08:05
10:50
13:40
16:35
19:05
06:30
08:45
11:30
14:30
17:20
19:45
07:15
09:35
12:20
15:25
18:10
20:35','06:50
09:10
12:05
14:55
17:45
20:10
07:35
09:50
12:40
15:40
18:30
20:50
08:20
10:40
13:30
16:30
19:20
21:45','Active');
INSERT INTO "busTable" VALUES(216,'354','Pimprigaon','Market yard','Mon, Tue, Wed, Thu, Fri, Sat, Sun','26 KMs','80 Minutes','1	Pimprigaon
2	PMC School Pimpri
3	Ashok Talkies
4	Jaihind School
5	Delux
6	Krushnamandir corner
7	Ingale Hospital
8	Vijaynagar
9	Dhangar Nagar Kalewadi
10	Avinash mangal karyalay
11	M M Shala
12	Tapkir Nagar
13	Dhangar Nagar Kalewadi
14	Shrinagar
15	Rahatani Phata
16	Saurabh company Tambe Shala
17	Nakate wasti
18	Ramnagar rahatni
19	Rahatani gaon
20	Sindhu Park
21	Shivar Chowk
22	Jagtap Dairy
23	Wakad phata
24	Military Stores
25	Rakshak chauk
26	ESI Hospital
27	Aundh post office
28	Aundh chest hospital
29	Sangvi Phata
30	Aundh gaon
31	Body gate
32	Bremen chauk
33	Sindh Colony Gate2
34	Kasturba vasahat
35	Boys Batalian
36	Pune University Gate
37	Rangehills Corner
38	E Square
39	Pune central
40	Pumping station
41	Masoba gate
42	shimala office shivajinagar
43	Engineering college hostel
44	Shivaji putala
45	PMC Mangala
46	Kasaba Police Chowky
47	Vasant talkies
48	Mandai
49	Shahu chauk
50	Mamledar kacheri
51	Gokul bhavan
52	Swargate
53	Lakshi narayan theature
54	Panchami hotel
55	Bhapkar Petrol Pump City pride
56	Mafco Company
57	Shivaji putala Kalubai mandir
58	Godown Marketyard
59	Wakhar Mahamandal Marketyard
60	Marketyard','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	Godown Marketyard
4	Shivaji Putala Kalubai Mandir
5	Mafco Company
6	Bhapkar petrol pump City Pride
7	Panchami hotel
8	Laxmi Narayan Theature
9	Swargate
10	Swargate
11	Sarasbag
12	Bhikardas maruti madnir
13	Shanipar
14	A B Chowk
15	Dakshinabhimukh Maruti mandir
16	Shaniwar wada
17	PMC mangala
18	Shivaji putala pmc
19	shimala office shivajinagar
20	Masoba gate
21	Pumping station
22	Pune central
23	E square
24	Rangehills Corner
25	Rajbhavan
26	Boys batalian
27	Kasturba vasahat
28	Sindh colony gate 2
29	Bremen chauk
30	Body gate
31	Aundh gaon
32	Sangvi phata
33	Aundh chest hospital
34	Aundh post office
35	ESI Hospital
36	Rakshak chauk
37	Military Stores
38	Wakad phata
39	Jagtap Dairy
40	Shivar Chowk
41	Sindhu Park
42	Rahatani gaon
43	Ramnagar rahatani
44	akate wasti
45	Saurabh company tambe company
46	Rahatani phata
47	Shrinagar
48	Dhangar Nagar Kalewadi
49	Tapgir nagar
50	M M shala
51	Avinash Mangal Karyalaya
52	Dhangar nagar kalewadi
53	Vijaynagar
54	Ingale hospital
55	Krushnamandir Corner
56	Delux
57	Jaihind School
58	Ashok Talkies
59	PMC School Pimpri
60	Pimprigaon','60','05:40
08:10
11:35
15:05
18:00
21:35
06:45
09:25
12:50
16:15
19:15
22:40
07:30
10:45
13:35
17:00
20:35
23:35','06:50
09:40
13:00
16:35
20:05
22:35
08:05
10:55
14:15
17:45
21:15
23:35
08:50
12:10
15:00
18:35
22:05
00:05','Active');
INSERT INTO "busTable" VALUES(217,'355','Chikhali','Dange chowk','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','46 Minutes','1	Chikhali
2	Newad wasti
3	Sane wasti
4	Sane chauk
5	Krushnanagar Corner
6	Kasturi market
7	Ajantha nagar corner
8	Thermax
9	Yamunanagar Corner
10	LIC corner
11	Sweet mart
12	Bajaj auto
13	Akurdi Khandoba Chowk
14	Chafekar chauk
15	Jai Hind Vidyalaya
16	Jakatnaka Pavanapool
17	Birla hospital
18	Dattanagar Chinchwad
19	Padmji Paper Mill
20	Thergaon phata
21	Dange chowk','1	Dange chowk
2	Thergaon phata
3	Padmji Paper Mill
4	Dattanagar Chinchwad
5	Birla Hospital
6	Jakatnaka pavanapul
7	Walhekarwadi phata
8	Chafekar chauk
9	Akurdi khandoba chauk
10	Bajaj auto
11	Sweet mart
12	LIC Corner
13	Yamunanagar corner
14	Thermax
15	Ajanta Nagar Corner
16	Kasturi Market
17	Krushnanaga corner
18	Sane chowk
19	Sane Wasti
20	Newad Wasti
21	Chikhali','21','07:40
09:10
10:40
12:40
14:10
15:40
17:10
06:45
08:25
09:50
11:25
13:25
14:55
16:25','08:25
09:55
11:25
13:25
14:55
16:25
17:55
07:40
09:10
10:40
12:40
14:10
15:40
17:10','Active');
INSERT INTO "busTable" VALUES(218,'357','Pune station','Rajgurunagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','46.2 KMs','115 Minutes','1	Pune station
2	Sasoon hospital
3	Ambedkar bhavan
4	Juna Bajar
5	RTO wellesley road
6	College of engineering pune
7	Patil Estate
8	Labour office
9	Bajaj showroom wakadewadi
10	Mariaai Gate Old Mumbai Pune Road
11	Poultry Farm Old Mumbai Pune Road
12	Krutrim reshim paidas kendra
13	Raja Bungalow
14	Khadaki post office
15	Khadki church stop
16	Khadaki railway station
17	Khadaki
18	Bopodi
19	Dapodi
20	Fugewadi
21	Sandwik
22	Alfa laval atlas company
23	Forbes marshal stop
24	Kasrawadi
25	Nashik phata
26	Bhosari Police Station
27	MIDC bhosari
28	Philips
29	Landewadi
30	Century Enka Colony
31	Bhosari gaon
32	Sadgurunagar PCMT depot
33	Panjarpol
34	Wakhar mahamandal bhosari
35	Tan protex
36	Juna jakat naka
37	Borate Vasti
38	Bankar wasti moshi
39	Chaudhari dhaba
40	Moshi goan
41	Hood company
42	Moshi Phata Chimbli Phata
43	Gaikwad wasti
44	Kuruli Gaon
45	Alandi Phata
46	Petrol Pump
47	Talegaon Phata ST Stand
48	Chakan market yard
49	Protact Company
50	Waki Khurda
51	Rohakal Phata
52	Bham
53	Waki Budruk
54	Kadwasti
55	Khadi Machine Chakan
56	Shiroli Phata
57	Bhandari Company
58	Kanda Lasoon Sanshodhan Kendra
59	Kadus Phata
60	Rajgurunagar Vidyalaya
61	Rajgurunagar Khed','1	Rajgurunagar Khed
2	Rajgurunagar Vidyalaya
3	Kadus Phata
4	Kanda Lasoon Sanshodhan Kendra
5	Bhandari Company
6	Shiroli Phata
7	Khadi Machine Chakan
8	Kadwasti
9	Waki Budruk
10	Bham
11	Rohakal Phata
12	Waki Khurda
13	Protact Company
14	Chakan market yard
15	Talegaon Phata ST Stand
16	Petrol Pump
17	Alandi Phata
18	Kuruli Gaon
19	Gaikwad wasti
20	Moshi phata chimboli phata
21	Hood company
22	Moshi goan
23	Chaudhari dhaba
24	Bankar Vasti Moshi
25	Borate wasti
26	Juna Jakat naka
27	Tan Protex
28	Wakhar Mahamandal Bhosari
29	Panjarpol
30	Sadgurunagar PCMT depot
31	Bhosari gaon
32	Century Enka Colony
33	Landewadi
34	Philips
35	MIDC Bhosari
36	Bhosari Police Station
37	Nashik phata
38	Kasarwadi
39	Forbes marshal stop
40	Alfa Laval Atlas Company
41	Sandwik
42	Fugewadi
43	Dapodi
44	Bopodi Jakat Naka
45	Bopodi
46	Khadaki
47	Khadaki railway station
48	Petrol Pump Khadki
49	Khadaki church stop
50	Khadaki post office
51	Raja bangalow
52	Krutrim Reshim Paidas Kendra
53	Poultry Farm Old Mumbai Pune Road
54	Mariaai Gate Old Mumbai Pune Road
55	Bajaj showroom
56	Labor office
57	Patil Estate
58	College of engineering pune
59	RTO wellesley road
60	Juna Bajar
61	Ambedkar bhavan
62	Pune station','61','07:40
15:40
19:45
05:50
10:00
13:50
17:30
07:55
15:50
20:00
06:00
10:15
14:00
17:45
08:10
16:05
20:15
06:20
10:30
14:15
18:00
08:25
16:20
20:30
06:35
10:45
14:30
18:15
08:40
16:35
20:45
06:50
11:00
14:45
18:30
09:00
16:50
21:00
07:05
11:15
15:00
18:45
09:15
17:05
21:10
07:15
11:30
15:15
19:00
09:35
17:15
21:20
07:25
15:20
19:15
09:50
17:20
21:30
07:30
11:40
15:30
19:30','10:00
17:30
21:20
07:40
11:45
15:40
18:45
10:15
17:45
21:50
07:55
12:10
15:50
20:00
10:30
18:00
21:30
08:10
12:15
16:05
20:15
10:45
18:15
22:05
08:25
12:40
16:20
20:30
11:00
18:30
22:00
08:40
12:55
16:35
20:45
11:15
18:45
22:35
09:00
13:10
16:50
21:00
11:30
19:00
22:30
09:15
13:20
17:05
21:10
11:20
19:15
22:35
09:35
17:15
21:20
11:40
19:30
23:05
09:50
13:35
17:20
21:30','Active');
INSERT INTO "busTable" VALUES(219,'358','Pimpri Manapa','Rajgurunagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','36 KMs','76 Minutes','1	Pimpri chauk Bus stand
2	Kharalwadi
3	H A Factory
4	Vallabhnagar
5	Deichi Company
6	Nashik phata
7	Bhosari Police Station
8	MIDC bhosari
9	Philips
10	Landewadi
11	Century Enka Colony
12	Bhosari gaon
13	Sadgurunagar PCMT depot
14	Panjarpol
15	Wakhar mahamandal bhosari
16	Tan protex
17	Juna jakat naka
18	Borate Vasti
19	Bankar wasti moshi
20	Chaudhari dhaba
21	Moshi goan
22	Hood company
23	Moshi Phata Chimbli Phata
24	Gaikwad wasti
25	Kuruli Gaon
26	Alandi Phata
27	Petrol Pump
28	Talegaon Phata ST Stand
29	Chakan market yard
30	Protact Company
31	Waki Khurda
32	Rohakal Phata
33	Bham
34	Waki Budruk
35	Kadwasti
36	Khadi Machine Chakan
37	Shiroli Phata
38	Bhandari Company
39	Kanda Lasoon Sanshodhan Kendra
40	Kadus Phata
41	Rajgurunagar Vidyalaya
42	Rajgurunagar Khed','1	Rajgurunagar Khed
2	Rajgurunagar Vidyalaya
3	Kadus Phata
4	Kanda Lasoon Sanshodhan Kendra
5	Bhandari Company
6	Shiroli Phata
7	Khadi Machine Chakan
8	Kadwasti
9	Waki Budruk
10	Bham
11	Rohakal Phata
12	Waki Khurda
13	Protact Company
14	Chakan market yard
15	Talegaon Phata ST Stand
16	Petrol Pump
17	Alandi Phata
18	Kuruli Gaon
19	Gaikwad wasti
20	Moshi phata chimboli phata
21	Hood company
22	Moshi goan
23	Chaudhari dhaba
24	Bankar Vasti Moshi
25	Borate wasti
26	Juna Jakat naka
27	Tan Protex
28	Wakhar Mahamandal Bhosari
29	Panjarpol
30	Sadgurunagar PCMT depot
31	Bhosari gaon
32	Century Enka Colony
33	Landewadi
34	Philips
35	MIDC Bhosari
36	Bhosari Police Station
37	Nashik phata
38	Deichi company
39	Vallabhnagar
40	HA Factory D Y Patil college
41	Kharalwadi
42	Pimpri chauk Bus stop','42','06:00
08:25
11:35
14:45
17:25
20:25
06:40
09:10
12:20
15:30
18:05
21:15
07:10
09:50
13:05
16:15
18:50
22:00
07:55
10:35
13:45
17:00
19:40
22:45','07:10
10:10
12:50
16:00
19:05
21:40
07:50
11:05
13:30
16:45
19:55
22:30
08:30
11:45
14:20
17:35
20:40
23:15
09:10
12:20
14:55
18:20
21:35
00:00','Active');
INSERT INTO "busTable" VALUES(220,'36','Manapa','Chinchwad Gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','19 KMs','60 Minutes','1	PMC
2	PMC mangala
3	Shivaji putala pmc
4	shimala office shivajinagar
5	Masoba gate
6	Pumping station
7	Pune central
8	E square
9	Rangehills Corner
10	Rajbhavan
11	Boys batalian
12	Kasturba vasahat
13	Sindh colony gate 2
14	Bremen chauk
15	Body gate
16	Aundh gaon
17	Sangvi phata
18	Aundh chest hospital
19	Aundh post office
20	ESI Hospital
21	Rakshak chauk
22	Military Stores
23	Wakad phata
24	Jagtap Dairy
25	Kaspate Vasti
26	Kalewadi phata
27	16 Number
28	Laxman nagar
29	Dange chowk
30	Thergaon phata
31	Padmji Paper Mill
32	Dattanagar Chinchwad
33	Birla Hospital
34	Jakatnaka pavanapul
35	Walhekarwadi phata
36	Chafekar chauk
37	Chinchwad gaon','1	Chinchwad gaon
2	Chafekar chauk
3	Jai Hind Vidyalaya
4	Jakatnaka Pavanapool
5	Birla hospital
6	Dattanagar Chinchwad
7	Padmji Paper Mill
8	Thergaon phata
9	Dange chowk
10	Laxman nagar
11	16 Number
12	Kalewadi phata
13	Kaspate Vasti
14	Jagtap Dairy
15	Wakad phata
16	Military Stores
17	Rakshak chauk
18	ESI Hospital
19	Aundh post office
20	Aundh chest hospital
21	Sangvi Phata
22	Aundh gaon
23	Body gate
24	Bremen chauk
25	Sindh Colony Gate2
26	Kasturba vasahat
27	Boys Batalian
28	Pune University Gate
29	Rangehills Corner
30	E Square
31	Pune central
32	Pumping station
33	Masoba gate
34	shimala office shivajinagar
35	Engineering college hostel
36	Shivaji putala
37	PMC Mangala
38	PMC','37','05:20
07:20
09:20
11:50
14:30
16:35
18:35
21:05
05:35
07:35
09:35
12:05
14:45
16:45
18:45
21:15
05:50
07:50
09:50
12:20
15:00
17:00
19:00
21:30
06:00
08:00
10:35
12:30
15:10
17:10
19:45
21:45
06:15
08:15
10:15
12:45
15:25
17:25
19:25
22:00
06:30
08:30
11:00
13:00
15:40
17:40
20:10
22:15
06:45
08:45
11:15
13:15
15:55
17:55
20:30
22:30
07:00
09:00
11:30
13:30
16:10
18:10
20:45
22:45
07:10
09:10
11:40
13:45
16:25
18:25
20:55
23:00','06:15
08:20
10:20
12:50
15:30
17:35
19:35
22:00
06:30
08:35
10:35
13:05
15:45
17:45
19:45
22:15
06:45
08:50
10:50
13:20
16:00
18:00
20:00
22:30
07:00
09:00
11:35
13:30
16:10
18:10
20:45
22:45
07:15
09:15
11:15
13:45
16:25
18:25
20:25
23:23
07:30
09:30
12:00
14:00
16:40
18:40
21:10
23:15
07:45
09:45
12:15
14:15
16:55
18:55
21:30
23:30
08:00
10:00
12:30
14:30
17:10
19:10
21:45
23:45
08:10
10:10
12:40
14:45
17:25
19:25
21:55
00:00','Active');
INSERT INTO "busTable" VALUES(221,'360','Alandi bus stand','Balewadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','34 KMs','86 Minutes','1	Alandi bus stand
2	Moshi Phata Dehu Phata
3	Sai Lila nagar Kate Wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale Mala Sankalpa Garden
8	Nirma company
9	Sai madnir
10	Moje vidyalaya
11	Bhosari phata
12	Tata stores
13	Dighi Corner Odha
14	Durwankur lawns
15	Shatri chauk
16	Hutatma chauk
17	Maharashtra chauk
18	Bhosari gaon
19	Century Enka Colony
20	Landewadi
21	Philips
22	MIDC Bhosari
23	Bhosari police station
24	Nashik phata
25	Deichi Company
26	Vallabhnagar
27	H A Factory
28	Kharalwadi
29	Pimpri chauk Bus stand
30	Finolex
31	Premier company
32	Chinchwad chauk
33	chinchwad station
34	Lokmanya Hospital
35	Prekshagruha
36	Elpro Company
37	Chafekar chauk
38	Jai Hind Vidyalaya
39	Jakatnaka Pavanapool
40	Birla hospital
41	Dattanagar Chinchwad
42	Padmji Paper Mill
43	Thergaon phata
44	Dange chowk
45	Wakad Chowk
46	Wakad Highway
47	Mutha Pool Balewadi
48	Chh.Shivaji krida sankul
49	Mhalunge corner
50	Balewadi','1	Balewadi
2	Mhalunge corner
3	Chha. Shivaji Krida Sankul
4	Mutha Pool Balewadi
5	Wakad Highway
6	Wakad Chowk
7	Dange chowk
8	Thergaon phata
9	Padmji Paper Mill
10	Dattanagar Chinchwad
11	Birla Hospital
12	Jakatnaka pavanapul
13	Walhekarwadi phata
14	Chafekar chauk
15	Elpro Company
16	Prekshagruha
17	Lokmanya Hospital
18	Chinchwad station
19	Premier company
20	Finolex
21	Pimpri chauk Bus stop
22	Kharalwadi
23	HA Factory D Y Patil college
24	Vallabhnagar
25	Deichi company
26	Nashik phata
27	Bhosari police station
28	MIDC bhosari
29	Philips
30	Landewadi
31	Century Enka Colony
32	Bhosari gaon
33	Maharashtra Chowk
34	Hutatma chauk
35	Shastri chowk
36	Durvankur Lawns
37	Didhi corner odha
38	Tata Stores
39	Bhosari phata
40	Moje vidyalaya
41	Sai mandir
42	Nirma company
43	Gokhale mala sankalp garden
44	Wadmukhwadi
45	Chincheche jhad
46	Charholi phata
47	Sai lila nagar kate wasti
48	Dehu phata
49	Alandi bus stand','50','05:40
08:25
11:45
14:30
17:10
20:45','07:00
09:55
13:05
15:50
18:45
22:15','Active');
INSERT INTO "busTable" VALUES(222,'363','Nigadi','Kiwale','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11.3 KMs','36 Minutes','1	Pradhikaran Chowk
2	Nigadi jakat naka
3	Cantonment jakat naka
4	Kohima line
5	B sub depot
6	Kendriya vidyalaya
7	Garden city
8	CISV
9	Dehu phata highway
10	Dehuroad railway staion
11	Shankar Mandir
12	Vikasnagar
13	Medical Shop
14	Petrol Pump Vikasnagar
15	Indraprabha Mamurdi
16	Kiwale phata
17	Adarshnagar corner
18	Shelke wasti
19	Kiwale','1	Kiwale
2	Shelke wasti
3	Adarshnagar Corner
4	Kivale phata
5	Indraprabha mamurdi
6	Petrol pump vikasnagar
7	Medical shop
8	Vikasnagar
9	Shankar mandir
10	Dehu road railway station
11	Dehu phata highway
12	CISV
13	Garden City
14	Kendriya Vidyalaya
15	B Sub Depot
16	Kohima Line
17	Cantonment Jakat Naka
18	Nigadi jakat naka
19	Nigadi','19','06:05
07:05
08:15
09:25
11:15
12:30
14:15
15:25
16:35
17:45
19:35
20:50
06:35
07:40
08:50
10:05
11:50
13:05
14:50
16:00
17:10
18:25
20:10
21:25','06:35
07:40
08:50
10:05
11:50
13:05
14:50
16:00
17:10
18:25
20:10
21:25
07:05
08:15
09:25
10:40
12:30
13:45
15:25
16:35
17:45
19:00
20:50
22:00','Active');
INSERT INTO "busTable" VALUES(223,'366','Nigadi','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','20 KMs','67 Minutes','1	Nigadi
2	Pradhikaran Chowk
3	Bajaj auto
4	Akurdi Khandoba Chowk
5	Ruston Company
6	Kalbhor nahar bus stop
7	Mehta hospital
8	chinchwad station
9	Chinchwad chauk
10	Premier company
11	Finolex
12	Pimpri chauk Bus stand
13	Kharalwadi
14	H A Factory
15	Vallabhnagar
16	Nashik phata
17	Kasarwadi
18	Forbes marshal stop
19	Alfa Laval Atlas Company
20	Sandwik
21	Fugewadi
22	Dapodi
23	Bopodi Jakat Naka
24	Bopodi
25	Gangaram park
26	Kirloskar oil engine manaji bag
27	Alegaonkar High school
28	Khadki Bazar
29	Supply Depot
30	Amunition Factory Road
31	Mathyadist Church
32	Holkar Water Supply
33	Sapras post
34	Deccan college
35	Shadal baba Darga
36	Yerwada
37	Band garden
38	Guruprasad bangala
39	Jahangir Hospital
40	Alankar Talkies
41	Pune Station Depot','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Pune station
6	Ruby hall
7	Wadia college
8	Guruprasad bangala
9	Band garden
10	Yerwada
11	Shadal baba Darga
12	Deccan college
13	Sapras post
14	Holkar Water Supply
15	Mathyadist Church
16	Amunition factory road
17	Suply depot
18	Khadaki bajar
19	Alegaonkar High school
20	Kirloskar Oil Engine Manaji Bag
21	Gangaram park
22	Bopodi
23	Dapodi
24	Fugewadi
25	Sandwik
26	Alfa laval atlas company
27	Forbes marshal stop
28	Kasrawadi
29	Nashik phata
30	Deichi company
31	Vallabhnagar
32	HA Factory D Y Patil college
33	Kharalwadi
34	Pimpri chauk Bus stop
35	Finolex
36	Premier company
37	Chinchwad station
38	Mehta hospital
39	Kalbhor nagar bus stop
40	Rustan company
41	Akurdi khandoba chauk
42	Bajaj auto
43	Pradhikaran Chowk
44	Nigadi','41','05:30
07:30
10:45
13:15
15:35
05:45
08:05
10:25
13:25
15:45
18:05
06:00
08:20
10:40
13:35
15:55
18:15
06:15
08:35
10:55
13:50
16:05
18:25
06:30
08:50
11:10
14:05
16:25
18:45
06:45
09:05
11:50
14:20
16:40
19:00
07:00
09:20
12:05
14:40
17:00
19:20
07:15
09:35
12:20
15:15
17:35
20:25
07:35
09:50
12:35
14:50
17:10
07:45
10:05
12:50
15:05
17:25
05:25
07:30
09:40
12:20
14:30
16:50
19:40
07:45
09:55
12:05
14:45
17:05
05:50
07:55
10:05
12:45
14:55
17:15
20:00
06:00
08:05
10:15
12:55
15:10
17:30
20:20
08:15
10:25
12:35
15:20
17:40
06:20
08:25
10:35
13:15
15:35
17:55
20:40
06:30
08:35
10:45
13:25
15:45
18:05
21:00
08:45
10:55
13:05
16:00
18:20
06:50
08:55
11:05
13:45
16:10
18:30
21:20
07:00
09:05
11:50
13:55
16:20
19:20
21:35
09:15
11:25
13:35
16:30
18:45
07:20
09:25
11:35
14:15
16:40
19:00
21:50','06:30
08:55
11:50
14:25
16:45
06:55
09:15
12:00
14:35
16:55
19:15
07:10
09:30
12:15
14:45
17:05
19:25
07:25
09:45
12:30
15:00
17:15
19:35
07:40
10:00
12:45
15:15
17:35
20:25
07:55
10:15
13:00
15:30
17:50
20:40
08:10
10:30
13:15
15:50
18:10
21:00
08:25
10:45
13:30
16:25
18:45
21:35
08:40
11:00
13:45
16:00
18:20
08:55
11:15
14:00
16:15
18:35
06:25
08:35
11:15
13:20
15:40
18:00
20:50
08:50
11:00
13:00
15:55
18:15
06:50
09:00
11:40
13:45
16:05
18:25
21:10
07:00
09:10
11:50
13:55
16:20
18:40
21:30
09:20
11:30
13:35
16:30
18:50
07:30
09:30
12:10
14:15
16:45
19:05
21:50
07:30
09:40
12:20
14:25
16:55
19:15
22:10
09:50
12:00
14:05
17:10
19:30
07:50
10:00
12:40
14:45
17:20
19:40
22:30
08:00
10:45
12:50
14:55
17:30
20:30
22:45
10:20
12:30
14:35
17:40
19:55
08:20
10:30
13:10
15:15
17:50
20:10
23:00','Active');
INSERT INTO "busTable" VALUES(224,'367','Nigadi','BhosariPrint','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','35 Minutes','1	Nigadi
2	Sweet mart
3	LIC Corner
4	Yamunanagar corner
5	Thermax
6	Sarpodyan Telco Road
7	HDFC corner
8	KSB chauk
9	Telco company
10	Telco hostel
11	Yashwant Nagar Telco Road
12	Gavalimatha
13	Power house Bhosari
14	Indrayani nagar Corner
15	Century Company
16	Electronic Sadan
17	Landewadi
18	Gavane Vasti
19	PCMT chauk','1	PCMT chauk
2	Gavane Vasti
3	Landewadi
4	Electronic sadan
5	Century company
6	Indrayani nagar corner
7	Power house bhosari
8	Gavalimatha
9	Yashwant nagar telco road
10	Telco hostel
11	Telco company
12	KSB Chowk
13	HDFC Corner
14	Sarpoudyan telco road
15	Thermax
16	Yamunanagar Corner
17	LIC corner
18	Sweet mart
19	Nigadi','19','06:05
07:15
08:25
09:35
11:15
12:25
14:20
15:30
16:40
17:50
19:30
20:40
07:20
08:20
09:40
10:50
12:30
13:40
15:35
16:45
17:55
19:05
20:45
21:55
06:15
07:25
08:35
09:45
11:25
12:35
14:30
15:40
16:50
18:00
19:40
20:50
06:25
07:35
08:45
09:55
11:05
12:45
14:40
15:45
16:55
18:05
19:45
20:55
07:40
08:50
10:00
11:35
12:50
14:00
15:50
17:00
18:10
19:20
21:00
22:10
06:35
07:45
08:55
10:05
11:45
12:55
14:50
16:00
17:10
18:20
20:00
21:10
07:50
09:00
10:10
11:50
13:00
14:55
16:05
17:15
18:25
20:05
21:15
06:45
07:55
09:05
10:15
11:55
13:50
15:00
16:10
17:20
18:30
20:10
06:55
08:05
09:15
10:25
12:05
13:15
15:05
16:15
17:25
18:35
20:15
21:25
05:55
07:05
08:15
09:25
10:35
12:15
14:05
15:15
16:25
17:35
18:45
20:25
07:10
08:20
09:20
10:40
12:20
13:30
14:40
17:10
18:20
20:00
21:10
22:20
08:40
09:50
11:40
13:20
14:25
15:55
17:05
18:50
20:20
21:30
22:30
23:40','06:40
07:50
09:00
10:40
11:50
13:00
14:55
16:05
17:15
18:55
20:05
21:15
07:55
09:05
10:15
11:55
13:05
14:15
16:10
17:20
18:30
20:10
21:20
22:30
06:50
08:00
09:10
10:50
12:10
13:10
15:05
16:15
17:25
19:05
20:15
21:15
07:00
08:10
09:20
10:30
12:10
13:20
15:10
16:20
17:30
19:10
20:20
21:30
08:15
09:25
11:00
12:15
13:25
14:35
16:25
17:35
18:45
20:25
21:35
22:45
07:10
08:20
09:30
11:10
12:20
13:30
15:25
16:35
17:45
19:25
20:35
21:45
08:25
09:35
11:15
12:25
13:35
15:30
16:40
17:50
19:30
20:40
21:50
07:20
08:30
09:40
11:20
12:30
14:25
15:35
16:45
17:55
19:35
20:45
07:30
08:40
09:50
11:30
12:40
13:50
15:40
16:50
18:00
19:40
20:50
22:00
06:30
07:40
08:50
10:00
11:40
12:50
14:40
15:50
17:00
18:10
19:50
21:00
07:45
08:50
10:05
11:45
12:55
14:05
16:40
17:45
18:55
20:35
21:45
23:00
09:15
10:50
12:45
13:55
15:00
16:30
17:35
19:20
20:55
22:10
23:10
00:10','Active');
INSERT INTO "busTable" VALUES(225,'368','Alandi bus stand','Lonikand phata','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18.6 KMs','49 Minutes','1	Alandi bus stand
2	Markal Gaon
3	Indrayani Nadi Pool
4	Tulapur
5	Balsadan
6	Phulgaon
7	Malwadi Phulgaon
8	Sakore Mala
9	Raysoni Farm
10	Kukut Palan Kendra
11	Power House Markal
12	Phulgaon Phata','1	Phulgaon phata
2	Power house markal
3	Kukkut palan kendra
4	Raysoni farm
5	Sakore mala
6	Malwadi Phulgaon
7	Phulgaon
8	Balsadan
9	Tulapur
10	Indrayani pul
11	Markal Gaon
12	Alandi bus stand','12','06:15
07:50
09:30
11:40
14:40
16:20
18:00
20:10
07:05
08:40
10:20
12:30
15:35
17:15
18:55
21:05','07:00
08:40
10:20
12:30
15:30
17:10
18:50
21:00
07:50
09:30
11:10
13:20
16:25
18:05
19:45
21:55','Active');
INSERT INTO "busTable" VALUES(226,'37','narveer tanaji wadi','Sahkaranagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7 KMs','40 Minutes','1	N T wadi
2	Shivaji nagar S T stand
3	Lokmangal
4	Engineering college hostel
5	Shivaji putala
6	PMC Mangala
7	Kasaba Police Chowky
8	Vasant talkies
9	Mandai
10	Shahu chauk
11	Mamledar kacheri
12	Gokul bhavan
13	Swargate
14	Sarasbag
15	Mahila Mandal
16	Parvati payatha
17	Mitramandal Sabhagruh
18	Bank of Maharashtra Parvati gaon
19	Lakshminagar Corner
20	Sarang Society
21	Gandhi Training Corner
22	Sahakar Nagar','1	Sahakar Nagar
2	Gandhi Training Corner
3	Sarang Society
4	Lakshminagar Corner
5	Bank of Maharashtra Parvati gaon
6	Mitramandal Sabhagruh
7	Parvati payatha
8	Mahila mandal
9	Hirabag
10	Madiwale colony
11	Bhikardas maruti madnir
12	Shanipar
13	A B Chowk
14	Dakshinabhimukh Maruti mandir
15	Shaniwar wada
16	PMC mangala
17	Shivaji putala pmc
18	shimala office shivajinagar
19	Shivaji nagar ST Stand
20	N T wadi','22','06:10
07:30
08:50
10:50
12:20
14:00
15:20
16:40
18:00
19:50
21:20
06:35
07:55
09:15
11:10
12:40
14:25
15:45
17:05
18:30
20:30
07:00
08:20
09:40
11:30
13:00
14:50
16:10
17:35
19:00
20:55','06:50
08:10
09:35
11:35
13:00
14:40
16:00
17:20
18:40
20:30
21:55
07:15
08:35
09:55
11:55
13:20
15:05
16:25
17:45
19:10
21:10
07:40
09:00
10:20
12:15
13:40
15:30
16:50
18:15
19:40
21:35','Active');
INSERT INTO "busTable" VALUES(227,'370','Pimpri manapa','Pimpri manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.2 KMs','55 Minutes','1	Shagun chauk
2	Karachi chowk
3	Delux
4	Krushnamandir corner
5	Ingale Hospital
6	Vijaynagar
7	Dhangar Nagar Kalewadi
8	Avinash mangal karyalay
9	M M Shala
10	Tapkir Nagar
11	Dhangar Nagar Kalewadi
12	Shrinagar
13	Rahatani phata
14	Kalewadi phata
15	16 Number
16	Laxman nagar
17	Dange chowk
18	Thergaon phata
19	Padmji Paper Mill
20	Dattanagar Chinchwad
21	Birla Hospital
22	Jakatnaka pavanapul
23	Walhekarwadi phata
24	Chafekar chauk
25	Elpro Company
26	Prekshagruha
27	Lokmanya Hospital
28	chinchwad station
29	Chinchwad chauk
30	Premier company
31	Finolex
32	Pimpri chauk Bus stand','1	Shagun chauk
2	Karachi chowk
3	Delux
4	Krushnamandir corner
5	Ingale Hospital
6	Vijaynagar
7	Dhangar Nagar Kalewadi
8	Avinash mangal karyalay
9	M M Shala
10	Tapkir Nagar
11	Dhangar Nagar Kalewadi
12	Shrinagar
13	Rahatani phata
14	Kalewadi phata
15	16 Number
16	Laxman nagar
17	Dange chowk
18	Thergaon phata
19	Padmji Paper Mill
20	Dattanagar Chinchwad
21	Birla Hospital
22	Jakatnaka pavanapul
23	Walhekarwadi phata
24	Chafekar chauk
25	Elpro Company
26	Prekshagruha
27	Lokmanya Hospital
28	chinchwad station
29	Chinchwad chauk
30	Premier company
31	Finolex
32	Pimpri chauk Bus stand','32','06:00
06:55
08:00
09:00
10:30
11:30
12:30
14:10
15:10
16:10
17:10
18:40
19:40
20:35
06:05
07:10
08:10
09:40
10:40
11:40
12:40
14:15
15:20
16:20
17:45
18:50
19:50
20:50
06:20
07:20
08:20
09:20
10:50
11:50
12:50
14:30
15:30
16:25
17:30
19:00
20:00
21:00
06:30
07:30
08:40
10:00
11:00
12:00
12:55
14:40
15:35
16:40
18:10
19:10
20:05
21:10
06:40
07:40
08:35
10:10
11:10
12:05
13:10
14:45
15:50
16:50
18:20
19:20
20:20
21:20
06:50
07:45
08:50
10:15
11:15
12:20
13:20
15:00
16:00
17:00
18:30
19:30
20:30
21:25','06:00
06:55
08:00
09:00
10:30
11:30
12:30
14:10
15:10
16:10
17:10
18:40
19:40
20:35
06:05
07:10
08:10
09:40
10:40
11:40
12:40
14:15
15:20
16:20
17:45
18:50
19:50
20:50
06:20
07:20
08:20
09:20
10:50
11:50
12:50
14:30
15:30
16:25
17:30
19:00
20:00
21:00
06:30
07:30
08:40
10:00
11:00
12:00
12:55
14:40
15:35
16:40
18:10
19:10
20:05
21:10
06:40
07:40
08:35
10:10
11:10
12:05
13:10
14:45
15:50
16:50
18:20
19:20
20:20
21:20
06:50
07:45
08:50
10:15
11:15
12:20
13:20
15:00
16:00
17:00
18:30
19:30
20:30
21:25','Active');
INSERT INTO "busTable" VALUES(228,'371','Pimpri manapa','Pimpri manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.9 KMs','55 Minutes','1	Pimpri chauk Bus stop
2	Finolex
3	Premier company
4	Chinchwad station
5	Lokmanya Hospital
6	Prekshagruha
7	Elpro Company
8	Chafekar chauk
9	Jai Hind Vidyalaya
10	Jakatnaka Pavanapool
11	Birla hospital
12	Dattanagar Chinchwad
13	Padmji Paper Mill
14	Thergaon phata
15	Dange chowk
16	Laxman nagar
17	16 Number
18	Kalewadi phata
19	Rahatani phata
20	Shrinagar
21	Dhangar Nagar Kalewadi
22	Tapgir nagar
23	M M shala
24	Avinash Mangal Karyalaya
25	Dhangar nagar kalewadi
26	Vijaynagar
27	Ingale hospital
28	Krushnamandir Corner
29	Delux
30	Karachi chauk
31	Lalmandir
32	Bhatnagar
33	Finolex
34	Pimpri chauk Bus stand','1	Pimpri chauk Bus stop
2	Finolex
3	Premier company
4	Chinchwad station
5	Lokmanya Hospital
6	Prekshagruha
7	Elpro Company
8	Chafekar chauk
9	Jai Hind Vidyalaya
10	Jakatnaka Pavanapool
11	Birla hospital
12	Dattanagar Chinchwad
13	Padmji Paper Mill
14	Thergaon phata
15	Dange chowk
16	Laxman nagar
17	16 Number
18	Kalewadi phata
19	Rahatani phata
20	Shrinagar
21	Dhangar Nagar Kalewadi
22	Tapgir nagar
23	M M shala
24	Avinash Mangal Karyalaya
25	Dhangar nagar kalewadi
26	Vijaynagar
27	Ingale hospital
28	Krushnamandir Corner
29	Delux
30	Karachi chauk
31	Lalmandir
32	Bhatnagar
33	Finolex
34	Pimpri chauk Bus stand','34','06:05
07:05
08:05
09:05
10:35
11:35
12:35
14:15
15:15
16:15
17:15
18:45
19:45
20:45
06:15
07:15
08:15
09:45
10:45
11:45
12:45
14:25
15:25
16:25
17:45
18:55
19:55
20:55
06:25
07:25
08:25
09:25
10:55
11:55
12:55
14:35
15:35
16:35
17:35
19:05
20:05
21:05
06:35
07:35
08:35
10:05
11:05
12:05
13:05
14:45
15:45
16:45
18:15
19:15
20:15
21:15
06:45
07:45
08:45
10:15
11:15
12:15
13:15
14:55
15:55
16:55
18:25
19:25
20:25
21:25
06:55
07:55
08:55
09:55
10:25
11:25
12:25
13:25
15:05
16:05
17:05
18:35
19:35
20:35
21:35','06:05
07:05
08:05
09:05
10:35
11:35
12:35
14:15
15:15
16:15
17:15
18:45
19:45
20:45
06:15
07:15
08:15
09:45
10:45
11:45
12:45
14:25
15:25
16:25
17:45
18:55
19:55
20:55
06:25
07:25
08:25
09:25
10:55
11:55
12:55
14:35
15:35
16:35
17:35
19:05
20:05
21:05
06:35
07:35
08:35
10:05
11:05
12:05
13:05
14:45
15:45
16:45
18:15
19:15
20:15
21:15
06:45
07:45
08:45
10:15
11:15
12:15
13:15
14:55
15:55
16:55
18:25
19:25
20:25
21:25
06:55
07:55
08:55
09:55
10:25
11:25
12:25
13:25
15:05
16:05
17:05
18:35
19:35
20:35
21:35','Active');
INSERT INTO "busTable" VALUES(229,'376','Nigadi','Katraj bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','33.6 KMs','97 Minutes','1	Nigadi
2	Pradhikaran Chowk
3	Bajaj auto
4	Akurdi Khandoba Chowk
5	Ruston Company
6	Kalbhor nahar bus stop
7	Mehta hospital
8	chinchwad station
9	Chinchwad chauk
10	Premier company
11	Finolex
12	Masulkar Colony
13	Ajmer school
14	Vitthalwadi Mandir Masulkar
15	Wastu Udyog
16	Master bakery
17	Zero Boys
18	Nehrunagar corner
19	PCMT
20	Mahesh nagar
21	YCM
22	Wadilal
23	Vallabhnagar
24	Deichi Company
25	Nashik phata
26	Kasarwadi
27	Forbes marshal stop
28	Alfa Laval Atlas Company
29	Sandwik
30	Fugewadi
31	Dapodi
32	Bopodi Jakat Naka
33	Bopodi
34	Khadaki
35	Khadaki railway station
36	Petrol Pump Khadki
37	Khadaki church stop
38	Khadaki post office
39	Raja bangalow
40	Krutrim Reshim Paidas Kendra
41	Poultry Farm Old Mumbai Pune Road
42	Mariaai Gate Old Mumbai Pune Road
43	Bajaj showroom
44	Labor office
45	Patil Estate
46	Engineering college hostel
47	Shivaji putala
48	PMC Mangala
49	Kasaba Police Chowky
50	Vasant talkies
51	Mandai
52	Shahu chauk
53	Mamledar kacheri
54	Gokul bhavan
55	Swargate
56	Lakshi narayan theature
57	Panchami hotel
58	Bhapkar Petrol Pump City pride
59	Aranyeshwar Corner
60	Natu Bag
61	Padmavati corner
62	Vishweshwar Bank KK market
63	Balaji nagar
64	Chaitanya nagar
65	Bharti vidyapeeth gate
66	Katraj dairy Sarpodyan
67	More bag
68	Katraj bus stand','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Swargate
16	Sarasbag
17	Bhikardas maruti madnir
18	Shanipar
19	A B Chowk
20	Dakshinabhimukh Maruti mandir
21	Shaniwar wada
22	PMC mangala
23	Shivaji putala pmc
24	shimala office shivajinagar
25	Lokmangal
26	Patil Estate
27	Labour office
28	Bajaj showroom wakadewadi
29	Mariaai Gate Old Mumbai Pune Road
30	Poultry Farm Old Mumbai Pune Road
31	Krutrim reshim paidas kendra
32	Raja Bungalow
33	Khadaki post office
34	Khadki church stop
35	Khadaki railway station
36	Khadaki
37	Bopodi
38	Dapodi
39	Fugewadi
40	Sandwik
41	Alfa laval atlas company
42	Forbes marshal stop
43	Kasrawadi
44	Nashik phata
45	Deichi company
46	Vallabhnagar
47	YCM
48	Mahesh nagar
49	PCMT
50	Nehrunagar corner
51	Zero boys
52	Master Bakery
53	Wastu Udyog
54	Vitthalwadi Mandir Masulkar
55	Ajmer school
56	Masulkar Colony
57	Finolex
58	Premier company
59	Chinchwad station
60	Mehta hospital
61	Kalbhor nagar bus stop
62	Rustan company
63	Akurdi khandoba chauk
64	Bajaj auto
65	Pradhikaran Chowk','68','06:00
09:10
13:00
16:25
20:20
06:40
09:55
13:45
17:10
21:05
07:25
10:40
14:30
17:55
21:50
08:00
11:20
15:10
18:35
21:55
08:45
12:05
15:55
19:20
22:40','07:30
11:20
14:45
18:05
22:00
08:15
12:05
15:30
18:50
22:45
09:00
12:50
16:15
19:35
22:30
09:40
13:30
16:55
20:15
23:50
10:25
14:15
17:40
21:00
23:35','Active');
INSERT INTO "busTable" VALUES(230,'376A','Nigadi','Warje Malwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','32.5 KMs','96 Minutes','1	Nigadi
2	Pradhikaran Chowk
3	Bajaj auto
4	Akurdi Khandoba Chowk
5	Ruston Company
6	Kalbhor nahar bus stop
7	Mehta hospital
8	chinchwad station
9	Chinchwad chauk
10	Premier company
11	Finolex
12	Masulkar Colony
13	Ajmer school
14	Vitthalwadi Mandir Masulkar
15	Wastu Udyog
16	Master bakery
17	Zero Boys
18	PCMT
19	Mahesh nagar
20	YCM
21	Wadilal
22	Vallabhnagar
23	Deichi Company
24	Nashik phata
25	Kasarwadi
26	Forbes marshal stop
27	Alfa Laval Atlas Company
28	Sandwik
29	Fugewadi
30	Dapodi
31	Bopodi Jakat Naka
32	Bopodi
33	Khadaki
34	Khadaki railway station
35	Petrol Pump Khadki
36	Khadaki church stop
37	Khadaki post office
38	Raja bangalow
39	Krutrim Reshim Paidas Kendra
40	Poultry Farm Old Mumbai Pune Road
41	Mariaai Gate Old Mumbai Pune Road
42	Bajaj showroom
43	Labor office
44	Patil Estate
45	Engineering college hostel
46	Modern Highschool
47	Balgandharv sambhaji par
48	Deccan Gymkhana
49	Deccan Corner Sambhaji Pul Corner
50	Garware college
51	Petrol Pump Karve Road
52	Nal Stop
53	SNDT college
54	Paud Phata Dashabhuja Ganpati
55	Maruti mandir karve road
56	Karve putala
57	Kothrud Stand
58	Dahanukar colony
59	Wadache Jhad Bhairavnath Mandir
60	Karvenagar
61	Warje Jakatnaka
62	Tapodham
63	Warje Malwadi
64	Dnanesh society
65	Ganpati matha','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Goodluck Chowk
19	F C College
20	Dnyaneshwar paduka chauk
21	shimala office shivajinagar
22	Lokmangal
23	Patil Estate
24	Labour office
25	Bajaj showroom wakadewadi
26	Mariaai Gate Old Mumbai Pune Road
27	Poultry Farm Old Mumbai Pune Road
28	Krutrim reshim paidas kendra
29	Raja Bungalow
30	Khadaki post office
31	Khadki church stop
32	Khadaki railway station
33	Khadaki
34	Bopodi
35	Dapodi
36	Fugewadi
37	Sandwik
38	Alfa laval atlas company
39	Forbes marshal stop
40	Kasrawadi
41	Nashik phata
42	Deichi company
43	Vallabhnagar
44	Wadilal
45	YCM
46	Mahesh nagar
47	PCMT
48	Zero boys
49	Master Bakery
50	Wastu Udyog
51	Vitthalwadi Mandir Masulkar
52	Ajmer school
53	Masulkar Colony
54	Finolex
55	Premier company
56	Chinchwad station
57	Mehta hospital
58	Kalbhor nagar bus stop
59	Rustan company
60	Akurdi khandoba chauk
61	Bajaj auto
62	Pradhikaran Chowk','65','06:10
10:20
14:00
17:20
21:25
08:15
12:20
15:55
19:55
06:45
10:50
14:20
17:50
22:00
09:25
13:30
17:00
21:05
07:30
11:15
14:45
18:15
22:35','08:00
12:10
15:40
19:05
22:25
10:35
14:05
18:10
21:20
08:35
12:40
16:10
19:40
22:50
11:45
15:15
19:20
21:30
09:10
13:00
16:25
20:35
23:45','Active');
INSERT INTO "busTable" VALUES(231,'376B','Nigadi','Hadapsar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','31 KMs','104 Minutes','1	Nigadi
2	Pradhikaran Chowk
3	Bajaj auto
4	Akurdi Khandoba Chowk
5	Ruston Company
6	Kalbhor nahar bus stop
7	Mehta hospital
8	chinchwad station
9	Chinchwad chauk
10	Premier company
11	Finolex
12	Masulkar Colony
13	Ajmer school
14	Vitthalwadi Mandir Masulkar
15	Wastu Udyog
16	Master bakery
17	Zero Boys
18	PCMT
19	Mahesh nagar
20	YCM
21	Wadilal
22	Vallabhnagar
23	Deichi Company
24	Nashik phata
25	Kasarwadi
26	Forbes marshal stop
27	Alfa Laval Atlas Company
28	Sandwik
29	Fugewadi
30	Dapodi
31	Bopodi Jakat Naka
32	Bopodi
33	Khadaki
34	Khadaki railway station
35	Petrol Pump Khadki
36	Khadaki church stop
37	Khadaki post office
38	Raja bangalow
39	Krutrim Reshim Paidas Kendra
40	Poultry Farm Old Mumbai Pune Road
41	Mariaai Gate Old Mumbai Pune Road
42	Bajaj showroom
43	Labor office
44	Patil Estate
45	College of engineering pune
46	RTO wellesley road
47	Juna Bajar
48	Ambedkar bhavan
49	Sasoon hospital
50	Pune station
51	Alankar Talkies
52	Pune Station Depot
53	Sadhu wasvani chauk
54	General post office
55	West end talkies
56	Bombay garaje
57	juna pul gate
58	Mahatma gandhi stand
59	Race course
60	Bhauraba nala
61	Fatimanagar Municipal shala
62	Kalubai mandir
63	Ram tekadi
64	Vaidwadi
65	Gurushankar math
66	Magarpatta
67	Hadapsar gaon
68	Hadapsar gadital','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	Bombay Garage
14	West end talkies
15	GPO
16	Collector kacheri
17	Ambedkar bhavan
18	Juna Bajar
19	RTO wellesley road
20	College of engineering pune
21	Patil Estate
22	Labour office
23	Bajaj showroom wakadewadi
24	Mariaai Gate Old Mumbai Pune Road
25	Poultry Farm Old Mumbai Pune Road
26	Krutrim reshim paidas kendra
27	Raja Bungalow
28	Khadaki post office
29	Khadki church stop
30	Khadaki railway station
31	Khadaki
32	Bopodi
33	Dapodi
34	Fugewadi
35	Sandwik
36	Alfa laval atlas company
37	Forbes marshal stop
38	Kasrawadi
39	Nashik phata
40	Deichi company
41	Vallabhnagar
42	Wadilal
43	YCM
44	Mahesh nagar
45	PCMT
46	Zero boys
47	Master Bakery
48	Wastu Udyog
49	Vitthalwadi Mandir Masulkar
50	Ajmer school
51	Masulkar Colony
52	Finolex
53	Premier company
54	Chinchwad station
55	Mehta hospital
56	Kalbhor nagar bus stop
57	Rustan company
58	Akurdi khandoba chauk
59	Bajaj auto
60	Pradhikaran Chowk','68','07:00
10:15
14:30
18:05
06:50
09:35
13:50
17:25
07:40
11:25
15:10
18:45
05:30
08:55
12:35
16:55
08:20
12:05
15:45
19:25','08:30
12:40
16:15
20:30
07:50
12:00
15:35
19:50
09:10
13:20
16:55
21:10
06:45
10:45
14:30
18:40
09:50
13:55
17:35
21:50','Active');
INSERT INTO "busTable" VALUES(232,'38','Dhanakwadi','narveer tanaji wadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','50 Minutes','1	Dhankawadi
2	Pratibhanagar
3	Gulabnagar
4	Balaji nagar
5	Vishweshwar Bank KK market
6	Padmavati corner
7	Natu bag
8	Aranyeshwar Corner
9	Bhapkar petrol pump City Pride
10	Panchami hotel
11	Laxmi Narayan Theature
12	Swargate
13	Sarasbag
14	Bhikardas maruti madnir
15	Shanipar
16	A B Chowk
17	Dakshinabhimukh Maruti mandir
18	Shaniwar wada
19	PMC mangala
20	Shivaji putala pmc
21	shimala office shivajinagar
22	Shivaji nagar ST Stand
23	N T wadi','1	N T wadi
2	Shivaji nagar S T stand
3	Sancheti Hospital
4	Shivaji putala
5	PMC Mangala
6	Kasaba Police Chowky
7	Vasant talkies
8	Mandai
9	Shahu chauk
10	Gokul bhavan
11	Swargate
12	Lakshi narayan theature
13	Panchami hotel
14	Bhapkar Petrol Pump City pride
15	Aranyeshwar Corner
16	Natu Bag
17	Padmavati corner
18	Vishweshwar Bank KK market
19	Balaji nagar
20	Gulabnagar
21	Pratibhanagar
22	Dhankawadi','23','05:50
07:30
09:10
11:20
13:00
14:50
16:30
18:10
20:20
06:00
07:40
09:20
11:00
13:10
15:00
16:40
18:20
20:30
06:10
07:50
09:30
11:40
13:20
15:00
16:50
18:30
20:40
06:20
08:00
09:40
11:10
13:30
15:20
17:00
18:40
20:50
06:30
08:10
09:50
12:00
13:40
15:30
17:10
18:50
21:00
06:40
08:20
10:00
12:10
14:00
15:40
17:20
19:00
21:10
06:50
08:30
10:10
12:20
14:10
15:50
17:30
19:40
21:20
07:00
08:40
10:20
12:30
14:20
16:00
17:40
19:20
21:30
07:10
08:50
10:30
12:40
14:30
16:10
17:50
20:00
21:40
07:20
09:00
10:40
12:50
14:40
16:20
18:00
20:10
22:00','06:40
08:20
10:30
12:10
13:50
15:40
17:20
19:30
21:10
06:50
08:30
10:10
12:20
14:00
15:50
17:30
19:40
21:20
07:00
08:40
10:50
12:30
14:10
16:00
17:40
19:50
21:30
07:10
08:50
10:30
12:40
14:10
16:10
17:50
20:00
21:40
07:20
09:00
11:10
12:50
14:30
16:20
18:00
20:10
21:50
07:20
09:10
11:20
13:00
14:50
16:30
18:10
20:20
22:00
07:40
09:20
11:30
13:10
15:00
16:40
18:50
20:30
22:10
07:50
09:30
11:40
13:20
15:10
16:50
18:30
20:40
22:20
08:00
09:40
11:50
13:30
15:20
17:00
19:10
20:50
22:30
08:10
09:50
12:00
13:40
15:30
17:10
19:20
21:00
22:50','Active');
INSERT INTO "busTable" VALUES(233,'39','Dhanakwadi','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','51 Minutes','1	Dhankawadi
2	Pratibhanagar
3	Gulabnagar
4	Balaji nagar
5	Vishweshwar Bank KK market
6	Padmavati corner
7	Natu bag
8	Aranyeshwar Corner
9	Bhapkar petrol pump City Pride
10	Mafco Company
11	Shivaji putala Kalubai mandir
12	Godown Marketyard
13	Wakhar Mahamandal Marketyard
14	P and T colony
15	Canol Jhopadpatti
16	Apsara Talkies
17	Ghorpade peth colony
18	Lakud Bajar
19	Sonwane hospital
20	Ramoshi gate
21	Nana peth
22	A D camp chauk
23	Power house
24	Employment Office
25	Sasoon hospital
26	Pune station','1	Pune station
2	Income tax office
3	Employment Office
4	Power house
5	A D camp chauk
6	Nana peth
7	Ramoshi gate
8	Sonwane hospital
9	Lakud Bajar
10	Ghorpadi Peth Colony
11	Apsara Talkies
12	Canol Jhopadpatti
13	P and T colony
14	Wakhar Mahamandal Marketyard
15	Godown Marketyard
16	Shivaji Putala Kalubai Mandir
17	Mafco Company
18	Bhapkar Petrol Pump City pride
19	Aranyeshwar Corner
20	Natu Bag
21	Padmavati corner
22	Vishweshwar Bank KK market
23	Balaji nagar
24	Gulabnagar
25	Pratibhanagar
26	Dhankawadi','26','06:15
07:45
09:15
11:35
13:15
14:50
16:35
18:25
20:40
07:00
08:35
10:15
12:25
14:05
15:40
17:25
19:15
21:30','07:00
08:35
10:45
12:30
14:00
15:40
17:30
19:50
21:30
07:50
09:25
11:35
13:15
14:50
16:30
18:20
20:40
22:20','Active');
INSERT INTO "busTable" VALUES(234,'3R','Katraj bus stand','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','53 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Ghorpade peth colony
16	Lakud Bajar
17	Sonwane hospital
18	Ramoshi gate
19	Nana peth
20	A D camp chauk
21	Power house
22	KEM hospital
23	15 August Lodge Somwar Peth
24	Sasoon hospital
25	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	15 August Lodge Somwar Peth
6	KEM hospital
7	Power house
8	A D camp chauk
9	Nana peth
10	Ramoshi gate
11	Sonwane hospital
12	Lakud Bajar
13	Ghorpadi Peth Colony
14	Swargate police line
15	Swargate
16	Lakshi narayan theature
17	Panchami hotel
18	Bhapkar Petrol Pump City pride
19	Aranyeshwar Corner
20	Natu Bag
21	Padmavati corner
22	Vishweshwar Bank KK market
23	Balaji nagar
24	Chaitanya nagar
25	Bharti vidyapeeth gate
26	Katraj dairy Sarpodyan
27	More bag
28	Katraj bus stand','25','22:30
00:10
03:10','23:30
01:00
04:00','Active');
INSERT INTO "busTable" VALUES(235,'3S ','Katraj bus stand','Mandai','Mon, Tue, Wed, Thu, Fri, Sat, Sun','8 KMs','46 Minutes','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Sarasbag
16	Bhikardas maruti madnir
17	Shanipar
18	Mandai','1	Mandai
2	Mandai
3	Shahu chauk
4	Gokul bhavan
5	Swargate
6	Lakshi narayan theature
7	Panchami hotel
8	Bhapkar Petrol Pump City pride
9	Aranyeshwar Corner
10	Natu Bag
11	Padmavati corner
12	Vishweshwar Bank KK market
13	Balaji nagar
14	Chaitanya nagar
15	Bharti vidyapeeth gate
16	Katraj dairy Sarpodyan
17	More bag
18	Katraj bus stand','18','08:30
09:50
11:10
12:30
14:10
15:30
16:50
18:20
08:45
10:05
11:25
12:45
13:50
15:45
17:05
18:30
09:00
10:20
11:40
13:00
14:50
16:05
17:25
18:45
09:15
10:35
11:55
13:15
14:30
16:20
17:40
19:00
09:30
10:50
12:10
13:30
15:15
16:40
18:00
19:20','09:10
10:30
11:50
13:10
14:50
16:10
17:40
19:00
09:25
10:45
12:05
13:25
14:35
16:25
17:50
19:10
09:40
11:00
15:50
13:40
15:30
16:50
18:05
19:25
09:55
11:15
12:35
13:50
15:10
17:00
18:20
19:40
10:10
11:30
12:50
14:05
16:00
17:20
18:40
20:00','Active');
INSERT INTO "busTable" VALUES(236,'41','Market yard','Sangvi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','19 KMs','74 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	P and T colony
4	Sant namdeo vidyalay
5	Maharshi nagar
6	Mauli bangala
7	Lakshmi narayan theature
8	Swargate
9	Sarasbag
10	Madiwale colony
11	S P college
12	Maharashtra mandal
13	Sahitya parishad peru gate
14	Goodluck Chowk
15	Bhandarkar Institute
16	Symbiosis college
17	Sheti mahamandal
18	Vetal Maharaj chauk
19	Shivaji housing board bus stop
20	ICC bus stop
21	Chatushringi payatha
22	Pune University Gate
23	chavan nagar university road
24	Sakal nagar
25	Sindh colony
26	Baner phata
27	Sanewadi
28	Anand park sindhi colony
29	ITI parihar Chauk
30	Police workshop
31	Body gate
32	Aundh gaon
33	Sangvi Phata
34	Nurses Quarters
35	Ba ra gholap
36	Navi Sangvi
37	Panyachi taki sangvi
38	shitole nagar corner
39	Anand nagar
40	Sangvi goan
41	Vasantdada Putala','1	Vasantdada Putala
2	Sangvi goan
3	Anand nagar
4	shitole nagar corner
5	panyachi takai sangvi
6	Navi Sangvi
7	Bara gholap
8	Nurses Quarters
9	Sangvi Phata
10	Aundh gaon
11	Body gate
12	ITI parihar chauk
13	Aanand park sindhi colony
14	Sanewadi
15	Baner phata
16	Sindh colony
17	Sakal nagar
18	Chavan Nagar University Road
19	Pune University Gate
20	Chatushringi payatha
21	ICC bus stop
22	Shivaji housing board bus stop
23	Vetal Maharaj chauk
24	Sheti mahamandal
25	Symbiosis college
26	Bhandarkar Institute
27	Deccan Gymkhana
28	Sahitya Parishad Peru Gate
29	Maharashtra mandal
30	S P college
31	Madiwale colony
32	Hirabag
33	Swargate corner
34	Swargate
35	Lakshi narayan theature
36	Mauli bangala
37	Maharshi nagar
38	Sant namdeo vidyalay
39	P and T colony
40	Wakhar Mahamandal Marketyard
41	Marketyard','41','06:00
08:20
11:20
13:45
16:45
19:15
06:45
09:05
12:05
14:35
17:35
20:05
07:30
09:50
12:50
15:25
18:25
21:00','07:10
09:35
12:35
15:00
18:00
20:30
07:55
10:20
13:20
15:50
18:50
21:20
08:40
11:05
14:05
16:40
19:40
22:10','Active');
INSERT INTO "busTable" VALUES(237,'42','Katraj bus stand','Nigadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','31 KMs','92 Minutes','1	Katraj bus stand
2	Katraj dairy Sarpodyan
3	Bharti vidyapeeth gate
4	Chaitanya nagar
5	Balaji nagar
6	Vishweshwar Bank KK market
7	Padmavati corner
8	Natu bag
9	Aranyeshwar Corner
10	Bhapkar petrol pump City Pride
11	Panchami hotel
12	Laxmi Narayan Theature
13	Swargate
14	Parvati payatha
15	Dandekar pul
16	Petrol Pump Rajendranagar
17	Lokmanya nagar
18	Ganjwewadi
19	Alka talkies
20	Goodluck Chowk
21	F C College
22	Dnyaneshwar Paduka chowk
23	Lokmangal
24	College of engineering pune
25	Patil Estate
26	Labour office
27	Bajaj showroom wakadewadi
28	Mariaai Gate Old Mumbai Pune Road
29	Poultry Farm Old Mumbai Pune Road
30	Krutrim reshim paidas kendra
31	Raja Bungalow
32	Khadaki post office
33	Khadki church stop
34	Khadaki railway station
35	Khadaki
36	Bopodi
37	Dapodi
38	Fugewadi
39	Sandwik
40	Alfa laval atlas company
41	Forbes marshal stop
42	Kasrawadi
43	Nashik phata
44	Deichi company
45	Vallabhnagar
46	HA Factory D Y Patil college
47	Kharalwadi
48	Pimpri chauk Bus stop
49	Finolex
50	Premier company
51	Chinchwad station
52	Mehta hospital
53	Kalbhor nagar bus stop
54	Rustan company
55	Akurdi khandoba chauk
56	Bajaj auto
57	Pradhikaran Chowk
58	Nigadi jakat naka
59	Bhakti shakti depot','1	Bhakti shakti depot
2	Nigadi jakat naka
3	Nigadi
4	Bajaj auto
5	Akurdi Khandoba Chowk
6	Ruston Company
7	Kalbhor nahar bus stop
8	Mehta hospital
9	chinchwad station
10	Chinchwad chauk
11	Premier company
12	Finolex
13	Pimpri chauk Bus stand
14	Kharalwadi
15	H A Factory
16	Vallabhnagar
17	Deichi Company
18	Nashik phata
19	Kasarwadi
20	Forbes marshal stop
21	Alfa Laval Atlas Company
22	Sandwik
23	Fugewadi
24	Dapodi
25	Bopodi Jakat Naka
26	Bopodi
27	Khadaki
28	Khadaki railway station
29	Khadaki church stop
30	Khadaki post office
31	Raja bangalow
32	Krutrim Reshim Paidas Kendra
33	Poultry Farm Old Mumbai Pune Road
34	Mariaai Gate Old Mumbai Pune Road
35	Bajaj showroom
36	Labor office
37	Patil Estate
38	Engineering college hostel
39	Modern Highschool
40	Balgandharv sambhaji par
41	Deccan Gymkhana
42	Alka talkies
43	Ganjwewadi
44	Lokmanya nagar
45	Petrol pump rajendranagar
46	Dandekar pul
47	Parvati payatha
48	Sarasbag
49	Hirabag
50	Swargate corner
51	Swargate
52	Lakshi narayan theature
53	Panchami hotel
54	Bhapkar Petrol Pump City pride
55	Aranyeshwar Corner
56	Natu Bag
57	Padmavati corner
58	Vishweshwar Bank KK market
59	Balaji nagar
60	Chaitanya nagar
61	Bharti vidyapeeth gate
62	Katraj dairy Sarpodyan
63	Katraj bus stand','59','05:30
08:20
11:50
14:50
18:40
05:40
08:30
12:00
15:00
18:50
05:45
08:35
12:05
15:10
19:00
05:55
08:45
12:15
15:20
19:10
06:00
08:50
12:20
15:30
19:20
06:10
09:00
12:30
15:40
19:30
06:15
09:05
12:35
15:50
19:40
06:25
09:15
12:45
16:00
19:50
06:30
09:20
12:50
16:10
20:00
06:40
09:30
13:00
16:20
20:10
06:45
09:35
13:05
16:20
20:20
06:55
09:45
13:15
16:40
20:30
07:05
10:00
13:30
16:50
20:40
07:15
10:05
13:35
17:00
20:50
07:25
10:15
13:45
17:10
21:00
07:40
10:30
14:00
17:20
22:10
07:45
10:35
14:05
17:30
21:20
07:55
10:45
14:15
17:40
21:30
08:00
10:50
14:20
17:50
21:40
08:10
11:25
14:30
18:00
21:50
08:15
11:05
14:35
18:10
22:00','06:40
09:45
13:20
16:45
20:10
07:00
10:00
13:30
16:50
20:20
07:05
10:05
13:40
17:05
20:30
07:15
10:15
13:45
17:10
20:35
07:20
10:20
13:50
17:25
20:50
07:25
10:25
14:00
17:30
21:05
07:35
10:35
14:05
17:45
21:10
07:45
10:45
14:10
18:00
21:25
07:50
10:55
14:20
18:05
21:30
08:00
11:00
14:30
18:10
21:35
08:05
11:05
14:40
18:25
21:50
08:15
11:15
14:45
18:40
21:55
08:25
12:00
15:00
18:45
22:10
08:35
12:05
15:05
18:50
22:15
08:45
12:15
15:20
19:05
22:30
09:00
12:25
15:30
19:10
22:40
09:05
12:35
15:40
19:25
22:15
09:15
12:45
15:45
19:40
22:55
09:20
12:50
15:50
19:45
23:10
09:25
13:00
16:00
19:50
23:20
09:35
13:05
16:20
20:05
23:30','Active');
INSERT INTO "busTable" VALUES(238,'42A','Bhakti Shakti','Katraj bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','31 KMs','96 Minutes','1	Bhakti shakti depot
2	Nigadi jakat naka
3	Pradhikaran Chowk
4	Bajaj auto
5	Akurdi Khandoba Chowk
6	Ruston Company
7	Kalbhor nahar bus stop
8	Mehta hospital
9	chinchwad station
10	Chinchwad chauk
11	Premier company
12	Finolex
13	Pimpri chauk Bus stand
14	Kharalwadi
15	H A Factory
16	Vallabhnagar
17	Deichi Company
18	Nashik phata
19	Kasarwadi
20	Forbes marshal stop
21	Alfa Laval Atlas Company
22	Sandwik
23	Fugewadi
24	Dapodi
25	Bopodi Jakat Naka
26	Bopodi
27	Khadaki
28	Khadaki railway station
29	Khadaki church stop
30	Khadaki post office
31	Raja bangalow
32	Krutrim Reshim Paidas Kendra
33	Poultry Farm Old Mumbai Pune Road
34	Mariaai Gate Old Mumbai Pune Road
35	Bajaj showroom
36	Labor office
37	Patil Estate
38	College of engineering pune
39	Engineering college hostel
40	Modern Highschool
41	Balgandharv sambhaji par
42	Deccan Gymkhana
43	Alka talkies
44	Ganjwewadi
45	Lokmanya nagar
46	Petrol pump rajendranagar
47	Dandekar pul
48	Parvati payatha
49	Sarasbag
50	Hirabag
51	Swargate corner
52	Swargate
53	Lakshi narayan theature
54	Panchami hotel
55	Bhapkar Petrol Pump City pride
56	Aranyeshwar Corner
57	Natu Bag
58	Padmavati corner
59	Vishweshwar Bank KK market
60	Balaji nagar
61	Chaitanya nagar
62	Bharti vidyapeeth gate
63	Katraj dairy Sarpodyan
64	More bag
65	Katraj bus stand','1	Katraj bus stand
2	More bag
3	Katraj dairy Sarpodyan
4	Bharti vidyapeeth gate
5	Chaitanya nagar
6	Balaji nagar
7	Vishweshwar Bank KK market
8	Padmavati corner
9	Natu bag
10	Aranyeshwar Corner
11	Bhapkar petrol pump City Pride
12	Panchami hotel
13	Laxmi Narayan Theature
14	Swargate
15	Swargate
16	Parvati payatha
17	Dandekar pul
18	Petrol Pump Rajendranagar
19	Lokmanya nagar
20	Ganjwewadi
21	Alka talkies
22	Goodluck Chowk
23	F C College
24	Dnyaneshwar Paduka chowk
25	shimala office shivajinagar
26	Lokmangal
27	RTO wellesley road
28	College of engineering pune
29	Patil Estate
30	Labour office
31	Bajaj showroom wakadewadi
32	Mariaai Gate Old Mumbai Pune Road
33	Poultry Farm Old Mumbai Pune Road
34	Krutrim reshim paidas kendra
35	Raja Bungalow
36	Khadaki post office
37	Khadki church stop
38	Khadaki railway station
39	Khadaki
40	Bopodi
41	Dapodi
42	Fugewadi
43	Sandwik
44	Alfa laval atlas company
45	Forbes marshal stop
46	Kasrawadi
47	Nashik phata
48	Deichi company
49	Vallabhnagar
50	HA Factory D Y Patil college
51	Kharalwadi
52	Pimpri chauk Bus stop
53	Finolex
54	Premier company
55	Chinchwad station
56	Mehta hospital
57	Kalbhor nagar bus stop
58	Rustan company
59	Akurdi khandoba chauk
60	Bajaj auto
61	Nigadi jakat naka
62	Bhakti shakti depot','65','05:40
08:20
11:50
16:30
20:15
06:15
08:50
12:20
16:50
20:25','07:00
09:50
13:20
18:20
22:30
07:30
10:20
13:50
18:30
23:05','Active');
INSERT INTO "busTable" VALUES(239,'43','Katraj bus stand','Nigdi bypass','Mon, Tue, Wed, Thu, Fri, Sat, Sun','36 KMs','73 Minutes','1	Katraj bus stand
2	Dattanagar Highway
3	Trimurti garden
4	Ambegaon Highway
5	Shubham hotel
6	Krushnai Mangal Karyalaya
7	Wadgaon bu. Highway
8	Daulatnagar Patilbag
9	Warje gaon highway
10	Popular Nagar Cipla cancer care entre
11	Atulnagar gate
12	Aditya garden city
13	Wonder funkey
14	Raviraj residency
15	Chandani chauk
16	Paranjpe scheme
17	Nisarg Aaditya group
18	DSK Toyota Showroom
19	HRA relance
20	Sutarwadi
21	Sayali Restaurant
22	Soos phata
23	Shivsagar mangal karyalay
24	Yashoda Nivas
25	Mhalunge corner
26	Chha. Shivaji Krida Sankul
27	Mutha Pool Balewadi
28	Wakad Highway
29	BU Bhandari Showroom
30	Wakad Police Chowky
31	Dange chowk
32	Padmji Paper Mill
33	Dattanagar Chinchwad
34	Birla Hospital
35	Jakatnaka pavanapul
36	Walhekarwadi phata
37	Chafekar chauk
38	Chinchwad station
39	Mehta hospital
40	Kalbhor nagar bus stop
41	Rustan company
42	Akurdi khandoba chauk
43	Bajaj auto
44	Pradhikaran Chowk
45	Nigadi jakat naka
46	Bhakti shakti depot','1	Bhakti shakti depot
2	Nigadi jakat naka
3	Nigadi
4	Bajaj auto
5	Akurdi Khandoba Chowk
6	Ruston Company
7	Kalbhor nahar bus stop
8	Mehta hospital
9	chinchwad station
10	Chafekar chauk
11	Walhekarwadi Phata
12	Jakatnaka Pavanapool
13	Birla hospital
14	Dattanagar Chinchwad
15	Padmji Paper Mill
16	Dange chowk
17	Wakad Police Chowky
18	BU Bhandari Showroom
19	Wakad Highway
20	Mutha Pool Balewadi
21	Chh.Shivaji krida sankul
22	Mhalunge corner
23	Yashoda nivas
24	Shivsagar mangal karyalaya
25	Soos Phata
26	Sayli Restaurant
27	Sutarwadi
28	HRA Relance
29	DSK Toyota Showroom
30	Nisarg Aaditya group
31	Paranjpe Scheme
32	Chandani chauk
33	Raviraj Residency
34	Wonder funkey
35	Aditya garden city
36	Atulnagar gate
37	Popular Nagar Cipla cancer care entre
38	Warje Gaon Highway
39	Daulatnagar PatilBag
40	Wadgaon Budruk Highway
41	Krushnai Mangal Karyalaya
42	Shubham Hotel
43	Ambegaon Highway
44	Trimurti Garden
45	Dattanagar Highway
46	Katraj bus stand','46','05:30
08:05
11:30
15:05
16:05
19:35
06:10
09:00
12:25
16:00
17:00
20:30','06:40
09:30
12:55
15:35
17:35
21:05
07:30
10:25
13:25
16:30
18:35
21:50','Active');
INSERT INTO "busTable" VALUES(240,'45','Swargate','Vidyanagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18 KMs','53 Minutes','1	Swargate
2	Sarasbag
3	Madiwale colony
4	S P college
5	Maharashtra mandal
6	Sahitya parishad peru gate
7	Goodluck Chowk
8	F C College
9	Dnyaneshwar Paduka chowk
10	shimala office shivajinagar
11	Patil Estate
12	Labour office
13	Bajaj showroom wakadewadi
14	Mariaai Gate Old Mumbai Pune Road
15	Poultry Farm Old Mumbai Pune Road
16	Mula road bhaiyawadi
17	Pachawadw
18	Holkar Water Supply
19	Sapras post
20	Deccan college
21	Ambedkar Society
22	RTO New
23	Phulenagar
24	MES Water Works
25	Mental Hospital Corner
26	Shantinagar
27	Sathe Biscuit company
28	Vishrantwadi
29	Vishrantwadi corner
30	Kasturba general hospital
31	Gandhi Acid Company
32	Tingre nagar Shanti nagar
33	Medical Stores
34	Grampanchayat Tingrenagar
35	Vidyanagar Swapnaganga bangalow','1	Vidyanagar Swapnaganga bangalow
2	Grampanchayat Tingrenagar
3	Medical stores
4	Tingre nagar Shanti nagar
5	Gandhi Acid Company
6	Kasturba general hospital
7	Vishrantwadi corner
8	Vishrantwadi
9	Sathe Biscuit company
10	Shantinagar
11	Mental Hospital Corner
12	MES Water Works
13	Phulenagar
14	RTO New
15	Ambedkar Society
16	Deccan college
17	Sapras post
18	Holkar Water Supply
19	Pachwade
20	Mula bhaiyawadi
21	Poultry Farm Old Mumbai Pune Road
22	Mariaai Gate Old Mumbai Pune Road
23	Bajaj showroom
24	Labor office
25	Patil Estate
26	Engineering college hostel
27	Modern Highschool
28	Balgandharv sambhaji par
29	Deccan Gymkhana
30	Sahitya Parishad Peru Gate
31	Maharashtra mandal
32	S P college
33	Madiwale colony
34	Hirabag
35	Swargate corner
36	Swargate
37	Swargate','35','05:30
07:00
08:35
11:00
15:45
17:45','06:10
07:45
09:25
12:00
16:45
18:50','Active');
INSERT INTO "busTable" VALUES(241,'46','Swargate','Lohgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','70 Minutes','1	Swargate
2	Sarasbag
3	Madiwale colony
4	S P college
5	Maharashtra mandal
6	Sahitya parishad peru gate
7	Goodluck Chowk
8	F C College
9	Dnyaneshwar Paduka chowk
10	shimala office shivajinagar
11	Lokmangal
12	Patil Estate
13	Labour office
14	Bajaj showroom wakadewadi
15	Mariaai Gate Old Mumbai Pune Road
16	Poultry Farm Old Mumbai Pune Road
17	Mula road bhaiyawadi
18	Pachawadw
19	Holkar Water Supply
20	Sapras post
21	Deccan college
22	Ambedkar Society
23	RTO New
24	Phulenagar
25	MES Water Works
26	Mental Hospital Corner
27	Shantinagar
28	Sathe Biscuit company
29	Vishrantwadi
30	Panyachi Taki
31	Bhairavnagar
32	Gokul Nagar
33	Sai Corner
34	Dhanori Gaon
35	Lohoan','1	Lohoan
2	Dhanori Gaon
3	Sai Corner
4	Gokul Nagar
5	Bhairavnagar
6	Panyachi Taki
7	Vishrantwadi
8	Sathe Biscuit company
9	Shantinagar
10	Mental Hospital Corner
11	MES Water Works
12	Phulenagar
13	RTO New
14	Ambedkar Society
15	Deccan college
16	Sapras post
17	Holkar Water Supply
18	Pachwade
19	Mula bhaiyawadi
20	Poultry Farm Old Mumbai Pune Road
21	Mariaai Gate Old Mumbai Pune Road
22	Bajaj showroom
23	Labor office
24	Patil Estate
25	Engineering college hostel
26	Modern Highschool
27	Balgandharv sambhaji par
28	Deccan Gymkhana
29	Sahitya Parishad Peru Gate
30	Maharashtra mandal
31	S P college
32	Madiwale colony
33	Hirabag
34	Swargate corner
35	Swargate
36	Swargate','35','06:00
07:55
10:15
12:50
15:30
18:15','06:55
09:05
11:20
13:50
16:55
19:40','Active');
INSERT INTO "busTable" VALUES(242,'47','Shaniwar wada','Sanaswadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18 KMs','63 Minutes','1	Surya hospital
2	Kasaba Police Chowky
3	Vasant talkies
4	Mandai
5	Shahu chauk
6	Gokul bhavan
7	Swargate
8	Parvati payatha
9	Dandekar pul
10	Pan mala Sinhgad Road
11	Jal Shuddhikarn Kendra Sinhgad Road
12	Ganesh mala
13	Vitbhatti Sinhgad Road
14	Vitthalwadi jakat naka
15	Jaydeo nagar
16	Rajaram pul
17	Vitthalwadi Mandir Hingne
18	Hingne rasta
19	Anand nagar singhgad rd
20	Manik Bag
21	Indian hum company
22	Wadgaon phata
23	Patil colony
24	Dhayari phata
25	Lagad wasti
26	Mate Pat Sasa company
27	Nanded Phata
28	Jadhavwadi Andh shala
29	CWPRS gate no.1
30	Nandoshi Phata
31	Nivedita Jhula Ghar Kirkat wadi
32	Malwadi Kirkat wadi
33	Hagwane Padwal
34	Mal Hagwane wasti
35	Nandoshi Limbache Zad
36	Nandoshi
37	Jivan Shikshan Mandir Wanjal Wadi
38	Sanaswadi Nandoshi','1	Sanaswadi Nandoshi
2	Jivan shikshan mandir wanjalwadi
3	Nandoshi
4	Nandoshi Limbache jhad
5	Mal Hagwane wasti
6	Hagwane padwal
7	Malwadi Kirkatwadi
8	Nivedita Jhula Ghar Kirkat wadi
9	Nandoshi phata
10	CWPRS Gate no.1
11	Jadhavwadi Andh shala
12	Nanded phata
13	Mate Pat Sasa company
14	Lagad wasti
15	Dhayari phata
16	Patil colony
17	Wadgaon phata
18	Indican hyum company
19	Manik bag
20	Anand nagar
21	Hingne rasta
22	Vitthalwadi mandir hingne
23	RajaramPool
24	Jaydeo nagar
25	Vitthalwadi Jakat Naka
26	Vitbhatti singhgad rd
27	Ganesh mala
28	Jal shudhikaran kendra singhroad rd
29	Pan mala siinghgad road
30	Dandekar pul
31	Parvati payatha
32	Sarasbag
33	Bhikardas maruti madnir
34	Shanipar
35	A B Chowk
36	Dakshinabhimukh Maruti mandir
37	Shaniwar wada
38	Surya hospital','38','07:45
09:45
12:20
16:15
18:30
21:10','08:45
10:50
13:20
17:15
19:40
22:10','Active');
INSERT INTO "busTable" VALUES(243,'48','Pune Station','Venutai College','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','61 Minutes','1	Jayprakash Stand Pune station
2	Pune station
3	Alankar Talkies
4	Sadhu wasvani chauk
5	GPO
6	Collector kacheri
7	Ambedkar bhavan
8	Juna Bajar
9	Engineering college hostel
10	Modern Highschool
11	Balgandharv sambhaji par
12	Deccan Gymkhana
13	Alka talkies
14	Ganjwewadi
15	Lokmanya nagar
16	Dattawadi pul
17	Mhasoba Chowk
18	Raksha Lekha Society
19	Jal Shuddhikarn Kendra Sinhgad Road
20	Ganesh mala
21	Vitbhatti Sinhgad Road
22	Vitthalwadi jakat naka
23	Jaydeo nagar
24	Rajaram pul
25	Vitthalwadi Mandir Hingne
26	Hingne rasta
27	Anand nagar singhgad rd
28	Manik Bag
29	Indian hum company
30	Wadgaon phata
31	Jadhav nagar
32	Wadgaon budruk
33	Venutai College','1	Venutai College
2	Wadgaon budruk
3	Jadhav nagar
4	Wadgaon phata
5	Indican hyum company
6	Manik bag
7	Anand nagar
8	Hingne rasta
9	Vitthalwadi mandir hingne
10	RajaramPool
11	Jaydeo nagar
12	Vitthalwadi Jakat Naka
13	Vitbhatti singhgad rd
14	Ganesh mala
15	Jal shudhikaran kendra singhroad rd
16	Raksha Lekha Society
17	Mhasoba Chowk
18	Dattawadi pul
19	Lokmanya nagar
20	Ganjwewadi
21	Goodluck Chowk
22	F C College
23	Dnyaneshwar Paduka chowk
24	shimala office shivajinagar
25	Lokmangal
26	Juna Bajar
27	Ambedkar bhavan
28	Sasoon hospital
29	Pune station
30	Jayprakash Stand Pune station','33','06:50
09:00
11:40
13:50
15:55
18:05
20:45','08:00
10:00
12:40
14:50
16:55
19:10
21:40','Active');
INSERT INTO "busTable" VALUES(244,'49','Pune Station','Khanapur','Mon, Tue, Wed, Thu, Fri, Sat, Sun','28 KMs','84 Minutes','1	Jayprakash Stand Pune station
2	Pune station
3	Sadhu wasvani chauk
4	GPO
5	Collector kacheri
6	Zila Parishad
7	KEM hospital
8	Apolo Talkies
9	RCM
10	Daruwala Pool
11	Sonya Maruti Chowk
12	City post
13	Kunte Chauk
14	Gokhale hall
15	Vijay Talkies
16	Alka talkies
17	Alka talkies
18	Ganjwewadi
19	Lokmanya nagar
20	Petrol pump rajendranagar
21	Dandekar pul
22	Pan mala Sinhgad Road
23	Jal Shuddhikarn Kendra Sinhgad Road
24	Ganesh mala
25	Vitbhatti Sinhgad Road
26	Vitthalwadi jakat naka
27	Jaydeo nagar
28	Rajaram pul
29	Vitthalwadi Mandir Hingne
30	Hingne rasta
31	Anand nagar singhgad rd
32	Manik Bag
33	Indian hum company
34	Wadgaon phata
35	Patil colony
36	Dhayari phata
37	Lagad wasti
38	Mate Pat Sasa company
39	Nanded Phata
40	Jadhavwadi Andh shala
41	CWPRS gate no.1
42	Nandoshi Phata
43	Kolhewadi
44	Khadakwasla Gaon
45	Khadakwasla Dharan
46	Childrens School
47	IAT Gate Girinagar
48	Sant Dharmaji Samadhi
49	Gorhe Budruk
50	Gorhe bu. jeevan shikshan mandir
51	Donje Goan Phata
52	Paygude wasti Donje
53	Venkatesh poultry farm
54	Gorhe khurd
55	Malatwadi
56	Khanapur','1	Khanapur
2	Malatwadi
3	Gorhe Khurd
4	Venkatesh Poultry Farm
5	Paygide wasti Donje
6	Donje gaon phata
7	Gorhe Bu Jeevan Shikshan Mandir
8	Gorhe Budruk
9	Saint Dharmaji Samadhi
10	IAT Gate Girinagar
11	Childrens school
12	Khadakwasala Dharan
13	Khadakwasala gaon
14	Kolhewadi
15	Nandoshi phata
16	CWPRS Gate no.1
17	Jadhavwadi Andh shala
18	Nanded phata
19	Mate Pat Sasa company
20	Lagad wasti
21	Dhayari phata
22	Patil colony
23	Wadgaon phata
24	Indican hyum company
25	Manik bag
26	Anand nagar
27	Hingne rasta
28	Vitthalwadi mandir hingne
29	RajaramPool
30	Jaydeo nagar
31	Vitthalwadi Jakat Naka
32	Vitbhatti singhgad rd
33	Ganesh mala
34	Jal shudhikaran kendra singhroad rd
35	Pan mala siinghgad road
36	Dandekar pul
37	Petrol Pump Rajendranagar
38	Lokmanya nagar
39	Ganjwewadi
40	Alka talkies
41	Chitrashala
42	Sadashiv Peth Houd
43	A B Chowk
44	Dakshinabhimukh Maruti mandir
45	Shaniwar wada
46	Kasaba Police Chowky
47	Lalmahal
48	RCM
49	Apolo Talkies
50	KEM hospital
51	Ambedkar bhavan
52	Sasoon hospital
53	Pune station
54	Jayprakash Stand Pune station','56','07:45
10:40
15:15
18:15','08:55
12:15
16:40
19:40','Active');
INSERT INTO "busTable" VALUES(245,'4S','Pune Station','Alandi bus stand','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','57 Minutes','1	Pune Station Depot
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Pune station
6	Ruby hall
7	Wadia college
8	Guruprasad bangala
9	Band garden
10	Yerwada
11	Shadal baba Darga
12	Deccan college
13	Ambedkar Society
14	RTO New
15	Phulenagar
16	MES Water Works
17	Mental Hospital Corner
18	Shantinagar
19	Sathe Biscuit company
20	Vishrantwadi
21	R D colony
22	kalasgaon
23	Mhaske wasti
24	Parade ground
25	Wireless colony
26	AIT college
27	Dighigaon
28	Mitra sahakar nagar
29	Dattanagar
30	Telco godown
31	Bhosari phata
32	Moje vidyalaya
33	Sai madnir
34	Nirma company
35	Gokhale Mala Sankalpa Garden
36	Wadmukhwadi
37	Chincheche jhad
38	Charholi phata
39	Sai Lila nagar Kate Wasti
40	Moshi Phata Dehu Phata
41	Alandi bus stand','1	Alandi bus stand
2	Dehu phata
3	Sai lila nagar kate wasti
4	Charholi phata
5	Chincheche jhad
6	Wadmukhwadi
7	Gokhale mala sankalp garden
8	Nirma company
9	Sai mandir
10	Moje vidyalaya
11	Bhosari phata
12	Telco godown
13	Dattanagar
14	Mitra sahkar nagar
15	Dighigaon
16	AIT college
17	Wireless colony
18	Parade ground
19	Mhaske wasti
20	Kalasgaon
21	R D colony
22	Vishrantwadi
23	Sathe Biscuit company
24	Shantinagar
25	Mental Hospital Corner
26	MES Water Works
27	Phulenagar
28	RTO New
29	Ambedkar Society
30	Deccan college
31	Shadal baba Darga
32	Yerwada
33	Band garden
34	Guruprasad bangala
35	Jahangir Hospital
36	Alankar Talkies
37	Pune Station Depot','41','05:25
07:20
09:25
12:05
14:10
16:15
18:30
21:00
05:55
07:40
09:45
12:25
14:40
16:45
19:30
21:25
06:20
08:00
10:05
12:50
15:05
17:10
19:05
06:55
09:05
11:05
13:15
15:55
18:05
20:10
08:30
10:35
13:40
15:30
17:40','06:05
08:20
10:25
13:05
15:10
17:20
19:30
21:50
06:35
08:40
10:45
13:25
15:40
17:45
20:25
22:15
07:05
09:00
11:05
13:50
16:05
18:10
20:05
07:35
10:00
12:05
14:15
16:55
19:05
21:10
09:30
11:35
14:35
16:30
18:40','Active');
INSERT INTO "busTable" VALUES(246,'5','Swargate','Pune station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','5 KMs','29 Minutes','1	Swargate
2	Ghorpade peth colony
3	Lakud Bajar
4	Sonwane hospital
5	Ramoshi gate
6	Nana peth
7	A D camp chauk
8	Power house
9	KEM hospital
10	Ambedkar bhavan
11	Sasoon hospital
12	Pune station','1	Pune station
2	Income tax office
3	Collector kacheri
4	Ambedkar bhavan
5	KEM hospital
6	Power house
7	A D camp chauk
8	Nana peth
9	Ramoshi gate
10	Sonwane hospital
11	Lakud Bajar
12	Ghorpadi Peth Colony
13	Swargate','12','06:45
07:35
08:25
09:15
10:05
10:55
11:45
12:35
13:25
14:45
15:45
16:45
17:45
18:45
19:45
20:45
06:50
07:40
08:30
09:20
10:10
11:00
11:50
12:40
13:30
14:50
15:50
16:50
17:50
18:50
19:50
20:50
06:55
07:45
08:35
09:25
10:15
11:05
11:55
12:45
13:35
14:55
15:55
16:55
17:55
18:55
19:55
20:55
07:00
07:50
08:40
09:30
10:20
11:10
12:00
12:50
13:50
15:00
16:00
17:00
18:00
19:00
20:00
21:00
07:05
07:55
08:45
09:35
10:25
11:15
12:05
12:55
13:45
15:10
16:10
17:10
18:10
19:10
20:10
21:10
06:45
07:35
08:25
09:15
10:05
10:55
11:45
12:35
13:25
14:45
15:45
16:45
17:45
18:45
19:45
20:45
06:50
07:40
08:30
09:20
10:10
11:00
11:50
12:40
13:30
14:50
15:50
16:50
17:50
18:50
19:50
20:50
06:55
07:45
08:35
09:25
10:15
11:05
11:55
12:45
13:35
14:55
15:55
16:55
17:55
18:55
19:55
20:55
07:00
07:50
08:40
09:30
10:20
11:10
12:00
12:50
13:40
15:00
16:00
17:00
18:00
19:00
20:00
21:00
07:05
07:55
08:45
09:35
10:25
11:15
12:05
12:55
13:45
15:10
16:10
17:10
18:10
19:10
20:10
21:10','06:45
07:35
08:25
09:15
10:05
10:55
11:45
12:35
13:25
14:45
15:45
16:45
17:45
18:45
19:45
20:45
06:50
07:40
08:30
09:20
10:10
11:00
11:50
12:40
13:30
14:50
15:50
16:50
17:50
18:50
19:50
20:50
06:55
07:45
08:35
09:25
10:15
11:05
11:55
12:45
13:35
14:55
15:55
16:55
17:55
18:55
19:55
20:55
07:00
07:50
08:40
09:30
10:20
11:10
12:00
12:50
13:50
15:00
16:00
17:00
18:00
19:00
20:00
21:00
07:05
07:55
08:45
09:35
10:25
11:15
12:05
12:55
13:45
15:10
16:10
17:10
18:10
19:10
20:10
21:10
06:45
07:35
08:25
09:15
10:05
10:55
11:45
12:35
13:25
14:45
15:45
16:45
17:45
18:45
19:45
20:45
06:50
07:40
08:30
09:20
10:10
11:00
11:50
12:40
13:30
14:50
15:50
16:50
17:50
18:50
19:50
20:50
06:55
07:45
08:35
09:25
10:15
11:05
11:55
12:45
13:35
14:55
15:55
16:55
17:55
18:55
19:55
20:55
07:00
07:50
08:40
09:30
10:20
11:10
12:00
12:50
13:40
15:00
16:00
17:00
18:00
19:00
20:00
21:00
07:05
07:55
08:45
09:35
10:25
11:15
12:05
12:55
13:45
15:10
16:10
17:10
18:10
19:10
20:10
21:10','Active');
INSERT INTO "busTable" VALUES(247,'50','Shaniwar wada','Singhgad payatha','Mon, Tue, Wed, Thu, Fri, Sat, Sun','25 KMs','80 Minutes','1	Surya hospital
2	Kasaba Police Chowky
3	Vasant talkies
4	Mandai
5	Shahu chauk
6	Mamledar kacheri
7	Gokul bhavan
8	Swargate
9	Parvati payatha
10	Dandekar pul
11	Pan mala Sinhgad Road
12	Jal Shuddhikarn Kendra Sinhgad Road
13	Ganesh mala
14	Vitbhatti Sinhgad Road
15	Vitthalwadi jakat naka
16	Jaydeo nagar
17	Rajaram pul
18	Vitthalwadi Mandir Hingne
19	Hingne rasta
20	Anand nagar singhgad rd
21	Manik Bag
22	Indian hum company
23	Wadgaon phata
24	Patil colony
25	Dhayari phata
26	Lagad wasti
27	Mate Pat Sasa company
28	Nanded Phata
29	Jadhavwadi Andh shala
30	CWPRS gate no.1
31	Nandoshi Phata
32	Kolhewadi
33	Khadakwasla Gaon
34	Khadakwasla Dharan
35	Childrens School
36	IAT Gate Girinagar
37	Sant Dharmaji Samadhi
38	Gorhe Budruk
39	Gorhe bu. jeevan shikshan mandir
40	Donje Goan Phata
41	Harijan wasti
42	Krishnai water park
43	Golewadi
44	Mandhare wasti pole phata
45	Tilak Bag
46	Sinhgad Payth Aatekar wasti','1	Sinhgad Payth Aatekar wasti
2	Tilak bag
3	Mandhre wasti Pole Phata
4	Golewadi
5	Krushnai Water Park
6	Harijan wasti
7	Donje gaon phata
8	Gorhe Bu Jeevan Shikshan Mandir
9	Gorhe Budruk
10	Saint Dharmaji Samadhi
11	IAT Gate Girinagar
12	Childrens school
13	Khadakwasala Dharan
14	Khadakwasala gaon
15	Kolhewadi
16	Nandoshi phata
17	CWPRS Gate no.1
18	Jadhavwadi Andh shala
19	Nanded phata
20	Mate Pat Sasa company
21	Lagad wasti
22	Dhayari phata
23	Patil colony
24	Wadgaon phata
25	Indican hyum company
26	Manik bag
27	Anand nagar
28	Hingne rasta
29	Vitthalwadi mandir hingne
30	RajaramPool
31	Jaydeo nagar
32	Vitthalwadi Jakat Naka
33	Vitbhatti singhgad rd
34	Ganesh mala
35	Jal shudhikaran kendra singhroad rd
36	Pan mala siinghgad road
37	Dandekar pul
38	Parvati payatha
39	Sarasbag
40	Bhikardas maruti madnir
41	Shanipar
42	A B Chowk
43	Dakshinabhimukh Maruti mandir
44	Shaniwar wada
45	Surya hospital','46','07:35
10:45
13:35
16:15
19:30
08:00
11:15
14:00
16:40
19:50
06:00
08:35
11:45
14:30
17:10
20:20
06:30
09:05
12:15
15:00
17:40
20:50
07:05
09:40
12:50
15:35
18:15
18:15
21:35','08:55
12:05
14:55
17:35
20:50
09:20
12:35
15:20
18:00
21:10
07:00
09:55
13:05
15:50
18:30
21:40
07:50
10:25
13:35
16:20
19:00
22:10
08:25
11:00
14:10
16:55
19:45
19:45
22:55','Active');
INSERT INTO "busTable" VALUES(248,'51','Shivajinagar Station','Dhyari maruti mandir','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13.2 KMs','56 Minutes','1	Shivajinagar Station
2	Lokmangal
3	Engineering college hostel
4	Modern Highschool
5	Balgandharv sambhaji par
6	Deccan Gymkhana
7	Alka talkies
8	Ganjwewadi
9	Lokmanya nagar
10	Dattawadi pul
11	Mhasoba Chowk
12	Raksha Lekha Society
13	Jal Shuddhikarn Kendra Sinhgad Road
14	Ganesh mala
15	Vitbhatti Sinhgad Road
16	Vitthalwadi jakat naka
17	Jaydeo nagar
18	Rajaram pul
19	Vitthalwadi Mandir Hingne
20	Hingne rasta
21	Anand nagar singhgad rd
22	Manik Bag
23	Indian hum company
24	Wadgaon phata
25	Patil colony
26	Dhayari phata
27	Sanas Vidyalaya
28	Dangat wasti
29	Gar mala
30	Dhayarai gaon
31	Raykar wasti
32	Poultry farm singhgad road
33	Maruti Mandir
34	Dhayreshwar Mandir','1	Dhayreshwar Mandir
2	Maruti Mandir
3	Poultry Farm Sinhgadh Road
4	Raykar wasti
5	Dhayari Gaon
6	Gar mala
7	Dangat wasti
8	Sanas Vidyalaya
9	Dhayari phata
10	Patil colony
11	Wadgaon phata
12	Indican hyum company
13	Manik bag
14	Anand nagar
15	Hingne rasta
16	Vitthalwadi mandir hingne
17	RajaramPool
18	Jaydeo nagar
19	Vitthalwadi Jakat Naka
20	Vitbhatti singhgad rd
21	Ganesh mala
22	Jal shudhikaran kendra singhroad rd
23	Raksha Lekha Society
24	Mhasoba Chowk
25	Dattawadi pul
26	Lokmanya nagar
27	Ganjwewadi
28	Alka talkies
29	Goodluck Chowk
30	F C College
31	Dnyaneshwar paduka chauk
32	shimala office shivajinagar
33	Shivajinagar Station','34','06:30
08:00
10:00
12:30
16:05
18:00
20:30','07:15
09:00
11:00
13:20
17:00
19:00
21:30','Active');
INSERT INTO "busTable" VALUES(249,'52','Shaniwar wada','Wardade gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','29 KMs','77 Minutes','1	Surya hospital
2	Kasaba Police Chowky
3	Vasant talkies
4	Mandai
5	Shahu chauk
6	Mamledar kacheri
7	Gokul bhavan
8	Swargate
9	Parvati payatha
10	Dandekar pul
11	Pan mala Sinhgad Road
12	Jal Shuddhikarn Kendra Sinhgad Road
13	Ganesh mala
14	Vitbhatti Sinhgad Road
15	Vitthalwadi jakat naka
16	Jaydeo nagar
17	Rajaram pul
18	Vitthalwadi Mandir Hingne
19	Hingne rasta
20	Anand nagar singhgad rd
21	Manik Bag
22	Indian hum company
23	Wadgaon phata
24	Patil colony
25	Dhayari phata
26	Lagad wasti
27	Mate Pat Sasa company
28	Nanded Phata
29	Jadhavwadi Andh shala
30	CWPRS gate no.1
31	Nandoshi Phata
32	Kolhewadi
33	Khadakwasla Gaon
34	Khadakwasla Dharan
35	Childrens School
36	IAT Gate Girinagar
37	Gorhe Budruk
38	Gorhe bu. jeevan shikshan mandir
39	Donje Goan Phata
40	Paygude wasti Donje
41	Venkatesh poultry farm
42	Gorhe khurd
43	Malatwadi
44	Khanapur
45	Shantiban
46	Malkhed
47	Wardade phata
48	Wardade','1	Wardade
2	Wardade Phata
3	Malkhed
4	Shantiban
5	Khanapur
6	Malatwadi
7	Gorhe Khurd
8	Venkatesh Poultry Farm
9	Paygide wasti Donje
10	Donje gaon phata
11	Gorhe Bu Jeevan Shikshan Mandir
12	Gorhe Budruk
13	IAT Gate Girinagar
14	Childrens school
15	Khadakwasala Dharan
16	Khadakwasala gaon
17	Kolhewadi
18	Nandoshi phata
19	CWPRS Gate no.1
20	Jadhavwadi Andh shala
21	Nanded phata
22	Mate Pat Sasa company
23	Lagad wasti
24	Dhayari phata
25	Patil colony
26	Wadgaon phata
27	Indican hyum company
28	Manik bag
29	Anand nagar
30	Hingne rasta
31	Vitthalwadi mandir hingne
32	RajaramPool
33	Jaydeo nagar
34	Vitthalwadi Jakat Naka
35	Vitbhatti singhgad rd
36	Ganesh mala
37	Jal shudhikaran kendra singhroad rd
38	Pan mala siinghgad road
39	Dandekar pul
40	Parvati payatha
41	Sarasbag
42	Bhikardas maruti madnir
43	Shanipar
44	A B Chowk
45	Dakshinabhimukh Maruti mandir
46	Shaniwar wada
47	Surya hospital','48','07:55
11:10
14:00
17:00
20:10
09:00
12:25
17:50
21:15
06:45
10:10
13:15
16:25
19:05
22:15','09:15
12:30
15:30
18:20
21:30
10:30
13:45
19:20
22:30
08:05
11:40
14:30
17:45
20:25','Active');
INSERT INTO "busTable" VALUES(250,'53','Shaniwar wada','DSK Vishwa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14 KMs','56 Minutes','1	Surya hospital
2	Kasaba Police Chowky
3	Vasant talkies
4	Kunte Chauk
5	Gokhale hall
6	Vijay Talkies
7	Alka talkies
8	Alka talkies
9	Ganjwewadi
10	Lokmanya nagar
11	Petrol pump rajendranagar
12	Pan mala Sinhgad Road
13	Jal Shuddhikarn Kendra Sinhgad Road
14	Ganesh mala
15	Vitbhatti Sinhgad Road
16	Vitthalwadi jakat naka
17	Jaydeo nagar
18	Rajaram pul
19	Vitthalwadi Mandir Hingne
20	Hingne rasta
21	Anand nagar singhgad rd
22	Manik Bag
23	Indian hum company
24	Wadgaon phata
25	Patil colony
26	Dhayari phata
27	Sanas Vidyalaya
28	Dangat wasti
29	Gar mala
30	Dhayarai gaon
31	Raykar wasti
32	Poultry farm singhgad road
33	Dhayarigaon shala
34	Chavan mala
35	DSK Vishwa','1	DSK Vishwa
2	chavan mala
3	Dhayarigaon Shala
4	Poultry Farm Sinhgadh Road
5	Raykar wasti
6	Dhayari Gaon
7	Gar mala
8	Dangat wasti
9	Sanas Vidyalaya
10	Dhayari phata
11	Patil colony
12	Wadgaon phata
13	Indican hyum company
14	Manik bag
15	Anand nagar
16	Hingne rasta
17	Vitthalwadi mandir hingne
18	RajaramPool
19	Jaydeo nagar
20	Vitthalwadi Jakat Naka
21	Vitbhatti singhgad rd
22	Ganesh mala
23	Jal shudhikaran kendra singhroad rd
24	Pan mala siinghgad road
25	Petrol Pump Rajendranagar
26	Lokmanya nagar
27	Ganjwewadi
28	Alka talkies
29	Chitrashala
30	Sadashiv Peth Houd
31	A B Chowk
32	Dakshinabhimukh Maruti mandir
33	Shaniwar wada
34	Surya hospital','35','07:25
09:15
11:35
15:40
17:40
19:40
22:00
08:25
10:15
12:30
16:10
18:40
20:40
22:30
10:00
15:10
17:10','06:30
08:20
10:10
12:30
16:40
18:40
20:35
22:55
07:30
09:20
11:05
13:25
17:10
19:40
21:35
23:20
10:50
16:10
18:10','Active');
INSERT INTO "busTable" VALUES(251,'54','Shaniwar wada','Venutai College','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.1 KMs','45 Minutes','1	Surya hospital
2	Kasaba Police Chowky
3	Vasant talkies
4	Mandai
5	Shahu chauk
6	Mamledar kacheri
7	Gokul bhavan
8	Swargate
9	Parvati payatha
10	Dandekar pul
11	Pan mala Sinhgad Road
12	Jal Shuddhikarn Kendra Sinhgad Road
13	Ganesh mala
14	Vitbhatti Sinhgad Road
15	Vitthalwadi jakat naka
16	Jaydeo nagar
17	Rajaram pul
18	Vitthalwadi Mandir Hingne
19	Hingne rasta
20	Anand nagar singhgad rd
21	Manik Bag
22	Indian hum company
23	Wadgaon phata
24	Jadhav nagar
25	Wadgaon budruk
26	Venutai College','1	Venutai College
2	Wadgaon budruk
3	Jadhav nagar
4	Wadgaon phata
5	Indican hyum company
6	Manik bag
7	Anand nagar
8	Hingne rasta
9	Vitthalwadi mandir hingne
10	RajaramPool
11	Jaydeo nagar
12	Vitthalwadi Jakat Naka
13	Vitbhatti singhgad rd
14	Ganesh mala
15	Jal shudhikaran kendra singhroad rd
16	Pan mala siinghgad road
17	Dandekar pul
18	Parvati payatha
19	Sarasbag
20	Bhikardas maruti madnir
21	Shanipar
22	A B Chowk
23	Dakshinabhimukh Maruti mandir
24	Shaniwar wada
25	Surya hospital','26','07:00
09:00
10:30
12:00
14:30
16:00
17:40
19:50
21:20
06:30
08:00
09:30
11:30
13:00
15:00
16:30
18:10
20:20
21:50','07:45
09:45
11:15
12:40
15:15
16:50
18:30
20:35
22:00
07:15
08:45
10:15
12:15
13:45
15:45
17:20
19:00
21:05
22:30','Active');
INSERT INTO "busTable" VALUES(252,'55','Shanipar','Suncity','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7.8 KMs','41 Minutes','1	Shanipar Bus Stand
2	Kunte Chauk
3	Gokhale hall
4	Vijay Talkies
5	Alka talkies
6	Alka talkies
7	Ganjwewadi
8	Lokmanya nagar
9	Dattawadi pul
10	Mhasoba Chowk
11	Raksha Lekha Society
12	Ganesh mala
13	Vitbhatti Sinhgad Road
14	Vitthalwadi jakat naka
15	Jaydeo nagar
16	Rajaram pul
17	Vitthalwadi Mandir Hingne
18	Hingne rasta
19	Anand nagar singhgad rd
20	Shivpushpak park
21	Star gardan
22	Krushna mandir
23	Suncity','1	Suncity
2	Krushna mandir
3	Star garden
4	Shivpushpak park
5	Anand nagar
6	Hingne rasta
7	Vitthalwadi mandir hingne
8	RajaramPool
9	Jaydeo nagar
10	Vitthalwadi Jakat Naka
11	Vitbhatti singhgad rd
12	Ganesh mala
13	Raksha Lekha Society
14	Mhasoba Chowk
15	Dattawadi pul
16	Lokmanya nagar
17	Ganjwewadi
18	Alka talkies
19	Chitrashala
20	Sadashiv Peth Houd
21	Shanipar Bus Stand','23','07:15
09:10
10:40
12:00
13:20
14:45
16:05
17:30
19:00
20:55
07:45
09:40
11:10
12:30
13:50
15:15
16:35
18:00
19:30
21:25','08:25
09:55
11:20
12:40
14:00
15:25
16:45
18:15
20:15
21:35
08:55
10:25
11:50
13:10
14:30
15:55
17:15
18:45
20:45
22:05','Active');
INSERT INTO "busTable" VALUES(253,'56','Shanipar','Wadgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','43 Minutes','1	Shanipar Bus Stand
2	Kunte Chauk
3	Gokhale hall
4	Vijay Talkies
5	Alka talkies
6	Alka talkies
7	Ganjwewadi
8	Lokmanya nagar
9	Dattawadi pul
10	Mhasoba Chowk
11	Raksha Lekha Society
12	Ganesh mala
13	Vitbhatti Sinhgad Road
14	Vitthalwadi jakat naka
15	Jaydeo nagar
16	Rajaram pul
17	Vitthalwadi Mandir Hingne
18	Hingne rasta
19	Anand nagar singhgad rd
20	Manik Bag
21	Indian hum company
22	Wadgaon phata
23	Krushnai Mangal Karyalaya
24	Shubham Hotel
25	Wadgaon budruk','1	Wadgaon budruk
2	Wadgaon phata
3	Indican hyum company
4	Manik bag
5	Anand nagar
6	Hingne rasta
7	Vitthalwadi mandir hingne
8	RajaramPool
9	Jaydeo nagar
10	Vitthalwadi Jakat Naka
11	Vitbhatti singhgad rd
12	Ganesh mala
13	Raksha Lekha Society
14	Mhasoba Chowk
15	Dattawadi pul
16	Lokmanya nagar
17	Ganjwewadi
18	Alka talkies
19	Chitrashala
20	Sadashiv Peth Houd
21	Shanipar Bus Stand','25','07:00
08:20
10:20
11:50
13:15
15:00
16:30
18:00
19:35
21:35
09:55
11:25
15:50
17:05
18:35
08:00
09:20
10:50
12:50
14:15
16:00
17:30
19:05
20:35
22:35','07:40
09:35
11:05
12:35
13:55
15:45
17:15
18:50
20:50
22:15
10:40
12:10
16:20
17:50
19:20
08:40
10:05
12:05
13:35
14:55
16:45
18:15
19:50
21:50
23:15','Active');
INSERT INTO "busTable" VALUES(254,'57','Pune Station','Wadgaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.3 KMs','44 Minutes','1	Jayprakash Stand Pune station
2	Pune station
3	Alankar Talkies
4	Sadhu wasvani chauk
5	GPO
6	Zila Parishad
7	KEM hospital
8	Apolo Talkies
9	RCM
10	Daruwala Pool
11	Sonya Maruti Chowk
12	City post
13	Kunte Chauk
14	Gokhale hall
15	Vijay Talkies
16	Alka talkies
17	Alka talkies
18	Ganjwewadi
19	Lokmanya nagar
20	Dattawadi pul
21	Mhasoba Chowk
22	Raksha Lekha Society
23	Ganesh mala
24	Vitbhatti Sinhgad Road
25	Vitthalwadi jakat naka
26	Jaydeo nagar
27	Rajaram pul
28	Vitthalwadi Mandir Hingne
29	Hingne rasta
30	Anand nagar singhgad rd
31	Manik Bag
32	Indian hum company
33	Wadgaon phata
34	Wadgaon budruk','1	Wadgaon budruk
2	Wadgaon phata
3	Indican hyum company
4	Manik bag
5	Anand nagar
6	Hingne rasta
7	Vitthalwadi mandir hingne
8	RajaramPool
9	Jaydeo nagar
10	Vitthalwadi Jakat Naka
11	Vitbhatti singhgad rd
12	Ganesh mala
13	Raksha Lekha Society
14	Mhasoba Chowk
15	Dattawadi pul
16	Lokmanya nagar
17	Ganjwewadi
18	Alka talkies
19	Chitrashala
20	Sadashiv Peth Houd
21	A B Chowk
22	Dakshinabhimukh Maruti mandir
23	Shaniwar wada
24	Kasaba Police Chowky
25	Lalmahal
26	RCM
27	Rastewada
28	KEM hospital
29	Ambedkar bhavan
30	Sasoon hospital
31	Pune station
32	Jayprakash Stand Pune station','34','06:05
07:50
09:40
11:30
13:45
15:35
17:25
19:15
21:35
23:15','06:55
08:45
10:35
12:55
16:30
18:20
20:40
22:30','Active');
INSERT INTO "busTable" VALUES(255,'57A','Pune Station','Suncity','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','53 Minutes','1	Jayprakash Stand Pune station
2	Pune Station Depot
3	Sadhu wasvani chauk
4	Collector kacheri
5	Zila Parishad
6	KEM hospital
7	Apolo Talkies
8	RCM
9	Phadake Houd
10	Sonya Maruti Chowk
11	City post
12	Kunte Chauk
13	Gokhale hall
14	Vijay Talkies
15	Alka talkies
16	Ganjwewadi
17	Lokmanya nagar
18	Dattawadi pul
19	Mhasoba Chowk
20	Raksha Lekha Society
21	Jal shudhikaran kendra singhroad rd
22	Ganesh mala
23	Vitbhatti singhgad rd
24	Vitthalwadi Jakat Naka
25	Jaydeo nagar
26	RajaramPool
27	Vitthalwadi mandir hingne
28	Hingne rasta
29	Anand nagar
30	Shivpushpak park
31	Star garden
32	Krushna mandir
33	Suncity','1	Suncity
2	Krushna mandir
3	Star gardan
4	Shivpushpak park
5	Anand nagar singhgad rd
6	Hingne rasta
7	Vitthalwadi Mandir Hingne
8	Rajaram pul
9	Jaydeo nagar
10	Vitthalwadi jakat naka
11	Vitbhatti Sinhgad Road
12	Ganesh mala
13	Jal Shuddhikarn Kendra Sinhgad Road
14	Raksha Lekha Society
15	Mhasoba Chowk
16	Dattawadi pul
17	Lokmanya nagar
18	Ganjwewadi
19	Alka talkies
20	Chitrashala
21	Sadashiv Peth Houd
22	A B Chowk
23	Dakshinabhimukh Maruti mandir
24	Shaniwar wada
25	Kasaba Police Chowky
26	Lalmahal
27	RCM
28	KEM hospital
29	Ambedkar bhavan
30	Central building
31	Sadhu wasvani chauk
32	Jayprakash Stand Pune station','33','05:20
06:45
08:25
10:25
12:50
15:00
17:30
19:30
21:30','06:00
07:35
09:20
11:20
13:45
15:55
18:30
20:30
22:20','Active');
INSERT INTO "busTable" VALUES(256,'58','Shanipar','Gokhalenagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','5.6 KMs','29 Minutes','1	Shanipar Bus Stand
2	Kunte Chauk
3	Gokhale hall
4	Vijay Talkies
5	Alka talkies
6	Goodluck Chowk
7	Deccan Gymkhana
8	Bhandarkar Institute
9	Symbiosis college
10	Sheti mahamandal
11	Vetal Maharaj chauk
12	Kusalkar Putala
13	Gokhalenagar shala
14	Gokhalenagar
15	Police line Gokhalenagar','1	Police line Gokhalenagar
2	Gokhalenagar
3	Gokhalenagar shala
4	Kusalkar putala
5	Vetal Maharaj chauk
6	Sheti mahamandal
7	Symbiosis college
8	Bhandarkar Institute
9	Deccan Gymkhana
10	Chitrashala
11	Sadashiv Peth Houd
12	Shanipar Bus Stand','15','05:55
06:50
07:50
08:50
09:50
10:50
11:50
13:20
14:40
15:40
16:40
17:40
18:40
19:45
21:20
06:15
07:10
08:10
09:10
10:10
11:10
12:40
13:40
15:05
16:05
17:05
18:05
19:05
20:40
21:45','06:20
07:20
08:20
09:20
10:20
11:20
12:50
13:45
15:10
16:10
17:10
18:10
19:10
20:45
21:45
06:40
07:40
08:40
09:40
10:40
12:15
13:10
14:05
15:35
16:35
17:35
18:35
20:05
21:10
22:10','Active');
INSERT INTO "busTable" VALUES(257,'58P','Shanipar','Pandavnagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','4.9 KMs','30 Minutes','1	Pandavnagar
2	Sheti mahamandal
3	Symbiosis college
4	Bhandarkar Institute
5	Deccan Gymkhana
6	Chitrashala
7	Sadashiv Peth Houd
8	Shanipar Bus Stand','1	Pandavnagar
2	Sheti mahamandal
3	Symbiosis college
4	Bhandarkar Institute
5	Deccan Gymkhana
6	Chitrashala
7	Sadashiv Peth Houd
8	Shanipar Bus Stand','8','06:30
07:15
08:10
09:00
09:55
10:45
12:10
12:55
14:15
15:10	
15:55
17:20
18:15
19:15
20:05
20:55','06:20
07:20
08:20
09:20
10:20
11:20
12:50
13:45
15:10
16:10
17:10
18:10
19:10
20:45
21:45
06:40
07:40
08:40
09:40
10:40
12:15
13:10
14:05
15:35
16:35
17:35
18:35
20:05
21:10
22:10','Active');
INSERT INTO "busTable" VALUES(258,'59','Shanipar','Niljyoti','Mon, Tue, Wed, Thu, Fri, Sat, Sun','6.2 KMs','30 Minutes','1	Shanipar Bus Stand
2	Kunte Chauk
3	Gokhale hall
4	Vijay Talkies
5	Alka talkies
6	Goodluck Chowk
7	Deccan Gymkhana
8	Bhandarkar Institute
9	Symbiosis college
10	Sheti mahamandal
11	Vetal Maharaj chauk
12	Kusalkar Putala
13	Janwadi
14	Maharashtra Housing Niljyoti','1	Maharashtra Housing Niljyoti
2	Janwadi
3	Kusalkar putala
4	Vetal Maharaj chauk
5	Sheti mahamandal
6	Symbiosis college
7	Bhandarkar Institute
8	Deccan Gymkhana
9	Chitrashala
10	Sadashiv Peth Houd
11	Shanipar Bus Stand','14','06:40
07:40
08:40
09:40
10:40
11:40
13:10
14:30
15:30
16:30
17:30
18:30
19:30
21:00
06:05
07:00
08:00
09:00
10:00
11:00
12:05
13:30
14:55
15:55
16:55
17:55
18:55
20:00
21:35
06:30
07:25
08:25
09:25
10:25
11:25
12:25
14:00
15:15
16:15
17:15
18:15
19:20
20:20
22:00','07:10
08:10
09:10
10:10
11:10
12:35
13:35
15:00
16:00
17:00
18:00
19:00
20:25
21:35
06:30
07:30
08:30
09:30
10:30
11:35
13:00
13:55
15:25
16:25
17:25
18:25
19:25
21:00
22:00
06:55
07:55
08:55
09:55
10:55
11:55
13:25
14:25
15:45
16:45
17:45
18:45
19:45
21:20
22:25','Active');
INSERT INTO "busTable" VALUES(259,'5S','Pune Station','Kesnand phata','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','56 Minutes','1	Jayprakash Stand Pune station
2	Pune station
3	Ruby hall
4	Wadia college
5	Guruprasad bangala
6	Band garden
7	Yerwada
8	wadia bangala
9	Shastri nagar
10	Agakhan palace
11	Ramwadi Jakatnaka
12	Ramwadi
13	Weikfield
14	ISL Company
15	Dharmanagar 5 va Mail
16	Chandan Nagar
17	Nagarroad Phata Shriramnagar
18	NEI Company
19	Naik bungalow
20	Janakbaba Darga
21	Ramnarayan Bungalow
22	Lieson company
23	Satav High School
24	Wagholi
25	Kesanand phata','1	Kesanand phata
2	Wagholi
3	Satva high school
4	Lieson Company
5	Ramnarayan Bungalow
6	Janakbaba Darga
7	Naik Bungalow
8	NEI company
9	Nagarroad Phata Shriramnagar
10	Chandan nagar
11	Dharmanagar 5 va mail
12	ISL Company
13	Weikfield
14	Ramwadi
15	Ramwadi jakatnaka
16	Agakhan palace
17	Shastri nagar
18	Wadia bunglow
19	Yerwada
20	Band garden
21	Guruprasad bangala
22	Jahangir Hospital
23	Alankar Talkies
24	Sadhu wasvani chauk
25	Collector kacheri
26	Pune station','25','06:00
07:40
09:50
12:20
14:40
16:40
18:45
21:15
06:25
08:05
10:45
12:45
15:00
17:00
19:10
06:05
08:30
10:25
13:05
15:35
17:40
19:50
07:00
09:20
12:05
14:05
15:20
17:25
19:30
07:10
08:55
10:55
13:45
16:00
18:00
20:15
08:10
10:10
12:35
14:20
16:20
18:25
20:45','06:45
08:40
10:50
13:20
15:35
17:35
19:40
22:05
07:10
09:05
11:45
13:45
16:00
17:55
20:05
07:35
09:25
11:25
14:00
16:35
18:40
20:45
08:00
10:25
13:05
15:05
16:20
18:20
20:25
08:05
09:55
11:05
14:35
16:55
19:00
21:05
09:10
11:00
13:25
15:10
17:15
19:30
21:35','Active');
INSERT INTO "busTable" VALUES(260,'6','Swargate','Wadgaon Sheri','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','60 Minutes','1	Swargate
2	Lakshi narayan theature
3	Mauli bangala
4	Maharshi nagar
5	Sant namdeo vidyalay
6	P and T colony
7	Bank of maharashtra
8	COD office
9	Juna pul gate
10	Bombay Garage
11	West end talkies
12	Poona club
13	Council Hall
14	Income tax office
15	Sasoon hospital
16	Alankar Talkies
17	Ruby hall
18	Wadia college
19	Guruprasad bangala
20	Band garden
21	Yerwada
22	wadia bangala
23	Shastri nagar
24	Agakhan palace
25	Ramwadi Jakatnaka
26	Ramwadi
27	Weikfield
28	Sainikwadi
29	Matchwel company
30	Datta mandir Wadgaon sheri
31	Wadgao sheri','1	Wadgao sheri
2	Datta mandir wadgaon sheri
3	Matchwel company
4	Sainikwadi
5	Weikfield
6	Ramwadi
7	Ramwadi jakatnaka
8	Agakhan palace
9	Shastri nagar
10	Wadia bunglow
11	Yerwada
12	Band garden
13	Guruprasad bangala
14	Jahangir Hospital
15	Sadhu wasvani chauk
16	General post office
17	West end talkies
18	Bombay garaje
19	juna pul gate
20	Mahatma gandhi stand
21	COD office
22	Bank of maharashtra
23	P and T colony
24	Sant namdeo vidyalay
25	Maharshi nagar
26	Mauli bangala
27	Lakshmi narayan theature
28	Swargate','31','06:00
08:00
10:00
12:30
14:30
16:30
19:00','07:00
09:00
11:00
13:30
15:30
17:30
20:00','Active');
INSERT INTO "busTable" VALUES(261,'6','Swargate','Pune Vidyapeeth','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','49 Minutes','1	Swargate
2	Swargate
3	Sarasbag
4	Bhikardas maruti madnir
5	Shanipar
6	Kunte Chauk
7	Gokhale hall
8	Vijay Talkies
9	Alka talkies
10	Deccan Corner Sambhaji Pul Corner
11	Garware college
12	Petrol Pump Karve Road
13	Nal Stop
14	SNDT college
15	SNDT college
16	Law college
17	Bhandarkar Institute
18	Symbiosis college
19	Sheti mahamandal
20	Vetal Maharaj chauk
21	Shivaji housing board bus stop
22	ICC bus stop
23	Chatushringi payatha
24	Pune University Gate
25	Gents hostel university
26	Vidyapeeth Press
27	Ladies Hostel Pune University
28	Sevak Vasaha
29	Pune University Main Building','1	Pune University Main Building
2	Sevak Vasaha
3	Ladies Hostel Pune University
4	Vidyapeeth Press
5	Gents hostel university
6	Pune University Gate
7	Chatushringi payatha
8	ICC bus stop
9	Shivaji housing board bus stop
10	Vetal Maharaj chauk
11	Sheti mahamandal
12	Symbiosis college
13	Bhandarkar Institute
14	Film institute
15	Nal stop
16	Petrol pump karve road
17	Garware college
18	Deccan corner sambhaji pul
19	Chitrashala
20	Sadashiv Peth Houd
21	Mandai
22	Mandai
23	Shahu chauk
24	Mamledar kacheri
25	Gokul bhavan
26	Swargate','29','08:00
09:40
15:40
17:30','08:50
10:30
16:30
18:15','Active');
INSERT INTO "busTable" VALUES(262,'61','Katraj bus stand','Nasarapur','Mon, Tue, Wed, Thu, Fri, Sat, Sun','27 KMs','55 Minutes','1	Katraj bus stand
2	Gujarwadi Phata
3	Mangdewadi Petrol Pump
4	Mangdewadi Phata
5	Bhilarewadi
6	Stage no.6
7	Stage no.7
8	Waghjai Mandir
9	Ghat utaar Walan
10	Gogalwadi Phata
11	Adlar Engineering
12	Shindewadi Gujarwadi
13	Velugoan Phata
14	Grand Hotel
15	Shivapur Bag Post office
16	Kodhanpur Phata
17	Kopo Phata Bormal
18	Poolachi wadi
19	Shivregoan Phata
20	Pravin Masala Company
21	Ashok Layland
22	Warje Gaon Nasrapur Road
23	Kalubai Jog Mandir
24	Shivanand Enclave Company
25	Kalewadigaon phata
26	Sangvi Company
27	Dalvi wasti
28	Nasrapur ST Stand
29	Bhairoba Mandir Nasarapur','1	Bhairoba Mandir Nasarapur
2	Narsapur ST Stand
3	Dalvi wasti
4	Sangvi company
5	Kelewadigoan Phata
6	Shivanand Enclave company
7	Kalubai Jog mandir
8	Warje Gaon Nasrapur Road
9	Ashok Layland
10	Praveen masale company
11	Shivregaon phata
12	Poolachi Wadi
13	Kopo Phata Bormal
14	Kondhanpur phata
15	Shivapur Bag Post office
16	Grand hotel
17	Velugaon phata
18	Shindewadi Gujarwadi
19	Adlar Engineering
20	Gogalwadi phata
21	Ghat utar walan
22	Waghjai mandir
23	Stage kramank 7
24	Stage kramank 6
25	Bhilarewadi
26	Mangdewadi Phata
27	Gujarwadi phata
28	Katraj bus stand','29','08:00
10:10
12:25
14:30
16:40
18:50
21:30','06:30
09:05
11:15
13:25
15:35
17:45
19:55','Active');
INSERT INTO "busTable" VALUES(263,'62','Marketyard','Sangamwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','15 KMs','66 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	Godown Marketyard
4	Shivaji Putala Kalubai Mandir
5	Mafco Company
6	Bhapkar petrol pump City Pride
7	Panchami hotel
8	Laxmi Narayan Theature
9	Swargate
10	Sarasbag
11	Bhikardas maruti madnir
12	Shanipar
13	A B Chowk
14	Dakshinabhimukh Maruti mandir
15	Shaniwar wada
16	Lalmahal
17	RCM
18	Apolo Talkies
19	KEM hospital
20	Ambedkar bhavan
21	Sasoon hospital
22	Pune station
23	Income tax office
24	Council Hall
25	Sarkari Vishram Gruh
26	Saint Janabai hostel
27	Budhrani Hospital
28	Saint Meera college
29	Blue Diamond hotel
30	Band garden
31	Yerwada
32	Shadal baba Darga
33	Deccan college
34	Sangamwadi shala
35	Sangamwadi gaon','1	Sangamwadi gaon
2	Sangamwadi shala
3	Deccan college
4	Shadal baba Darga
5	Yerwada
6	Band garden
7	Blue Diamond Hotel
8	Saint Meera college
9	Budhrani Hospital
10	Sant Janabai Hostel
11	Sarkari Vishram Gruh
12	Council Hall
13	Income tax office
14	GPO
15	Collector kacheri
16	Zila Parishad
17	KEM hospital
18	Apolo Talkies
19	Phadake Houd
20	Lal mahala
21	Vasant talkies
22	Mandai
23	Shahu chauk
24	Gokul bhavan
25	Swargate
26	Lakshi narayan theature
27	Panchami hotel
28	Bhapkar Petrol Pump City pride
29	Mafco Company
30	Shivaji putala Kalubai mandir
31	Godown Marketyard
32	Wakhar Mahamandal Marketyard
33	Marketyard','35','05:40
07:40
10:20
12:30
14:50
17:10
20:00
06:05
08:05
10:45
12:55
15:15
17:35
20:25
06:30
08:30
11:10
13:20
15:45
18:05
20:55
06:55
08:55
11:35
13:45
16:10
18:30
21:20
07:20
09:20
12:00
14:10
16:40
19:00
21:45','06:40
08:45
11:25
13:35
16:00
18:20
21:10
07:05
09:10
11:50
14:00
16:25
18:45
21:35
07:30
09:35
12:15
14:25
16:55
19:15
22:05
07:55
10:00
12:40
14:50
17:20
19:40
22:30
08:20
10:25
13:05
15:10
17:50
20:10
22:55','Active');
INSERT INTO "busTable" VALUES(264,'63','Swargate','Kalyani nagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11.5 KMs','54 Minutes','1	Swargate
2	Sarasbag
3	Bhikardas maruti madnir
4	Shanipar
5	A B Chowk
6	Dakshinabhimukh Maruti mandir
7	Shaniwar wada
8	Kasaba Police Chowky
9	Lalmahal
10	RCM
11	Rastewada
12	Apolo Talkies
13	KEM hospital
14	Ambedkar bhavan
15	Sasoon hospital
16	Pune station
17	Ruby hall
18	Wadia college
19	Blue Diamond hotel
20	Saint Meera college
21	Budhrani Hospital
22	Annadhanya Godam
23	Bungalow no 105
24	Kawdewasti
25	Kasturba School north lane
26	Kalyani nagar','1	Kalyani Nagar
2	Kasturba School north lane
3	Kawdewasti
4	Bungalow no 105
5	Annadhanya Godam
6	Budhrani Hospital
7	Saint Meera college
8	Blue Diamond Hotel
9	Jahangir Hospital
10	Alankar Talkies
11	Sadhu wasvani chauk
12	GPO
13	Collector kacheri
14	Zila Parishad
15	KEM hospital
16	Apolo Talkies
17	RCM
18	Lal mahala
19	Vasant talkies
20	Mandai
21	Shahu chauk
22	Mamledar kacheri
23	Gokul bhavan
24	Swargate','26','05:30
07:05
09:05
11:35
13:55
15:45
17:45
20:15
06:05
07:45
09:45
12:10
14:30
16:25
18:25
20:50
06:35
08:25
10:25
12:50
15:10
17:05
19:05
21:30','06:15
08:05
10:05
12:35
14:45
16:45
18:45
21:05
06:50
08:45
10:40
13:05
15:25
17:25
19:20
21:40
07:25
09:25
11:20
13:40
16:05
18:05
20:00
22:00','Active');
INSERT INTO "busTable" VALUES(265,'64','Swargate','Warje Malwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11 KMs','48 Minutes','1	Swargate
2	Sarasbag
3	Madiwale colony
4	S P college
5	Maharashtra mandal
6	Sahitya parishad peru gate
7	Deccan Corner Sambhaji Pul Corner
8	Garware college
9	Petrol Pump Karve Road
10	Nal Stop
11	SNDT college
12	Paud Phata Dashabhuja Ganpati
13	Maruti mandir karve road
14	Karve putala
15	Kothrud Stand
16	Dahanukar colony
17	Wadache Jhad Bhairavnath Mandir
18	Karvenagar
19	Warje Jakatnaka
20	Tapodham
21	Warje Malwadi
22	Dnanesh society
23	Ganpati matha','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Sahitya Parishad Peru Gate
19	Maharashtra mandal
20	S P college
21	Madiwale colony
22	Hirabag
23	Swargate corner
24	Swargate','23','05:45
15:00
09:15
06:10
15:15
06:25
15:45
08:20
06:55
16:00
07:10
16:15','06:30
08:10
09:50
12:00
13:40
15:50
17:30
19:40
21:40
10:05
11:40
13:55
15:35
17:15
19:10
06:55
08:35
10:20
12:30
14:10
16:05
17:45
20:05
21:55
07:10
08:50
10:35
12:45
14:25
16:35
18:15
20:35
22:25
09:05
10:50
13:00
14:40
16:20
18:00
07:40
09:20
11:05
13:15
14:55
16:50
18:30
20:50
22:45
07:55
09:35
11:20
13:30
15:10
17:05
18:45
21:10
23:05','Active');
INSERT INTO "busTable" VALUES(266,'64A','Swargate','Warje Malwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','54 Minutes','1	Swargate
2	Parvati payatha
3	Dandekar pul
4	Pan mala Sinhgad Road
5	Jal Shuddhikarn Kendra Sinhgad Road
6	Raksha Lekha Society
7	Mhasoba Chowk
8	Mahadeo mandir
9	Mehendale garage
10	Date Engineering
11	Bhim Jyoti Soc.
12	Karnataka High school
13	Alankar Police Chowki
14	Nav Sahyadri Sabhagruha
15	Madhusanchay Society
16	Shridhar Colony
17	Karvenagar
18	Warje Jakatnaka
19	Tapodham
20	Warje Malwadi
21	Dnanesh society
22	Ganpati matha','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Sahvas Soc
9	Shriman Society
10	Vitthal Mandir Karvenagar
11	Madhusanchay Society
12	Nav Sahyadri Sabhagruha
13	Alankar Police Chowki
14	Karnataka High school
15	Bhim Jyoti Soc.
16	Date Engineering
17	Mehandale Guarage
18	Mahadeo mandir
19	Mhasoba Chowk
20	Raksha Lekha Society
21	Jal shudhikaran kendra singhroad rd
22	Pan mala siinghgad road
23	Dandekar pul
24	Parvati payatha
25	Sarasbag
26	Hirabag
27	Swargate corner
28	Swargate','22','06:00
07:40
09:25
11:40
13:35
15:15
17:00
19:40
08:05
09:50
12:15
14:00
15:40
17:30
06:50
08:30
10:15
12:40
14:25
16:05
16:55
20:30
08:55
10:45
13:05
14:50
16:30
18:25','06:50
08:30
10:20
12:40
14:25
16:05
18:00
20:35
08:55
10:50
13:05
14:50
16:30
18:30
07:40
09:20
10:15
13:30
15:15
16:55
18:55
21:20
09:45
11:40
13:55
15:40
17:35
19:25','Active');
INSERT INTO "busTable" VALUES(267,'65','Upper Depot','Maharashtra housing board','Mon, Tue, Wed, Thu, Fri, Sat, Sun','16 KMs','66 Minutes','1	Rajiv Gandhi Nagar Upper Depot
2	Upper Indiranagar
3	Chintamani Nagar
4	Lower Indiranagar
5	Bibwewadi
6	Kothari Corner
7	Vasant Bag
8	Ganga Dham
9	Marketyard
10	Wakhar Mahamandal Marketyard
11	P and T colony
12	Canol Jhopadpatti
13	Apsara Talkies
14	Ghorpade peth colony
15	Lakud Bajar
16	Sonwane hospital
17	Ramoshi gate
18	Nana peth
19	A D camp chauk
20	Power house
21	KEM hospital
22	Ambedkar bhavan
23	Sasoon hospital
24	Pune station
25	Ruby hall
26	Wadia college
27	Guruprasad bangala
28	Band garden
29	Yerwada
30	White House
31	Netaji school
32	Vikrikar Karyalaya
33	Yerwada post office
34	M23
35	Moze Adhyapak Vidyalaya Yerwada
36	Maharashtra Housing Yerwada','1	Maharashtra Housing Yerwada
2	Moje adhyapak vidyalaya Yerwada
3	M23
4	Yerwada post office
5	Vikrikar karyalaya
6	Netaji school
7	White House
8	Yerwada
9	Band garden
10	Guruprasad bangala
11	Jahangir Hospital
12	Sadhu wasvani chauk
13	General post office
14	Employment Office
15	Power house
16	A D camp chauk
17	Nana peth
18	Ramoshi gate
19	Sonwane hospital
20	Lakud Bajar
21	Ghorpadi Peth Colony
22	Apsara Talkies
23	Canol Jhopadpatti
24	P and T colony
25	Wakhar Mahamandal Marketyard
26	Marketyard
27	Ganga Dham
28	Vasant Bag
29	Kothari Corner
30	Bibwewadi
31	Lower Indiranagar
32	Chintamani Nagar
33	Upper Indiranagar
34	Rajiv Gandhi Nagar Upper Depot','36','06:45
08:55
11:45
13:55
16:45
19:05','07:45
10:05
12:55
15:00
17:50
20:10','Active');
INSERT INTO "busTable" VALUES(268,'66','Market yard','Agalambe Gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','29 KMs','88 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	Godown Marketyard
4	Shivaji Putala Kalubai Mandir
5	Mafco Company
6	Bhapkar petrol pump City Pride
7	Panchami hotel
8	Laxmi Narayan Theature
9	Swargate
10	Sarasbag
11	Mahila Mandal
12	Petrol Pump Rajendranagar
13	Lokmanya nagar
14	Ganjwewadi
15	Alka talkies
16	Deccan Corner Sambhaji Pul Corner
17	Garware college
18	Petrol Pump Karve Road
19	Nal Stop
20	SNDT college
21	Paud Phata Dashabhuja Ganpati
22	Maruti mandir karve road
23	Karve putala
24	Kothrud Stand
25	Dahanukar colony
26	Wadache Jhad Bhairavnath Mandir
27	Karvenagar
28	Warje Jakatnaka
29	Tapodham
30	Warje Gaon Highway
31	Warje Malwadi
32	Dnanesh society
33	Ganpati matha
34	Dudhane wasti
35	Shivane Gaon
36	Deshmukhwadi
37	Ingale Colony
38	Ahire gate phata
39	Uttamnagar
40	Bhimnagar
41	Kondhava Dhavde
42	NDA gate Kondhva Gate
43	NDA Gate No 10
44	Khadakwasla Dharan Stores
45	Pickock Bay
46	Donger Matha
47	Dhumal Tali
48	Kudje gaon
49	Kudje Stand
50	Agalambe Phata
51	Amrai
52	Poultry Farm Aglambe
53	Agalambe Gaon','1	Agalambe Gaon
2	Poultry Farm Aglambe
3	Amrai
4	Agalambe Phata
5	Kudje Stand
6	Kudje gaon
7	Dhumal Tali
8	Donger Matha
9	Pickock
10	Khadakwasla Dharan Stores
11	NDA gate no.10
12	NDA gate Kondhava gate
13	Kondhava dhavade
14	Bhimnagar
15	Uttamanagar
16	Ahire gate Phata
17	Ingale colony
18	Deshmukhwadi
19	Shivane gaon
20	Dudhane wasti
21	Ganpati matha
22	Dnanesh society
23	Warje malwadi
24	Warje gaon highway
25	Tapodham
26	Warje jakatnaka
27	Karvenagar
28	Wadache jhad
29	Dahanukar colony
30	Kothrud Stand
31	Karve putala
32	Maruti Mandir Karve Road
33	Paud phata dashbhuja mandir
34	SNDT college
35	Nal stop
36	Petrol pump karve road
37	Garware college
38	Deccan corner sambhaji pul
39	Alka talkies
40	Ganjwewadi
41	Lokmanya nagar
42	Petrol pump rajendranagar
43	Mahila mandal
44	Hirabag
45	Swargate corner
46	Swargate
47	Lakshi narayan theature
48	Panchami hotel
49	Bhapkar Petrol Pump City pride
50	Mafco Company
51	Shivaji putala Kalubai mandir
52	Godown Marketyard
53	Wakhar Mahamandal Marketyard
54	Marketyard','53','05:25
08:30
14:15
17:45','06:45
10:00
15:45
19:15','Active');
INSERT INTO "busTable" VALUES(269,'67','Kharadi Gaon','Swargate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','17 KMs','67 Minutes','1	Kharadi Gaon
2	Patil Wasti Kharadi
3	Rakshak Society Kharadi
4	Tukaramnagar
5	Vidi Kamgar Vasahat
6	Chandan nagar
7	Tata gaurdroom Kharadi phata
8	Dharmanagar 5 va mail
9	ISL Company
10	Weikfield
11	Ramwadi
12	Ramwadi jakatnaka
13	Agakhan palace
14	Shastri nagar
15	Wadia bunglow
16	Yerwada
17	Band garden
18	Guruprasad bangala
19	Jahangir Hospital
20	Alankar Talkies
21	Sadhu wasvani chauk
22	Collector kacheri
23	Zila Parishad
24	KEM hospital
25	Power house
26	A D camp chauk
27	Nana peth
28	Ramoshi gate
29	Sonwane hospital
30	Lakud Bajar
31	Ghorpadi Peth Colony
32	Apsara Talkies
33	Canol Jhopadpatti
34	P and T colony
35	Sant namdeo vidyalay
36	Maharshi nagar
37	Mauli bangala
38	Lakshmi narayan theature
39	Swargate','1	Swargate
2	Lakshi narayan theature
3	Mauli bangala
4	Maharshi nagar
5	Sant namdeo vidyalay
6	P and T colony
7	Canol Jhopadpatti
8	Apsara Talkies
9	Ghorpade peth colony
10	Lakud Bajar
11	Sonwane hospital
12	Ramoshi gate
13	Nana peth
14	A D camp chauk
15	Power house
16	KEM hospital
17	Ambedkar bhavan
18	Sasoon hospital
19	Pune station
20	Ruby hall
21	Wadia college
22	Guruprasad bangala
23	Band garden
24	Yerwada
25	wadia bangala
26	Shastri nagar
27	Agakhan palace
28	Ramwadi Jakatnaka
29	Ramwadi
30	Weikfield
31	ISL Company
32	Dharmanagar 5 va Mail
33	Tata Guardroom Kharadi Phata
34	Chandan Nagar
35	Vidi Kamgar Vasahat
36	Tukaramnagar
37	Rakshak Society Kharadi
38	Patil Wasti Kharadi
39	Kharadi Gaon','39','06:15
08:25
10:35
13:25
15:40
17:45
20:25
22:30
07:30
09:35
11:45
14:25
16:40
18:45
21:30','05:25
07:20
09:35
12:20
14:35
16:45
19:20
21:30
06:30
08:35
10:40
13:20
15:35
17:45
20:25','Active');
INSERT INTO "busTable" VALUES(270,'68','Swargate','Kothrud Depot','Mon, Tue, Wed, Thu, Fri, Sat, Sun','8 KMs','38 Minutes','1	Swargate
2	Sarasbag
3	Madiwale colony
4	S P college
5	Maharashtra mandal
6	Sahitya parishad peru gate
7	Deccan corner sambhaji pool
8	Garware college
9	Petrol Pump Karve Road
10	Nal Stop
11	SNDT college
12	Paud phata police chauky
13	More vidyalaya
14	LIC colony
15	Anand nagar paud road
16	Jai bhavani
17	Vanaz Corner
18	Vanaz company
19	Kachara depot
20	Bharti nagar
21	kothrud depot','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Sahitya Parishad Peru Gate
17	Maharashtra mandal
18	S P college
19	Madiwale colony
20	Hirabag
21	Swargate corner
22	Swargate','21','05:40
14:40
08:25
06:00
14:50
07:25
15:00
06:20
15:20
09:05
06:40
15:30
06:50
15:40','06:15
07:35
08:55
10:50
12:15
13:40
15:20
16:40
18:10
20:10
21:35
09:05
10:30
12:25
13:50
15:10
16:30
18:00
19:30
06:35
07:50
09:15
11:10
12:35
14:00
15:30
16:50
18:20
20:20
21:45
23:05
08:05
09:25
11:20
12:45
14:10
15:40
17:00
18:30
20:30
21:55
06:55
08:15
09:35
11:30
12:55
14:20
16:00
17:20
18:50
20:50
22:15
23:35
09:45
11:40
13:05
14:30
15:50
17:10
18:40
20:00
07:15
08:35
09:55
11:50
13:15
14:40
16:10
17:30
19:00
21:00
22:25
07:25
08:45
10:10
12:00
13:25
14:50
16:20
17:40
19:15
21:15
22:35','Active');
INSERT INTO "busTable" VALUES(271,'68P','Kothrud depot','Swargate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9.4 KMs','56 Minutes','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Goodluck Chowk
17	Deccan Gymkhana
18	Alka talkies
19	Sadashiv Peth Houd
20	Mandai
21	Gadikhana
22	Shahu chauk
23	Mamledar kacheri
24	Gokul bhavan
25	Swargate','1	Swargate
2	Sarasbag
3	Bhikardas maruti madnir
4	Shanipar
5	Kunte Chauk
6	Gokhale hall
7	Vijay Talkies
8	Alka talkies
9	Deccan Corner Sambhaji Pul Corner
10	Garware college
11	Petrol Pump Karve Road
12	Nal Stop
13	SNDT college
14	Paud phata police chauky
15	More vidyalaya
16	LIC colony
17	Anand nagar paud road
18	Jai bhavani
19	Vanaz Corner
20	Paramhans corner
21	Kachara depot
22	Bharti nagar
23	kothrud depot','25','08:00
09:40
11:25
13:50
15:35
17:30
14:05
15:55
08:40
10:25
12:15
14:35
16:15
18:10
09:00
10:50
12:35
14:55
16:45
18:45
09:20
11:10
13:00
15:25
17:20
08:50
19:05','08:50
10:35
12:25
14:45
16:35
18:35
12:40
15:00
16:50
09:35
11:15
13:10
15:25
17:15
19:15
09:55
11:45
13:30
15:55
17:40
19:45
10:15
12:05
13:50
16:15
18:10
09:50
20:00','Active');
INSERT INTO "busTable" VALUES(272,'68S','Sutardara','Swargate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9.6 KMs','52 Minutes','1	Sutardara
2	Shivteerthnagar
3	Jai bhavani
4	Anand nagar paud road
5	LIC Colony Paud Road
6	More vidyalaya
7	Paudphata police chowky
8	SNDT college
9	Nal stop
10	Petrol pump karve road
11	Garware college
12	Deccan corner sambhaji pul
13	Alka talkies
14	Chitrashala
15	Sadashiv Peth Houd
16	Mandai
17	Gadikhana
18	Shahu chauk
19	Mamledar kacheri
20	Gokul bhavan
21	Swargate','1	Swargate
2	Sarasbag
3	Bhikardas maruti madnir
4	Shanipar
5	Kunte Chauk
6	Gokhale hall
7	Vijay Talkies
8	Alka talkies
9	Deccan Corner Sambhaji Pul Corner
10	Garware college
11	Petrol Pump Karve Road
12	Nal Stop
13	SNDT college
14	Paud phata police chauky
15	More vidyalaya
16	LIC colony
17	Anand nagar paud road
18	Jai bhavani
19	Shivteerthnagar
20	Sutardara','21','07:30
09:10
10:50
12:30
15:30
17:30','08:20
10:05
11:35
13:20
16:25
18:25','Active');
INSERT INTO "busTable" VALUES(273,'69','Marketyard','Ghotawade gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','31 KMs','84 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	Godown Marketyard
4	Shivaji Putala Kalubai Mandir
5	Mafco Company
6	Bhapkar petrol pump City Pride
7	Panchami hotel
8	Laxmi Narayan Theature
9	Swargate
10	Sarasbag
11	Mahila Mandal
12	Petrol Pump Rajendranagar
13	Lokmanya nagar
14	Ganjwewadi
15	Deccan Corner Sambhaji Pul Corner
16	Garware college
17	Petrol Pump Karve Road
18	Nal Stop
19	SNDT college
20	Paud phata police chauky
21	More vidyalaya
22	LIC colony
23	Anand nagar paud road
24	Jai bhavani
25	Vanaz Corner
26	Vanaz company
27	Paramhans corner
28	Kachara depot
29	Bharti nagar
30	kothrud depot
31	Shinde farm
32	Chandani chauk
33	Mail Dagad Kramank 8
34	Rajwade banglaow
35	Dagade wasti
36	Bhagwat wasti
37	Deshmukh wasti
38	Mariaai Mandir Bhugaon
39	Daulat Garden
40	Bhugoan
41	Chukate wasti
42	Mathalwadi
43	Tangde Bandhu Mala
44	Mail Dagad Kramank 18
45	Nerolac Paint Company
46	Bhukoom Ashram
47	Bandal farm
48	Ashram
49	Mail dagad kramank 21
50	Mail Dagad Kramank 22
51	Lavale Phata
52	ST stand pirangut
53	Vishkar India company
54	Ghotawale phata
55	Sangam Metal Company
56	Kanda Engineering Company
57	Power House Ghotawade
58	Bhar Phata
59	Alfa paper mill
60	Hanuman chowk
61	SNZ chemical company
62	Ghotawade gaon','1	Ghotawade gaon
2	SNZ Chemical Company
3	Hanuman chauk
4	Alfa Paper Mill
5	Bhar phata
6	Power house ghotawade
7	Kanda engnireeng company
8	Sangam metal company
9	Ghotawade Phata
10	Viskar India Company
11	ST stand Pirangut
12	Lavale phata
13	Mail Dagad Kramank 22
14	Mail Dagad Kramank 21
15	Ashram
16	Bandal Farm
17	Bhukoom ashram
18	Nerolac paint company
19	Mail dagad no.18
20	Tangade bandhu mala
21	Mathalwadi
22	Chutke wasti
23	Bhugaon
24	Daulat garden
25	Mariaai mandir bhugaon
26	Deshmukh wasti
27	Bhagwat wasti
28	Dagade wasti
29	Rajwade Bungalow
30	Mail Dagad Kramank 8
31	Chandani chauk
32	Shinde Farm
33	Kothrud depot
34	Bharti nagar
35	kachra depot
36	Paramhansa Corner
37	Vanaz corner
38	Jai bhavani
39	Anand nagar paud road
40	LIC Colony Paud Road
41	More vidyalaya
42	Paudphata police chowky
43	SNDT college
44	Nal stop
45	Petrol pump karve road
46	Garware college
47	Deccan corner sambhaji pul
48	Ganjwewadi
49	Lokmanya nagar
50	Petrol pump rajendranagar
51	Mahila mandal
52	Hirabag
53	Swargate corner
54	Swargate
55	Lakshi narayan theature
56	Panchami hotel
57	Bhapkar Petrol Pump City pride
58	Mafco Company
59	Shivaji putala Kalubai mandir
60	Godown Marketyard
61	Wakhar Mahamandal Marketyard
62	Marketyard','62','05:40
08:20
11:50
14:35
18:05
06:50
09:30
13:00
16:10
20:40','06:45
09:45
13:15
16:05
19:35
08:00
11:00
14:25
17:40
22:10','Active');
INSERT INTO "busTable" VALUES(274,'6S','Pune Station','Dange chowk','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','63 Minutes','1	Pune Station Depot
2	GPO
3	Collector kacheri
4	Ambedkar bhavan
5	Juna Bajar
6	Kumbhar wada
7	PMC
8	Shivaji putala pmc
9	shimala office shivajinagar
10	Masoba gate
11	Pumping station
12	Pune central
13	E square
14	Rangehills Corner
15	Rajbhavan
16	Boys batalian
17	Kasturba vasahat
18	Sindh colony gate 2
19	Bremen chauk
20	Body gate
21	Aundh gaon
22	Sangvi phata
23	Aundh chest hospital
24	Aundh post office
25	ESI Hospital
26	Rakshak chauk
27	Military Stores
28	Wakad phata
29	Jagtap Dairy
30	Kaspate Vasti
31	Kalewadi phata
32	16 Number
33	Laxman nagar
34	Dange chowk','1	Dange chowk
2	Laxman nagar
3	16 Number
4	Kalewadi phata
5	Kaspate Vasti
6	Jagtap Dairy
7	Wakad phata
8	Military Stores
9	Rakshak chauk
10	ESI Hospital
11	Aundh post office
12	Aundh chest hospital
13	Sangvi Phata
14	Aundh gaon
15	Body gate
16	Bremen chauk
17	Sindh Colony Gate2
18	Kasturba vasahat
19	Boys Batalian
20	Pune University Gate
21	Rangehills Corner
22	E Square
23	Pune central
24	Pumping station
25	Masoba gate
26	shimala office shivajinagar
27	Engineering college hostel
28	Shivaji putala
29	PMC Mangala
30	Kumbhar Wada
31	Juna Bajar
32	Ambedkar bhavan
33	Sasoon hospital
34	Pune station
35	Pune Station Depot','34','06:20
08:20
10:25
13:05
15:15
17:25
20:15
07:00
09:00
11:35
13:40
16:00
18:15
21:25','07:20
09:20
11:25
14:05
16:15
18:35
21:30
07:55
10:00
12:35
14:40
17:05
19:35
22:25','Active');
INSERT INTO "busTable" VALUES(275,'7','Swargate','Uruli Kanchan','Mon, Tue, Wed, Thu, Fri, Sat, Sun','32 KMs','75 Minutes','1	Sarasbag
2	Madiwale colony
3	Hirabag
4	Swargate corner
5	Ghorpade peth colony
6	S T Divisional office
7	Meera society
8	Golibar maidan
9	juna pul gate
10	Mahatma gandhi stand
11	Race course
12	Bhauraba nala
13	Fatimanagar Municipal shala
14	Kalubai mandir
15	Ram tekadi
16	Vaidwadi
17	Gurushankar math
18	Magarpatta
19	Hadapsar gaon
20	Hadapsar gadital
21	Agrawal Colony
22	Akashwani hadapasar
23	15 number Manjari Gaon Phata
24	Laxmideep colony
25	Rambag solapur rd
26	Manjri farm
27	Phursungi gaon phata
28	Krushi mahavidyalaya
29	Kavadi pat
30	Kavadi rasta
31	Wakvasti
32	Fuel depot
33	Kadam wasti
34	Loni station
35	Loni phata
36	Ramkrushna rasayan karkhana
37	Malyacha mala
38	Borkar wasti
39	Tamnya wasti
40	Theur phata
41	Kalbhor wasti solapur rd.
42	Tendulkar wasti
43	Kunjirwadi
44	Naygaon phata
45	Bank of badoda
46	Green ekars
47	Badade wasti
48	Chaudhari wasti
49	Sortapwadi
50	Rajendra pipe company
51	Inamdar Wasti
52	Bhosale Wasti
53	Prayag Dham Phata
54	Urali Kanchan','1	Urali Kanchan
2	Prayag Dham Phata
3	Bhosale Wasti
4	Inamdar Wasti
5	Rajendra pipe company
6	Sortapwadi
7	Chaudhari wasti
8	Badade wasti
9	Green ekars
10	Bank of badoda solapur rd
11	Naygaon phata
12	Kunjirwadi
13	Tendulkar wasti
14	Kalbhor wasti solapur rd.
15	Theur phata
16	Tamnya wasti
17	Borkar wasti
18	Malyacha mala
19	Ramkrushna rasayan karkhana
20	Loni phata
21	Loni station
22	Kadam wasti
23	Fuel depot
24	Wakvasti
25	Kavadi rasta
26	Kavadi pat
27	Krushi mahavidyalaya
28	Phursungi gaon phata
29	Manjri farm
30	Rambag solapur rd
31	Laxmideep colony
32	15 number Manjari Gaon Phata
33	Akashwani hadapasar
34	Agrawal colony
35	Hadapsar gadital
36	Hadapsar gaon
37	Magarpatta
38	Gurushankar math
39	Vaidwadi
40	Ram tekadi
41	Kalubai mandir solapur road
42	Fatimanagar Municipal shala
43	Bhauraba nala
44	Race course
45	Mahatma gandhi stand
46	Golibar maidan
47	Meera society
48	S T Divisional office
49	Ghorpadi Peth Colony
50	Swargate
51	Sarasbag','54','06:00
08:30
11:30
14:00
16:30
19:30
06:50
09:20
12:20
14:50
17:20
20:20','07:15
09:45
12:45
15:15
17:45
20:45
08:05
10:35
13:35
16:05
18:35
21:35','Active');
INSERT INTO "busTable" VALUES(276,'70','Deccan Gymkhana','Paudgoan','Mon, Tue, Wed, Thu, Fri, Sat, Sun','28 KMs','77 Minutes','1	Deccan Gymkhana
2	Deccan corner sambhaji pool
3	Garware college
4	Petrol Pump Karve Road
5	Nal Stop
6	SNDT college
7	Paud phata police chauky
8	More vidyalaya
9	LIC colony
10	Anand nagar paud road
11	Jai bhavani
12	Vanaz Corner
13	Paramhans corner
14	Kachara depot
15	Bharti nagar
16	kothrud depot
17	Shinde farm
18	Chandani chauk
19	Mail Dagad Kramank 8
20	Rajwade banglaow
21	Dagade wasti
22	Bhagwat wasti
23	Deshmukh wasti
24	Mariaai Mandir Bhugaon
25	Daulat Garden
26	Bhugoan
27	Chukate wasti
28	Mathalwadi
29	Tangde Bandhu Mala
30	Mail Dagad Kramank 18
31	Nerolac Paint Company
32	Bhukoom Ashram
33	Bandal farm
34	Ashram
35	Mail dagad kramank 21
36	Mail Dagad Kramank 22
37	Lavale Phata
38	ST stand pirangut
39	Vishkar India company
40	Ghotawale phata
41	Shindewadi Ghotawale
42	Kasar amboli
43	Cable company
44	Sutarwadi paudroad
45	Nursery
46	Amralewadi phata
47	Mukund shobha udyan dattamandir
48	Sanakata company
49	Santi company
50	Balkavade wasti
51	Vitthalwadi phata
52	Forest Office Road
53	Manik press road
54	ST stand Paudgaon
55	Shaskiya vishramgrah paud road
56	Paudgoan','1	Paudgoan
2	Shaskiy Vishramgruha Paud Road
3	ST stand paudgaon
4	Manik Press Road
5	Forest office road
6	Vitthalwadi phata
7	Balkawdewasti
8	Santi Company
9	Sanakata Company
10	Mukund Shobha Udyan Dattamandir
11	Amralewadi Phata
12	Nursery
13	Sutarwadi Paudroad
14	Cable Company
15	Kasar Amboli
16	Shindewadi Ghotawade
17	Ghotawade Phata
18	Viskar India Company
19	ST stand Pirangut
20	Lavale phata
21	Mail Dagad Kramank 22
22	Mail Dagad Kramank 21
23	Ashram
24	Bandal Farm
25	Bhukoom ashram
26	Nerolac paint company
27	Mail dagad no.18
28	Tangade bandhu mala
29	Mathalwadi
30	Chutke wasti
31	Bhugaon
32	Daulat garden
33	Mariaai mandir bhugaon
34	Deshmukh wasti
35	Bhagwat wasti
36	Dagade wasti
37	Rajwade Bungalow
38	Mail Dagad Kramank 8
39	Chandani chauk
40	Shinde Farm
41	Kothrud depot
42	Bharti nagar
43	kachra depot
44	Paramhansa Corner
45	Vanaz corner
46	Jai bhavani
47	Anand nagar paud road
48	LIC Colony Paud Road
49	More vidyalaya
50	Paudphata police chowky
51	SNDT college
52	Nal stop
53	Petrol pump karve road
54	Garware college
55	Deccan corner sambhaji pul
56	Goodluck Chowk
57	Deccan Gymkhana','56','07:20
10:30
13:45
16:25
19:30
06:10
08:40
11:40
15:10
17:40
21:00','06:10
08:40
11:50
15:05
17:40
20:50
07:20
09:55
12:55
16:25
19:00
22:20','Active');
INSERT INTO "busTable" VALUES(277,'71','Kothrud Depot','Upper Depot','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13.3 KMs','66 Minutes','1	Rajiv Gandhi Nagar Upper Depot
2	Upper Indiranagar
3	Chintamani Nagar
4	Lower Indiranagar
5	Bibwewadi
6	Kothari Corner
7	Vasant Bag
8	Pushp Mangal karyalaya
9	Bhapkar petrol pump City Pride
10	Panchami hotel
11	Laxmi Narayan Theature
12	Swargate
13	Sarasbag
14	Madiwale colony
15	S P college
16	Maharashtra mandal
17	Sahitya parishad peru gate
18	Deccan corner sambhaji pool
19	Garware college
20	Petrol Pump Karve Road
21	Nal Stop
22	SNDT college
23	Paud phata police chauky
24	More vidyalaya
25	LIC colony
26	Anand nagar paud road
27	Jai bhavani
28	Vanaz Corner
29	Vanaz company
30	Kachara depot
31	Bharti nagar
32	kothrud depot','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Sahitya Parishad Peru Gate
17	Maharashtra mandal
18	S P college
19	Madiwale colony
20	Hirabag
21	Swargate corner
22	Swargate
23	Lakshi narayan theature
24	Panchami hotel
25	Bhapkar Petrol Pump City pride
26	Pushp Mangal karyalaya
27	Vasant Bag
28	Kothari Corner
29	Bibwewadi
30	Lower Indiranagar
31	Chintamani Nagar
32	Upper Indiranagar
33	Rajiv Gandhi Nagar Upper Depot','32','07:00
09:30
11:40
13:45
15:45
17:50
20:45','06:10
08:30
10:35
12:45
14:45
16:45
19:35','Active');
INSERT INTO "busTable" VALUES(278,'72','Upper depot','Kondhva gate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','20 KMs','74 Minutes','1	Rajiv Gandhi Nagar Upper Depot
2	Upper Indiranagar
3	Chintamani Nagar
4	Lower Indiranagar
5	Bibwewadi
6	Kothari Corner
7	Vasant Bag
8	Pushp Mangal karyalaya
9	Bhapkar petrol pump City Pride
10	Panchami hotel
11	Laxmi Narayan Theature
12	Swargate
13	Sarasbag
14	Madiwale colony
15	S P college
16	Maharashtra mandal
17	Sahitya parishad peru gate
18	Deccan Corner Sambhaji Pul Corner
19	Garware college
20	Petrol Pump Karve Road
21	Nal Stop
22	SNDT college
23	Paud Phata Dashabhuja Ganpati
24	Maruti mandir karve road
25	Karve putala
26	Kothrud Stand
27	Dahanukar colony
28	Wadache Jhad Bhairavnath Mandir
29	Karvenagar
30	Warje Jakatnaka
31	Tapodham
32	Warje Malwadi
33	Dnanesh society
34	Ganpati matha
35	Dudhane wasti
36	Shivane Gaon
37	Deshmukhwadi
38	Ingale Colony
39	Ahire gate phata
40	Uttamnagar
41	Bhimnagar
42	Kondhava Dhavde
43	NDA gate Kondhva Gate','1	NDA gate Kondhava gate
2	Kondhava dhavade
3	Bhimnagar
4	Uttamanagar
5	Ahire gate Phata
6	Ingale colony
7	Deshmukhwadi
8	Shivane gaon
9	Dudhane wasti
10	Ganpati matha
11	Dnanesh society
12	Warje malwadi
13	Tapodham
14	Warje jakatnaka
15	Karvenagar
16	Wadache jhad
17	Dahanukar colony
18	Kothrud Stand
19	Karve putala
20	Maruti Mandir Karve Road
21	Paud phata dashbhuja mandir
22	SNDT college
23	Nal stop
24	Petrol pump karve road
25	Garware college
26	Deccan corner sambhaji pul
27	Sahitya Parishad Peru Gate
28	Maharashtra mandal
29	S P college
30	Madiwale colony
31	Hirabag
32	Swargate corner
33	Swargate
34	Lakshi narayan theature
35	Panchami hotel
36	Bhapkar Petrol Pump City pride
37	Pushp Mangal karyalaya
38	Vasant Bag
39	Kothari Corner
40	Bibwewadi
41	Lower Indiranagar
42	Chintamani Nagar
43	Upper Indiranagar
44	Rajiv Gandhi Nagar Upper Depot','43','06:05
08:25
11:00
14:10
16:40
19:20
06:50
09:20
11:50
15:00
17:35
20:15
07:40
10:10
13:05
15:50
18:25
21:30','07:10
09:40
12:45
15:25
17:55
21:15
08:05
10:35
13:35
16:15
18:55
21:55
08:45
11:55
14:15
16:55
19:45
22:45','Active');
INSERT INTO "busTable" VALUES(279,'73','Hadapsar gadital','kothrud depot','Mon, Tue, Wed, Thu, Fri, Sat, Sun','18.4 KMs','83 Minutes','1	Hadapsar gadital
2	Hadapsar gaon
3	Magarpatta
4	Gurushankar math
5	Vaidwadi
6	Ram tekadi
7	Kalubai mandir solapur road
8	Fatimanagar Municipal shala
9	Bhauraba nala
10	Race course
11	Mahatma gandhi stand
12	Juna pul gate
13	New hind school
14	Juna motor stand
15	Kashiwadi
16	Ramoshi gate
17	Lakud Bajar
18	Gul aali
19	Kasture chowk
20	Naik Hospital
21	Subhanshah Darga
22	Sonya Maruti Chowk
23	City post
24	Mandai
25	Kunte Chauk
26	Gokhale hall
27	Vijay Talkies
28	Alka talkies
29	Deccan corner sambhaji pool
30	Garware college
31	Petrol Pump Karve Road
32	Nal Stop
33	SNDT college
34	Paud phata police chauky
35	More vidyalaya
36	LIC colony
37	Anand nagar paud road
38	Jai bhavani
39	Vanaz Corner
40	Paramhans corner
41	Kachara depot
42	Bharti nagar
43	kothrud depot','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Chitrashala
17	Sadashiv Peth Houd
18	Mandai
19	Gadikhana
20	Shahu chauk
21	Shitaladevi chauk
22	Ganjpeth Police Chowky
23	Lakud Bajar
24	Juna motor stand
25	New hind school
26	juna pul gate
27	Mahatma gandhi stand
28	Race course
29	Bhauraba nala
30	Fatimanagar Municipal shala
31	Kalubai mandir
32	Ram tekadi
33	Vaidwadi
34	Gurushankar math
35	Magarpatta
36	Hadapsar gaon
37	Hadapsar gadital','43','05:50
08:35
11:45
14:30
17:30
21:00
06:20
09:05
12:30
15:05
17:55
21:45
06:50
09:35
13:05
15:35
18:35
07:30
10:15
13:50
16:15
19:20
07:55
11:10
14:10
16:50
19:45','07:10
09:55
13:10
15:55
19:00
22:30
07:40
10:25
13:55
16:30
19:25
23:05
08:10
11:00
14:30
17:00
20:00
08:50
11:40
14:55
17:40
20:45
09:15
12:35
15:20
18:15
21:15','Active');
INSERT INTO "busTable" VALUES(280,'75','Deccan Gymkhana','Vidyanagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13.5 KMs','68 Minutes','1	Deccan Gymkhana
2	Alka talkies
3	Chitrashala
4	Sadashiv Peth Houd
5	Vishrambag wada
6	A B Chowk
7	Dakshinabhimukh Maruti mandir
8	Shaniwar wada
9	Kasaba Police Chowky
10	Lalmahal
11	Phadake Houd
12	Apolo Talkies
13	KEM hospital
14	Ambedkar bhavan
15	Sasoon hospital
16	Pune station
17	Ruby hall
18	Wadia college
19	Guruprasad bangala
20	Band garden
21	Yerwada
22	Gunjan Theature
23	Netaji school
24	Vikrikar Karyalaya
25	Yerwada post office
26	Nagpur chawl
27	Sanjay park
28	Five nine area
29	Kekan gas agency
30	Tingre nagar Shanti nagar
31	Medical Stores
32	Grampanchayat Tingrenagar
33	Vidyanagar Swapnaganga bangalow','1	Vidyanagar Swapnaganga bangalow
2	Grampanchayat Tingrenagar
3	Medical stores
4	Tingre nagar Shanti nagar
5	Kekan ges agency
6	Five nine area
7	Sanjay park
8	Nagpur Chawl
9	Yerwada post office
10	Vikrikar karyalaya
11	Netaji school
12	White House
13	Yerwada
14	Band garden
15	Guruprasad bangala
16	Jahangir Hospital
17	Alankar Talkies
18	Sadhu wasvani chauk
19	GPO
20	Collector kacheri
21	Zila Parishad
22	KEM hospital
23	Apolo Talkies
24	Daruwala Pool
25	Sonya Maruti Chowk
26	City post
27	Kunte Chauk
28	Gokhale hall
29	Vijay Talkies
30	Alka talkies
31	Goodluck Chowk
32	Deccan Gymkhana','33','05:30
07:45
10:45
14:00
16:15
19:10
06:40
08:55
11:55
15:10
17:25
20:30
07:15
09:30
12:30
15:40
18:05
21:15','06:20
09:00
11:55
15:05
17:30
20:20
07:45
10:10
13:05
16:15
18:40
21:30
08:20
10:45
13:40
16:50
19:20
22:10','Active');
INSERT INTO "busTable" VALUES(281,'76','Kumbare Park','Swargate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','8.6 KMs','52 Minutes','1	Kumbare Park
2	Eklavya polytechnic College
3	Guruganesh Nagar
4	Ashish Garden
5	Mahesh vidyalaya
6	Sahajanand Soc
7	Gandhibhavan Andhshala
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Sahitya Parishad Peru Gate
19	Maharashtra mandal
20	S P college
21	Madiwale colony
22	Hirabag
23	Swargate corner
24	Swargate','1	Swargate
2	Sarasbag
3	Madiwale colony
4	S P college
5	Maharashtra mandal
6	Sahitya parishad peru gate
7	Deccan Corner Sambhaji Pul Corner
8	Garware college
9	Petrol Pump Karve Road
10	Nal Stop
11	SNDT college
12	Paud Phata Dashabhuja Ganpati
13	Maruti mandir karve road
14	Karve putala
15	Kothrud Stand
16	Dahanukar colony
17	Gandhibhavan Andhshala
18	Sahajanand Soc
19	Mahesh Vidyalaya
20	Ashish Garden
21	Guruganesh nagar
22	Kumbare Park','24','06:15
07:45
09:20
11:40
15:00
16:45
18:35
20:55','07:00
08:30
10:15
12:35
15:50
17:40
19:30
21:50','Active');
INSERT INTO "busTable" VALUES(282,'77','Warje Malwadi','Shivajinagar Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','55 Minutes','1	Shivajinagar Station
2	Lokmangal
3	Engineering college hostel
4	Shivaji putala
5	PMC
6	Balgandharv sambhaji par
7	Deccan Gymkhana
8	Deccan Corner Sambhaji Pul Corner
9	Garware college
10	Petrol Pump Karve Road
11	Nal Stop
12	Mehendale garage
13	Date Engineering
14	Bhim Jyoti Soc.
15	Karnataka High school
16	Prasanna Bungalow
17	Ganesh Nagar
18	Bank of Maharashtra
19	Natraj Society
20	Karvenagar
21	Warje Jakatnaka
22	Tapodham
23	Warje Malwadi
24	Dnanesh society
25	Ganpati matha','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Natraj Society
8	Bank of Maharashtra
9	Ganesh Nagar
10	Prasanna Bungalow
11	Karnataka High school
12	Bhim Jyoti Soc.
13	Date Engineering
14	Mehandale Guarage
15	Nal stop
16	Petrol pump karve road
17	Garware college
18	Deccan corner sambhaji pul
19	Goodluck Chowk
20	F C College
21	Dnyaneshwar Paduka chowk
22	Police Line Modern College
23	Modern Highschool
24	PMC
25	Shivaji putala pmc
26	shimala office shivajinagar
27	Shivajinagar Station','25','07:00
08:30
10:30
12:50
14:35
16:15
18:45
20:40','07:45
09:25
11:30
13:45
15:25
17:10
19:45
21:40','Active');
INSERT INTO "busTable" VALUES(283,'78','Market yard','Kondhava gate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','19 KMs','73 Minutes','1	Marketyard
2	Wakhar Mahamandal Marketyard
3	P and T colony
4	Sant namdeo vidyalay
5	Maharshi nagar
6	Mauli bangala
7	Lakshmi narayan theature
8	Swargate
9	Sarasbag
10	Madiwale colony
11	S P college
12	Maharashtra mandal
13	Sahitya parishad peru gate
14	Deccan Corner Sambhaji Pul Corner
15	Garware college
16	Petrol Pump Karve Road
17	Nal Stop
18	Mehandale Guarage
19	Date Engineering
20	Bhim Jyoti Soc.
21	Karnataka High school
22	Alankar Police Chowki
23	Nav Sahyadri Sabhagruha
24	Madhusanchay Society
25	Vitthal Mandir Karvenagar
26	Shriman Society
27	Sahvas Soc
28	Wadache Jhad Bhairavnath Mandir
29	Karvenagar
30	Warje Jakatnaka
31	Tapodham
32	Warje Malwadi
33	Dnanesh society
34	Ganpati matha
35	Dudhane wasti
36	Shivane Gaon
37	Deshmukhwadi
38	Ingale Colony
39	Ahire gate phata
40	Uttamnagar
41	Bhimnagar
42	Kondhava Dhavde
43	NDA gate Kondhva Gate','1	NDA gate Kondhava gate
2	Kondhava dhavade
3	Bhimnagar
4	Uttamanagar
5	Ahire gate Phata
6	Ingale colony
7	Deshmukhwadi
8	Shivane gaon
9	Dudhane wasti
10	Ganpati matha
11	Dnanesh society
12	Warje malwadi
13	Tapodham
14	Warje jakatnaka
15	Karvenagar
16	Wadache jhad
17	Sahvas Soc
18	Shriman Society
19	Vitthal Mandir Karvenagar
20	Madhusanchay Society
21	Nav Sahyadri Sabhagruha
22	Alankar Police Chowki
23	Karnataka High school
24	Bhim Jyoti Soc.
25	Date Engineering
26	Mehandale Guarage
27	Nal stop
28	Petrol pump karve road
29	Garware college
30	Deccan corner sambhaji pul
31	Sahitya Parishad Peru Gate
32	Maharashtra mandal
33	S P college
34	Madiwale colony
35	Hirabag
36	Swargate corner
37	Swargate
38	Lakshi narayan theature
39	Mauli bangala
40	Maharshi nagar
41	Sant namdeo vidyalay
42	P and T colony
43	Wakhar Mahamandal Marketyard
44	Marketyard','43','05:45
08:10
10:40
13:55
16:50
19:20
06:15
08:40
11:10
14:25
17:20
19:50
06:45
09:10
11:40
14:55
17:50
20:20
07:15
09:40
12:40
15:25
18:20
20:50
07:45
10:10
13:10
15:55
18:50
21:30','06:55
09:25
12:25
15:05
18:05
20:35
07:25
09:55
12:55
15:35
18:35
21:05
07:55
10:25
13:25
16:05
19:05
21:35
08:25
10:55
13:55
16:35
19:35
22:05
08:55
11:25
14:25
17:05
20:05
22:35','Active');
INSERT INTO "busTable" VALUES(284,'79','Warje Malwadi','Shivajinagar Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','52 Minutes','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Goodluck Chowk
19	F C College
20	Dnyaneshwar paduka chauk
21	shimala office shivajinagar
22	Shivajinagar Station','1	Shivajinagar Station
2	Lokmangal
3	Engineering college hostel
4	Modern Highschool
5	Balgandharv sambhaji par
6	Deccan Gymkhana
7	Deccan corner sambhaji pool
8	Garware college
9	Petrol Pump Karve Road
10	Nal Stop
11	SNDT college
12	Paud Phata Dashabhuja Ganpati
13	Maruti mandir karve road
14	Karve putala
15	Kothrud Stand
16	Dahanukar colony
17	Wadache Jhad Bhairavnath Mandir
18	Karvenagar
19	Warje Jakatnaka
20	Tapodham
21	Warje Malwadi
22	Dnanesh society
23	Ganpati matha','22','06:35
08:10
09:55
12:20
14:00
15:30
17:15
19:15
21:40','07:20
09:00
10:50
13:15
14:45
16:20
18:15
20:20
22:20','Active');
INSERT INTO "busTable" VALUES(285,'7A','Hadapsar gadital','Urali Kanchan','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','45 Minutes','1	Hadapsar gadital
2	Agrawal Colony
3	Akashwani hadapasar
4	15 number Manjari Gaon Phata
5	Laxmideep colony
6	Rambag solapur rd
7	Manjri farm
8	Phursungi gaon phata
9	Krushi mahavidyalaya
10	Kavadi pat
11	Kavadi rasta
12	Wakvasti
13	Fuel depot
14	Kadam wasti
15	Loni station
16	Loni phata
17	Ramkrushna rasayan karkhana
18	Malyacha mala
19	Borkar wasti
20	Tamnya wasti
21	Theur phata
22	Kalbhor wasti solapur rd.
23	Tendulkar wasti
24	Kunjirwadi
25	Naygaon phata
26	Bank of badoda
27	Green ekars
28	Badade wasti
29	Chaudhari wasti
30	Sortapwadi
31	Rajendra pipe company
32	Inamdar Wasti
33	Bhosale Wasti
34	Prayag Dham Phata
35	Urali Kanchan','1	Urali Kanchan
2	Prayag Dham Phata
3	Bhosale Wasti
4	Inamdar Wasti
5	Rajendra pipe company
6	Sortapwadi
7	Chaudhari wasti
8	Badade wasti
9	Green ekars
10	Bank of badoda solapur rd
11	Naygaon phata
12	Kunjirwadi
13	Tendulkar wasti
14	Kalbhor wasti solapur rd.
15	Theur phata
16	Tamnya wasti
17	Borkar wasti
18	Malyacha mala
19	Ramkrushna rasayan karkhana
20	Loni phata
21	Loni station
22	Kadam wasti
23	Fuel depot
24	Wakvasti
25	Kavadi rasta
26	Kavadi pat
27	Krushi mahavidyalaya
28	Phursungi gaon phata
29	Manjri farm
30	Rambag solapur rd
31	Laxmideep colony
32	15 number Manjari Gaon Phata
33	Akashwani hadapasar
34	Agrawal colony
35	Hadapsar gadital','35','05:20
06:45
08:10
09:40
11:45
13:15
14:45
16:15
17:45
19:15
21:15
05:30
06:55
08:25
09:55
11:55
13:25
14:55
16:25
17:55
19:25
21:25
05:40
07:05
08:35
10:05
12:05
13:35
15:05
16:35
18:05
19:35
21:35
05:50
07:15
08:45
10:15
12:15
13:45
15:15
16:45
18:15
19:45
21:45
06:05
07:30
09:00
10:30
12:30
14:00
15:30
17:00
18:30
20:30
22:00
06:15
07:40
09:10
10:40
12:40
14:10
15:40
17:10
18:40
20:40
22:15
06:30
07:55
09:25
10:55
12:55
15:55
17:25
18:55
20:55
22:30','06:00
07:30
09:00
10:30
12:30
14:00
15:30
17:00
18:30
20:00
22:00
06:10
07:40
09:10
10:40
12:40
14:10
15:40
17:10
18:40
20:10
22:10
06:20
07:50
09:20
10:50
12:50
14:20
15:50
17:20
18:50
20:20
22:20
06:30
08:00
09:30
11:00
13:00
14:30
16:00
17:30
19:00
20:30
22:30
06:45
08:15
09:45
11:15
13:15
14:45
16:15
17:45
19:15
21:15
22:45
06:55
08:25
09:55
11:25
13:25
14:50
16:25
17:55
19:25
21:25
22:55
07:10
08:40
10:10
11:40
13:40
16:40
18:10
19:40
21:40
23:15','Active');
INSERT INTO "busTable" VALUES(286,'7S','Pune Station','Hinjewadi phase3','Mon, Tue, Wed, Thu, Fri, Sat, Sun','23 KMs','75 Minutes','1	Pune Station Depot
2	GPO
3	Collector kacheri
4	Ambedkar bhavan
5	Juna Bajar
6	Kumbhar wada
7	PMC
8	Shivaji putala pmc
9	shimala office shivajinagar
10	Masoba gate
11	Pumping station
12	Pune central
13	E square
14	Rangehills Corner
15	Pune University Gate
16	chavan nagar university road
17	Sakal nagar
18	Sindh colony
19	Baner phata
20	Green Park hotel
21	Trimurti bunglow
22	Ambedkar nagar
23	Murkute wasti
24	Baner gaon
25	Baner odha
26	Balewadi Phata
27	Chakankar mala
28	Deasi poultry farm
29	Balewadi
30	Bharat English school
31	Chha. Shivaji Krida Sankul
32	Mutha Pool Balewadi
33	Wakad Highway
34	Hinjewadi Gaon
35	Hinjewadi Police Station
36	Infosys company
37	Wipro company Circle
38	Infosys Phase 2
39	Power House IT Park
40	Tata Motors IT Park
41	Circle IT Park
42	Infosys Phase 3 Gawarwadi','1	Infosys Phase 3 Gawarwadi
2	Circle IT Park
3	Tata Motors IT Park
4	Power House IT Park
5	Infosys Phase 2
6	Wipro company Circle
7	Infosys company
8	Hinjewadi Police Station
9	Hinjewadi Gaon
10	Wakad Highway
11	Mutha Pool Balewadi
12	Chh.Shivaji krida sankul
13	Bharat English School
14	Balewadi
15	Desai Poultry Farm
16	Chakankar Mala
17	Balewadi Phata
18	Baner odha
19	Baner Gaon
20	Murkutewasti Pavitra hotel
21	Ambedkar Nagar
22	Trimurti Bungalow
23	Green park hotel
24	Baner phata
25	Sindh colony
26	Sakal nagar
27	Chavan Nagar University Road
28	Pune University Gate
29	Pune University Gate
30	Rangehills Corner
31	E Square
32	Pune central
33	Pumping station
34	Masoba gate
35	shimala office shivajinagar
36	Engineering college hostel
37	Shivaji putala
38	PMC Mangala
39	Kumbhar Wada
40	Juna Bajar
41	Ambedkar bhavan
42	Sasoon hospital
43	Pune station
44	Pune Station Depot','42','07:10
09:40
12:15
15:30','08:20
10:55
13:35
16:45','Active');
INSERT INTO "busTable" VALUES(287,'8','Hadapsar gadital','Mhatobachi Alandi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','19 KMs','39 Minutes','1	Hadapsar gadital
2	Agrawal Colony
3	Akashwani hadapasar
4	15 number Manjari Gaon Phata
5	Laxmideep colony
6	Rambag solapur rd
7	Manjri farm
8	Phursungi gaon phata
9	Krushi mahavidyalaya
10	Kavadi pat
11	Kavadi rasta
12	Wakvasti
13	Fuel depot
14	Kadam wasti
15	Loni station
16	Loni phata
17	Ramkrushna rasayan karkhana
18	Malyacha mala
19	Borkar wasti
20	Tamnya wasti
21	Theur phata
22	Kalbhor wasti solapur rd.
23	Tendulkar wasti
24	Kunjirwadi
25	Kunjir Wadi Goan
26	Malwadi Kunjir
27	Karade Wasti
28	Chowdhari Bag
29	Railway gate Mhatobachi alandi
30	Javalkar Hospital
31	Mhatobachi Alandi','1	Mhatobachi Alandi
2	Jawalkar Hospital
3	Railway gate Mhatobachi alandi
4	Chowdhari Bag
5	Karade Wasti
6	Malwadi Kunjir
7	Kunjir Wadi Goan
8	Kunjirwadi
9	Tendulkar wasti
10	Kalbhor wasti solapur rd.
11	Theur phata
12	Tamnya wasti
13	Borkar wasti
14	Malyacha mala
15	Ramkrushna rasayan karkhana
16	Loni phata
17	Loni station
18	Kadam wasti
19	Fuel depot
20	Wakvasti
21	Kavadi rasta
22	Kavadi pat
23	Krushi mahavidyalaya
24	Phursungi gaon phata
25	Manjri farm
26	Rambag solapur rd
27	Laxmideep colony
28	15 number Manjari Gaon Phata
29	Akashwani hadapasar
30	Agrawal colony
31	Hadapsar gadital','31','06:50
08:25
10:00
12:00
15:15
16:45
18:15
20:40','06:10
07:35
09:10
10:45
12:45
16:00
17:30
19:00','Active');
INSERT INTO "busTable" VALUES(288,'80','Manapa','Cipla center','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9.4 KMs','45 Minutes','1	PMC
2	Balgandharv sambhaji par
3	Deccan Gymkhana
4	Deccan Corner Sambhaji Pul Corner
5	Garware college
6	Petrol Pump Karve Road
7	Nal Stop
8	SNDT college
9	Paud Phata Dashabhuja Ganpati
10	Maruti mandir karve road
11	Karve putala
12	Kothrud Stand
13	Dahanukar colony
14	Wadache Jhad Bhairavnath Mandir
15	Karvenagar
16	Warje Jakatnaka
17	Tapodham
18	Warje gaon highway
19	Popular Nagar Cipla cancer care entre','1	Popular Nagar Cipla cancer care entre
2	Warje Gaon Highway
3	Tapodham
4	Warje jakatnaka
5	Karvenagar
6	Wadache jhad
7	Dahanukar colony
8	Kothrud Stand
9	Karve putala
10	Maruti Mandir Karve Road
11	Paud phata dashbhuja mandir
12	SNDT college
13	Nal stop
14	Petrol pump karve road
15	Garware college
16	Deccan corner sambhaji pul
17	Goodluck Chowk
18	F C College
19	Dnyaneshwar Paduka chowk
20	Police Line Modern College
21	Modern Highschool
22	PMC','19','09:20
15:35','07:20
10:05
16:20','Active');
INSERT INTO "busTable" VALUES(289,'81','Kumbare Park','Pune station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','13 KMs','59 Minutes','1	Kumbare Park
2	Guruganesh Nagar
3	Ashish Garden
4	Mahesh Vidyalaya
5	Sahajanand Soc
6	Gandhibhavan Andhshala
7	Ankur Bungalow
8	Shastrinagar
9	Vivekanand Society
10	Sutar Dawakhana
11	Vanaz corner
12	Jai bhavani
13	Anand nagar paud road
14	LIC Colony Paud Road
15	More vidyalaya
16	Paudphata police chowky
17	SNDT college
18	Nal stop
19	Petrol pump karve road
20	Garware college
21	Deccan corner sambhaji pul
22	Alka talkies
23	Chitrashala
24	Sadashiv Peth Houd
25	Vishrambag wada
26	A B Chowk
27	Dakshinabhimukh Maruti mandir
28	Shaniwar wada
29	Kasaba Police Chowky
30	Lalmahal
31	Phadake Houd
32	Rastewada
33	15 August Lodge Somwar Peth
34	Ambedkar bhavan
35	Sasoon hospital
36	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Zila Parishad
6	KEM hospital
7	Daruwala Pool
8	Sonya Maruti Chowk
9	City post
10	Kunte Chauk
11	Gokhale hall
12	Vijay Talkies
13	Alka talkies
14	Deccan Corner Sambhaji Pul Corner
15	Garware college
16	Petrol Pump Karve Road
17	Nal Stop
18	SNDT college
19	Paud phata police chauky
20	More vidyalaya
21	LIC colony
22	Anand nagar paud road
23	Jai bhavani
24	Pratik nagar
25	Andhshala
26	Sahajanand Soc
27	Mahesh vidyalaya
28	Ashish Garden
29	Guruganesh nagar
30	Kumbare Park','36','06:20
08:05
10:15
12:45
14:55
16:55
19:00
21:35
06:35
08:25
10:30
13:05
15:25
17:20
19:25
07:05
08:55
11:35
13:25
15:45
17:45
19:50
07:20
09:25
12:00
13:55
16:10
18:05
20:10
07:45
09:35
12:15
14:15
16:30
18:30
21:05','07:10
09:10
11:15
13:40
15:55
17:55
20:05
22:35
07:30
09:30
11:35
14:00
16:20
18:20
20:30
07:55
09:55
12:30
14:25
16:45
18:45
20:55
08:20
10:20
12:55
14:50
17:10
19:05
21:15
08:40
10:40
13:10
15:10
17:30
19:35
22:05','Active');
INSERT INTO "busTable" VALUES(290,'82','Manapa','Kondhava Gate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','14.3 KMs','58 Minutes','1	PMC
2	Balgandharv sambhaji par
3	Deccan Gymkhana
4	Deccan Corner Sambhaji Pul Corner
5	Garware college
6	Petrol Pump Karve Road
7	Nal Stop
8	SNDT college
9	Paud Phata Dashabhuja Ganpati
10	Maruti mandir karve road
11	Karve putala
12	Kothrud Stand
13	Dahanukar colony
14	Wadache Jhad Bhairavnath Mandir
15	Karvenagar
16	Warje Jakatnaka
17	Tapodham
18	Warje Malwadi
19	Dnanesh society
20	Ganpati matha
21	Dudhane wasti
22	Shivane Gaon
23	Deshmukhwadi
24	Ingale Colony
25	Ahire gate phata
26	Uttamnagar
27	Bhimnagar
28	Kondhava Dhavde
29	NDA gate Kondhva Gate','1	NDA gate Kondhava gate
2	Kondhava dhavade
3	Bhimnagar
4	Uttamanagar
5	Ahire gate Phata
6	Ingale colony
7	Deshmukhwadi
8	Shivane gaon
9	Dudhane wasti
10	Ganpati matha
11	Dnanesh society
12	Warje malwadi
13	Tapodham
14	Warje jakatnaka
15	Karvenagar
16	Wadache jhad
17	Dahanukar colony
18	Kothrud Stand
19	Karve putala
20	Maruti Mandir Karve Road
21	Paud phata dashbhuja mandir
22	SNDT college
23	Nal stop
24	Petrol pump karve road
25	Garware college
26	Deccan corner sambhaji pul
27	Goodluck Chowk
28	F C College
29	Dnyaneshwar Paduka chowk
30	Police Line Modern College
31	Modern Highschool
32	PMC','29','07:20
09:20
11:50
14:00
16:00
18:00
20:25
05:45
07:35
09:35
12:05
14:15
16:10
18:10
20:40
06:00
07:50
09:50
12:20
16:20
18:20
20:50
22:50
06:15
08:05
10:05
12:35
14:30
16:30
18:30
21:00
08:20
10:20
12:50
14:40
16:40
18:40
21:10
06:40
08:30
10:30
13:00
14:50
16:50
18:50
21:20
08:40
10:40
13:10
15:05
17:05
07:00
08:50
10:50
13:20
15:20
17:20
19:20
21:50
09:00
11:30
13:30
15:35
17:35
19:35
22:05
07:10
09:10
11:10
13:40
15:50
17:50
19:55
22:20','06:20
08:20
10:20
12:45
15:00
17:00
18:55
21:25
06:35
08:35
10:35
13:00
15:10
17:10
19:10
21:35
06:50
08:50
10:50
13:15
17:20
19:20
21:50
23:45
07:05
09:05
11:05
13:30
15:30
17:30
19:30
21:55
07:20
09:20
11:20
13:45
15:40
17:40
19:40
22:05
07:30
09:30
11:30
13:55
15:50
17:50
19:50
22:15
07:40
09:40
11:40
14:05
16:05
18:05
07:50
09:50
11:50
14:15
16:20
18:20
20:20
22:45
08:00
10:00
12:30
14:25
16:35
18:35
20:35
23:00
08:10
10:10
12:10
14:35
16:50
18:50
20:50
23:15','Active');
INSERT INTO "busTable" VALUES(291,'83','Manapa','Warje malwadi','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','41 Minutes','1	PMC
2	Balgandharv sambhaji par
3	Deccan Gymkhana
4	Deccan Corner Sambhaji Pul Corner
5	Garware college
6	Petrol Pump Karve Road
7	Nal Stop
8	SNDT college
9	Paud Phata Dashabhuja Ganpati
10	Maruti mandir karve road
11	Karve putala
12	Kothrud Stand
13	Dahanukar colony
14	Wadache Jhad Bhairavnath Mandir
15	Karvenagar
16	Warje Jakatnaka
17	Tapodham
18	Warje Malwadi
19	Dnanesh society
20	Ganpati matha','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Goodluck Chowk
19	F C College
20	Dnyaneshwar Paduka chowk
21	Police Line Modern College
22	Modern Highschool
23	PMC','20','06:25
07:45
09:15
11:15
12:45
14:10
15:40
17:15
18:55
21:05
06:35
07:55
09:25
11:25
12:55
15:45
17:25
19:05
21:15
22:35
06:45
08:10
09:40
11:35
13:05
14:25
15:55
17:40
19:15
21:25
07:05
08:25
09:55
11:55
13:25
16:15
17:55
19:40
21:10
23:15
07:15
08:35
10:10
12:00
13:35
15:00
16:25
18:05
20:15
21:45
07:25
08:45
10:15
12:10
13:45
16:35
18:15
19:55
22:00
23:25
07:30
08:55
10:55
12:25
13:50
15:15
16:45
18:25
20:35
22:10
07:40
09:05
10:35
12:30
13:55
15:30
17:00
18:40
20:45
22:15','05:45
07:05
08:30
10:00
12:00
13:30
14:55
16:25
18:05
19:45
05:55
07:15
08:40
10:10
12:10
13:40
16:35
18:15
19:55
21:50
06:05
07:25
08:50
10:20
12:20
13:50
15:15
16:45
18:25
20:05
06:25
07:45
09:10
10:40
12:40
14:10
17:05
18:45
20:25
22:00
06:35
07:55
09:20
10:55
12:50
14:20
15:45
17:15
18:55
21:05
06:45
08:05
09:30
11:00
13:00
14:30
17:25
19:05
20:45
22:40
06:50
08:10
09:35
11:35
13:05
14:35
16:05
17:35
19:15
21:25
07:00
08:20
09:45
11:15
13:15
14:45
16:15
17:45
19:30
21:35','Active');
INSERT INTO "busTable" VALUES(292,'84','Deccan gymkhana','Sangrun','Mon, Tue, Wed, Thu, Fri, Sat, Sun','1 KMs','90 Minutes','1	Deccan Gymkhana
2	Deccan Corner Sambhaji Pul Corner
3	Garware college
4	Petrol Pump Karve Road
5	Nal Stop
6	SNDT college
7	Paud Phata Dashabhuja Ganpati
8	Maruti mandir karve road
9	Karve putala
10	Kothrud Stand
11	Dahanukar colony
12	Wadache Jhad Bhairavnath Mandir
13	Karvenagar
14	Warje Jakatnaka
15	Tapodham
16	Warje Malwadi
17	Dnanesh society
18	Ganpati matha
19	Dudhane wasti
20	Shivane Gaon
21	Deshmukhwadi
22	Ingale Colony
23	Ahire gate phata
24	Uttamnagar
25	Bhimnagar
26	Kondhava Dhavde
27	NDA gate Kondhva Gate
28	NDA Gate No 10
29	Khadakwasla Dharan Stores
30	Pickock Bay
31	Donger Matha
32	Dhumal Tali
33	Kudje gaon
34	Kudje Stand
35	Agalambe Phata
36	Patvardhan Farm
37	Mandvi Khurd
38	Mandavi Budruk
39	Spedor Country cluB Gate 2
40	Sangrun Phata
41	Sangrun','1	Sangrun
2	Sangrun Phata
3	Spedor Country cluB Gate 2
4	Mandavi Budruk
5	Mandvi Khurd
6	Patvardhan Farm
7	Agalambe Phata
8	Kudje Stand
9	Kudje gaon
10	Dhumal Tali
11	Donger Matha
12	Pickock
13	Khadakwasla Dharan Stores
14	NDA gate no.10
15	NDA gate Kondhava gate
16	Kondhava dhavade
17	Bhimnagar
18	Uttamanagar
19	Ahire gate phata
20	Ingale colony
21	Deshmukhwadi
22	Shivane gaon
23	Dudhane wasti
24	Ganpati matha
25	Dnanesh society
26	Warje malwadi
27	Tapodham
28	Warje jakatnaka
29	Karvenagar
30	Wadache jhad
31	Dahanukar colony
32	Kothrud Stand
33	Karve putala
34	Maruti Mandir Karve Road
35	Paud phata dashbhuja mandir
36	SNDT college
37	Nal stop
38	Petrol pump karve road
39	Garware college
40	Deccan corner sambhaji pul
41	Goodluck Chowk
42	Deccan Gymkhana','41','08:00
14:30
18:00','06:30
09:30
16:00
19:30','Active');
INSERT INTO "busTable" VALUES(293,'85','Manapa','Ahire gaon','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21.6 KMs','76 Minutes','1	PMC
2	Balgandharv sambhaji par
3	Deccan Gymkhana
4	Deccan corner sambhaji pool
5	Garware college
6	Petrol Pump Karve Road
7	Nal Stop
8	SNDT college
9	Paud Phata Dashabhuja Ganpati
10	Maruti mandir karve road
11	Karve putala
12	Dahanukar colony
13	Wadache Jhad Bhairavnath Mandir
14	Karvenagar
15	Warje Jakatnaka
16	Tapodham
17	Warje Malwadi
18	Dnanesh society
19	Ganpati matha
20	Dudhane wasti
21	Shivane Gaon
22	Deshmukhwadi
23	Ingale Colony
24	Ahire gate phata
25	Uttamnagar
26	Bhimnagar
27	Kondhava Dhavde
28	NDA gate Kondhva Gate
29	Ashok Stambha
30	Gol Market NDA
31	Gol Market NDA
32	Stadium NDA
33	Servents Quarters
34	D2 Circle
35	Ahire phata
36	Ahire gaon','1	Ahire gaon
2	Ahire phata
3	D2 Circle
4	Servents Quarters
5	Stadium NDA
6	Ashok Stambha
7	Gol Market NDA
8	Hockey Ground
9	NDA gate Kondhva Gate
10	Kondhava dhavade
11	Bhimnagar
12	Uttamanagar
13	Ahire gate phata
14	Ingale colony
15	Deshmukhwadi
16	Shivane gaon
17	Dudhane wasti
18	Ganpati matha
19	Dnanesh society
20	Warje malwadi
21	Tapodham
22	Warje jakatnaka
23	Karvenagar
24	Wadache jhad
25	Dahanukar colony
26	Kothrud Stand
27	Karve putala
28	Maruti Mandir Karve Road
29	Paud phata dashbhuja mandir
30	SNDT college
31	Nal stop
32	Petrol pump karve road
33	Garware college
34	Deccan corner sambhaji pul
35	Goodluck Chowk
36	F C College
37	Dnyaneshwar Paduka chowk
38	Police Line Modern College
39	Modern Highschool
40	PMC','36','08:35
11:40
14:20
17:00','07:15
09:45
12:55
15:40
18:20','Active');
INSERT INTO "busTable" VALUES(294,'86','Kothrud Depot','Manapa','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7.6 KMs','42 Minutes','1	PMC
2	Balgandharv sambhaji par
3	Deccan Gymkhana
4	Deccan corner sambhaji pool
5	Garware college
6	Petrol Pump Karve Road
7	Nal Stop
8	SNDT college
9	Paud phata police chauky
10	More vidyalaya
11	LIC colony
12	Anand nagar paud road
13	Jai bhavani
14	Vanaz Corner
15	Vanaz company
16	Paramhans corner
17	Kachara depot
18	Bharti nagar
19	kothrud depot','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Goodluck Chowk
17	F C College
18	Dnyaneshwar Paduka chowk
19	Police Line Modern College
20	Modern Highschool
21	PMC','19','05:45
07:05
08:25
09:55
11:45
13:10
14:30
15:50
17:10
18:35
20:25
21:55
07:15
08:35
10:05
12:00
13:20
14:40
16:00
17:20
18:45
20:40
06:05
07:25
08:45
10:15
12:10
13:30
14:50
16:10
17:30
18:55
20:50
22:15
07:35
08:55
10:25
12:20
13:40
15:00
16:20
17:40
19:05
21:00
06:25
07:45
09:05
10:35
12:30
13:50
15:10
16:30
17:50
19:15
21:10
22:35
06:25
07:55
09:15
10:45
12:40
14:00
15:20
16:40
18:00
19:25
21:20
06:45
08:05
09:25
11:35
12:50
14:10
15:30
16:50
18:10
20:05
21:30
06:55
08:15
09:35
11:05
13:00
14:20
15:40
17:00
18:20
19:45
21:40','06:25
07:45
09:10
10:40
12:25
13:50
15:10
16:30
17:50
19:15
21:15
22:35
07:55
09:20
10:50
12:40
14:00
15:20
16:40
18:00
19:25
21:25
06:45
08:05
09:30
11:00
12:50
14:10
15:30
16:50
18:10
19:35
21:35
22:55
08:15
09:40
11:10
13:00
14:20
15:40
17:00
18:20
19:45
21:45
07:05
08:25
09:50
11:20
13:10
14:30
15:50
17:10
18:30
19:55
21:55
23:15
07:15
08:35
10:00
11:30
13:20
14:40
16:00
17:20
18:40
20:05
22:05
07:25
08:45
10:10
12:10
13:30
14:50
16:10
17:30
18:50
20:45
22:15
07:35
08:55
10:20
11:50
13:40
15:00
16:20
17:40
19:00
20:25
22:45','Active');
INSERT INTO "busTable" VALUES(295,'87','Deccan gymkhana','Abhinav college','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','42 Minutes','1	Deccan Gymkhana
2	Goodluck Chowk
3	F C College
4	Dnyaneshwar Paduka chowk
5	Police Line Modern College
6	Modern Highschool
7	PMC
8	Shivaji putala pmc
9	shimala office shivajinagar
10	Masoba gate
11	Pune central
12	E square
13	Rangehills Corner
14	Pune Vidyapeeth
15	Police head office
16	Loyala Highschool
17	NCL market
18	NCL
19	Panchwati
20	IITM
21	ARDE bus stop
22	Pashan
23	Pashan gaon
24	NIV
25	Sai Chauk
26	Abhinav college
27	Sutarwadi','1	Abhinav college
2	Sai Chauk
3	NIV
4	Pashan gaon
5	Pashan
6	ARDE bus stop
7	IITM
8	Panchwati
9	NCL
10	NCL Market
11	Loyala Highschool
12	Police head office
13	Pune Vidyapeeth
14	Pune University Gate
15	Rangehills Corner
16	E Square
17	Pune central
18	Pumping station
19	Masoba gate
20	shimala office shivajinagar
21	Engineering college hostel
22	Modern Highschool
23	PMC
24	Balgandharv sambhaji par
25	Deccan Gymkhana','27','06:10
07:35
09:10
11:20
12:40
14:20
15:50
17:20
19:00
21:05
22:40
06:30
07:55
09:30
11:30
13:00
14:40
16:10
17:45
19:25
21:30
23:00
06:50
08:15
09:50
11:50
13:20
15:00
16:30
18:05
19:45
21:50
07:10
08:35
10:10
12:10
13:40
15:20
16:50
18:25
20:05
22:10
08:55
10:35
12:30
14:00
15:40
17:10
18:50
20:25
22:30','05:30
06:50
08:20
10:00
12:00
13:20
15:05
16:35
18:10
19:50
21:50
23:15
05:50
07:10
08:40
10:20
12:15
13:40
15:25
16:55
18:35
20:10
22:15
06:10
07:30
09:00
10:40
12:35
14:00
15:45
17:15
18:55
20:30
22:30
06:30
07:50
09:20
11:00
12:55
14:20
16:05
17:35
19:15
20:50
08:10
09:45
11:25
13:15
14:45
16:25
18:00
19:35
21:10','Active');
INSERT INTO "busTable" VALUES(296,'88','Swargate','Medi point','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12 KMs','52 Minutes','1	Swargate
2	Sarasbag
3	Bhikardas maruti madnir
4	Shanipar
5	A B Chowk
6	Dakshinabhimukh Maruti mandir
7	Shaniwar wada
8	PMC mangala
9	Shivaji putala pmc
10	shimala office shivajinagar
11	Masoba gate
12	Pumping station
13	Pune central
14	E square
15	Rangehills Corner
16	Pune University Gate
17	chavan nagar university road
18	Sakal nagar
19	Sindh colony
20	Baner phata
21	Sanewadi
22	Anand park sindhi colony
23	ITI parihar Chauk
24	Pinnac Society
25	Vasundara Lawns
26	Medi point','1	Medi point
2	Vasundara Lawns
3	Pinnac Society
4	ITI parihar chauk
5	Aanand park sindhi colony
6	Sanewadi
7	Baner phata
8	Sindh colony
9	Sakal nagar
10	Chavan Nagar University Road
11	Pune University Gate
12	Rangehills Corner
13	E Square
14	Pune central
15	Pumping station
16	Masoba gate
17	shimala office shivajinagar
18	Sancheti Hospital
19	Shivaji putala
20	PMC Mangala
21	Kasaba Police Chowky
22	Vasant talkies
23	Mandai
24	Shahu chauk
25	Gokul bhavan
26	Swargate','26','06:10
07:50
10:05
11:55
13:40
15:20
17:35
19:20
07:00
08:40
11:00
12:50
14:30
16:10
18:25
20:20','07:00
08:40
11:00
12:50
14:30
16:10
18:25
20:10
07:50
09:30
11:55
13:40
15:20
17:05
19:20
21:10','Active');
INSERT INTO "busTable" VALUES(297,'89','Swargate','Niljyoti','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7.5 KMs','42 Minutes','1	Swargate
2	Swargate
3	Sarasbag
4	Madiwale colony
5	S P college
6	Maharashtra mandal
7	Sahitya parishad peru gate
8	Goodluck Chowk
9	F C College
10	Dnyaneshwar paduka chauk
11	Lakaki Bungalow
12	Model colony
13	Deep Bungalow Chowk
14	Vetal Maharaj chauk
15	Kusalkar Putala
16	Janwadi
17	Maharashtra Housing Niljyoti','1	Maharashtra Housing Niljyoti
2	Janwadi
3	Kusalkar putala
4	Vetal Maharaj chauk
5	Deep Bungalow Chowk
6	Model colony
7	Lakaki Bungalow
8	Dnyaneshwar Paduka chowk
9	Police Line Modern College
10	Modern Highschool
11	Balgandharv sambhaji par
12	Deccan Gymkhana
13	Sahitya Parishad Peru Gate
14	Maharashtra mandal
15	S P college
16	Madiwale colony
17	Hirabag
18	Swargate corner
19	Swargate
20	Swargate','17','05:40
06:55
08:15
09:40
11:35
12:55
14:40
16:00
17:35
19:10
21:10
06:05
07:20
08:40
10:05
12:00
13:20
15:05
16:25
18:00
19:35
21:35
06:30
07:45
09:05
10:30
12:25
13:45
15:30
16:50
18:25
20:00
22:00','06:15
07:35
08:55
10:20
12:15
13:35
15:20
16:45
18:25
19:55
21:55
06:40
08:00
09:20
10:45
12:40
14:00
15:45
17:10
18:50
20:20
22:20
07:05
08:25
09:45
11:10
13:05
14:25
16:15
17:50
19:25
20:55
22:50','Active');
INSERT INTO "busTable" VALUES(298,'8S','Manapa','Pabal phata','Mon, Tue, Wed, Thu, Fri, Sat, Sun','38 KMs','106 Minutes','1	PMC Mangala
2	Kumbhar Wada
3	Juna Bajar
4	Ambedkar bhavan
5	Sasoon hospital
6	Pune station
7	Ruby hall
8	Wadia college
9	Guruprasad bangala
10	Band garden
11	Yerwada
12	wadia bangala
13	Shastri nagar
14	Agakhan palace
15	Ramwadi Jakatnaka
16	Ramwadi
17	Weikfield
18	ISL Company
19	WNC Company
20	Dharmanagar 5 va Mail
21	Tata Guardroom Kharadi Phata
22	Chandan Nagar
23	NEI Company
24	Nagarroad Phata Shriramnagar
25	NEI Company
26	Naik bungalow
27	Janakbaba Darga
28	Ramnarayan Bungalow
29	Lieson company
30	Satav High School
31	Wagholi
32	Kesanand phata
33	Pacharne wasti
34	Bharti Jain Sanghatna College
35	Jagtap Dairy Lonikand
36	Lonikand
37	Phulgaon Phata
38	Power House Phulgaon
39	Mail Dagad Kramank 23
40	Perne Phata
41	Polcompany
42	Waghmare wasti
43	Koregaon Bhima
44	Bafna Industries
45	Ekora Company Kalyani Forbes
46	Darekar Wasti
47	Sanaswadi
48	Jakate wasti
49	Shikrapur Phata
50	Pabal Phata','1	Pabal Phata
2	Shikrapur Phata
3	Jakate wasti
4	Sanaswadi
5	Darekar Wasti
6	Ekora Company Kalyani Forbes
7	Bafna Industries
8	Koregaon Bhima
9	Waghmare wasti
10	Polcompany
11	Perne Phata
12	Mail Dagad Kramank 23
13	Power House Phulgaon
14	Phulgaon phata
15	Lonikand
16	Jagtap Dairy Lonikand
17	Bharti Jain Sanghatna College
18	Pacharne wasti
19	Kesanand phata
20	Wagholi
21	Satva high school
22	Lieson Company
23	Ramnarayan Bungalow
24	Janakbaba Darga
25	Naik Bungalow
26	NEI company
27	Nagarroad Phata Shriramnagar
28	NEI Company
29	Chandan nagar
30	Tata gaurdroom Kharadi phata
31	Dharmanagar 5 va mail
32	WNC Company
33	ISL Company
34	Weikfield
35	Ramwadi
36	Ramwadi jakatnaka
37	Agakhan palace
38	Shastri nagar
39	Wadia bunglow
40	Yerwada
41	Band garden
42	Guruprasad bangala
43	Jahangir Hospital
44	Alankar Talkies
45	Sadhu wasvani chauk
46	GPO
47	Collector kacheri
48	Ambedkar bhavan
49	Juna Bajar
50	Kumbhar wada
51	PMC','50','09:00
13:00
16:30
09:20
13:30
17:00
10:00
14:00
17:30
10:30
14:30
18:00','10:45
14:45
18:15
11:15
15:15
18:45
11:45
15:45
19:15
12:15
16:15
19:45','Active');
INSERT INTO "busTable" VALUES(299,'9','Hadapasar','Uruli Kanchan Railway Staion','Mon, Tue, Wed, Thu, Fri, Sat, Sun','27 KMs','70 Minutes','1	Hadapsar gadital
2	Agrawal Colony
3	Akashwani hadapasar
4	15 number Manjari Gaon Phata
5	Laxmideep colony
6	Rambag solapur rd
7	Manjri farm
8	Phursungi gaon phata
9	Krushi mahavidyalaya
10	Kavadi pat
11	Kavadi rasta
12	Wakvasti
13	Fuel depot
14	Kadam wasti
15	Loni station
16	Loni phata
17	Ramkrushna rasayan karkhana
18	Malyacha mala
19	Borkar wasti
20	Tamnya wasti
21	Theur phata
22	Kalbhor wasti solapur rd.
23	Tendulkar wasti
24	Kunjirwadi
25	Naygaon phata
26	Railway gate no.1
27	Chaufula
28	Yadav Wasti Chaufula
29	Malwadi Naygaon
30	Naygoan
31	Malran
32	Prayagdham Ashram
33	Prayagdham Hospital
34	Bodhe wasti
35	Railway Gate Aata Mill Karkhana
36	Bagade wasti
37	Railway Station Uruli Kanchan ','1	Railway Station Uruli Kanchan
2	Bagade wasti
3	Railway Gate Aata Mill Karkhana
4	Bodhe wasti
5	Prayagdham Hospital
6	Prayagdham Ashram
7	Malran
8	Naygoan
9	Malwadi Naygaon
10	Yadav Wasti Chaufula
11	Chaufula
12	Railway gate no.1
13	Naygaon phata
14	Kunjirwadi
15	Tendulkar wasti
16	Kalbhor wasti solapur rd.
17	Theur phata
18	Tamnya wasti
19	Borkar wasti
20	Malyacha mala
21	Ramkrushna rasayan karkhana
22	Loni phata
23	Loni station
24	Kadam wasti
25	Fuel depot
26	Wakvasti
27	Kavadi rasta
28	Kavadi pat
29	Krushi mahavidyalaya
30	Phursungi gaon phata
31	Manjri farm
32	Rambag solapur rd
33	Laxmideep colony
34	15 number Manjari Gaon Phata
35	Akashwani hadapasar
36	Agrawal colony
37	Hadapsar gadital','37','05:30
07:50
10:40
13:30
15:50
18:40
08:40
11:05
14:50
17:15','06:40
09:00
11:50
14:40
17:00
19:50
09:55
12:10
16:05
18:20','Active');
INSERT INTO "busTable" VALUES(300,'90','Swargate','Gokhalenagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','7.3 KMs','42 Minutes','1	Swargate
2	Swargate
3	Sarasbag
4	Madiwale colony
5	S P college
6	Maharashtra mandal
7	Sahitya parishad peru gate
8	Goodluck Chowk
9	F C College
10	Dnyaneshwar paduka chauk
11	Lakaki Bungalow
12	Model colony
13	Deep Bungalow Chowk
14	Vetal Maharaj chauk
15	Kusalkar Putala
16	Gokhalenagar shala
17	Gokhalenagar
18	Police line Gokhalenagar','1	Police line Gokhalenagar
2	Gokhalenagar
3	Gokhalenagar shala
4	Kusalkar putala
5	Vetal Maharaj chauk
6	Deep Bungalow Chowk
7	Model colony
8	Lakaki Bungalow
9	Dnyaneshwar Paduka chowk
10	Police Line Modern College
11	Modern Highschool
12	Balgandharv sambhaji par
13	Deccan Gymkhana
14	Sahitya Parishad Peru Gate
15	Maharashtra mandal
16	S P college
17	Madiwale colony
18	Hirabag
19	Swargate corner
20	Swargate
21	Swargate','18','05:30
06:45
08:05
09:30
11:25
12:45
14:30
15:50
17:25
19:00
21:00
05:55
07:10
08:30
09:55
11:50
13:10
14:55
16:15
17:50
19:25
21:25
06:15
07:30
08:50
10:15
12:10
13:30
15:15
16:35
18:10
19:45
21:45','06:05
07:25
08:45
10:10
12:05
13:25
15:10
16:35
18:15
19:45
21:45
06:30
07:50
09:10
10:35
12:30
13:50
15:35
17:00
18:40
20:10
22:10
06:50
08:10
09:30
10:55
12:50
14:10
15:55
17:20
19:00
20:30
22:30','Active');
INSERT INTO "busTable" VALUES(301,'90P','Swargate','Pandavnagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','9 KMs','42 Minutes','1	Swargate
2	Swargate
3	Sarasbag
4	Madiwale colony
5	S P college
6	Maharashtra mandal
7	Sahitya parishad peru gate
8	Goodluck Chowk
9	F C College
10	Dnyaneshwar paduka chauk
11	Lakaki Bungalow
12	Model colony
13	Deep Bungalow Chowk
14	Vetal Maharaj chauk
15	Sheti mahamandal
16	Pandavnagar','1	Pandavnagar
2	Sheti mahamandal
3	Vetal Maharaj chauk
4	Deep Bungalow Chowk
5	Model colony
6	Lakaki Bungalow
7	Dnyaneshwar Paduka chowk
8	Police Line Modern College
9	Modern Highschool
10	Balgandharv sambhaji par
11	Deccan Gymkhana
12	Sahitya Parishad Peru Gate
13	Maharashtra mandal
14	S P college
15	Madiwale colony
16	Hirabag
17	Swargate corner
18	Swargate
19	Swargate','18','06:25
07:40
09:00
10:55
12:20
14:00
15:25
16:45
18:20
20:30','07:00
08:20
09:40
11:35
13:00
14:40
16:05
17:30
19:10
21:15','Active');
INSERT INTO "busTable" VALUES(302,'93','Deccan Gymkhana','Pimple Nilakh','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.6 KMs','50 Minutes','1	Deccan Gymkhana
2	Goodluck Chowk
3	F C College
4	Dnyaneshwar Paduka chowk
5	Police Line Modern College
6	Modern Highschool
7	PMC
8	Shivaji putala pmc
9	shimala office shivajinagar
10	Masoba gate
11	Pumping station
12	Pune central
13	E square
14	Rangehills Corner
15	Rajbhavan
16	Boys batalian
17	Kasturba vasahat
18	Sindh colony gate 2
19	Bremen chauk
20	Body gate
21	Aundh gaon
22	Sangvi phata
23	Aundh chest hospital
24	Aundh post office
25	ESI Hospital
26	Rakshak Soc.
27	Pimple Nilakh Shala
28	Pimple Nilakh','1	Pimple Nilakh
2	Pimple Nilakh Shala
3	Rakshak Soc. Ganpati mandir
4	Rakshak chauk
5	ESI Hospital
6	Aundh post office
7	Aundh chest hospital
8	Sangvi Phata
9	Aundh gaon
10	Body gate
11	Bremen chauk
12	Sindh Colony Gate2
13	Kasturba vasahat
14	Boys Batalian
15	Pune University Gate
16	Rangehills Corner
17	E Square
18	Pune central
19	Pumping station
20	Masoba gate
21	shimala office shivajinagar
22	Engineering college hostel
23	Shivaji putala
24	PMC
25	Balgandharv sambhaji par
26	Deccan Gymkhana','28','05:30
07:00
08:40
10:20
12:30
14:45
16:35
18:30
20:45
06:10
07:40
09:20
11:25
13:05
15:45
17:40
19:30
21:45','06:15
07:50
09:30
11:10
13:15
15:40
17:35
19:25
21:30
06:55
08:30
10:10
12:15
13:50
16:40
18:35
20:20
22:30','Active');
INSERT INTO "busTable" VALUES(303,'94','Kothrud depot','Pune Station','Mon, Tue, Wed, Thu, Fri, Sat, Sun','11.4 KMs','61 Minutes','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Shastrinagar
6	Vivekanand Society
7	Sutar Dawakhana
8	Vanaz corner
9	Jai bhavani
10	Anand nagar paud road
11	LIC Colony Paud Road
12	More vidyalaya
13	Paudphata police chowky
14	SNDT college
15	Nal stop
16	Petrol pump karve road
17	Garware college
18	Deccan corner sambhaji pul
19	A B Chowk
20	Dakshinabhimukh Maruti mandir
21	Shaniwar wada
22	Kasaba Police Chowky
23	Lalmahal
24	Phadake Houd
25	Apolo Talkies
26	Rastewada
27	15 August Lodge Somwar Peth
28	Ambedkar bhavan
29	Sasoon hospital
30	Pune station','1	Pune station
2	Sadhu wasvani chauk
3	GPO
4	Collector kacheri
5	Zila Parishad
6	KEM hospital
7	Apolo talkies
8	Phadake Houd
9	Lal mahala
10	Vasant talkies
11	A B Chauk Stand
12	Deccan Corner Sambhaji Pul Corner
13	Garware college
14	Petrol Pump Karve Road
15	Nal Stop
16	SNDT college
17	Paud phata police chauky
18	More vidyalaya
19	LIC colony
20	Anand nagar paud road
21	Jai bhavani
22	Pratik nagar
23	Vanaz Corner
24	Sutar Dawakhana
25	Vivekanand Society
26	Shastrinagar
27	Paramhans corner
28	Kachara depot
29	Bharti nagar
30	kothrud depot','30','05:50
07:40
09:50
12:35
14:30
16:30
18:40
21:20
06:10
08:00
10:10
12:55
14:50
16:50
19:00
21:40
06:30
08:20
10:30
13:15
15:10
17:10
19:20
06:50
08:40
10:50
13:35
15:30
17:30
19:40
22:10
07:05
09:00
11:15
13:55
15:50
17:55
20:00
07:20
09:30
12:05
14:15
16:10
18:20
20:25','06:40
08:45
10:55
13:35
15:30
17:35
19:45
22:20
07:00
09:05
11:15
13:55
15:50
17:55
20:00
22:40
07:20
09:25
11:35
14:15
16:10
18:15
20:20
07:40
09:45
11:55
14:35
16:30
18:35
20:40
23:10
08:00
10:05
12:15
14:55
16:50
18:55
21:00
08:25
10:35
13:05
15:10
17:15
19:20
21:25','Active');
INSERT INTO "busTable" VALUES(304,'94A','Kumbare Park','Wadgaon sheri','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21 KMs','90 Minutes','1	Kumbare Park
2	Guruganesh Nagar
3	Ashish Garden
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Kesari Wada
17	Ramanbag
18	A B Chowk
19	Dakshinabhimukh Maruti mandir
20	Shaniwar wada
21	Kasaba Police Chowky
22	Lalmahal
23	Phadake Houd
24	Rastewada
25	15 August Lodge Somwar Peth
26	Ambedkar bhavan
27	Sasoon hospital
28	Pune station
29	Ruby hall
30	Wadia college
31	Guruprasad bangala
32	Band garden
33	Yerwada
34	wadia bangala
35	Shastri nagar
36	Agakhan palace
37	Ramwadi Jakatnaka
38	Ramwadi
39	Weikfield
40	Matchwel company
41	Sainikwadi
42	Datta mandir Wadgaon sheri
43	Wadgao sheri','1	Wadgao sheri
2	Datta mandir wadgaon sheri
3	Sainikwadi
4	Matchwel company
5	Weikfield
6	Ramwadi
7	Ramwadi jakatnaka
8	Agakhan palace
9	Shastri nagar
10	Wadia bunglow
11	Yerwada
12	Band garden
13	Guruprasad bangala
14	Jahangir Hospital
15	Alankar Talkies
16	Sadhu wasvani chauk
17	GPO
18	Collector kacheri
19	Zila Parishad
20	Employment Office
21	KEM hospital
22	Apolo talkies
23	Phadake Houd
24	Lal mahala
25	A B Chauk Stand
26	Ramanbag
27	Kesari Wada
28	Deccan Corner Sambhaji Pul Corner
29	Garware college
30	Petrol Pump Karve Road
31	Nal Stop
32	SNDT college
33	Paud phata police chauky
34	More vidyalaya
35	LIC colony
36	Anand nagar paud road
37	Jai bhavani
38	Pratik nagar
39	Vanaz Corner
40	Paramhans corner
41	Ashish Garden
42	Guruganesh nagar
43	Kumbare Park','43','07:25
10:20
15:40
07:50
11:00
16:20
08:30
11:30
17:00
09:10
11:55
17:40','08:50
11:50
17:20
09:25
12:25
17:55
10:00
13:00
18:30
10:30
13:35
19:05','Active');
INSERT INTO "busTable" VALUES(305,'95','Kothrud depot','Pimple Gurav','Mon, Tue, Wed, Thu, Fri, Sat, Sun','21.1 KMs','77 Minutes','1	Kothrud depot
2	Bharti nagar
3	kachra depot
4	Paramhansa Corner
5	Vanaz corner
6	Jai bhavani
7	Anand nagar paud road
8	LIC Colony Paud Road
9	More vidyalaya
10	Paudphata police chowky
11	SNDT college
12	Nal stop
13	Petrol pump karve road
14	Garware college
15	Deccan corner sambhaji pul
16	Goodluck Chowk
17	F C College
18	Dnyaneshwar paduka chauk
19	Masoba gate
20	Pumping station
21	Pune central
22	E square
23	Rangehills Corner
24	Rajbhavan
25	Boys batalian
26	Kasturba vasahat
27	Sindh colony gate 2
28	Bremen chauk
29	Body gate
30	Aundh gaon
31	Sangvi phata
32	Sangvi Phata
33	Nurses Quarters
34	Ba ra gholap
35	Navi Sangvi
36	Panyachi taki sangvi
37	shitole nagar corner
38	Anand nagar
39	Sangvi goan
40	Vasantdada Putala
41	PWD gate
42	ST workshop
43	Mantri niketan Dapodi
44	Dapodi Gaon
45	Shitaladevi Mandir
46	Raviraj Hotel
47	Ramkrushna Mangal Karyalaya
48	Pooja hospital
49	Suvarna park
50	Panyachi Taki Pimple Gurav
51	Pimple gurav','1	Pimple gurav
2	Panyachi Taki Pimple Gurav
3	Suvarna Park
4	Pooja Hospital
5	Ramkrishna mangal karyalay
6	Raviraaj hotel
7	Shitaladevi Mandir
8	Dapodi Gaon
9	Mantri Niketan Dapodi
10	S T Workshop
11	P W D Gate
12	Vasantdada Putala
13	Anand nagar
14	shitole nagar corner
15	panyachi takai sangvi
16	Navi Sangvi
17	Bara gholap
18	Nurses Quarters
19	Sangvi Phata
20	Aundh gaon
21	Body gate
22	Bremen chauk
23	Sindh Colony Gate2
24	Kasturba vasahat
25	Boys Batalian
26	Pune University Gate
27	Rangehills Corner
28	E Square
29	Pune central
30	Pumping station
31	Masoba gate
32	shimala office shivajinagar
33	Engineering college hostel
34	Modern Highschool
35	Balgandharv sambhaji par
36	Deccan Gymkhana
37	Deccan corner sambhaji pool
38	Garware college
39	Petrol Pump Karve Road
40	Nal Stop
41	SNDT college
42	Paud phata police chauky
43	More vidyalaya
44	LIC colony
45	Anand nagar paud road
46	Jai bhavani
47	Pratik nagar
48	Vanaz Corner
49	Paramhans corner
50	Kachara depot
51	Bharti nagar
52	kothrud depot','51','05:35
07:50
11:05
15:05
17:45
20:55','06:40
09:05
12:30
16:25
19:05
22:10','Active');
INSERT INTO "busTable" VALUES(306,'96','Warje Malwadi','Pimple Gurav','Mon, Tue, Wed, Thu, Fri, Sat, Sun','20 KMs','81 Minutes','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Wadache jhad
8	Dahanukar colony
9	Kothrud Stand
10	Karve putala
11	Maruti Mandir Karve Road
12	Paud phata dashbhuja mandir
13	SNDT college
14	Nal stop
15	Petrol pump karve road
16	Garware college
17	Deccan corner sambhaji pul
18	Goodluck Chowk
19	F C College
20	Dnyaneshwar Paduka chowk
21	Police Line Modern College
22	Modern Highschool
23	PMC
24	Shivaji putala pmc
25	shimala office shivajinagar
26	Lokmangal
27	Patil Estate
28	Labour office
29	Bajaj showroom wakadewadi
30	Mariaai Gate Old Mumbai Pune Road
31	Poultry Farm Old Mumbai Pune Road
32	Krutrim reshim paidas kendra
33	Raja bangalow
34	Khadaki post office
35	Khadaki police station
36	Factory Hospital
37	Suply depot
38	Khadaki bajar
39	Alegaonkar High school
40	Kirloskar Oil Engine Manaji Bag
41	Gangaram park
42	Bopodi
43	Buddha Vihar
44	Shivaji putala dapodi
45	Mantri niketan Dapodi
46	Dapodi Gaon
47	Shitaladevi Mandir
48	Raviraj Hotel
49	Ramkrushna Mangal Karyalaya
50	Pooja hospital
51	Suvarna park
52	Pimple gurav','1	Pimple gurav
2	Suvarna Park
3	Pooja Hospital
4	Ramkrishna mangal karyalay
5	Raviraaj hotel
6	Shitaladevi Mandir
7	Dapodi Gaon
8	Mantri Niketan Dapodi
9	Shivaji Putala Dapodi
10	Buddha Vihar
11	Bopodi Jakat Naka
12	Bopodi
13	Gangaram park
14	Kirloskar oil engine manaji bag
15	Alegaonkar High school
16	Khadki Bazar
17	Supply Depot
18	Factory Hospital
19	Khadki Police Station
20	Petrol Pump Khadki
21	Khadaki church stop
22	Khadaki post office
23	Raja Bungalow
24	Krutrim Reshim Paidas Kendra
25	Poultry Farm Old Mumbai Pune Road
26	Mariaai Gate Old Mumbai Pune Road
27	Bajaj showroom
28	Labor office
29	Patil Estate
30	Engineering college hostel
31	Shivaji putala
32	PMC
33	Balgandharv sambhaji par
34	Deccan Gymkhana
35	Deccan Corner Sambhaji Pul Corner
36	Garware college
37	Petrol Pump Karve Road
38	Nal Stop
39	SNDT college
40	Paud Phata Dashabhuja Ganpati
41	Maruti mandir karve road
42	Karve putala
43	Kothrud Stand
44	Dahanukar colony
45	Wadache Jhad Bhairavnath Mandir
46	Karvenagar
47	Warje Jakatnaka
48	Tapodham
49	Warje Malwadi
50	Dnanesh society
51	Ganpati matha','52','06:00
08:40
12:00
14:40
17:30
20:50
07:15
10:00
13:15
15:55
18:40
21:50','07:20
10:00
13:20
16:00
19:00
22:05
08:40
11:20
14:35
17:15
20:00
23:10','Active');
INSERT INTO "busTable" VALUES(307,'97','Warje Malwadi','Sahkarnagar','Mon, Tue, Wed, Thu, Fri, Sat, Sun','12.5 KMs','75 Minutes','1	Ganpati matha
2	Dnanesh society
3	Warje malwadi
4	Tapodham
5	Warje jakatnaka
6	Karvenagar
7	Shriman Society
8	Vitthal Mandir Karvenagar
9	Madhusanchay Society
10	Nav Sahyadri Sabhagruha
11	Alankar Police Chowki
12	Karnataka High school
13	Bhim Jyoti Soc.
14	Date Engineering
15	Mehandale Guarage
16	Nal stop
17	Petrol pump karve road
18	Garware college
19	Deccan corner sambhaji pul
20	Alka talkies
21	Chitrashala
22	Sadashiv Peth Houd
23	Vishrambag wada
24	Mandai
25	Gadikhana
26	Shahu chauk
27	Mamledar kacheri
28	Gokul bhavan
29	Swargate
30	Parvati payatha
31	Mitramandal Sabhagruh
32	Bank of Maharashtra Parvati gaon
33	Lakshminagar Corner
34	Sarang Society
35	Kranti Society
36	Sahakar Nagar','1	Sahakar Nagar
2	Kranti Society
3	Sarang Society
4	Lakshminagar Corner
5	Bank of Maharashtra Parvati gaon
6	Mitramandal Sabhagruh
7	Parvati payatha
8	Mahila mandal
9	Bhikardas maruti madnir
10	Shanipar
11	Kunte Chauk
12	Gokhale hall
13	Vijay Talkies
14	Alka talkies
15	Deccan Corner Sambhaji Pul Corner
16	Garware college
17	Petrol Pump Karve Road
18	Nal Stop
19	Mehendale garage
20	Date Engineering
21	Bhim Jyoti Soc.
22	Karnataka High school
23	Alankar Police Chowki
24	Nav Sahyadri Sabhagruha
25	Madhusanchay Society
26	Vitthal Mandir Karvenagar
27	Shriman Society
28	Karvenagar
29	Warje Jakatnaka
30	Tapodham
31	Warje Malwadi
32	Dnanesh society
33	Ganpati matha','36','08:40
11:30
15:20
17:40','09:50
12:45
16:35
19:00','Active');
INSERT INTO "busTable" VALUES(308,'9S','Galinde path','Swargate','Mon, Tue, Wed, Thu, Fri, Sat, Sun','10 KMs','52 Minutes','1	Warje jakatnaka
2	Karvenagar
3	Dahanukar colony
4	Kothrud Stand
5	Karve putala
6	Maruti Mandir Karve Road
7	Paud phata dashbhuja mandir
8	SNDT college
9	Nal stop
10	Petrol pump karve road
11	Garware college
12	Deccan corner sambhaji pul
13	Alka talkies
14	Chitrashala
15	Sadashiv Peth Houd
16	Vishrambag wada
17	Mandai
18	Gadikhana
19	Shahu chauk
20	Mamledar kacheri
21	Gokul bhavan
22	Swargate','1	Swargate
2	Sarasbag
3	Bhikardas maruti madnir
4	Shanipar
5	Kunte Chauk
6	Gokhale hall
7	Vijay Talkies
8	Alka talkies
9	Deccan Corner Sambhaji Pul Corner
10	Garware college
11	Petrol Pump Karve Road
12	Nal Stop
13	SNDT college
14	Paud Phata Dashabhuja Ganpati
15	Maruti mandir karve road
16	Karve putala
17	Kothrud Stand
18	Dahanukar colony
19	Wadache Jhad Bhairavnath Mandir
20	Karvenagar
21	Warje Jakatnaka','22','11:10
12:50
15:05
08:30
10:10
11:55
14:15
16:05
17:55','11:55
13:40
16:00
09:20
11:00
12:50
15:10
17:00
18:50','Active');
